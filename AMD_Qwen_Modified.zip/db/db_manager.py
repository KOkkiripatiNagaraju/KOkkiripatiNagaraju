"""
db_manager.py
Lightweight JSON-file-backed "DigiLocker-style" mock database manager.

Provides:
 - CRUD operations on user records (used by admin.py)
 - Lookup/verification helpers used by the KYC pipeline to check whether
   customer-submitted document data (Aadhaar/PAN/Passport/DL number, name,
   DOB, address, etc.) matches a genuine record in the official database
   (i.e. is the user "real" or "fake").

Thread-safety: simple file-lock-free read/write with full-file rewrite on
each mutation. Adequate for a hackathon/demo; replace with a real DB
(Postgres/Mongo) for production.
"""

import json
import os
import threading
from typing import Any, Dict, List, Optional, Tuple

DB_DIR = os.path.dirname(os.path.abspath(__file__))
DB_FILE = os.path.join(DB_DIR, "users_db.json")

_lock = threading.Lock()

# ID fields that can be used to look up a record, mapped to the JSON key
ID_FIELD_MAP = {
    "aadhaar": "aadhaar",
    "pan": "pan",
    "passport": "passport",
    "driving_licence": "driving_licence",
    "dl": "driving_licence",
}


# --------------------------------------------------------------------------
# Low-level load / save
# --------------------------------------------------------------------------
def _ensure_db_exists():
    if not os.path.exists(DB_FILE):
        with open(DB_FILE, "w", encoding="utf-8") as f:
            json.dump({}, f, indent=2)


def load_db() -> Dict[str, Any]:
    """Load the entire database as a dict keyed by record ID (string)."""
    _ensure_db_exists()
    with _lock:
        with open(DB_FILE, "r", encoding="utf-8") as f:
            try:
                return json.load(f)
            except json.JSONDecodeError:
                return {}


def save_db(db: Dict[str, Any]) -> None:
    """Persist the entire database dict back to disk."""
    with _lock:
        with open(DB_FILE, "w", encoding="utf-8") as f:
            json.dump(db, f, indent=2, ensure_ascii=False)


# --------------------------------------------------------------------------
# CRUD operations (used by admin.py)
# --------------------------------------------------------------------------
def list_users(db: Optional[Dict[str, Any]] = None) -> List[Tuple[str, Dict[str, Any]]]:
    """Return list of (record_id, record) sorted by integer-aware record id."""
    db = db if db is not None else load_db()

    def _key(item):
        rid = item[0]
        try:
            return (0, int(rid))
        except ValueError:
            return (1, rid)

    return sorted(db.items(), key=_key)


def get_user(record_id: str, db: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
    db = db if db is not None else load_db()
    return db.get(str(record_id))


def add_user(record: Dict[str, Any], record_id: Optional[str] = None) -> str:
    """Add a new record. If record_id is omitted, auto-assigns the next integer ID."""
    db = load_db()
    if record_id is None:
        existing_ids = []
        for rid in db.keys():
            try:
                existing_ids.append(int(rid))
            except ValueError:
                pass
        record_id = str((max(existing_ids) + 1) if existing_ids else 1)

    record_id = str(record_id)
    if record_id in db:
        raise ValueError(f"Record ID '{record_id}' already exists.")

    record = _normalize_record(record)
    db[record_id] = record
    save_db(db)
    return record_id


def update_user(record_id: str, updates: Dict[str, Any]) -> Dict[str, Any]:
    """Merge `updates` into the existing record (shallow merge for top-level,
    deep merge for nested 'address'/'business'/'income' dicts)."""
    db = load_db()
    record_id = str(record_id)
    if record_id not in db:
        raise KeyError(f"Record ID '{record_id}' not found.")

    record = db[record_id]
    for key, value in updates.items():
        if isinstance(value, dict) and isinstance(record.get(key), dict):
            record[key].update(value)
        else:
            record[key] = value

    record = _normalize_record(record)
    db[record_id] = record
    save_db(db)
    return record


def delete_user(record_id: str) -> None:
    db = load_db()
    record_id = str(record_id)
    if record_id not in db:
        raise KeyError(f"Record ID '{record_id}' not found.")
    del db[record_id]
    save_db(db)


def replace_user(record_id: str, record: Dict[str, Any]) -> Dict[str, Any]:
    """Fully overwrite a record with new data."""
    db = load_db()
    record_id = str(record_id)
    record = _normalize_record(record)
    db[record_id] = record
    save_db(db)
    return record


def _normalize_record(record: Dict[str, Any]) -> Dict[str, Any]:
    """Ensure required nested structures exist with sane defaults."""
    record.setdefault("address", {})
    for k in ("line1", "city", "state", "pin", "country"):
        record["address"].setdefault(k, None)

    record.setdefault("business", {})
    for k in ("cin", "gst", "tan", "name", "type"):
        record["business"].setdefault(k, None)

    record.setdefault("income", {})
    for k in ("annual_declared", "employer", "employment_type"):
        record["income"].setdefault(k, None)

    for k in ("is_pep", "is_sanctioned", "risk_flag"):
        record.setdefault(k, False)

    for k in ("aadhaar", "pan", "passport", "driving_licence", "name", "dob",
              "gender", "nationality", "phone", "email"):
        record.setdefault(k, None)

    return record


# --------------------------------------------------------------------------
# Verification helpers (used by the KYC pipeline)
# --------------------------------------------------------------------------
def find_record_by_id_number(id_type: str, id_number: str, db: Optional[Dict[str, Any]] = None) -> Optional[Tuple[str, Dict[str, Any]]]:
    """
    Find a database record whose ID field of the given type matches id_number.

    id_type: one of 'aadhaar', 'pan', 'passport', 'driving_licence' (or 'dl')
    Returns (record_id, record) or None if not found.
    """
    if not id_number:
        return None

    field = ID_FIELD_MAP.get(id_type.lower())
    if not field:
        return None

    db = db if db is not None else load_db()
    id_number_norm = str(id_number).strip().upper()

    for rid, record in db.items():
        value = record.get(field)
        if value and str(value).strip().upper() == id_number_norm:
            return rid, record

    return None


def find_record_by_name(name: str, db: Optional[Dict[str, Any]] = None) -> List[Tuple[str, Dict[str, Any]]]:
    """Find database records with a fuzzy/normalized name match (case-insensitive substring)."""
    if not name:
        return []
    db = db if db is not None else load_db()
    name_norm = name.strip().lower()
    matches = []
    for rid, record in db.items():
        rec_name = (record.get("name") or "").strip().lower()
        if not rec_name:
            continue
        if rec_name == name_norm or name_norm in rec_name or rec_name in name_norm:
            matches.append((rid, record))
    return matches


def verify_against_registry(extracted_fields: Dict[str, Any], db: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """
    Cross-check a customer's extracted document fields against the mock
    DigiLocker-style registry to determine whether the user / documents
    appear genuine.

    extracted_fields: dict possibly containing keys like
        full_name, date_of_birth, id_number, nationality, address,
        and an optional 'id_type' hint (aadhaar/pan/passport/driving_licence)

    Returns a dict:
        {
          "matched": bool,
          "matched_record_id": str | None,
          "match_method": "id_number" | "name" | "none",
          "field_matches": {field: bool, ...},
          "registry_record": dict | None,
          "is_pep": bool,
          "is_sanctioned": bool,
          "risk_flag": bool,
          "discrepancies": [str, ...],
          "verdict": "genuine" | "mismatch" | "not_found",
        }
    """
    db = db if db is not None else load_db()

    id_number = extracted_fields.get("id_number")
    full_name = extracted_fields.get("full_name")
    dob = extracted_fields.get("date_of_birth")

    record_match = None
    match_method = "none"

    # 1) Try matching by ID number across all known ID types
    if id_number:
        for id_type in ("aadhaar", "pan", "passport", "driving_licence"):
            found = find_record_by_id_number(id_type, id_number, db)
            if found:
                record_match = found
                match_method = "id_number"
                break

    # 2) Fall back to name match
    if record_match is None and full_name:
        name_matches = find_record_by_name(full_name, db)
        if len(name_matches) == 1:
            record_match = name_matches[0]
            match_method = "name"
        elif len(name_matches) > 1:
            # ambiguous - pick first but note it
            record_match = name_matches[0]
            match_method = "name_ambiguous"

    if record_match is None:
        return {
            "matched": False,
            "matched_record_id": None,
            "match_method": "none",
            "field_matches": {},
            "registry_record": None,
            "is_pep": False,
            "is_sanctioned": False,
            "risk_flag": False,
            "discrepancies": ["No matching record found in identity registry."],
            "verdict": "not_found",
        }

    record_id, record = record_match
    discrepancies: List[str] = []
    field_matches: Dict[str, bool] = {}

    # Name comparison (token overlap, tolerant of suffixes/prefixes)
    if full_name:
        reg_name = (record.get("name") or "").strip().lower()
        extr_name = full_name.strip().lower()
        reg_tokens = set(reg_name.split())
        extr_tokens = set(extr_name.split())
        overlap = len(reg_tokens & extr_tokens) / max(len(reg_tokens | extr_tokens), 1)
        name_match = overlap >= 0.5
        field_matches["name"] = name_match
        if not name_match:
            discrepancies.append(f"Name mismatch: document='{full_name}' vs registry='{record.get('name')}'.")

    # DOB comparison
    if dob:
        reg_dob = record.get("dob")
        dob_match = (reg_dob == dob)
        field_matches["date_of_birth"] = dob_match
        if not dob_match:
            discrepancies.append(f"Date of birth mismatch: document='{dob}' vs registry='{reg_dob}'.")

    # Nationality comparison
    nationality = extracted_fields.get("nationality")
    if nationality:
        reg_nat = (record.get("nationality") or "").strip().lower()
        nat_match = reg_nat == nationality.strip().lower()
        field_matches["nationality"] = nat_match
        if not nat_match:
            discrepancies.append(f"Nationality mismatch: document='{nationality}' vs registry='{record.get('nationality')}'.")

    if match_method == "name_ambiguous":
        discrepancies.append("Multiple registry records share a similar name; ID-number match recommended for certainty.")

    verdict = "genuine" if not discrepancies else "mismatch"

    return {
        "matched": True,
        "matched_record_id": record_id,
        "match_method": match_method,
        "field_matches": field_matches,
        "registry_record": record,
        "is_pep": bool(record.get("is_pep", False)),
        "is_sanctioned": bool(record.get("is_sanctioned", False)),
        "risk_flag": bool(record.get("risk_flag", False)),
        "discrepancies": discrepancies,
        "verdict": verdict,
    }
