"""
generate_dummy_db.py
One-off generator script for db/users_db.json — a mock "DigiLocker-style"
government identity database used to verify whether customer-submitted
document data is genuine (matches official records) or fake/mismatched.

Run:  python db/generate_dummy_db.py
"""

import json
import os
import random
import string

random.seed(42)

FIRST_NAMES = [
    "Priya", "Rahul", "Anjali", "Vikram", "Sneha", "Arjun", "Kavya", "Rohan",
    "Divya", "Karthik", "Pooja", "Amit", "Neha", "Suresh", "Meera", "Aditya",
    "Lakshmi", "Sanjay", "Ritu", "Manoj",
]
LAST_NAMES = [
    "Sharma", "Verma", "Iyer", "Reddy", "Nair", "Gupta", "Singh", "Patel",
    "Menon", "Das", "Banerjee", "Rao", "Mehta", "Joshi", "Kapoor", "Pillai",
]
CITIES_STATES = [
    ("Mumbai", "Maharashtra"), ("Delhi", "Delhi"), ("Bengaluru", "Karnataka"),
    ("Chennai", "Tamil Nadu"), ("Kochi", "Kerala"), ("Hyderabad", "Telangana"),
    ("Pune", "Maharashtra"), ("Kolkata", "West Bengal"), ("Jaipur", "Rajasthan"),
    ("Ahmedabad", "Gujarat"), ("Lucknow", "Uttar Pradesh"), ("Chandigarh", "Punjab"),
]
STREET_NAMES = ["Park Street", "MG Road", "Church Street", "Station Road", "Gandhi Nagar", "Lake View Lane", "Hill Road", "Civil Lines"]
EMPLOYERS = ["HCL", "TCS", "Infosys", "Wipro", "Self Employed", "Reliance Industries", "ICICI Bank", "Tata Motors", "Govt of India", "Startup Pvt Ltd"]
EMPLOYMENT_TYPES = ["Salaried", "Business", "Self-Employed", "Unemployed", "Retired"]
GENDERS = ["Male", "Female", "Other"]
BUSINESS_TYPES = ["Pvt Ltd", "LLP", "Proprietorship", "Partnership", None]


def rand_alnum(n):
    return "".join(random.choices(string.ascii_uppercase + string.digits, k=n))


def rand_digits(n):
    return "".join(random.choices(string.digits, k=n))


def make_record(idx: int, force_pep=False, force_sanctioned=False, force_risk=False):
    first = random.choice(FIRST_NAMES)
    last = random.choice(LAST_NAMES)
    name = f"{first} {last}"
    city, state = random.choice(CITIES_STATES)

    dob_year = random.randint(1955, 2005)
    dob_month = random.randint(1, 12)
    dob_day = random.randint(1, 28)
    dob = f"{dob_year:04d}-{dob_month:02d}-{dob_day:02d}"

    has_business = random.random() < 0.4
    business_type = random.choice(BUSINESS_TYPES) if has_business else None

    record = {
        "aadhaar": f"AADHAAR-{rand_alnum(10)}",
        "pan": f"PAN-{rand_alnum(10)}",
        "passport": f"PASS-{rand_alnum(8)}",
        "driving_licence": f"DL-{rand_alnum(8)}",
        "name": name,
        "dob": dob,
        "gender": random.choice(GENDERS),
        "address": {
            "line1": f"{random.randint(1, 999)} {random.choice(STREET_NAMES)}",
            "city": city,
            "state": state,
            "pin": rand_digits(6),
            "country": "India",
        },
        "nationality": "Indian",
        "phone": f"+91{rand_digits(10)}",
        "email": f"{first.lower()}_{last.lower()}{idx}@email.com",
        "business": {
            "cin": f"CIN-{rand_alnum(15)}" if business_type == "Pvt Ltd" else None,
            "gst": f"GST-{rand_alnum(13)}" if has_business else None,
            "tan": f"TAN-{rand_alnum(8)}" if has_business else None,
            "name": f"{last} {random.choice(['Enterprises', 'Traders', 'Solutions', 'Industries', 'Exports'])}" if has_business else None,
            "type": business_type,
        },
        "income": {
            "annual_declared": random.choice([300000, 500000, 800000, 1200000, 2500000, 5000000, 8000000, 15000000]),
            "employer": random.choice(EMPLOYERS),
            "employment_type": random.choice(EMPLOYMENT_TYPES),
        },
        "is_pep": force_pep,
        "is_sanctioned": force_sanctioned,
        "risk_flag": force_risk,
    }
    return record


def main():
    db = {}

    # 1) Standard "clean" records
    for i in range(1, 31):
        db[str(i)] = make_record(i)

    # 2) A few flagged records for testing screening logic
    db["31"] = make_record(31, force_pep=True)
    db["31"]["name"] = "Jane Smith"  # matches MOCK_WATCHLIST PEP entry

    db["32"] = make_record(32, force_sanctioned=True)
    db["32"]["name"] = "John Doe"  # matches MOCK_WATCHLIST sanctions entry

    db["33"] = make_record(33, force_risk=True)
    db["33"]["name"] = "Carlos Mendez"  # matches MOCK_WATCHLIST adverse media entry

    db["34"] = make_record(34, force_sanctioned=True)
    db["34"]["name"] = "Vladimir Petrov"
    db["34"]["nationality"] = "Russian"
    db["34"]["address"]["country"] = "Russia"

    # 3) A minor (for age plausibility testing)
    db["35"] = make_record(35)
    db["35"]["name"] = "Aditya Kapoor"
    db["35"]["dob"] = "2015-04-12"

    # 4) An expired-looking / incomplete record
    db["36"] = make_record(36)
    db["36"]["name"] = "Suresh Singh"
    db["36"]["passport"] = None
    db["36"]["driving_licence"] = None

    # Sample provided in the prompt (kept for compatibility)
    db["1"] = {
        "aadhaar": "AADHAAR-UP75NWH376Q1",
        "pan": "PAN-GSDQW8FIIT",
        "passport": "PASS-TE1DVFMH",
        "driving_licence": "DL-JHFN07RVS3",
        "name": "Priya Sharma 1",
        "dob": "1965-10-30",
        "gender": "Other",
        "address": {
            "line1": "686 Park Street",
            "city": "Kochi",
            "state": "Telangana",
            "pin": "245985",
            "country": "India",
        },
        "nationality": "Indian",
        "phone": "+919336942245",
        "email": "priya_sharma1@email.com",
        "business": {
            "cin": None,
            "gst": "GST-JLLQXBP6FBD5F1N",
            "tan": "TAN-A4TG0JWF",
            "name": None,
            "type": "LLP",
        },
        "income": {
            "annual_declared": 5000000,
            "employer": "HCL",
            "employment_type": "Business",
        },
        "is_pep": False,
        "is_sanctioned": False,
        "risk_flag": False,
    }

    out_path = os.path.join(os.path.dirname(__file__), "users_db.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(db, f, indent=2)

    print(f"Generated {len(db)} records -> {out_path}")


if __name__ == "__main__":
    main()
