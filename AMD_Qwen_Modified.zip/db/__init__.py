"""
db package
Mock "DigiLocker-style" identity registry used by the KYC platform to
verify whether customer-submitted documents match genuine official records.
"""

from .db_manager import (
    load_db,
    save_db,
    list_users,
    get_user,
    add_user,
    update_user,
    delete_user,
    replace_user,
    find_record_by_id_number,
    find_record_by_name,
    verify_against_registry,
)

__all__ = [
    "load_db",
    "save_db",
    "list_users",
    "get_user",
    "add_user",
    "update_user",
    "delete_user",
    "replace_user",
    "find_record_by_id_number",
    "find_record_by_name",
    "verify_against_registry",
]
