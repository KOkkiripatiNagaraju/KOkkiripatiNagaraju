"""
identity_verification_agent.py
Agent 3: Identity Verification.

Responsibilities:
 - AUTO-EXTRACT the portrait photo from the uploaded identity document
   (no separate "Photo on ID" upload required from the user)
 - Verify the extracted ID portrait matches the live captured photo
 - Validate ID document fields for plausibility (expiry date, ID number format)
 - Use LLM to assess document authenticity signals from OCR text
   (e.g. tampering hints, inconsistent formatting)

Change log:
 - Replaced manual `photo_id` document lookup with `extract_face_from_id()`
   called on the `identity_proof` bytes.
 - Added PDF-aware extraction path via `pdf_page_to_bgr()`.
 - compare_faces() now receives a numpy BGR array (extracted crop) for the
   ID side instead of raw bytes, avoiding a redundant encode/decode cycle.
 - Added `face_extraction_status` field to findings for audit transparency.
 - Extraction failure is surfaced as a distinct issue with its own risk penalty
   (separate from a failed face *match*).
"""

from datetime import datetime
from typing import Any, Dict, List, Optional

from .base_agent import BaseAgent, AgentResult
from .doc_utils import compare_faces, extract_face_from_id, pdf_page_to_bgr

AUTHENTICITY_PROMPT = """You are an identity-document authenticity reviewer.
Given the OCR raw text of an identity document, assess whether there are any
signs of tampering, inconsistency, or suspicious formatting (e.g. mismatched
fonts described in OCR artifacts, inconsistent date formats, missing standard
fields for the document type).

Document type: {doc_type}
OCR text:
---
{raw_text}
---

Respond with ONLY a JSON object with fields:
- authenticity_concern (boolean)
- concern_details (string, empty if none)
- confidence (float 0-1, your confidence in this assessment)

No commentary, no markdown fences.
"""


def _extract_id_portrait(identity_doc: Dict[str, Any]):
    """
    Best-effort extraction of the portrait face from an identity document.

    Tries image bytes first; if the document is a PDF, rasterises page 0
    with PyMuPDF and retries.

    Returns
    -------
    (face_crop, extraction_status, extraction_note)
      face_crop         : numpy BGR ndarray or None
      extraction_status : "success" | "failed_image" | "failed_pdf" | "no_bytes"
      extraction_note   : human-readable string for the audit trail
    """
    raw_bytes: Optional[bytes] = identity_doc.get("bytes")
    filename: str = identity_doc.get("filename", "").lower()

    if not raw_bytes:
        return None, "no_bytes", "Identity document bytes not available for face extraction."

    # ── Try direct image extraction first ─────────────────────────────────
    face_crop = extract_face_from_id(raw_bytes)
    if face_crop is not None:
        return face_crop, "success", "Portrait successfully extracted from identity document image."

    # ── If PDF, rasterise page 0 and retry ────────────────────────────────
    if filename.endswith(".pdf") or identity_doc.get("mimetype", "") == "application/pdf":
        page_img = pdf_page_to_bgr(raw_bytes, page_index=0)
        if page_img is not None:
            face_crop = extract_face_from_id(page_img)
            if face_crop is not None:
                return (
                    face_crop,
                    "success",
                    "Portrait successfully extracted from identity document (PDF page 0).",
                )
        return (
            None,
            "failed_pdf",
            "Could not extract a portrait from the PDF identity document. "
            "The scan may be too low-resolution or the portrait region was not detectable.",
        )

    return (
        None,
        "failed_image",
        "Could not detect a face in the identity document image. "
        "The document may be blurry, poorly lit, or the portrait region is not visible.",
    )


class IdentityVerificationAgent(BaseAgent):
    name = "IdentityVerificationAgent"

    def run(
        self,
        customer_id: str,
        extraction_findings: Dict[str, Any],
        documents: Dict[str, Dict[str, Any]],
    ) -> AgentResult:
        extracted_data = extraction_findings.get("extracted_data", {})
        identity_fields = (
            extracted_data.get("identity_proof", {}).get("fields", {}) or {}
        )

        evidence: List[str] = []
        issues: List[str] = []
        risk_score = 0.0

        # ----------------------------------------------------------------
        # 1. Auto-extract portrait from identity document + face match
        # ----------------------------------------------------------------
        face_score: Optional[float] = None
        face_extraction_status = "not_attempted"

        identity_doc = documents.get("identity_proof")
        live_photo_doc = documents.get("live_photo")

        if not identity_doc:
            issues.append("Identity document not provided; face extraction and match skipped.")
            face_extraction_status = "no_document"
            risk_score += 30

        elif not live_photo_doc or not live_photo_doc.get("bytes"):
            issues.append("Live photo not provided; face match skipped.")
            face_extraction_status = "no_live_photo"
            risk_score += 30

        else:
            # ── Extract portrait from ID doc ──────────────────────────
            face_crop, face_extraction_status, extraction_note = _extract_id_portrait(
                identity_doc
            )
            evidence.append(extraction_note)

            if face_crop is None:
                # Extraction failed — moderate risk; cannot verify identity visually
                issues.append(
                    f"Portrait could not be extracted from identity document "
                    f"({face_extraction_status}). Manual review required."
                )
                risk_score += 30

            else:
                # ── Compare extracted portrait vs live photo ───────────
                face_score, match_msg = compare_faces(
                    face_crop,                      # numpy BGR array (no re-decode)
                    live_photo_doc["bytes"],
                )
                evidence.append(match_msg)

                if face_score is None:
                    issues.append(
                        "Face match could not be computed — face not detectable "
                        "in the extracted portrait or live photo."
                    )
                    risk_score += 25
                else:
                    from config import FACE_MATCH_THRESHOLD

                    evidence.append(
                        f"Face similarity score: {face_score:.2f} "
                        f"(threshold: {FACE_MATCH_THRESHOLD})."
                    )
                    if face_score < FACE_MATCH_THRESHOLD:
                        issues.append(
                            f"Live photo does not sufficiently match the portrait "
                            f"extracted from the ID document "
                            f"(similarity {face_score:.2f} < threshold {FACE_MATCH_THRESHOLD})."
                        )
                        risk_score += 45
                    else:
                        evidence.append(
                            "Live photo matches the portrait extracted from the "
                            "identity document."
                        )

        # ----------------------------------------------------------------
        # 2. Document expiry validation
        # ----------------------------------------------------------------
        expiry_str = identity_fields.get("document_expiry")
        if expiry_str:
            try:
                expiry_date = datetime.strptime(expiry_str, "%Y-%m-%d")
                if expiry_date < datetime.now():
                    issues.append(f"Identity document expired on {expiry_str}.")
                    risk_score += 35
                else:
                    evidence.append(f"Identity document valid until {expiry_str}.")
            except Exception:
                issues.append(
                    f"Could not parse document expiry date: '{expiry_str}'."
                )
                risk_score += 5
        else:
            issues.append("Document expiry date not found / not extracted.")
            risk_score += 8

        # ----------------------------------------------------------------
        # 3. ID number plausibility
        # ----------------------------------------------------------------
        id_number = identity_fields.get("id_number")
        if not id_number:
            issues.append("ID number not found in extracted identity document.")
            risk_score += 10
        else:
            evidence.append(f"ID number extracted: {id_number}.")

        # ----------------------------------------------------------------
        # 4. LLM-based authenticity check on OCR text
        # ----------------------------------------------------------------
        raw_text = extracted_data.get("identity_proof", {}).get("raw_text", "")
        doc_subtype = extracted_data.get("identity_proof", {}).get(
            "doc_subtype", "Identity Document"
        )
        if raw_text:
            try:
                prompt = AUTHENTICITY_PROMPT.format(
                    doc_type=doc_subtype,
                    raw_text=raw_text[:4000],
                )
                response = self.call_llm(prompt, expect_json=True)
                auth_result = self.safe_json_loads(response, default={})
            except Exception as e:
                auth_result = {}
                evidence.append(f"Authenticity LLM check failed: {e}")

            if auth_result.get("authenticity_concern"):
                detail = auth_result.get("concern_details", "Unspecified concern.")
                issues.append(f"Document authenticity concern: {detail}")
                risk_score += 25
            else:
                evidence.append(
                    "No authenticity concerns flagged by LLM review of OCR text."
                )

        # ----------------------------------------------------------------
        # Finalise
        # ----------------------------------------------------------------
        risk_score = min(100.0, risk_score)

        if face_score is not None and face_score < 0.4:
            status = "error"
        elif face_extraction_status not in ("success", "not_attempted"):
            status = "warning" if risk_score < 60 else "error"
        elif issues:
            status = "warning" if risk_score < 60 else "error"
        else:
            status = "success"

        explanation_parts = []
        if face_extraction_status == "success":
            explanation_parts.append("Portrait auto-extracted from identity document.")
        elif face_extraction_status != "not_attempted":
            explanation_parts.append(
                f"Portrait extraction {face_extraction_status} — manual review needed."
            )
        if face_score is not None:
            explanation_parts.append(f"Face similarity = {face_score:.2f}.")
        if issues:
            explanation_parts.append(f"{len(issues)} identity verification issue(s) found.")
        else:
            explanation_parts.append("Identity verification passed all checks.")

        findings = {
            "face_extraction_status": face_extraction_status,
            "face_match_score": face_score,
            "issues": issues,
            "id_number": id_number,
            "document_expiry": expiry_str,
        }

        result = AgentResult(
            agent_name=self.name,
            status=status,
            risk_score=risk_score,
            findings=findings,
            evidence=evidence,
            explanation=" ".join(explanation_parts),
            raw_data={
                "face_extraction_status": face_extraction_status,
                "face_match_score": face_score,
            },
        )
        self.log_audit(customer_id, result.to_dict())
        return result