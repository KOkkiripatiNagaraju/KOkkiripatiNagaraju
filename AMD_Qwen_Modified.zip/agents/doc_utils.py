"""
doc_utils.py
Utility functions for reading uploaded documents (images / PDFs),
extracting text via OCR, and basic face-comparison for photo verification.

Change log:
  - Added extract_face_from_id(): automatically detects and crops the portrait
    photo embedded in an identity document (Passport, Aadhaar, DL, etc.) so
    callers no longer need a separately uploaded "Photo on ID" file.
  - Updated compare_faces() to accept either raw bytes OR a pre-cropped
    numpy BGR array, enabling the identity_verification_agent to pass the
    result of extract_face_from_id() directly without re-encoding.
"""

import io
import logging
import os
from typing import Optional, Tuple, Union

import numpy as np
from PIL import Image

logger = logging.getLogger(__name__)

try:
    import pytesseract
    TESSERACT_AVAILABLE = True
except ImportError:
    TESSERACT_AVAILABLE = False

try:
    import fitz  # PyMuPDF
    PYMUPDF_AVAILABLE = True
except ImportError:
    PYMUPDF_AVAILABLE = False

try:
    import cv2
    CV2_AVAILABLE = True
except ImportError:
    CV2_AVAILABLE = False


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _bytes_to_bgr(data: Union[bytes, bytearray, np.ndarray, Image.Image]) -> Optional[np.ndarray]:
    """
    Normalise any supported image representation to an OpenCV BGR numpy array.

    Accepts:
      - bytes / bytearray  : raw encoded image bytes (JPEG, PNG, …)
      - numpy.ndarray      : already-decoded BGR array (returned as-is / copy)
      - PIL.Image.Image    : converted via RGB → BGR
    Returns None on failure.
    """
    if not CV2_AVAILABLE:
        return None

    if isinstance(data, (bytes, bytearray)):
        arr = np.frombuffer(data, np.uint8)
        img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
        return img  # may be None if decoding fails

    if isinstance(data, np.ndarray):
        return data.copy()

    if isinstance(data, Image.Image):
        rgb = np.array(data.convert("RGB"))
        return cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)

    logger.warning("_bytes_to_bgr: unsupported type %s", type(data))
    return None


def _load_face_cascade() -> Optional["cv2.CascadeClassifier"]:
    if not CV2_AVAILABLE:
        return None
    cascade_path = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
    if not os.path.exists(cascade_path):
        logger.warning("Haar cascade XML not found at %s", cascade_path)
        return None
    return cv2.CascadeClassifier(cascade_path)


def _run_face_detection(img_bgr: np.ndarray) -> list:
    """
    Run Haar-cascade face detection on a BGR image.
    Returns a list of (x, y, w, h) tuples (may be empty).
    Applies histogram equalisation on the gray channel before detection
    to improve robustness on ID-document scans.
    """
    cascade = _load_face_cascade()
    if cascade is None:
        return []

    gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
    gray = cv2.equalizeHist(gray)
    faces = cascade.detectMultiScale(
        gray,
        scaleFactor=1.05,
        minNeighbors=4,
        minSize=(60, 60),
        flags=cv2.CASCADE_SCALE_IMAGE,
    )
    return list(faces) if len(faces) else []


# ---------------------------------------------------------------------------
# Text extraction
# ---------------------------------------------------------------------------

def extract_text_from_image(file_bytes: bytes) -> str:
    """Run OCR on an image and return extracted text."""
    if not TESSERACT_AVAILABLE:
        return "[OCR unavailable: pytesseract / tesseract-ocr not installed]"
    try:
        img = Image.open(io.BytesIO(file_bytes))
        if img.mode != "RGB":
            img = img.convert("RGB")
        text = pytesseract.image_to_string(img)
        return text.strip()
    except Exception as e:
        return f"[OCR error: {e}]"


def extract_text_from_pdf(file_bytes: bytes) -> str:
    """Extract text from a PDF. Falls back to OCR per-page if no text layer."""
    if not PYMUPDF_AVAILABLE:
        return "[PDF parsing unavailable: PyMuPDF not installed]"
    text_chunks = []
    try:
        doc = fitz.open(stream=file_bytes, filetype="pdf")
        for page in doc:
            page_text = page.get_text().strip()
            if page_text:
                text_chunks.append(page_text)
            elif TESSERACT_AVAILABLE:
                pix = page.get_pixmap(matrix=fitz.Matrix(2, 2))
                img_bytes = pix.tobytes("png")
                ocr_text = extract_text_from_image(img_bytes)
                text_chunks.append(ocr_text)
        doc.close()
    except Exception as e:
        return f"[PDF error: {e}]"
    return "\n".join(text_chunks).strip()


def extract_text(filename: str, file_bytes: bytes) -> str:
    """Dispatch text extraction based on file extension."""
    ext = os.path.splitext(filename)[1].lower()
    if ext == ".pdf":
        return extract_text_from_pdf(file_bytes)
    if ext in (".png", ".jpg", ".jpeg", ".bmp", ".tiff", ".webp"):
        return extract_text_from_image(file_bytes)
    if ext in (".txt", ".csv"):
        try:
            return file_bytes.decode("utf-8", errors="ignore")
        except Exception:
            return ""
    return f"[Unsupported file type: {ext}]"


# ---------------------------------------------------------------------------
# Face extraction from identity documents  (NEW)
# ---------------------------------------------------------------------------

def extract_face_from_id(
    image_input: Union[bytes, bytearray, np.ndarray, Image.Image, str]
) -> Optional[np.ndarray]:
    """
    Automatically detect and crop the portrait photo from an identity
    document (Passport, Aadhaar card, Driving Licence, National ID, etc.).

    This replaces the previous workflow that required users to manually upload
    a cropped "Photo on ID Proof" file.

    Detection strategy
    ------------------
    Pass 1 — standard Haar cascade on the equalised grayscale image.
    Pass 2 — if Pass 1 finds nothing, apply CLAHE contrast enhancement and retry.
              CLAHE helps with washed-out or unevenly lit scanned documents.

    The largest detected face region is returned (ID cards carry exactly one
    portrait; picking the largest face discards small background artefacts).
    A 15 % padding is added on all sides so the crop includes forehead / chin
    context that improves downstream histogram-correlation matching.

    Args:
        image_input:
            Any of the following:
              - ``bytes`` / ``bytearray``  — raw encoded image bytes
              - ``numpy.ndarray``          — BGR image array (OpenCV convention)
              - ``PIL.Image.Image``        — PIL image object
              - ``str``                    — file-system path to an image file

            PDF inputs are NOT supported here; rasterise individual pages with
            PyMuPDF first (see ``pdf_page_to_bgr`` below) and pass the result.

    Returns:
        numpy.ndarray (BGR, uint8) of the cropped face region,
        or ``None`` if detection failed (low quality scan, text-only PDF page,
        no face present, or OpenCV not installed).
    """
    if not CV2_AVAILABLE:
        logger.warning("extract_face_from_id: OpenCV not available — cannot extract face")
        return None

    # ── Normalise input ────────────────────────────────────────────────────
    if isinstance(image_input, str):
        # File-system path
        img = cv2.imread(image_input)
        if img is None:
            logger.warning("extract_face_from_id: could not read file at '%s'", image_input)
            return None
    else:
        img = _bytes_to_bgr(image_input)

    if img is None or img.size == 0:
        logger.warning("extract_face_from_id: received empty or unreadable image")
        return None

    # ── Pass 1: standard detection ─────────────────────────────────────────
    faces = _run_face_detection(img)

    # ── Pass 2: CLAHE enhancement + retry ─────────────────────────────────
    if not faces:
        logger.info(
            "extract_face_from_id: no face in Pass 1 — retrying with CLAHE enhancement"
        )
        lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
        l_ch, a_ch, b_ch = cv2.split(lab)
        clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8, 8))
        l_ch = clahe.apply(l_ch)
        enhanced = cv2.cvtColor(cv2.merge([l_ch, a_ch, b_ch]), cv2.COLOR_LAB2BGR)
        faces = _run_face_detection(enhanced)
        if faces:
            img = enhanced      # crop from the enhanced image for better quality

    if not faces:
        logger.warning(
            "extract_face_from_id: could not detect a face in the identity document "
            "(document may be low-resolution, a text-only PDF page, or the portrait "
            "region is not detectable by the Haar cascade)"
        )
        return None

    # ── Pick the largest face ──────────────────────────────────────────────
    x, y, w, h = max(faces, key=lambda r: r[2] * r[3])

    # Add ~15 % padding without going out-of-bounds
    pad_x = int(w * 0.15)
    pad_y = int(h * 0.15)
    x1 = max(0, x - pad_x)
    y1 = max(0, y - pad_y)
    x2 = min(img.shape[1], x + w + pad_x)
    y2 = min(img.shape[0], y + h + pad_y)

    face_crop = img[y1:y2, x1:x2]
    logger.info(
        "extract_face_from_id: portrait extracted successfully "
        "(face bounding box %dx%d, crop with padding %dx%d)",
        w, h, x2 - x1, y2 - y1,
    )
    return face_crop


def pdf_page_to_bgr(file_bytes: bytes, page_index: int = 0) -> Optional[np.ndarray]:
    """
    Rasterise a single PDF page to a BGR numpy array so it can be passed to
    ``extract_face_from_id``.

    Uses a 2× zoom matrix for sufficient resolution on typical A4/ID scans.
    Returns None if PyMuPDF is unavailable or the page index is out of range.
    """
    if not PYMUPDF_AVAILABLE:
        logger.warning("pdf_page_to_bgr: PyMuPDF not installed")
        return None
    if not CV2_AVAILABLE:
        logger.warning("pdf_page_to_bgr: OpenCV not installed")
        return None
    try:
        doc = fitz.open(stream=file_bytes, filetype="pdf")
        if page_index >= len(doc):
            logger.warning(
                "pdf_page_to_bgr: page_index %d out of range (doc has %d pages)",
                page_index, len(doc),
            )
            doc.close()
            return None
        page = doc[page_index]
        pix = page.get_pixmap(matrix=fitz.Matrix(2, 2))
        img_bytes = pix.tobytes("png")
        doc.close()
        arr = np.frombuffer(img_bytes, np.uint8)
        img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
        return img
    except Exception as exc:
        logger.error("pdf_page_to_bgr: error rasterising PDF — %s", exc)
        return None


# ---------------------------------------------------------------------------
# Face detection / comparison
# ---------------------------------------------------------------------------

def _detect_and_crop_face(
    image_input: Union[bytes, np.ndarray]
) -> Optional[np.ndarray]:
    """
    Detect the largest face and return a normalised 200×200 grayscale crop
    suitable for histogram-based comparison.

    Accepts raw bytes OR a pre-decoded BGR numpy array (e.g. the output of
    ``extract_face_from_id``), so the caller does not need to re-encode.
    """
    if not CV2_AVAILABLE:
        return None

    img = _bytes_to_bgr(image_input)
    if img is None:
        return None

    faces = _run_face_detection(img)
    if not faces:
        return None

    x, y, w, h = max(faces, key=lambda f: f[2] * f[3])
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    face = gray[y: y + h, x: x + w]
    face = cv2.resize(face, (200, 200))
    face = cv2.equalizeHist(face)
    return face


def compare_faces(
    id_photo: Union[bytes, np.ndarray],
    live_photo: Union[bytes, np.ndarray],
) -> Tuple[Optional[float], str]:
    """
    Compare two face images using histogram correlation as a lightweight
    similarity proxy.

    Both arguments accept **either** raw image bytes **or** a pre-decoded BGR
    numpy array (e.g. the crop returned by ``extract_face_from_id``).  This
    avoids a redundant encode→decode cycle when the ID face has already been
    extracted in-memory.

    Returns
    -------
    (similarity_score, message)
      similarity_score : float in [0, 1] where 1.0 is identical, or None on failure.
      message          : human-readable status string.

    Note
    ----
    Histogram correlation is a heuristic — it works as a quick sanity check but
    is NOT production-grade.  Replace with a face-embedding model (ArcFace,
    FaceNet, AWS Rekognition, Azure Face API) for production use.
    """
    if not CV2_AVAILABLE:
        return None, "Face comparison unavailable: OpenCV not installed."

    face1 = _detect_and_crop_face(id_photo)
    face2 = _detect_and_crop_face(live_photo)

    if face1 is None and face2 is None:
        return None, "Could not detect a clear face in either image."
    if face1 is None:
        return None, "Could not detect a face in the ID document image."
    if face2 is None:
        return None, "Could not detect a face in the live photo."

    hist1 = cv2.calcHist([face1], [0], None, [256], [0, 256])
    hist2 = cv2.calcHist([face2], [0], None, [256], [0, 256])
    cv2.normalize(hist1, hist1)
    cv2.normalize(hist2, hist2)

    raw_score = cv2.compareHist(hist1, hist2, cv2.HISTCMP_CORREL)
    # HISTCMP_CORREL returns [-1, 1]; map to [0, 1]
    score = float(max(0.0, min(1.0, (raw_score + 1) / 2)))

    return score, "Face comparison completed using histogram correlation (heuristic)."


# ---------------------------------------------------------------------------
# Image quality checks
# ---------------------------------------------------------------------------

def get_image_quality_flags(file_bytes: bytes) -> list:
    """
    Basic image quality heuristics: resolution, blur, and brightness.

    Returns a list of human-readable warning strings (empty list = no issues).
    """
    flags = []
    if not CV2_AVAILABLE:
        return ["Image quality check unavailable (OpenCV missing)."]

    arr = np.frombuffer(file_bytes, np.uint8)
    img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    if img is None:
        return ["Could not decode image for quality check."]

    h, w = img.shape[:2]
    if h < 300 or w < 300:
        flags.append(f"Low resolution image ({w}×{h}px — minimum 300px on each side).")

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    blur_score = cv2.Laplacian(gray, cv2.CV_64F).var()
    if blur_score < 50:
        flags.append(f"Image appears blurry (sharpness score={blur_score:.1f}).")

    brightness = float(gray.mean())
    if brightness < 40:
        flags.append(f"Image appears too dark (mean brightness={brightness:.1f}).")
    elif brightness > 220:
        flags.append(f"Image appears overexposed (mean brightness={brightness:.1f}).")

    return flags