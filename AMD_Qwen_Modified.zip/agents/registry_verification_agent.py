"""
registry_verification_agent.py
Agent: Identity Registry Verification (mock "DigiLocker" cross-check).

Responsibilities:
 - Cross-check the customer's extracted identity-document fields (ID number,
   name, DOB, nationality) against the mock government identity registry
   (db/users_db.json) to determine whether the user/documents appear genuine,
   mismatched, or not found at all (potential fake identity).
 - Surface any PEP / sanctions / risk flags already recorded against the
   matched registry record.
"""

from typing import Any, Dict, List

from .base_agent import BaseAgent, AgentResult
from db import verify_against_registry


class RegistryVerificationAgent(BaseAgent):
    name = "RegistryVerificationAgent"

    def run(self, customer_id: str, extraction_findings: Dict[str, Any]) -> AgentResult:
        extracted_data = extraction_findings.get("extracted_data", {})
        identity_fields = extracted_data.get("identity_proof", {}).get("fields", {}) or {}

        evidence: List[str] = []
        registry_result = verify_against_registry(identity_fields)

        verdict = registry_result["verdict"]
        match_method = registry_result["match_method"]
        discrepancies = registry_result["discrepancies"]

        risk_score = 0.0
        status = "success"

        if verdict == "not_found":
            evidence.append(
                "No matching record found in the identity registry for the submitted "
                "ID number / name. This may indicate a fake or unregistered identity."
            )
            risk_score += 70
            status = "error"
        else:
            matched_id = registry_result["matched_record_id"]
            evidence.append(
                f"Matched registry record #{matched_id} via {match_method.replace('_', ' ')}."
            )

            if verdict == "genuine":
                evidence.append("All compared fields (name/DOB/nationality) match the registry record.")
            else:
                for d in discrepancies:
                    evidence.append(f"Discrepancy: {d}")
                # Each discrepancy raises risk
                risk_score += min(60.0, len(discrepancies) * 25)
                status = "warning" if risk_score < 60 else "error"

            if registry_result["is_pep"]:
                evidence.append("Registry record flagged as a Politically Exposed Person (PEP).")
                risk_score += 35
                status = "warning" if status == "success" else status

            if registry_result["is_sanctioned"]:
                evidence.append("Registry record flagged as SANCTIONED.")
                risk_score += 60
                status = "error"

            if registry_result["risk_flag"]:
                evidence.append("Registry record carries a general risk flag.")
                risk_score += 25
                status = "warning" if status == "success" else status

        risk_score = min(100.0, risk_score)

        explanation_map = {
            "not_found": (
                "No corresponding record could be located in the identity registry for "
                "this customer's submitted ID number/name, which raises the possibility "
                "that the documents reference a fake or unregistered identity."
            ),
            "genuine": "Customer details match an existing identity registry record with no discrepancies.",
            "mismatch": "Customer details partially match a registry record but one or more fields differ from official records.",
        }
        explanation = explanation_map.get(verdict, "Registry verification completed.")

        if registry_result.get("is_sanctioned"):
            explanation += " The matched registry record is flagged as SANCTIONED."
        elif registry_result.get("is_pep"):
            explanation += " The matched registry record is flagged as a PEP."

        # Strip the full registry record from raw_data evidence shown to UI to avoid
        # leaking unrelated PII fields, but keep a trimmed summary.
        registry_record = registry_result.get("registry_record")
        registry_summary = None
        if registry_record:
            registry_summary = {
                "name": registry_record.get("name"),
                "dob": registry_record.get("dob"),
                "nationality": registry_record.get("nationality"),
                "is_pep": registry_record.get("is_pep"),
                "is_sanctioned": registry_record.get("is_sanctioned"),
                "risk_flag": registry_record.get("risk_flag"),
            }

        findings = {
            "verdict": verdict,
            "match_method": match_method,
            "matched_record_id": registry_result.get("matched_record_id"),
            "field_matches": registry_result.get("field_matches"),
            "discrepancies": discrepancies,
            "registry_summary": registry_summary,
            "is_pep": registry_result.get("is_pep"),
            "is_sanctioned": registry_result.get("is_sanctioned"),
            "risk_flag": registry_result.get("risk_flag"),
        }

        result = AgentResult(
            agent_name=self.name,
            status=status,
            risk_score=risk_score,
            findings=findings,
            evidence=evidence,
            explanation=explanation,
            raw_data={"registry_result": registry_result},
        )
        self.log_audit(customer_id, result.to_dict())
        return result
