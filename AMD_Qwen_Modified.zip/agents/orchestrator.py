"""
orchestrator.py
The AMD (Agent Master / Director) Orchestrator.

Coordinates the full KYC pipeline:
  1. DataExtractionAgent       - parse & cross-check uploaded documents
  2. EnrichmentAgent           - normalize profile, country risk, age checks
  3. IdentityVerificationAgent - face match, document validity, authenticity
  4. ScreeningAgent            - sanctions / PEP / adverse media screening
  5. FinancialProfileAgent     - source-of-funds & financial behavior profiling

Aggregates per-agent risk scores into a composite score, applies decision
thresholds, and produces an explainable final KYC decision with full
evidence trail for human reviewers.
"""

import json
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List

from .data_extraction_agent import DataExtractionAgent
from .enrichment_agent import EnrichmentAgent
from .identity_verification_agent import IdentityVerificationAgent
from .registry_verification_agent import RegistryVerificationAgent
from .screening_agent import ScreeningAgent
from .financial_profile_agent import FinancialProfileAgent
from .base_agent import AgentResult

from config import AGENT_WEIGHTS, RISK_THRESHOLDS, AUDIT_LOG_FILE, llm_creative


FINAL_EXPLANATION_PROMPT = """You are the lead KYC compliance reviewer (AMD - Agent Master / Director).
Multiple specialist agents have analyzed a customer onboarding application.
Below is a summary of each agent's findings, risk score, and evidence.

Composite risk score: {composite_score:.1f} / 100
Preliminary decision: {decision}

Agent reports:
{agent_summaries}

Write a clear, concise explanation (4-6 sentences) for a human compliance
reviewer summarizing:
- Why this decision was reached
- The most significant risk factors (if any)
- What a reviewer should focus on if escalated/reviewed

Do not use markdown formatting. Plain prose only.
"""


class KYCOrchestrator:
    """AMD - orchestrates all specialized KYC agents end-to-end."""

    def __init__(self):
        self.data_extraction_agent = DataExtractionAgent()
        self.enrichment_agent = EnrichmentAgent()
        self.identity_verification_agent = IdentityVerificationAgent()
        self.registry_verification_agent = RegistryVerificationAgent()
        self.screening_agent = ScreeningAgent()
        self.financial_profile_agent = FinancialProfileAgent()
        self.llm_creative = llm_creative

    # ----------------------------------------------------------------
    def run_pipeline(self, customer_id: str, documents: Dict[str, Dict[str, Any]], progress_callback=None) -> Dict[str, Any]:
        """
        Run the full multi-agent KYC pipeline.

        documents: dict keyed by category -> {"filename", "bytes", "doc_subtype"}
        progress_callback: optional callable(step_name: str, result: AgentResult) for live UI updates.
        """
        if not customer_id:
            customer_id = f"CUST-{uuid.uuid4().hex[:8].upper()}"

        agent_results: Dict[str, AgentResult] = {}

        # Step 1: Data & Document Extraction
        result = self.data_extraction_agent.run(customer_id, documents)
        agent_results["data_extraction_quality"] = result
        if progress_callback:
            progress_callback("Data & Document Extraction", result)

        # Step 2: Enrichment
        result_enrich = self.enrichment_agent.run(customer_id, result.findings)
        if progress_callback:
            progress_callback("Data Enrichment", result_enrich)

        # Step 3: Identity Verification
        result_idv = self.identity_verification_agent.run(customer_id, result.findings, documents)
        agent_results["identity_verification"] = result_idv
        if progress_callback:
            progress_callback("Identity Verification", result_idv)

        # Step 3b: Registry Verification (mock DigiLocker cross-check)
        result_registry = self.registry_verification_agent.run(customer_id, result.findings)
        agent_results["registry_verification"] = result_registry
        if progress_callback:
            progress_callback("Identity Registry Verification", result_registry)

        # Step 4: Compliance Screening
        result_screen = self.screening_agent.run(customer_id, result.findings)
        agent_results["compliance_screening"] = result_screen
        if progress_callback:
            progress_callback("Compliance Screening", result_screen)

        # Step 5: Financial Profiling
        result_fin = self.financial_profile_agent.run(customer_id, result.findings)
        agent_results["financial_profile"] = result_fin
        if progress_callback:
            progress_callback("Financial Profiling", result_fin)

        # Keep enrichment result for the report even though it's not in the weighted score
        all_results = {
            "data_extraction": result,
            "enrichment": result_enrich,
            "identity_verification": result_idv,
            "registry_verification": result_registry,
            "compliance_screening": result_screen,
            "financial_profile": result_fin,
        }

        # ------------------------------------------------------------
        # Composite risk scoring
        # ------------------------------------------------------------
        composite_score = 0.0
        for key, weight in AGENT_WEIGHTS.items():
            agent_result = agent_results.get(key)
            if agent_result:
                composite_score += agent_result.risk_score * weight

        # Hard override: any "error" status from screening forces escalate-level risk
        if agent_results["compliance_screening"].status == "error":
            composite_score = max(composite_score, 80.0)

        # Hard override: registry verification "error" (not_found / sanctioned) also forces escalation
        if agent_results["registry_verification"].status == "error":
            composite_score = max(composite_score, 80.0)

        composite_score = round(min(100.0, composite_score), 2)

        # ------------------------------------------------------------
        # Decision thresholds
        # ------------------------------------------------------------
        if composite_score <= RISK_THRESHOLDS["approve_max"]:
            decision = "APPROVE"
        elif composite_score <= RISK_THRESHOLDS["review_max"]:
            decision = "REVIEW"
        else:
            decision = "ESCALATE"

        # ------------------------------------------------------------
        # Build agent summaries for explanation prompt
        # ------------------------------------------------------------
        agent_summaries_text = []
        for label, res in all_results.items():
            agent_summaries_text.append(
                f"- {res.agent_name} (status: {res.status}, risk_score: {res.risk_score:.1f}): {res.explanation}"
            )
        agent_summaries_joined = "\n".join(agent_summaries_text)

        try:
            prompt = FINAL_EXPLANATION_PROMPT.format(
                composite_score=composite_score,
                decision=decision,
                agent_summaries=agent_summaries_joined,
            )
            final_explanation = self.llm_creative.invoke(prompt).content
        except Exception as e:
            final_explanation = (
                f"Composite risk score of {composite_score:.1f} resulted in a '{decision}' decision "
                f"based on weighted agent risk scores. (Narrative generation failed: {e})"
            )

        # ------------------------------------------------------------
        # Build evidence trail
        # ------------------------------------------------------------
        evidence_trail = []
        for label, res in all_results.items():
            evidence_trail.append({
                "agent": res.agent_name,
                "status": res.status,
                "risk_score": res.risk_score,
                "evidence": res.evidence,
                "findings": res.findings,
            })

        report = {
            "customer_id": customer_id,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "composite_risk_score": composite_score,
            "decision": decision,
            "decision_thresholds": RISK_THRESHOLDS,
            "agent_weights": AGENT_WEIGHTS,
            "final_explanation": final_explanation.strip(),
            "agent_results": {k: v.to_dict() for k, v in all_results.items()},
            "evidence_trail": evidence_trail,
            "human_review_required": decision in ("REVIEW", "ESCALATE"),
        }

        # Persist final decision to audit log
        try:
            with open(AUDIT_LOG_FILE, "a", encoding="utf-8") as f:
                f.write(json.dumps({
                    "timestamp": report["timestamp"],
                    "agent": "AMD_Orchestrator",
                    "customer_id": customer_id,
                    "payload": {
                        "composite_risk_score": composite_score,
                        "decision": decision,
                    },
                }, default=str) + "\n")
        except Exception:
            pass

        return report

    # ----------------------------------------------------------------
    @staticmethod
    def apply_human_override(report: Dict[str, Any], reviewer_name: str, override_decision: str, comment: str) -> Dict[str, Any]:
        """Record a human-in-the-loop override decision into the report."""
        report["human_override"] = {
            "reviewer": reviewer_name,
            "decision": override_decision,
            "comment": comment,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        report["final_decision"] = override_decision

        try:
            with open(AUDIT_LOG_FILE, "a", encoding="utf-8") as f:
                f.write(json.dumps({
                    "timestamp": report["human_override"]["timestamp"],
                    "agent": "HumanReviewer",
                    "customer_id": report["customer_id"],
                    "payload": report["human_override"],
                }, default=str) + "\n")
        except Exception:
            pass

        return report
