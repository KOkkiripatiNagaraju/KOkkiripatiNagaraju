"""
data_extraction_agent.py
Agent 1: Data & Document Extraction.

Responsibilities:
 - OCR / parse uploaded documents (identity proof, address proof, business docs)
 - Use the LLM to extract structured fields (name, DOB, ID number, address, etc.)
 - Cross-check consistency between documents (e.g., name on ID vs address proof)
 - Flag missing/poor-quality documents

Change log:
 - the portrait is auto-extracted from `identity_proof` by IdentityVerificationAgent.
 - `live_photo` still skips OCR (it is a selfie, not a text document) but
   now uses the shared _PHOTO_ONLY_CATEGORIES constant so future additions
   are made in one place.
 - Added image quality check for `identity_proof` in addition to `live_photo`
   so blur / resolution problems on the ID card are surfaced early, before
   the face-extraction step in Agent 3.
 - `mimetype` field (added by main.py) now considered alongside filename
   extension when deciding whether to run OCR.
"""

import json
from typing import Any, Dict, List, Set

from .base_agent import BaseAgent, AgentResult
from .doc_utils import extract_text, get_image_quality_flags

# Categories that carry image content only — OCR is skipped, quality is checked.
# `identity_proof` is NOT here: it is a real document that must be OCR-ed for
# field extraction AND quality-checked for the downstream face-extraction step.
_PHOTO_ONLY_CATEGORIES: Set[str] = {"live_photo", "selfie", "live_selfie", "liveness"}

# Categories where we also run an image quality check (in addition to OCR).
# Catching blur / low-res early avoids silent failures in face extraction.
_QUALITY_CHECK_CATEGORIES: Set[str] = {"identity_proof", "live_photo", "selfie"}

EXTRACTION_PROMPT = """You are a KYC document data-extraction specialist.
Given the raw OCR/text content of a document of type "{doc_type}", extract the
following structured fields as a JSON object. If a field is not present, use null.

Required fields:
- full_name
- date_of_birth (format YYYY-MM-DD if possible)
- id_number (passport/license/govt id number)
- nationality
- address
- document_expiry (YYYY-MM-DD if present)
- issuing_authority
- additional_notes (any anomalies, e.g. expired stamp, tampering signs noticed in text)

Document type: {doc_type}
Raw extracted text:
---
{raw_text}
---

Respond with ONLY a valid JSON object, no commentary, no markdown fences.
"""


class DataExtractionAgent(BaseAgent):
    name = "DataExtractionAgent"

    def run(self, customer_id: str, documents: Dict[str, Dict[str, Any]]) -> AgentResult:
        """
        Parameters
        ----------
        customer_id : str
        documents   : dict keyed by category (e.g. ``'identity_proof'``) →
                      ``{"filename": str, "bytes": bytes, "doc_subtype": str,
                         "mimetype": str}``
                      The ``mimetype`` key is set by main.py; fall back to
                      filename extension if absent.
        """
        extracted: Dict[str, Any] = {}
        evidence: List[str] = []
        quality_issues: List[str] = []
        missing_docs: List[str] = []

        from config import DOCUMENT_CATEGORIES

        for category, meta in DOCUMENT_CATEGORIES.items():
            doc = documents.get(category)

            if not doc or not doc.get("bytes"):
                if meta["required"]:
                    missing_docs.append(meta["label"])
                continue

            filename: str = doc["filename"]
            file_bytes: bytes = doc["bytes"]
            doc_subtype: str = doc.get("doc_subtype", meta["label"])

            # ── Image quality check (runs for photos AND identity docs) ──────
            if category in _QUALITY_CHECK_CATEGORIES:
                quality_flags = get_image_quality_flags(file_bytes)
                if quality_flags:
                    quality_issues.extend(
                        [f"{meta['label']}: {q}" for q in quality_flags]
                    )
            else:
                quality_flags = []

            # ── Photo-only categories: skip OCR, record and move on ──────────
            if category in _PHOTO_ONLY_CATEGORIES:
                evidence.append(
                    f"{meta['label']} ({filename}) received and quality-checked."
                )
                extracted[category] = {
                    "filename": filename,
                    "doc_subtype": doc_subtype,
                    "quality_flags": quality_flags,
                }
                continue

            # ── Text extraction (OCR / PDF parse) ────────────────────────────
            raw_text = extract_text(filename, file_bytes)

            if not raw_text or raw_text.startswith("["):
                quality_issues.append(
                    f"{meta['label']} ({filename}): "
                    f"{raw_text or 'no text extracted'}"
                )
                extracted[category] = {
                    "filename": filename,
                    "doc_subtype": doc_subtype,
                    "raw_text": raw_text,
                    "fields": {},
                    "quality_flags": quality_flags,
                }
                continue

            # ── LLM structured field extraction ──────────────────────────────
            prompt = EXTRACTION_PROMPT.format(
                doc_type=doc_subtype,
                raw_text=raw_text[:6000],
            )
            try:
                response = self.call_llm(prompt, expect_json=True)
                fields = self.safe_json_loads(response, default={})
            except Exception as e:
                fields = {}
                quality_issues.append(
                    f"{meta['label']} ({filename}): extraction LLM error — {e}"
                )

            extracted[category] = {
                "filename": filename,
                "doc_subtype": doc_subtype,
                "raw_text": raw_text[:2000],
                "fields": fields,
                "quality_flags": quality_flags,
            }
            evidence.append(
                f"Extracted structured fields from {meta['label']} ({filename})."
            )

        # ── Cross-document consistency checks ────────────────────────────────
        consistency_issues = self._cross_check(extracted)

        # ── Risk scoring ──────────────────────────────────────────────────────
        risk_score = 0.0
        risk_score += len(missing_docs) * 25
        risk_score += len(quality_issues) * 8
        risk_score += len(consistency_issues) * 15
        risk_score = min(100.0, risk_score)

        if missing_docs:
            status = "error"
        elif quality_issues or consistency_issues:
            status = "warning"
        else:
            status = "success"

        explanation_parts: List[str] = []
        if missing_docs:
            explanation_parts.append(
                f"Missing required documents: {', '.join(missing_docs)}."
            )
        if quality_issues:
            explanation_parts.append(
                f"{len(quality_issues)} document quality issue(s) detected."
            )
        if consistency_issues:
            explanation_parts.append(
                f"{len(consistency_issues)} cross-document consistency issue(s) found."
            )
        if not explanation_parts:
            explanation_parts.append(
                "All required documents received, extracted, and mutually consistent."
            )

        findings = {
            "extracted_data": extracted,
            "missing_documents": missing_docs,
            "quality_issues": quality_issues,
            "consistency_issues": consistency_issues,
        }

        result = AgentResult(
            agent_name=self.name,
            status=status,
            risk_score=risk_score,
            findings=findings,
            evidence=evidence,
            explanation=" ".join(explanation_parts),
            raw_data={"extracted": extracted},
        )
        self.log_audit(customer_id, result.to_dict())
        return result

    @staticmethod
    def _cross_check(extracted: Dict[str, Any]) -> List[str]:
        """
        Compare key fields (name, address) across documents for mismatches.

        Uses a token-overlap heuristic: if fewer than 50 % of name tokens
        are shared between two documents the names are considered inconsistent.
        """
        issues: List[str] = []
        names: List[tuple] = []

        for cat in ("identity_proof", "address_proof", "business_doc"):
            data = extracted.get(cat, {})
            fields = data.get("fields", {}) if isinstance(data, dict) else {}
            if fields.get("full_name"):
                names.append((cat, fields["full_name"].strip().lower()))

        if len(names) >= 2:
            base_cat, base_name = names[0]
            base_tokens = set(base_name.split())
            for cat, name in names[1:]:
                name_tokens = set(name.split())
                if base_tokens and name_tokens:
                    overlap = len(base_tokens & name_tokens) / max(
                        len(base_tokens), len(name_tokens)
                    )
                    if overlap < 0.5:
                        issues.append(
                            f"Name mismatch between {base_cat} "
                            f"('{base_name}') and {cat} ('{name}')."
                        )

        return issues