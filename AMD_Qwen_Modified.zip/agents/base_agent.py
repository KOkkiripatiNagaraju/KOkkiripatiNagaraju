"""
base_agent.py
Common base class for all KYC agents: standardized logging, LLM call wrapper,
and explainability evidence formatting.
"""

import json
import time
import traceback
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from config import llm, AUDIT_LOG_FILE


class AgentResult:
    """Standardized result object returned by every agent."""

    def __init__(
        self,
        agent_name: str,
        status: str,                 # "success" | "warning" | "error"
        risk_score: float,           # 0-100, higher = riskier
        findings: Dict[str, Any],
        evidence: List[str],
        explanation: str,
        raw_data: Optional[Dict[str, Any]] = None,
    ):
        self.agent_name = agent_name
        self.status = status
        self.risk_score = max(0.0, min(100.0, risk_score))
        self.findings = findings
        self.evidence = evidence
        self.explanation = explanation
        self.raw_data = raw_data or {}
        self.timestamp = datetime.now(timezone.utc).isoformat()

    def to_dict(self) -> Dict[str, Any]:
        return {
            "agent_name": self.agent_name,
            "status": self.status,
            "risk_score": round(self.risk_score, 2),
            "findings": self.findings,
            "evidence": self.evidence,
            "explanation": self.explanation,
            "raw_data": self.raw_data,
            "timestamp": self.timestamp,
        }


class BaseAgent:
    """Base class providing shared helpers for all specialized agents."""

    name: str = "BaseAgent"

    def __init__(self, llm_client=None):
        self.llm = llm_client or llm

    # ------------------------------------------------------------------
    # LLM helper with basic retry & JSON-extraction support
    # ------------------------------------------------------------------
    def call_llm(self, prompt: str, expect_json: bool = False, retries: int = 2) -> str:
        last_err = None
        for attempt in range(retries + 1):
            try:
                response = self.llm.invoke(prompt)
                content = response.content if hasattr(response, "content") else str(response)
                if expect_json:
                    return self._extract_json_block(content)
                return content
            except Exception as e:
                last_err = e
                time.sleep(1.0 * (attempt + 1))
        raise RuntimeError(f"[{self.name}] LLM call failed after retries: {last_err}")

    @staticmethod
    def _extract_json_block(text: str) -> str:
        """Strip markdown code fences and return the raw JSON string."""
        text = text.strip()
        if "```" in text:
            parts = text.split("```")
            for part in parts:
                part = part.strip()
                if part.startswith("json"):
                    part = part[4:].strip()
                if part.startswith("{") or part.startswith("["):
                    return part
        return text

    def safe_json_loads(self, text: str, default: Any = None) -> Any:
        try:
            return json.loads(self._extract_json_block(text))
        except Exception:
            return default if default is not None else {}

    # ------------------------------------------------------------------
    # Audit logging - append-only JSONL for explainability / compliance
    # ------------------------------------------------------------------
    def log_audit(self, customer_id: str, payload: Dict[str, Any]):
        record = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "agent": self.name,
            "customer_id": customer_id,
            "payload": payload,
        }
        try:
            with open(AUDIT_LOG_FILE, "a", encoding="utf-8") as f:
                f.write(json.dumps(record, default=str) + "\n")
        except Exception:
            traceback.print_exc()

    # ------------------------------------------------------------------
    # To be implemented by subclasses
    # ------------------------------------------------------------------
    def run(self, *args, **kwargs) -> AgentResult:
        raise NotImplementedError
