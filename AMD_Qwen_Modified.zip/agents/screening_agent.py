"""
screening_agent.py
Agent 4: Compliance Screening (Sanctions / PEP / Adverse Media).

Responsibilities:
 - Screen the customer's name against sanctions, PEP, and adverse media lists
 - Use fuzzy matching to catch near-matches/aliases
 - Use LLM to assess severity and contextual relevance of any matches
"""

from difflib import SequenceMatcher
from typing import Any, Dict, List

from .base_agent import BaseAgent, AgentResult
from config import MOCK_WATCHLIST

ASSESSMENT_PROMPT = """You are a financial-crime compliance analyst.
A name screening process has produced the following potential watchlist matches
for customer "{customer_name}":

{matches_json}

For each match, assess whether it is likely a true positive (same person/entity)
or a false positive (coincidental name similarity), considering name similarity
score and any available context. Then give an overall recommendation.

Respond with ONLY a JSON object:
{{
  "overall_recommendation": "clear" | "review" | "escalate",
  "summary": "<2-3 sentence summary>",
  "match_assessments": [
     {{"matched_name": "...", "list": "...", "verdict": "true_positive"|"false_positive"|"uncertain", "rationale": "..."}}
  ]
}}
No commentary, no markdown fences.
"""


def _similarity(a: str, b: str) -> float:
    return SequenceMatcher(None, a.lower().strip(), b.lower().strip()).ratio()


class ScreeningAgent(BaseAgent):
    name = "ScreeningAgent"

    def __init__(self, llm_client=None, watchlist: List[Dict[str, Any]] = None):
        super().__init__(llm_client)
        self.watchlist = watchlist if watchlist is not None else MOCK_WATCHLIST

    def run(self, customer_id: str, extraction_findings: Dict[str, Any], match_threshold: float = 0.75) -> AgentResult:
        extracted_data = extraction_findings.get("extracted_data", {})
        identity_fields = extracted_data.get("identity_proof", {}).get("fields", {}) or {}
        customer_name = identity_fields.get("full_name") or "Unknown"

        evidence: List[str] = [f"Screened name '{customer_name}' against {len(self.watchlist)} watchlist entries (Sanctions/PEP/Adverse Media)."]

        matches = []
        for entry in self.watchlist:
            score = _similarity(customer_name, entry["name"])
            if score >= match_threshold:
                matches.append({**entry, "similarity": round(score, 2)})

        if not matches:
            evidence.append("No watchlist matches found above similarity threshold.")
            findings = {
                "customer_name": customer_name,
                "matches": [],
                "overall_recommendation": "clear",
                "assessment_summary": "No sanctions, PEP, or adverse media matches found.",
            }
            result = AgentResult(
                agent_name=self.name,
                status="success",
                risk_score=0.0,
                findings=findings,
                evidence=evidence,
                explanation="No watchlist matches found; screening cleared.",
                raw_data={"matches": []},
            )
            self.log_audit(customer_id, result.to_dict())
            return result

        # Potential matches found -> LLM-assisted assessment
        evidence.append(f"{len(matches)} potential watchlist match(es) found; performing contextual assessment.")

        import json as _json
        prompt = ASSESSMENT_PROMPT.format(
            customer_name=customer_name,
            matches_json=_json.dumps(matches, default=str),
        )
        try:
            response = self.call_llm(prompt, expect_json=True)
            assessment = self.safe_json_loads(response, default={})
        except Exception as e:
            assessment = {}
            evidence.append(f"LLM assessment failed: {e}")

        overall = assessment.get("overall_recommendation", "review")
        summary = assessment.get("summary", "Potential watchlist match requires manual review.")

        # Risk score based on recommendation + match severity
        base_risk = {"clear": 10, "review": 55, "escalate": 90}.get(overall, 60)
        max_similarity = max(m["similarity"] for m in matches)
        risk_score = min(100.0, base_risk + (max_similarity * 10))

        status_map = {"clear": "success", "review": "warning", "escalate": "error"}
        status = status_map.get(overall, "warning")

        for m in matches:
            evidence.append(f"Match: '{m['name']}' on {m['list']} (similarity {m['similarity']}).")

        findings = {
            "customer_name": customer_name,
            "matches": matches,
            "overall_recommendation": overall,
            "assessment_summary": summary,
            "match_assessments": assessment.get("match_assessments", []),
        }

        result = AgentResult(
            agent_name=self.name,
            status=status,
            risk_score=risk_score,
            findings=findings,
            evidence=evidence,
            explanation=summary,
            raw_data={"matches": matches, "assessment": assessment},
        )
        self.log_audit(customer_id, result.to_dict())
        return result
