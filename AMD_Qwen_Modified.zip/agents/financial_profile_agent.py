"""
financial_profile_agent.py
Agent 5: Financial Profiling.

Responsibilities:
 - Analyze address proof / business documents (bank statements, invoices, lease)
   for financial behavior signals
 - Use LLM to estimate income/turnover bracket, source-of-funds plausibility,
   and flag unusual patterns (large round-number transactions, mismatched
   declared occupation vs financial activity)
"""

from typing import Any, Dict, List

from .base_agent import BaseAgent, AgentResult

FINANCIAL_PROMPT = """You are a financial-profiling analyst for KYC due diligence.
Given the OCR text from the customer's financial/business documents below,
produce a JSON assessment with these fields:

- estimated_income_bracket: "low" | "medium" | "high" | "unknown"
- source_of_funds_plausible: boolean
- declared_business_activity: string or null
- unusual_patterns: list of strings (e.g. "large round-number deposits", "frequent cash withdrawals")
- risk_notes: string (2-3 sentences)

Document type: {doc_type}
OCR text:
---
{raw_text}
---

Respond with ONLY a valid JSON object, no commentary, no markdown fences.
"""


class FinancialProfileAgent(BaseAgent):
    name = "FinancialProfileAgent"

    def run(self, customer_id: str, extraction_findings: Dict[str, Any]) -> AgentResult:
        extracted_data = extraction_findings.get("extracted_data", {})

        # Prefer business doc, fall back to address proof (e.g. bank statement)
        source_doc = None
        source_label = None
        for cat, label in (("business_doc", "Business Document"), ("address_proof", "Address Proof")):
            data = extracted_data.get(cat, {})
            raw_text = data.get("raw_text", "") if isinstance(data, dict) else ""
            if raw_text and not raw_text.startswith("["):
                source_doc = data
                source_label = data.get("doc_subtype", label)
                break

        evidence: List[str] = []

        if not source_doc:
            evidence.append("No financial/business document with usable text was available for profiling.")
            findings = {
                "assessment": None,
                "note": "Insufficient documents for financial profiling.",
            }
            result = AgentResult(
                agent_name=self.name,
                status="warning",
                risk_score=20.0,
                findings=findings,
                evidence=evidence,
                explanation="Financial profiling skipped due to lack of suitable documents (low confidence default risk applied).",
                raw_data={},
            )
            self.log_audit(customer_id, result.to_dict())
            return result

        raw_text = source_doc.get("raw_text", "")
        prompt = FINANCIAL_PROMPT.format(doc_type=source_label, raw_text=raw_text[:4000])

        try:
            response = self.call_llm(prompt, expect_json=True)
            assessment = self.safe_json_loads(response, default={})
        except Exception as e:
            assessment = {}
            evidence.append(f"LLM financial profiling failed: {e}")

        evidence.append(f"Financial profile derived from {source_label}.")

        unusual_patterns = assessment.get("unusual_patterns", []) or []
        plausible = assessment.get("source_of_funds_plausible", True)
        income_bracket = assessment.get("estimated_income_bracket", "unknown")

        risk_score = 0.0
        if not plausible:
            risk_score += 40
            evidence.append("Source of funds assessed as NOT plausible based on document content.")
        else:
            evidence.append("Source of funds appears plausible based on document content.")

        risk_score += min(30.0, len(unusual_patterns) * 12)
        if unusual_patterns:
            for p in unusual_patterns:
                evidence.append(f"Unusual pattern flagged: {p}")

        if income_bracket == "unknown":
            risk_score += 10

        risk_score = min(100.0, risk_score)

        status = "success"
        if not plausible or len(unusual_patterns) >= 2:
            status = "error" if risk_score >= 60 else "warning"
        elif unusual_patterns:
            status = "warning"

        findings = {
            "assessment": assessment,
            "source_document": source_label,
            "estimated_income_bracket": income_bracket,
            "source_of_funds_plausible": plausible,
            "unusual_patterns": unusual_patterns,
        }

        explanation = assessment.get("risk_notes") or "Financial profile assessed based on available documents."

        result = AgentResult(
            agent_name=self.name,
            status=status,
            risk_score=risk_score,
            findings=findings,
            evidence=evidence,
            explanation=explanation,
            raw_data={"assessment": assessment},
        )
        self.log_audit(customer_id, result.to_dict())
        return result
