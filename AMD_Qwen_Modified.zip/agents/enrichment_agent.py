"""
enrichment_agent.py
Agent 2: Data Enrichment.

Responsibilities:
 - Enrich extracted customer profile with derived/inferred attributes
   (age from DOB, country risk classification, address geo-normalization)
 - Use LLM to normalize/standardize names, addresses, and detect country of risk
 - In production this would call external APIs (credit bureaus, company registries,
   geolocation services). Here we simulate enrichment with LLM reasoning + a
   configurable country-risk lookup.
"""

from datetime import datetime
from typing import Any, Dict, List

from .base_agent import BaseAgent, AgentResult

# A small illustrative country risk table (replace/extend with real FATF lists in production)
HIGH_RISK_COUNTRIES = {
    "iran", "north korea", "myanmar", "syria", "afghanistan", "yemen",
}
MEDIUM_RISK_COUNTRIES = {
    "russia", "pakistan", "nigeria", "venezuela", "uganda",
}

ENRICHMENT_PROMPT = """You are a KYC data-enrichment specialist.
Given the customer's extracted profile data below, produce an enriched JSON
profile with the following fields:

- normalized_full_name
- inferred_age (integer, based on date_of_birth if present, else null)
- normalized_address
- country_of_residence (best guess, derived from address/nationality)
- nationality
- profile_completeness_pct (0-100, how complete the data is)
- notes (any observations useful for compliance review)

Customer extracted data:
---
{profile_json}
---

Respond with ONLY a valid JSON object, no commentary, no markdown fences.
"""


class EnrichmentAgent(BaseAgent):
    name = "EnrichmentAgent"

    def run(self, customer_id: str, extraction_findings: Dict[str, Any]) -> AgentResult:
        extracted_data = extraction_findings.get("extracted_data", {})

        # Build a compact profile dict from identity + address proof fields
        identity_fields = extracted_data.get("identity_proof", {}).get("fields", {}) or {}
        address_fields = extracted_data.get("address_proof", {}).get("fields", {}) or {}
        business_fields = extracted_data.get("business_doc", {}).get("fields", {}) or {}

        profile_input = {
            "identity": identity_fields,
            "address": address_fields,
            "business": business_fields,
        }

        import json as _json
        prompt = ENRICHMENT_PROMPT.format(profile_json=_json.dumps(profile_input, default=str)[:6000])

        try:
            response = self.call_llm(prompt, expect_json=True)
            enriched = self.safe_json_loads(response, default={})
        except Exception as e:
            enriched = {}
            evidence_extra = [f"LLM enrichment failed: {e}"]
        else:
            evidence_extra = []

        evidence: List[str] = ["Profile enriched via LLM normalization."] + evidence_extra

        # Country risk classification
        country = (enriched.get("country_of_residence") or identity_fields.get("nationality") or "").strip().lower()
        country_risk = "low"
        if country in HIGH_RISK_COUNTRIES:
            country_risk = "high"
        elif country in MEDIUM_RISK_COUNTRIES:
            country_risk = "medium"

        enriched["country_risk_level"] = country_risk
        if country:
            evidence.append(f"Country of residence/nationality '{country}' classified as {country_risk} risk.")
        else:
            evidence.append("Country of residence could not be determined; defaulted to low risk classification.")

        # Age plausibility check
        age_flag = None
        dob = identity_fields.get("date_of_birth")
        if dob:
            try:
                dob_date = datetime.strptime(dob, "%Y-%m-%d")
                age = (datetime.now() - dob_date).days // 365
                enriched["inferred_age"] = age
                if age < 18:
                    age_flag = "Customer appears to be a minor based on DOB."
                elif age > 110:
                    age_flag = "Date of birth implies an implausible age (>110)."
                evidence.append(f"Inferred age: {age} years.")
            except Exception:
                age_flag = "Could not parse date_of_birth for age inference."

        # ------------------------------------------------------------
        # Risk scoring
        # ------------------------------------------------------------
        risk_score = 0.0
        if country_risk == "high":
            risk_score += 40
        elif country_risk == "medium":
            risk_score += 18

        completeness = enriched.get("profile_completeness_pct")
        try:
            completeness = float(completeness)
        except (TypeError, ValueError):
            completeness = 50.0
            enriched["profile_completeness_pct"] = completeness

        if completeness < 50:
            risk_score += 20
        elif completeness < 75:
            risk_score += 8

        if age_flag:
            risk_score += 30

        risk_score = min(100.0, risk_score)

        status = "success"
        if age_flag or country_risk == "high":
            status = "warning" if not age_flag else "error"
        elif country_risk == "medium" or completeness < 75:
            status = "warning"

        explanation_parts = [
            f"Country/jurisdiction risk classified as '{country_risk}'.",
            f"Profile completeness estimated at {completeness:.0f}%.",
        ]
        if age_flag:
            explanation_parts.append(age_flag)

        findings = {
            "enriched_profile": enriched,
            "country_risk_level": country_risk,
            "age_flag": age_flag,
        }

        result = AgentResult(
            agent_name=self.name,
            status=status,
            risk_score=risk_score,
            findings=findings,
            evidence=evidence,
            explanation=" ".join(explanation_parts),
            raw_data={"enriched_profile": enriched},
        )
        self.log_audit(customer_id, result.to_dict())
        return result
