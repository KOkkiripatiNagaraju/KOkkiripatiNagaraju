
"""
config.py
Modified for LOCAL Qwen2/vLLM usage.
No .env required.
"""

import os
import httpx
from openai import OpenAI

# --------------------------------------------------------------------------
# Token cache
# --------------------------------------------------------------------------
TIKTOKEN_CACHE_DIR = "./token"
os.makedirs(TIKTOKEN_CACHE_DIR, exist_ok=True)
os.environ["TIKTOKEN_CACHE_DIR"] = TIKTOKEN_CACHE_DIR

# --------------------------------------------------------------------------
# Local vLLM Configuration
# --------------------------------------------------------------------------
VLLM_BASE_URL = "http://localhost:8000/v1"

# Any string works for local vLLM
VLLM_API_KEY = "EMPTY"

# Your model
LLM_MODEL_NAME = "Qwen/Qwen2-7B-Instruct"

# --------------------------------------------------------------------------
# HTTP Client
# --------------------------------------------------------------------------
HTTP_CLIENT = httpx.Client(timeout=120.0)

# --------------------------------------------------------------------------
# OpenAI-Compatible Client
# --------------------------------------------------------------------------
client = OpenAI(
    base_url=VLLM_BASE_URL,
    api_key=VLLM_API_KEY,
    http_client=HTTP_CLIENT,
)

# --------------------------------------------------------------------------
# Compatible Local LLM Wrapper
# --------------------------------------------------------------------------
class LocalQwenLLM:

    def invoke(self, prompt):

        response = client.chat.completions.create(
            model=LLM_MODEL_NAME,
            messages=[
                {
                    "role": "system",
                    "content": "You are a KYC AI assistant."
                },
                {
                    "role": "user",
                    "content": str(prompt)
                }
            ],
            temperature=0.1,
            max_tokens=1024,
        )

        return response.choices[0].message.content


# Shared instances for old code compatibility
llm = LocalQwenLLM()
llm_creative = LocalQwenLLM()

# --------------------------------------------------------------------------
# Application Settings
# --------------------------------------------------------------------------
UPLOAD_DIR = "./uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

# --------------------------------------------------------------------------
# Document Categories
# --------------------------------------------------------------------------
DOCUMENT_CATEGORIES = {
    "identity_proof": {
        "label": "Identity Proof",
        "accepted": ["Passport", "Government ID", "Driving License"],
        "required": True,
    },
    "address_proof": {
        "label": "Address Proof",
        "accepted": ["Government Utility Bill", "Aadhaar", "Bank Statement"],
        "required": True,
    },
    "live_photo": {
        "label": "Live Captured Photo",
        "accepted": ["Live selfie / webcam capture"],
        "required": True,
    },
    "business_doc": {
        "label": "Business Document",
        "accepted": [
            "Tax Invoice",
            "Business Registration",
            "Lease Agreement"
        ],
        "required": False,
    },
}

# --------------------------------------------------------------------------
# Risk Thresholds
# --------------------------------------------------------------------------
RISK_THRESHOLDS = {
    "approve_max": 30,
    "review_max": 65,
}

# --------------------------------------------------------------------------
# Agent Weights
# --------------------------------------------------------------------------
AGENT_WEIGHTS = {
    "identity_verification": 0.22,
    "registry_verification": 0.20,
    "compliance_screening": 0.28,
    "financial_profile": 0.16,
    "data_extraction_quality": 0.14,
}

# --------------------------------------------------------------------------
# Mock Watchlist
# --------------------------------------------------------------------------
MOCK_WATCHLIST = [
    {
        "name": "John Doe",
        "type": "Sanctions",
        "list": "OFAC SDN",
        "country": "N/A"
    },
    {
        "name": "Jane Smith",
        "type": "PEP",
        "list": "Politically Exposed Person",
        "country": "N/A"
    },
]

# --------------------------------------------------------------------------
# Face Verification
# --------------------------------------------------------------------------
FACE_MATCH_THRESHOLD = 0.35

# --------------------------------------------------------------------------
# Logging
# --------------------------------------------------------------------------
LOG_DIR = "./logs"
os.makedirs(LOG_DIR, exist_ok=True)

AUDIT_LOG_FILE = os.path.join(
    LOG_DIR,
    "audit_trail.jsonl"
)
