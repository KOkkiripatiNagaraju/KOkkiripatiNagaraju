"""
Agentic KYC Intelligence Platform - Streamlit Frontend.

Multi-agent, AMD-orchestrated end-to-end customer due diligence:
 - Document upload (identity, address, live photo, business docs)
 - Portrait photo is AUTO-EXTRACTED from the identity document —
   no separate "Photo on ID" upload required from the user.
 - Pipeline execution with live agent-by-agent progress
 - Explainable KYC decision (APPROVE / REVIEW / ESCALATE) with full evidence
 - Human-in-the-loop override & audit trail viewer

Change log:
 - Removed `photo_on_id_proof` / "Photo on ID" file uploader entirely.
 - `build_documents_dict()` now skips any category whose key contains
   "photo_id" or "photo_on_id" so the change is config-driven.
 - Added an info banner on the New Onboarding page explaining the
   auto-extraction behaviour to the operator/reviewer.
 - Required-document validation guard updated to exclude the removed category.
 - About page copy updated to reflect automatic portrait extraction.
"""

import json
import os
import uuid
from datetime import datetime

import pandas as pd
import streamlit as st

from config import DOCUMENT_CATEGORIES, AUDIT_LOG_FILE, RISK_THRESHOLDS
from agents import KYCOrchestrator

# --------------------------------------------------------------------------
# Page config & styling
# --------------------------------------------------------------------------
st.set_page_config(
    page_title="Agentic KYC Intelligence Platform",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded",
)

DECISION_COLORS = {
    "APPROVE": "#1f9d55",
    "REVIEW": "#d97706",
    "ESCALATE": "#dc2626",
}

STATUS_ICONS = {
    "success": "✅",
    "warning": "⚠️",
    "error": "❌",
}

CUSTOM_CSS = """
<style>
.decision-badge {
    display: inline-block;
    padding: 0.5rem 1.25rem;
    border-radius: 0.5rem;
    font-weight: 700;
    font-size: 1.4rem;
    color: white;
    text-align: center;
}
.agent-card {
    border: 1px solid #e5e7eb;
    border-radius: 0.5rem;
    padding: 1rem;
    margin-bottom: 0.75rem;
    background-color: #fafafa;
}
.evidence-item {
    font-size: 0.9rem;
    margin: 0.15rem 0;
}
.metric-box {
    border: 1px solid #e5e7eb;
    border-radius: 0.5rem;
    padding: 0.75rem;
    text-align: center;
}
</style>
"""
st.markdown(CUSTOM_CSS, unsafe_allow_html=True)

# --------------------------------------------------------------------------
# Keys that must NEVER appear as file uploaders — portrait is auto-extracted
# --------------------------------------------------------------------------
_AUTO_EXTRACTED_CATEGORIES = {"photo_on_id_proof", "photo_id", "photo_on_id"}


def _is_auto_extracted(category_key: str) -> bool:
    """Return True for categories whose content is derived, not uploaded."""
    return category_key.lower() in _AUTO_EXTRACTED_CATEGORIES


def _is_live_capture(category_key: str, label: str) -> bool:
    """Return True for categories that require a live camera capture."""
    live_keys = {"live_photo", "selfie", "live_selfie", "liveness"}
    return (
        category_key.lower() in live_keys
        or "live" in label.lower()
        or "selfie" in label.lower()
        or "photo verification" in label.lower()
    )


# --------------------------------------------------------------------------
# Session state init
# --------------------------------------------------------------------------
if "orchestrator" not in st.session_state:
    st.session_state.orchestrator = KYCOrchestrator()
if "report" not in st.session_state:
    st.session_state.report = None
if "customer_id" not in st.session_state:
    st.session_state.customer_id = f"CUST-{uuid.uuid4().hex[:8].upper()}"
if "pipeline_log" not in st.session_state:
    st.session_state.pipeline_log = []

# --------------------------------------------------------------------------
# Sidebar - navigation & customer info
# --------------------------------------------------------------------------
with st.sidebar:
    st.title("🛡️ Agentic KYC Platform")
    st.caption("AMD-orchestrated multi-agent due diligence")

    page = st.radio(
        "Navigate",
        ["📤 New Onboarding", "📊 Decision Report", "🗂️ Audit Trail", "ℹ️ About"],
        index=0,
    )

    st.divider()
    st.text_input("Customer ID", key="customer_id")

    st.divider()
    st.caption("Decision Thresholds")
    st.write(f"APPROVE: score ≤ {RISK_THRESHOLDS['approve_max']}")
    st.write(f"REVIEW: ≤ {RISK_THRESHOLDS['review_max']}")
    st.write(f"ESCALATE: > {RISK_THRESHOLDS['review_max']}")

# --------------------------------------------------------------------------
# Helper: file uploader → bytes dict
# --------------------------------------------------------------------------
def build_documents_dict() -> dict:
    """
    Render upload / camera widgets for each document category and return a
    dict keyed by category name.

    Categories in `_AUTO_EXTRACTED_CATEGORIES` are silently skipped — their
    content is derived automatically inside the Identity Verification Agent
    (portrait extracted from the identity_proof document).
    """
    documents = {}

    for category, meta in DOCUMENT_CATEGORIES.items():

        # ── Skip auto-extracted categories — no uploader shown ────────────
        if _is_auto_extracted(category):
            continue

        required_label = " *(required)*" if meta["required"] else " *(optional)*"
        st.markdown(f"**{meta['label']}**{required_label}")

        col1, col2 = st.columns([2, 1])

        with col2:
            subtype = st.selectbox(
                "Type",
                meta["accepted"],
                key=f"subtype_{category}",
                label_visibility="collapsed",
            )

        with col1:
            if _is_live_capture(category, meta["label"]):
                # Live camera capture — uploads disabled for liveness assurance
                st.info("📷 Live capture required — file uploads disabled for security.")
                captured = st.camera_input(
                    f"Capture {meta['label']}",
                    key=f"camera_{category}",
                    help="Click 'Take Photo' to enable your camera.",
                )
                if captured is not None:
                    file_bytes = captured.getvalue()
                    documents[category] = {
                        "filename": (
                            f"{category}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.jpg"
                        ),
                        "bytes": file_bytes,
                        "doc_subtype": subtype,
                        "mimetype": "image/jpeg",
                    }
                    st.success("✓ Live photo captured.")

            else:
                # Standard file upload for identity / address / business docs
                uploaded_file = st.file_uploader(
                    f"Upload {meta['label']}",
                    type=["pdf", "png", "jpg", "jpeg", "bmp", "tiff", "webp"],
                    key=f"upload_{category}",
                    label_visibility="collapsed",
                )
                if uploaded_file is not None:
                    file_bytes = uploaded_file.getvalue()
                    documents[category] = {
                        "filename": uploaded_file.name,
                        "bytes": file_bytes,
                        "doc_subtype": subtype,
                        "mimetype": uploaded_file.type or "",
                    }
                    if uploaded_file.type and "image" in uploaded_file.type:
                        st.image(file_bytes, width=180)
                    else:
                        st.caption(
                            f"📄 {uploaded_file.name} "
                            f"({len(file_bytes) / 1024:.1f} KB)"
                        )

        st.markdown("---")

    return documents


# --------------------------------------------------------------------------
# PAGE: New Onboarding
# --------------------------------------------------------------------------
if page == "📤 New Onboarding":
    st.header("New Customer Onboarding")
    st.write(
        "Upload the customer's documents below. The AMD orchestrator will route "
        "them through the specialised KYC agent pipeline: data extraction, "
        "enrichment, identity verification, compliance screening, and financial profiling."
    )

    # ── Auto-extraction notice ─────────────────────────────────────────────
    st.info(
        "🤖 **Portrait auto-extraction enabled** — the Identity Verification Agent "
        "will automatically detect and extract the portrait photo embedded in the "
        "Identity Proof document. No separate 'Photo on ID' upload is required.",
        icon="ℹ️",
    )

    documents = build_documents_dict()

    submitted = st.button(
        "🚀 Run KYC Pipeline", use_container_width=True, type="primary"
    )

    if submitted:
        # Validate required documents (photo_on_id excluded — it's auto-derived)
        missing_required = [
            meta["label"]
            for cat, meta in DOCUMENT_CATEGORIES.items()
            if meta["required"]
            and not _is_auto_extracted(cat)
            and cat not in documents
        ]
        if missing_required:
            st.error(f"Missing required documents: {', '.join(missing_required)}")
        else:
            st.session_state.pipeline_log = []
            progress_bar = st.progress(0, text="Starting AMD orchestration…")
            steps_total = 6
            step_counter = {"n": 0}

            log_container = st.container()

            def progress_callback(step_name, agent_result):
                step_counter["n"] += 1
                pct = int((step_counter["n"] / steps_total) * 100)
                progress_bar.progress(pct, text=f"Completed: {step_name}")
                icon = STATUS_ICONS.get(agent_result.status, "ℹ️")
                st.session_state.pipeline_log.append(
                    (step_name, agent_result.status, agent_result.risk_score)
                )
                with log_container:
                    st.write(
                        f"{icon} **{step_name}** — "
                        f"risk score: {agent_result.risk_score:.1f} — "
                        f"{agent_result.explanation}"
                    )

            with st.spinner("Running multi-agent KYC pipeline…"):
                report = st.session_state.orchestrator.run_pipeline(
                    customer_id=st.session_state.customer_id,
                    documents=documents,
                    progress_callback=progress_callback,
                )
            st.session_state.report = report
            progress_bar.progress(100, text="Pipeline complete.")
            st.success(
                "KYC pipeline completed. "
                "Go to '📊 Decision Report' to review the explainable decision."
            )

# --------------------------------------------------------------------------
# PAGE: Decision Report
# --------------------------------------------------------------------------
elif page == "📊 Decision Report":
    st.header("Explainable KYC Decision Report")

    report = st.session_state.report
    if not report:
        st.info("No report yet. Run a new onboarding from '📤 New Onboarding'.")
    else:
        decision = report.get("final_decision", report["decision"])
        color = DECISION_COLORS.get(decision, "#6b7280")

        col1, col2, col3 = st.columns([1.2, 1, 1])
        with col1:
            st.markdown(
                f"<div class='decision-badge' style='background-color:{color};'>"
                f"{decision}</div>",
                unsafe_allow_html=True,
            )
        with col2:
            st.markdown(
                f"<div class='metric-box'><b>Composite Risk Score</b><br>"
                f"<span style='font-size:1.5rem;'>"
                f"{report['composite_risk_score']:.1f} / 100</span></div>",
                unsafe_allow_html=True,
            )
        with col3:
            st.markdown(
                f"<div class='metric-box'><b>Customer ID</b><br>"
                f"<span style='font-size:1.1rem;'>{report['customer_id']}</span></div>",
                unsafe_allow_html=True,
            )

        st.markdown("### 🧭 AMD Final Explanation")
        st.write(report["final_explanation"])

        st.markdown("### 🤖 Agent-by-Agent Findings")
        for label, agent_data in report["agent_results"].items():
            icon = STATUS_ICONS.get(agent_data["status"], "ℹ️")
            with st.expander(
                f"{icon} {agent_data['agent_name']}  —  "
                f"risk: {agent_data['risk_score']:.1f}/100"
            ):
                st.write(f"**Explanation:** {agent_data['explanation']}")

                # Surface face extraction status badge if present
                face_ext = agent_data.get("findings", {}).get("face_extraction_status")
                if face_ext:
                    badge_color = "#1f9d55" if face_ext == "success" else "#dc2626"
                    st.markdown(
                        f"<span style='background:{badge_color};color:white;"
                        f"padding:2px 8px;border-radius:4px;font-size:0.8rem;'>"
                        f"Portrait extraction: {face_ext}</span>",
                        unsafe_allow_html=True,
                    )

                st.write("**Evidence:**")
                for ev in agent_data["evidence"]:
                    st.markdown(
                        f"<div class='evidence-item'>• {ev}</div>",
                        unsafe_allow_html=True,
                    )
                with st.popover("View raw findings (JSON)"):
                    st.json(agent_data["findings"])

        st.markdown("### 📈 Risk Score Breakdown")
        chart_data = pd.DataFrame({
            "Agent": [v["agent_name"] for v in report["agent_results"].values()],
            "Risk Score": [v["risk_score"] for v in report["agent_results"].values()],
        })
        st.bar_chart(chart_data.set_index("Agent"))

        st.markdown("### 👤 Human-in-the-Loop Override")
        if report.get("human_override"):
            ho = report["human_override"]
            st.success(
                f"Reviewed by {ho['reviewer']} at {ho['timestamp']} "
                f"→ Final decision: **{ho['decision']}**"
            )
            st.caption(f"Comment: {ho['comment']}")
        else:
            with st.form("override_form"):
                reviewer = st.text_input("Reviewer name")
                override_decision = st.selectbox(
                    "Override decision",
                    ["APPROVE", "REVIEW", "ESCALATE"],
                    index=["APPROVE", "REVIEW", "ESCALATE"].index(decision),
                )
                comment = st.text_area("Reviewer comment / rationale")
                override_submitted = st.form_submit_button("Submit Review Decision")

            if override_submitted:
                if not reviewer:
                    st.error("Please enter a reviewer name.")
                else:
                    updated = st.session_state.orchestrator.apply_human_override(
                        report, reviewer, override_decision, comment
                    )
                    st.session_state.report = updated
                    st.rerun()

        st.markdown("### 📥 Export")
        report_json = json.dumps(report, indent=2, default=str)
        st.download_button(
            "Download Full Report (JSON)",
            data=report_json,
            file_name=f"kyc_report_{report['customer_id']}.json",
            mime="application/json",
        )

# --------------------------------------------------------------------------
# PAGE: Audit Trail
# --------------------------------------------------------------------------
elif page == "🗂️ Audit Trail":
    st.header("Audit Trail")
    st.write(
        "Append-only log of every agent action, decision, and human override — "
        "for explainability and compliance."
    )

    if not os.path.exists(AUDIT_LOG_FILE):
        st.info("No audit log entries yet.")
    else:
        records = []
        with open(AUDIT_LOG_FILE, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    records.append(json.loads(line))
                except json.JSONDecodeError:
                    continue

        if not records:
            st.info("No audit log entries yet.")
        else:
            df = pd.DataFrame([
                {
                    "Timestamp": r.get("timestamp"),
                    "Agent": r.get("agent"),
                    "Customer ID": r.get("customer_id"),
                    "Status": r.get("payload", {}).get("status", ""),
                    "Risk Score": r.get("payload", {}).get("risk_score", ""),
                    "Decision": r.get("payload", {}).get(
                        "decision",
                        r.get("payload", {}).get("composite_risk_score", ""),
                    ),
                }
                for r in records
            ])
            st.dataframe(df, use_container_width=True, height=400)

            with st.expander("View raw log entries"):
                for r in reversed(records[-50:]):
                    st.json(r)

# --------------------------------------------------------------------------
# PAGE: About
# --------------------------------------------------------------------------
elif page == "ℹ️ About":
    st.header("About this Platform")
    st.markdown("""
**Agentic KYC Intelligence Platform** demonstrates a multi-agent architecture
for end-to-end customer due diligence, orchestrated by an AMD (Agent Master / Director).

**Pipeline:**
1. **Data & Document Extraction Agent** — OCR + LLM extraction of structured fields from
   identity proof, address proof, and business documents; cross-document consistency checks.
2. **Enrichment Agent** — Normalizes profile data, classifies country/jurisdiction risk,
   checks age plausibility, and computes profile completeness.
3. **Identity Verification Agent** — **Automatically extracts** the portrait photo embedded
   in the identity document (Passport, Aadhaar, Driving Licence, etc.) using OpenCV face
   detection, then compares it against the live captured photo. No separate "Photo on ID"
   upload is required. Also validates document expiry and runs an LLM-based authenticity review.
4. **Compliance Screening Agent** — Screens the customer name against sanctions / PEP /
   adverse media watchlists with fuzzy matching and LLM-assisted true/false-positive analysis.
5. **Financial Profile Agent** — Assesses source-of-funds plausibility and flags unusual
   financial patterns from bank statements / business documents.

**Decision Layer (AMD):** Aggregates weighted risk scores from all agents into a composite
score (0–100), applies configurable thresholds to produce **APPROVE / REVIEW / ESCALATE**,
and generates a plain-language explanation for human reviewers.

**Human Oversight:** Every decision can be reviewed and overridden by a compliance officer,
with the override recorded in the immutable audit trail.

**Explainability:** Every agent records evidence statements and structured findings,
all persisted to an append-only JSONL audit log (`logs/audit_trail.jsonl`).
""")
    st.caption(
        "Built for hackathon demo purposes. Replace mock watchlists, country-risk tables, "
        "and face-matching with production-grade services before real-world use."
    )