"""
admin.py
Admin panel (Streamlit) for managing the mock "DigiLocker-style" identity
registry database (db/users_db.json).

Allows an administrator to:
 - Browse / search all registry records
 - View a single record's full details
 - Add a new record
 - Update / edit an existing record
 - Delete a record
 - Toggle PEP / Sanctioned / Risk flags quickly
 - Export the database as JSON

Run:  streamlit run admin.py
(Run on a different port than main.py if running both simultaneously, e.g.:
 streamlit run admin.py --server.port 8502)
"""

import json

import pandas as pd
import streamlit as st

from db import (
    list_users,
    get_user,
    add_user,
    update_user,
    delete_user,
    replace_user,
    load_db,
)

st.set_page_config(
    page_title="KYC Registry Admin",
    page_icon="🗄️",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown("""
<style>
.admin-badge {
    display: inline-block;
    padding: 0.15rem 0.6rem;
    border-radius: 0.35rem;
    font-size: 0.8rem;
    font-weight: 600;
    color: white;
    margin-right: 0.3rem;
}
</style>
""", unsafe_allow_html=True)


# --------------------------------------------------------------------------
# Sidebar navigation
# --------------------------------------------------------------------------
with st.sidebar:
    st.title("🗄️ KYC Registry Admin")
    st.caption("Manage the mock DigiLocker-style identity registry")
    page = st.radio(
        "Navigate",
        ["📋 Browse Records", "➕ Add Record", "✏️ Edit / Delete Record", "📤 Export / Raw DB"],
        index=0,
    )
    st.divider()
    db_preview = load_db()
    st.metric("Total Records", len(db_preview))
    st.metric("PEP Flagged", sum(1 for r in db_preview.values() if r.get("is_pep")))
    st.metric("Sanctioned", sum(1 for r in db_preview.values() if r.get("is_sanctioned")))
    st.metric("Risk Flagged", sum(1 for r in db_preview.values() if r.get("risk_flag")))


# --------------------------------------------------------------------------
# Helper: render record form, returns a dict of values
# --------------------------------------------------------------------------
def record_form(prefix: str, existing: dict = None):
    existing = existing or {}
    address = existing.get("address", {}) or {}
    business = existing.get("business", {}) or {}
    income = existing.get("income", {}) or {}

    st.markdown("##### Identity Documents")
    c1, c2 = st.columns(2)
    with c1:
        aadhaar = st.text_input("Aadhaar", value=existing.get("aadhaar") or "", key=f"{prefix}_aadhaar")
        passport = st.text_input("Passport", value=existing.get("passport") or "", key=f"{prefix}_passport")
    with c2:
        pan = st.text_input("PAN", value=existing.get("pan") or "", key=f"{prefix}_pan")
        dl = st.text_input("Driving Licence", value=existing.get("driving_licence") or "", key=f"{prefix}_dl")

    st.markdown("##### Personal Details")
    c1, c2, c3 = st.columns(3)
    with c1:
        name = st.text_input("Full Name", value=existing.get("name") or "", key=f"{prefix}_name")
        nationality = st.text_input("Nationality", value=existing.get("nationality") or "Indian", key=f"{prefix}_nationality")
    with c2:
        dob = st.text_input("Date of Birth (YYYY-MM-DD)", value=existing.get("dob") or "", key=f"{prefix}_dob")
        gender = st.selectbox(
            "Gender", ["Male", "Female", "Other"],
            index=["Male", "Female", "Other"].index(existing.get("gender")) if existing.get("gender") in ["Male", "Female", "Other"] else 0,
            key=f"{prefix}_gender",
        )
    with c3:
        phone = st.text_input("Phone", value=existing.get("phone") or "", key=f"{prefix}_phone")
        email = st.text_input("Email", value=existing.get("email") or "", key=f"{prefix}_email")

    st.markdown("##### Address")
    c1, c2, c3, c4, c5 = st.columns(5)
    with c1:
        line1 = st.text_input("Address Line 1", value=address.get("line1") or "", key=f"{prefix}_line1")
    with c2:
        city = st.text_input("City", value=address.get("city") or "", key=f"{prefix}_city")
    with c3:
        state = st.text_input("State", value=address.get("state") or "", key=f"{prefix}_state")
    with c4:
        pin = st.text_input("PIN", value=address.get("pin") or "", key=f"{prefix}_pin")
    with c5:
        country = st.text_input("Country", value=address.get("country") or "India", key=f"{prefix}_country")

    st.markdown("##### Business Details (optional)")
    c1, c2, c3, c4, c5 = st.columns(5)
    with c1:
        cin = st.text_input("CIN", value=business.get("cin") or "", key=f"{prefix}_cin")
    with c2:
        gst = st.text_input("GST", value=business.get("gst") or "", key=f"{prefix}_gst")
    with c3:
        tan = st.text_input("TAN", value=business.get("tan") or "", key=f"{prefix}_tan")
    with c4:
        biz_name = st.text_input("Business Name", value=business.get("name") or "", key=f"{prefix}_bizname")
    with c5:
        biz_types = ["", "Pvt Ltd", "LLP", "Proprietorship", "Partnership"]
        existing_type = business.get("type") or ""
        biz_type = st.selectbox(
            "Business Type", biz_types,
            index=biz_types.index(existing_type) if existing_type in biz_types else 0,
            key=f"{prefix}_biztype",
        )

    st.markdown("##### Income / Employment")
    c1, c2, c3 = st.columns(3)
    with c1:
        annual = st.number_input(
            "Annual Declared Income", min_value=0,
            value=int(income.get("annual_declared") or 0), step=10000, key=f"{prefix}_annual",
        )
    with c2:
        employer = st.text_input("Employer", value=income.get("employer") or "", key=f"{prefix}_employer")
    with c3:
        emp_types = ["", "Salaried", "Business", "Self-Employed", "Unemployed", "Retired"]
        existing_emp = income.get("employment_type") or ""
        emp_type = st.selectbox(
            "Employment Type", emp_types,
            index=emp_types.index(existing_emp) if existing_emp in emp_types else 0,
            key=f"{prefix}_emptype",
        )

    st.markdown("##### Compliance Flags")
    c1, c2, c3 = st.columns(3)
    with c1:
        is_pep = st.checkbox("Politically Exposed Person (PEP)", value=bool(existing.get("is_pep", False)), key=f"{prefix}_pep")
    with c2:
        is_sanctioned = st.checkbox("Sanctioned", value=bool(existing.get("is_sanctioned", False)), key=f"{prefix}_sanctioned")
    with c3:
        risk_flag = st.checkbox("General Risk Flag", value=bool(existing.get("risk_flag", False)), key=f"{prefix}_riskflag")

    record = {
        "aadhaar": aadhaar or None,
        "pan": pan or None,
        "passport": passport or None,
        "driving_licence": dl or None,
        "name": name or None,
        "dob": dob or None,
        "gender": gender,
        "address": {
            "line1": line1 or None,
            "city": city or None,
            "state": state or None,
            "pin": pin or None,
            "country": country or None,
        },
        "nationality": nationality or None,
        "phone": phone or None,
        "email": email or None,
        "business": {
            "cin": cin or None,
            "gst": gst or None,
            "tan": tan or None,
            "name": biz_name or None,
            "type": biz_type or None,
        },
        "income": {
            "annual_declared": annual,
            "employer": employer or None,
            "employment_type": emp_type or None,
        },
        "is_pep": is_pep,
        "is_sanctioned": is_sanctioned,
        "risk_flag": risk_flag,
    }
    return record


# --------------------------------------------------------------------------
# PAGE: Browse Records
# --------------------------------------------------------------------------
if page == "📋 Browse Records":
    st.header("Browse Identity Registry Records")

    db = load_db()
    search = st.text_input("🔍 Search by name, ID number, email, or phone")

    rows = []
    for rid, rec in list_users(db):
        rows.append({
            "ID": rid,
            "Name": rec.get("name"),
            "Aadhaar": rec.get("aadhaar"),
            "PAN": rec.get("pan"),
            "Passport": rec.get("passport"),
            "DL": rec.get("driving_licence"),
            "DOB": rec.get("dob"),
            "City": (rec.get("address") or {}).get("city"),
            "Phone": rec.get("phone"),
            "Email": rec.get("email"),
            "PEP": "🟡" if rec.get("is_pep") else "",
            "Sanctioned": "🔴" if rec.get("is_sanctioned") else "",
            "Risk": "⚠️" if rec.get("risk_flag") else "",
        })

    df = pd.DataFrame(rows)

    if search:
        s = search.strip().lower()
        mask = df.apply(lambda row: row.astype(str).str.lower().str.contains(s).any(), axis=1)
        df = df[mask]

    st.dataframe(df, use_container_width=True, height=500)
    st.caption(f"Showing {len(df)} of {len(rows)} records.")


# --------------------------------------------------------------------------
# PAGE: Add Record
# --------------------------------------------------------------------------
elif page == "➕ Add Record":
    st.header("Add New Registry Record")

    with st.form("add_record_form"):
        custom_id = st.text_input("Record ID (leave blank to auto-assign next available integer)")
        record = record_form("add")
        submitted = st.form_submit_button("➕ Add Record", type="primary")

    if submitted:
        if not record.get("name"):
            st.error("Name is required.")
        else:
            try:
                rid = add_user(record, record_id=custom_id.strip() or None)
                st.success(f"Record added with ID '{rid}'.")
                st.json(get_user(rid))
            except ValueError as e:
                st.error(str(e))


# --------------------------------------------------------------------------
# PAGE: Edit / Delete Record
# --------------------------------------------------------------------------
elif page == "✏️ Edit / Delete Record":
    st.header("Edit or Delete a Registry Record")

    db = load_db()
    record_ids = [rid for rid, _ in list_users(db)]

    if not record_ids:
        st.info("No records in the database yet.")
    else:
        selected_id = st.selectbox("Select Record ID", record_ids)
        existing = get_user(selected_id, db)

        if existing:
            with st.form("edit_record_form"):
                updated_record = record_form("edit", existing)
                col1, col2 = st.columns(2)
                with col1:
                    save_submitted = st.form_submit_button("💾 Save Changes", type="primary", use_container_width=True)
                with col2:
                    delete_submitted = st.form_submit_button("🗑️ Delete Record", use_container_width=True)

            if save_submitted:
                replace_user(selected_id, updated_record)
                st.success(f"Record '{selected_id}' updated.")
                st.json(get_user(selected_id))

            if delete_submitted:
                delete_user(selected_id)
                st.success(f"Record '{selected_id}' deleted.")
                st.rerun()

            st.divider()
            st.markdown("##### Quick Flag Toggles")
            c1, c2, c3 = st.columns(3)
            with c1:
                if st.button(("Unflag" if existing.get("is_pep") else "Flag") + " as PEP", use_container_width=True):
                    update_user(selected_id, {"is_pep": not existing.get("is_pep", False)})
                    st.rerun()
            with c2:
                if st.button(("Unflag" if existing.get("is_sanctioned") else "Flag") + " as Sanctioned", use_container_width=True):
                    update_user(selected_id, {"is_sanctioned": not existing.get("is_sanctioned", False)})
                    st.rerun()
            with c3:
                if st.button(("Unflag" if existing.get("risk_flag") else "Flag") + " as Risk", use_container_width=True):
                    update_user(selected_id, {"risk_flag": not existing.get("risk_flag", False)})
                    st.rerun()


# --------------------------------------------------------------------------
# PAGE: Export / Raw DB
# --------------------------------------------------------------------------
elif page == "📤 Export / Raw DB":
    st.header("Export / Raw Database View")

    db = load_db()
    st.download_button(
        "Download users_db.json",
        data=json.dumps(db, indent=2, ensure_ascii=False),
        file_name="users_db.json",
        mime="application/json",
    )

    with st.expander("View raw JSON", expanded=False):
        st.json(db)
