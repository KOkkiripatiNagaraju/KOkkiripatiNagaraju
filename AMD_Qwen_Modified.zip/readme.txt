# Agentic KYC Intelligence Platform

A multi-agent, AMD-orchestrated platform for end-to-end customer due diligence:
data extraction, enrichment, identity verification, compliance screening,
financial profiling, and explainable decisioning with human oversight.

## Architecture

```
Customer Onboarding Request
        │
        ▼
 ┌─────────────────────────┐
 │   AMD Orchestrator       │   (agents/orchestrator.py)
 └─────────────────────────┘
        │
   ┌────┼────────────────────────────────────────────────┐
   ▼    ▼               ▼                ▼                ▼
 Data   Enrichment   Identity        Compliance      Financial
 Extract Agent       Verification    Screening       Profile
 Agent               Agent           Agent           Agent
   │       │              │               │                │
   └───────┴──────────────┴───────────────┴────────────────┘
                          │
                          ▼
        Composite Risk Score → APPROVE / REVIEW / ESCALATE
                          │
                          ▼
            Explainable Report + Evidence Trail
                          │
                          ▼
              Human-in-the-loop Override (Streamlit UI)
                          │
                          ▼
              Append-only Audit Log (logs/audit_trail.jsonl)
```

## Project Structure

```
kyc_platform/
├── main.py                      # Streamlit application (entry point)
├── config.py                    # LLM/embedding config, thresholds, watchlist, doc categories
├── req.txt                      # Python dependencies
├── readme.txt                   # This file
├── admin.py                      # Streamlit admin panel for the mock identity registry DB
├── agents/
│   ├── __init__.py
│   ├── base_agent.py            # Shared AgentResult + BaseAgent (LLM calls, audit logging)
│   ├── doc_utils.py              # OCR, PDF parsing, face comparison, image quality checks
│   ├── data_extraction_agent.py  # Agent 1: document parsing & cross-checks
│   ├── enrichment_agent.py       # Agent 2: profile normalization & country risk
│   ├── identity_verification_agent.py  # Agent 3: face match, expiry, authenticity
│   ├── registry_verification_agent.py  # Agent 4: cross-check vs mock DigiLocker registry
│   ├── screening_agent.py        # Agent 5: sanctions/PEP/adverse media screening
│   ├── financial_profile_agent.py# Agent 6: source-of-funds & financial behavior
│   └── orchestrator.py           # AMD: pipeline coordination + composite scoring + decision
├── db/
│   ├── __init__.py
│   ├── db_manager.py             # CRUD + registry verification helper functions
│   ├── generate_dummy_db.py       # One-off script to (re)generate users_db.json
│   └── users_db.json              # Mock "DigiLocker-style" identity registry (36 sample records)
├── uploads/                       # (runtime) uploaded documents, if persisted
└── logs/
    └── audit_trail.jsonl          # (runtime) append-only audit log
```

## Setup

1. **Python environment** (Python 3.10+ recommended):

```bash
python -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r req.txt
```

2. **System dependencies** (for OCR and PDF/image processing):

- **Tesseract OCR** (required for `pytesseract`):
  - Ubuntu/Debian: `sudo apt-get install tesseract-ocr`
  - macOS: `brew install tesseract`
  - Windows: install from https://github.com/UB-Mannheim/tesseract/wiki and add to PATH

- **OpenCV** is installed via `opencv-python-headless` (no extra system deps needed
  on most platforms).

3. **Configure API credentials**

Edit `config.py` or set environment variables:

```bash
export GENAI_BASE_URL="https://genailab.tcs.in"
export GENAI_API_KEY="YOUR_REAL_API_KEY"
export LLM_MODEL_NAME="azure_ai/genailab-maas-DeepSeek-V3-0324"
export EMBEDDING_MODEL_NAME="azure/genailab-maas-text-embedding-3-large"
```

> ⚠️ Never commit real API keys to source control. Use environment variables
> or a secrets manager in production.

## Running the App

```bash
streamlit run main.py
```

Open the URL shown (typically http://localhost:8501).

## Using the Platform

1. **New Onboarding tab**:
   - Upload required documents:
     - **Identity Proof**: Passport / Government ID / Driving License
     - **Address Proof**: Government Utility Bill / Aadhaar / Bank Statement
     - **Photo on ID Proof**: cropped/extracted photo from the ID document
     - **Live Captured Photo**: live selfie/webcam capture
     - **Business Document** (optional): Tax Invoice / Business Registration / Lease Agreement
   - Click **"Run KYC Pipeline"**. Each agent runs sequentially with live progress
     and intermediate risk scores shown.

2. **Decision Report tab**:
   - View the composite risk score, final decision (APPROVE / REVIEW / ESCALATE),
     and an AMD-generated plain-language explanation.
   - Expand each agent's card to see detailed evidence and raw findings (JSON).
   - View a bar chart comparing each agent's risk contribution.
   - **Human-in-the-loop**: a compliance reviewer can submit a final override
     decision with a comment, recorded permanently in the audit trail.
   - Export the full report as JSON.

3. **Audit Trail tab**:
   - View the complete append-only log of every agent action and decision
     across all customers/sessions, sourced from `logs/audit_trail.jsonl`.

## Configuration & Tuning (config.py)

- `DOCUMENT_CATEGORIES` — document types accepted, labels, and required/optional flags.
- `RISK_THRESHOLDS` — composite score cutoffs for APPROVE / REVIEW / ESCALATE.
- `AGENT_WEIGHTS` — weight of each agent's risk score in the composite calculation.
- `MOCK_WATCHLIST` — sample sanctions/PEP/adverse-media list (replace with real
  data feeds, e.g. OFAC, UN, EU consolidated lists, Dow Jones, Refinitiv, etc.).
- `FACE_MATCH_THRESHOLD` — minimum face similarity (0-1) to pass identity verification.
- `HIGH_RISK_COUNTRIES` / `MEDIUM_RISK_COUNTRIES` (in `enrichment_agent.py`) —
  jurisdiction risk classification; replace with FATF grey/black lists in production.

## Mock Identity Registry ("DigiLocker") & Admin Panel

The platform includes a **mock government identity registry** (`db/users_db.json`)
containing 36 sample records (Aadhaar, PAN, Passport, Driving Licence, name, DOB,
address, business details, income/employment, and PEP/sanctions/risk flags).

### Registry Verification Agent

A dedicated **Registry Verification Agent** (`agents/registry_verification_agent.py`)
cross-checks the customer's extracted identity-document fields (ID number, name,
DOB, nationality) against this registry:

- **`genuine`** — matched record found and all compared fields agree.
- **`mismatch`** — a record was matched but one or more fields (name/DOB/nationality)
  differ from the official record.
- **`not_found`** — no matching record exists for the submitted ID number/name,
  signaling a potentially **fake or unregistered identity** (high risk, forces escalation).

It also surfaces any pre-existing `is_pep`, `is_sanctioned`, or `risk_flag` markers
on the matched registry record.

### Admin Panel (`admin.py`)

Run a separate Streamlit app to manage the registry:

```bash
streamlit run admin.py --server.port 8502
```

Features:
- **Browse Records** — searchable table of all registry entries with PEP/Sanctions/Risk indicators.
- **Add Record** — create a new identity record (auto-assigns the next integer ID, or specify a custom ID).
- **Edit / Delete Record** — full edit form for any record, plus quick-toggle buttons for PEP/Sanctioned/Risk flags, and delete.
- **Export / Raw DB** — download `users_db.json` or inspect it as raw JSON.

### Regenerating the dummy database

```bash
python db/generate_dummy_db.py
```

This regenerates `db/users_db.json` with 36 records: 30 random "clean" customers,
plus several pre-flagged records for testing (a PEP match, a sanctioned match,
an adverse-media match, a minor for age-plausibility checks, and an incomplete record).

## Production Hardening Checklist

- [ ] Replace the heuristic histogram-based face comparison (`doc_utils.compare_faces`)
      with a dedicated face-recognition model/service (e.g. AWS Rekognition, Azure Face API,
      or an open-source face-embedding model like ArcFace/FaceNet).
- [ ] Replace `MOCK_WATCHLIST` with live sanctions/PEP/adverse-media data providers.
- [ ] Add persistent storage (database) for customer records, documents, and reports
      instead of in-memory session state.
- [ ] Add authentication/authorization for reviewer access to the Streamlit app.
- [ ] Encrypt documents at rest and in transit; apply data-retention policies (PII handling).
- [ ] Add rate limiting / retry / circuit breakers around LLM and external API calls.
- [ ] Add structured logging + monitoring/alerting (beyond the JSONL audit log).
- [ ] Add unit/integration tests for each agent and the orchestrator.
- [ ] Validate uploaded file types/sizes and scan for malware before processing.
- [ ] Internationalize OCR (multi-language Tesseract language packs) for global ID documents.

## Extensibility

- **Add a new agent**: create `agents/<name>_agent.py` subclassing `BaseAgent`,
  implement `run()` returning an `AgentResult`, register it in `agents/__init__.py`
  and wire it into `KYCOrchestrator.run_pipeline`.
- **Adjust decisioning**: tune `AGENT_WEIGHTS` and `RISK_THRESHOLDS` in `config.py`
  without touching agent logic.
- **Swap LLM/embedding provider**: update `get_llm` / `get_embedding_model` in `config.py`.
