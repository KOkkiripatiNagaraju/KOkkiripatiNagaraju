"use client";

import { useState } from "react";
import { useParams } from "next/navigation";
import { useQuery } from "@tanstack/react-query";
import { listPublicJobs } from "@/lib/api";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { JobApplyForm } from "@/components/careers/job-apply-form";

export default function PublicJobDetailsPage() {
  const params = useParams<{ jobId: string }>();
  const jobId = Number(params.jobId);
  const [applying, setApplying] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  // Backend only exposes a list endpoint for public jobs, so we fetch the
  // list and select — no separate /public/jobs/{id} endpoint exists yet.
  const { data: jobs, isLoading } = useQuery({
    queryKey: ["public-jobs"],
    queryFn: listPublicJobs,
  });

  const job = jobs?.find((j) => j.id === jobId);

  if (isLoading) {
    return (
      <div className="mx-auto max-w-2xl px-6 py-10">
        <Skeleton className="h-40 w-full" />
      </div>
    );
  }

  if (!job) {
    return (
      <div className="mx-auto max-w-2xl px-6 py-10">
        <p className="text-sm text-secondary">This job could not be found.</p>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-2xl px-6 py-10">
      <h1 className="text-xl font-semibold text-ink">{job.title}</h1>
      <p className="mt-1 text-sm text-secondary">
        {job.department} · {job.location} · {job.employment_type} ·{" "}
        {job.salary_range}
      </p>

      <Card className="mt-5 p-5">
        <p className="whitespace-pre-wrap text-sm leading-relaxed text-secondary">
          {job.full_description}
        </p>
      </Card>

      {!applying && !submitted && (
        <Button
          variant="primary"
          className="mt-5"
          onClick={() => setApplying(true)}
        >
          Apply now
        </Button>
      )}

      {applying && !submitted && (
        <Card className="mt-5 p-5">
          <JobApplyForm jobId={job.id} onSuccess={() => setSubmitted(true)} />
        </Card>
      )}

      {submitted && (
        <Card className="mt-5 p-5">
          <p className="text-sm font-medium text-success">
            Application submitted successfully.
          </p>
          <p className="mt-1 text-sm text-secondary">
            We&apos;ll review your application and follow up by email.
          </p>
        </Card>
      )}
    </div>
  );
}
