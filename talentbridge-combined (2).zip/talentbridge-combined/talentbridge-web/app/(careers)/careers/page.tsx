"use client";

import Link from "next/link";
import { useQuery } from "@tanstack/react-query";
import { listPublicJobs } from "@/lib/api";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { EmptyState } from "@/components/ui/empty-state";

export default function CareersHomePage() {
  const { data: jobs, isLoading } = useQuery({
    queryKey: ["public-jobs"],
    queryFn: listPublicJobs,
  });

  return (
    <div className="mx-auto max-w-3xl px-6 py-10">
      <h1 className="mb-1 text-xl font-semibold text-ink">Open positions</h1>
      <p className="mb-6 text-sm text-secondary">
        Browse current openings and apply directly.
      </p>

      {isLoading && (
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-20 w-full" />
          ))}
        </div>
      )}

      {jobs && jobs.length === 0 && (
        <EmptyState title="No open positions right now" />
      )}

      {jobs && jobs.length > 0 && (
        <div className="space-y-3">
          {jobs.map((job) => (
            <Link key={job.id} href={`/careers/jobs/${job.id}`}>
              <Card className="p-5 transition-colors hover:border-primary/40">
                <h3 className="text-sm font-semibold text-ink">{job.title}</h3>
                <p className="mt-1 text-xs text-secondary">
                  {job.department} · {job.location} · {job.employment_type}
                </p>
              </Card>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
