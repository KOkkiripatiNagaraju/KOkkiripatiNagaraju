"use client";

import { useQuery } from "@tanstack/react-query";
import { getMe } from "@/lib/api";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

export default function CareersProfilePage() {
  const { data: me, isLoading } = useQuery({
    queryKey: ["me"],
    queryFn: getMe,
  });

  return (
    <div className="mx-auto max-w-2xl px-6 py-10">
      <h1 className="mb-6 text-xl font-semibold text-ink">Profile</h1>

      <Card className="p-5">
        {isLoading && <Skeleton className="h-20 w-full" />}
        {me && (
          <dl className="space-y-2 text-sm">
            <Row label="Name" value={me.full_name} />
            <Row label="Email" value={me.email} />
          </dl>
        )}
      </Card>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between gap-3">
      <dt className="text-secondary">{label}</dt>
      <dd className="text-right font-medium text-ink">{value}</dd>
    </div>
  );
}
