"use client";

import Link from "next/link";
import { useQuery } from "@tanstack/react-query";
import { getMyApplications } from "@/lib/api";
import { Card } from "@/components/ui/card";
import { StatusBadge } from "@/components/ui/status-badge";
import { Skeleton } from "@/components/ui/skeleton";
import { EmptyState } from "@/components/ui/empty-state";
import { Button } from "@/components/ui/button";

export default function MyApplicationsPage() {
  const { data: applications, isLoading } = useQuery({
    queryKey: ["my-applications"],
    queryFn: getMyApplications,
  });

  return (
    <div className="mx-auto max-w-3xl px-6 py-10">
      <h1 className="mb-1 text-xl font-semibold text-ink">My applications</h1>
      <p className="mb-6 text-sm text-secondary">
        Track the status of every position you&apos;ve applied to.
      </p>

      {isLoading && <Skeleton className="h-40 w-full" />}

      {applications && applications.length === 0 && (
        <EmptyState
          title="No applications yet"
          description="Browse open positions to get started."
          action={
            <Link href="/careers">
              <Button variant="primary">Browse open positions</Button>
            </Link>
          }
        />
      )}

      {applications && applications.length > 0 && (
        <div className="space-y-3">
          {applications.map((app) => (
            <Card key={app.candidate_id} className="p-5">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-semibold text-ink">
                    {app.job_title}
                  </h3>
                  <p className="mt-0.5 text-xs text-secondary">
                    {app.department} · {app.location}
                  </p>
                </div>
                <StatusBadge status={app.status} />
              </div>

              {app.interview_join_token && !app.interview_completed && (
                <Link
                  href={`/interview/${app.interview_join_token}`}
                  className="mt-3 inline-block"
                >
                  <Button variant="primary" size="sm">
                    Go to interview
                  </Button>
                </Link>
              )}
              {app.interview_completed && (
                <p className="mt-3 text-xs font-medium text-success">
                  Interview completed
                </p>
              )}
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
