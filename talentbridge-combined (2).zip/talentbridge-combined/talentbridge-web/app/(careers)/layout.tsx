import Link from "next/link";

const NAV = [
  { label: "Home", href: "/careers" },
  { label: "My Applications", href: "/careers/applications" },
  { label: "Profile", href: "/careers/profile" },
];

export default function CareersLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="min-h-screen bg-canvas">
      <header className="flex h-16 items-center justify-between border-b border-border bg-surface px-8">
        <span className="text-base font-semibold tracking-tight text-ink">
          TalentBridge Careers
        </span>
        <nav className="flex gap-5">
          {NAV.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="text-sm font-medium text-secondary hover:text-ink"
            >
              {item.label}
            </Link>
          ))}
        </nav>
      </header>
      <main>{children}</main>
    </div>
  );
}
