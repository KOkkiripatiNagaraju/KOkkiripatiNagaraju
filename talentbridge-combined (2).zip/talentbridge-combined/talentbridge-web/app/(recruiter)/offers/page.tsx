"use client";

import Link from "next/link";
import { useQuery } from "@tanstack/react-query";
import { listJobs, getCandidatesForJob } from "@/lib/api";
import { Topbar } from "@/components/shell/topbar";
import { Skeleton } from "@/components/ui/skeleton";
import { EmptyState } from "@/components/ui/empty-state";
import { StatusBadge } from "@/components/ui/status-badge";

export default function OffersPage() {
  const { data: jobs, isLoading: jobsLoading } = useQuery({
    queryKey: ["jobs"],
    queryFn: listJobs,
  });

  const { data: candidates, isLoading: candidatesLoading } = useQuery({
    queryKey: ["all-candidates", jobs?.map((j) => j.id)],
    queryFn: async () => {
      const results = await Promise.all(
        (jobs ?? []).map((j) => getCandidatesForJob(j.id).catch(() => []))
      );
      return results.flat();
    },
    enabled: !!jobs,
  });

  const isLoading = jobsLoading || candidatesLoading;
  const offerCandidates = (candidates ?? []).filter((c) =>
    c.status?.toLowerCase().includes("offer")
  );

  return (
    <>
      <Topbar title="Offers" />
      <div className="px-8 py-6">
        <p className="mb-5 text-sm text-secondary">
          Candidates who have been extended, accepted, or rejected an offer.
        </p>

        {isLoading && <Skeleton className="h-64 w-full" />}

        {!isLoading && offerCandidates.length === 0 && (
          <EmptyState
            title="No offers yet"
            description="Approve a candidate from Candidate Evaluation to extend an offer."
          />
        )}

        {!isLoading && offerCandidates.length > 0 && (
          <div className="space-y-2">
            {offerCandidates.map((c) => (
              <Link key={c.id} href={`/candidates/${c.id}`}>
                <div className="flex items-center justify-between rounded-card border border-border bg-surface p-4 hover:border-primary/40">
                  <div>
                    <div className="text-sm font-medium text-ink">
                      {c.name}
                    </div>
                    <div className="text-xs text-muted">{c.email}</div>
                  </div>
                  <StatusBadge status={c.status} />
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </>
  );
}
