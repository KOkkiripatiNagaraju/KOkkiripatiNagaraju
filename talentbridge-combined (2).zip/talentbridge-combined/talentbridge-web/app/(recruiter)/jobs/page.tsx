"use client";

import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { listJobs } from "@/lib/api";
import { Topbar } from "@/components/shell/topbar";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { EmptyState } from "@/components/ui/empty-state";
import { Drawer } from "@/components/ui/drawer";
import { JobCard } from "@/components/jobs/job-card";
import { JobCreateForm } from "@/components/jobs/job-create-form";

export default function JobsPage() {
  const [createOpen, setCreateOpen] = useState(false);

  const { data: jobs, isLoading, isError } = useQuery({
    queryKey: ["jobs"],
    queryFn: listJobs,
  });

  return (
    <>
      <Topbar title="Jobs" />
      <div className="px-8 py-6">
        <div className="mb-5 flex items-center justify-between">
          <p className="text-sm text-secondary">
            Manage job postings and review AI-analyzed requirements.
          </p>
          <Button variant="primary" onClick={() => setCreateOpen(true)}>
            New job posting
          </Button>
        </div>

        {isLoading && (
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-20 w-full" />
            ))}
          </div>
        )}

        {isError && (
          <EmptyState
            title="Couldn't load jobs"
            description="There was a problem reaching the server. Try refreshing the page."
          />
        )}

        {jobs && jobs.length === 0 && (
          <EmptyState
            title="No jobs posted yet"
            description="Create your first job posting to start receiving AI-evaluated candidates."
            action={
              <Button variant="primary" onClick={() => setCreateOpen(true)}>
                Create job posting
              </Button>
            }
          />
        )}

        {jobs && jobs.length > 0 && (
          <div className="space-y-3">
            {jobs.map((job) => (
              <JobCard key={job.id} job={job} />
            ))}
          </div>
        )}
      </div>

      <Drawer
        open={createOpen}
        onClose={() => setCreateOpen(false)}
        title="New job posting"
      >
        <JobCreateForm onCreated={() => setCreateOpen(false)} />
      </Drawer>
    </>
  );
}
