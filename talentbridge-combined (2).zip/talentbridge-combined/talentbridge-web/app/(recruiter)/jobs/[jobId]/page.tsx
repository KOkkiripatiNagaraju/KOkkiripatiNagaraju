"use client";

import { useState } from "react";
import { useParams } from "next/navigation";
import { useQuery } from "@tanstack/react-query";
import {
  getJob,
  getJobRankings,
  getInterviewResultsForJob,
} from "@/lib/api";
import { Topbar } from "@/components/shell/topbar";
import { Tabs } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { EmptyState } from "@/components/ui/empty-state";
import { JobOverviewTab } from "@/components/jobs/job-overview-tab";
import { JobApplicantsTab } from "@/components/jobs/job-applicants-tab";
import { CandidateEvaluationTable } from "@/components/candidates/candidate-evaluation-table";

const TABS = [
  { key: "overview", label: "Overview" },
  { key: "applicants", label: "Applicants" },
  { key: "interviews", label: "Interviews" },
  { key: "offers", label: "Offers" },
  { key: "analytics", label: "Analytics" },
];

export default function JobDetailsPage() {
  const params = useParams<{ jobId: string }>();
  const jobId = Number(params.jobId);
  const [activeTab, setActiveTab] = useState("overview");

  const { data: job, isLoading: jobLoading } = useQuery({
    queryKey: ["job", jobId],
    queryFn: () => getJob(jobId),
  });

  const { data: rankings } = useQuery({
    queryKey: ["job-rankings", jobId],
    queryFn: () => getJobRankings(jobId),
    enabled: activeTab === "interviews" || activeTab === "offers",
    retry: false,
  });

  const { data: interviewResults } = useQuery({
    queryKey: ["job-interview-results", jobId],
    queryFn: () => getInterviewResultsForJob(jobId),
    enabled: activeTab === "interviews" || activeTab === "offers",
  });

  if (jobLoading) {
    return (
      <>
        <Topbar title="Loading job…" />
        <div className="space-y-3 px-8 py-6">
          <Skeleton className="h-8 w-1/3" />
          <Skeleton className="h-40 w-full" />
        </div>
      </>
    );
  }

  if (!job) {
    return (
      <>
        <Topbar title="Job not found" />
        <div className="px-8 py-6">
          <EmptyState title="This job could not be found." />
        </div>
      </>
    );
  }

  const offerStageCandidates = (rankings ?? []).filter((r) => {
    const status = r.status?.toLowerCase() ?? "";
    return (
      status.includes("offer") || status.includes("join") || status.includes("reject")
    );
  });

  return (
    <>
      <Topbar title={job.title} />
      <div className="px-8 py-4">
        <Tabs tabs={TABS} active={activeTab} onChange={setActiveTab} />

        {activeTab === "overview" && <JobOverviewTab job={job} />}

        {activeTab === "applicants" && <JobApplicantsTab jobId={jobId} />}

        {activeTab === "interviews" && (
          <div className="py-5">
            {rankings && rankings.length > 0 ? (
              <CandidateEvaluationTable
                jobId={jobId}
                rankings={rankings}
                interviewResults={interviewResults?.results ?? []}
              />
            ) : (
              <EmptyState
                title="No candidates yet"
                description="Once resumes are processed for this job, ranked candidates will appear here."
              />
            )}
          </div>
        )}

        {activeTab === "offers" && (
          <div className="py-5">
            {offerStageCandidates.length > 0 ? (
              <CandidateEvaluationTable
                jobId={jobId}
                rankings={offerStageCandidates}
                interviewResults={interviewResults?.results ?? []}
              />
            ) : (
              <EmptyState
                title="No offers yet"
                description="Candidates move here once they're approved or rejected from Hiring Pipeline."
              />
            )}
          </div>
        )}

        {activeTab === "analytics" && (
          <div className="py-5">
            <EmptyState
              title="Job analytics"
              description="Funnel and conversion metrics for this job will appear here."
            />
          </div>
        )}
      </div>
    </>
  );
}
