"use client";

import { useState } from "react";
import { useParams } from "next/navigation";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  getCandidate,
  getAtsScore,
  getRecommendation,
  getDecision,
  approveCandidate,
  rejectCandidate,
} from "@/lib/api";
import { Topbar } from "@/components/shell/topbar";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { StatusBadge } from "@/components/ui/status-badge";
import { ScoreBar } from "@/components/ui/score-bar";
import { CandidateStatusTracker } from "@/components/candidates/candidate-status-tracker";
import { ResumePreviewDrawer } from "@/components/candidates/resume-preview-drawer";

export default function CandidateProfilePage() {
  const params = useParams<{ candidateId: string }>();
  const candidateId = Number(params.candidateId);
  const queryClient = useQueryClient();
  const [resumeOpen, setResumeOpen] = useState(false);

  const { data: candidate, isLoading } = useQuery({
    queryKey: ["candidate", candidateId],
    queryFn: () => getCandidate(candidateId),
  });

  const { data: ats } = useQuery({
    queryKey: ["ats-score", candidateId],
    queryFn: () => getAtsScore(candidateId),
    retry: false,
  });

  const { data: recommendation } = useQuery({
    queryKey: ["recommendation", candidateId],
    queryFn: () => getRecommendation(candidateId),
    retry: false,
  });

  const { data: decision } = useQuery({
    queryKey: ["decision", candidateId],
    queryFn: () => getDecision(candidateId),
    retry: false,
  });

  const approveMutation = useMutation({
    mutationFn: () => approveCandidate(candidateId),
    onSuccess: () =>
      queryClient.invalidateQueries({ queryKey: ["candidate", candidateId] }),
  });
  const rejectMutation = useMutation({
    mutationFn: () => rejectCandidate(candidateId),
    onSuccess: () =>
      queryClient.invalidateQueries({ queryKey: ["candidate", candidateId] }),
  });

  if (isLoading) {
    return (
      <>
        <Topbar title="Loading candidate…" />
        <div className="space-y-3 px-8 py-6">
          <Skeleton className="h-10 w-1/3" />
          <Skeleton className="h-40 w-full" />
        </div>
      </>
    );
  }

  if (!candidate) {
    return (
      <>
        <Topbar title="Candidate not found" />
      </>
    );
  }

  const status = candidate.status?.toLowerCase() ?? "";
  const isDecided =
    status.includes("reject") || status.includes("offer") || status.includes("join");

  return (
    <>
      <Topbar title={candidate.name} />
      <div className="grid grid-cols-3 gap-5 px-8 py-6">
        <div className="col-span-2 space-y-5">
          {/* Profile */}
          <Card className="p-5">
            <div className="mb-1 flex items-center justify-between">
              <div>
                <h2 className="text-base font-semibold text-ink">
                  {candidate.name}
                </h2>
                <p className="text-sm text-secondary">{candidate.email}</p>
              </div>
              <StatusBadge status={candidate.status} />
            </div>
            <div className="mt-3 flex gap-2">
              <Button size="sm" variant="secondary" onClick={() => setResumeOpen(true)}>
                Resume preview
              </Button>
              <Button
                size="sm"
                variant="primary"
                disabled={isDecided || approveMutation.isPending}
                onClick={() => approveMutation.mutate()}
              >
                Approve
              </Button>
              <Button
                size="sm"
                variant="danger"
                disabled={isDecided || rejectMutation.isPending}
                onClick={() => rejectMutation.mutate()}
              >
                Reject
              </Button>
            </div>
          </Card>

          {/* Current Hiring Stage / Timeline */}
          <Card className="p-5">
            <h3 className="mb-3 text-sm font-semibold text-ink">
              Current hiring stage
            </h3>
            <CandidateStatusTracker status={candidate.status} />
          </Card>

          {/* Interview Feedback */}
          <Card className="p-5">
            <h3 className="mb-3 text-sm font-semibold text-ink">
              Interview feedback
            </h3>
            {decision ? (
              <div className="space-y-2 text-sm">
                <Row label="Verdict" value={String(decision.verdict ?? "—")} />
                <Row
                  label="Confidence"
                  value={
                    decision.confidence != null
                      ? `${(Number(decision.confidence) * 100).toFixed(0)}%`
                      : "—"
                  }
                />
                <Row
                  label="Recommended action"
                  value={String(decision.recommended_action ?? "—")}
                />
                {decision.justification && (
                  <p className="mt-2 text-secondary">
                    {String(decision.justification)}
                  </p>
                )}
              </div>
            ) : (
              <p className="text-sm text-muted">
                No interview feedback available yet.
              </p>
            )}
          </Card>

          {/* Notes / Communication History — placeholders, no backend endpoint yet */}
          <Card className="p-5">
            <h3 className="mb-1 text-sm font-semibold text-ink">Notes</h3>
            <p className="text-sm text-muted">
              Recruiter notes aren&apos;t wired up to a backend endpoint yet.
            </p>
          </Card>

          <Card className="p-5">
            <h3 className="mb-1 text-sm font-semibold text-ink">
              Communication history
            </h3>
            <p className="text-sm text-muted">
              Sent emails for this candidate will appear here once linked to
              the Email Center.
            </p>
          </Card>
        </div>

        <div className="space-y-5">
          <Card className="p-5">
            <h3 className="mb-3 text-sm font-semibold text-ink">
              Match score
            </h3>
            {ats ? (
              <div className="space-y-3">
                <ScoreBar score={ats.total_score} />
                <div className="space-y-1.5 text-xs text-secondary">
                  <Row label="Skills match" value={`${ats.skills_match}%`} />
                  <Row
                    label="Experience match"
                    value={`${ats.experience_match}%`}
                  />
                  <Row
                    label="Semantic similarity"
                    value={`${ats.semantic_similarity}%`}
                  />
                </div>
              </div>
            ) : (
              <p className="text-sm text-muted">No ATS score available.</p>
            )}
          </Card>

          {recommendation && (
            <Card className="p-5">
              <h3 className="mb-2 text-sm font-semibold text-ink">
                AI recommendation
              </h3>
              <p className="text-sm text-secondary">
                {String(recommendation.ai_verdict ?? "—")}
              </p>
            </Card>
          )}

          <Card className="p-5">
            <h3 className="mb-3 text-sm font-semibold text-ink">Skills</h3>
            <div className="flex flex-wrap gap-1.5">
              {(candidate.skills ?? []).map((s) => (
                <span
                  key={s}
                  className="rounded-full bg-canvas px-2.5 py-1 text-xs text-secondary"
                >
                  {s}
                </span>
              ))}
              {(!candidate.skills || candidate.skills.length === 0) && (
                <p className="text-sm text-muted">No skills on file.</p>
              )}
            </div>
          </Card>

          <Card className="p-5">
            <h3 className="mb-3 text-sm font-semibold text-ink">
              Experience
            </h3>
            <p className="text-sm text-secondary">
              {candidate.experience_years ?? 0} years
            </p>
          </Card>
        </div>
      </div>

      <ResumePreviewDrawer
        candidateId={candidateId}
        candidateName={candidate.name}
        open={resumeOpen}
        onClose={() => setResumeOpen(false)}
      />
    </>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between gap-3">
      <dt className="text-secondary">{label}</dt>
      <dd className="text-right font-medium text-ink">{value}</dd>
    </div>
  );
}
