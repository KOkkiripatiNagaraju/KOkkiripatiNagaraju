"use client";

import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  listJobs,
  getJobRankings,
  getInterviewResultsForJob,
} from "@/lib/api";
import { Topbar } from "@/components/shell/topbar";
import { Skeleton } from "@/components/ui/skeleton";
import { EmptyState } from "@/components/ui/empty-state";
import { JobPicker } from "@/components/jobs/job-picker";
import { CandidateEvaluationTable } from "@/components/candidates/candidate-evaluation-table";
import { cn } from "@/lib/utils";
import type { JobRankingEntry } from "@/lib/types";

type Bucket = "pending" | "interviewed" | "approved" | "rejected";

function bucketize(
  r: JobRankingEntry,
  isCompleted: boolean
): Bucket {
  const status = r.status?.toLowerCase() ?? "";
  if (status.includes("reject")) return "rejected";
  if (
    status.includes("offer") ||
    status.includes("join") ||
    status.includes("approved")
  )
    return "approved";
  if (isCompleted) return "interviewed";
  return "pending";
}

export default function CandidatesPage() {
  const [selectedJobId, setSelectedJobId] = useState<number | null>(null);
  const [activeBucket, setActiveBucket] = useState<Bucket>("pending");

  const { data: jobs, isLoading: jobsLoading } = useQuery({
    queryKey: ["jobs"],
    queryFn: listJobs,
  });

  const { data: rankings, isError: rankingsError } = useQuery({
    queryKey: ["job-rankings", selectedJobId],
    queryFn: () => getJobRankings(selectedJobId as number),
    enabled: selectedJobId !== null,
    retry: false,
  });

  const { data: interviewResults } = useQuery({
    queryKey: ["job-interview-results", selectedJobId],
    queryFn: () => getInterviewResultsForJob(selectedJobId as number),
    enabled: selectedJobId !== null,
  });

  const interviewByCandidate = useMemo(() => {
    const map = new Map<number, boolean>();
    for (const r of interviewResults?.results ?? []) {
      map.set(r.candidate_id, r.is_completed);
    }
    return map;
  }, [interviewResults]);

  const bucketed = useMemo(() => {
    const result: Record<Bucket, JobRankingEntry[]> = {
      pending: [],
      interviewed: [],
      approved: [],
      rejected: [],
    };
    for (const r of rankings ?? []) {
      const completed = interviewByCandidate.get(r.candidate_id) ?? false;
      result[bucketize(r, completed)].push(r);
    }
    return result;
  }, [rankings, interviewByCandidate]);

  const BUCKETS: { key: Bucket; label: string }[] = [
    { key: "pending", label: "Pending interview" },
    { key: "interviewed", label: "Interviewed" },
    { key: "approved", label: "Approved" },
    { key: "rejected", label: "Rejected" },
  ];

  return (
    <>
      <Topbar title="Candidates" />
      <div className="px-8 py-6">
        <div className="mb-5 flex items-center justify-between">
          <p className="text-sm text-secondary">
            AI-ranked candidate evaluation for each job posting.
          </p>
          {jobsLoading ? (
            <Skeleton className="h-9 w-64" />
          ) : (
            jobs && (
              <JobPicker
                jobs={jobs}
                selectedJobId={selectedJobId}
                onChange={setSelectedJobId}
              />
            )
          )}
        </div>

        {selectedJobId === null && (
          <EmptyState
            title="Select a job to view candidate evaluations"
            description="Choose a job posting from the dropdown above."
          />
        )}

        {selectedJobId !== null && rankingsError && (
          <EmptyState
            title="No candidates evaluated yet"
            description="Rankings appear once resumes have been processed for this job."
          />
        )}

        {selectedJobId !== null && rankings && (
          <>
            <div className="mb-4 flex gap-1 border-b border-border">
              {BUCKETS.map((b) => (
                <button
                  key={b.key}
                  onClick={() => setActiveBucket(b.key)}
                  className={cn(
                    "border-b-2 px-4 py-2.5 text-sm font-medium transition-colors",
                    activeBucket === b.key
                      ? "border-primary text-primary"
                      : "border-transparent text-secondary hover:text-ink"
                  )}
                >
                  {b.label} ({bucketed[b.key].length})
                </button>
              ))}
            </div>

            {bucketed[activeBucket].length === 0 ? (
              <EmptyState
                title="No candidates in this category"
                description="They will appear here once their status changes."
              />
            ) : (
              <CandidateEvaluationTable
                jobId={selectedJobId}
                rankings={bucketed[activeBucket]}
                interviewResults={interviewResults?.results ?? []}
              />
            )}
          </>
        )}
      </div>
    </>
  );
}
