"use client";

import { Sidebar } from "@/components/shell/sidebar";
import { useRequireAuth } from "@/lib/use-require-auth";

export default function RecruiterLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const ready = useRequireAuth();

  if (!ready) {
    return <div className="h-screen w-screen bg-canvas" />;
  }

  return (
    <div className="flex h-screen bg-canvas">
      <Sidebar />
      <div className="flex-1 overflow-y-auto">{children}</div>
    </div>
  );
}
