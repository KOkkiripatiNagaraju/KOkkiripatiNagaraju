"use client";

import { useQuery } from "@tanstack/react-query";
import { getMe } from "@/lib/api";
import { Topbar } from "@/components/shell/topbar";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

export default function SettingsPage() {
  const { data: me, isLoading } = useQuery({
    queryKey: ["me"],
    queryFn: getMe,
  });

  return (
    <>
      <Topbar title="Settings" />
      <div className="px-8 py-6">
        <Card className="max-w-md p-5">
          <h3 className="mb-3 text-sm font-semibold text-ink">Account</h3>
          {isLoading && <Skeleton className="h-20 w-full" />}
          {me && (
            <dl className="space-y-2 text-sm">
              <Row label="Name" value={me.full_name} />
              <Row label="Email" value={me.email} />
              <Row label="Role" value={me.is_manager ? "Manager" : "Recruiter"} />
            </dl>
          )}
        </Card>
      </div>
    </>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between gap-3">
      <dt className="text-secondary">{label}</dt>
      <dd className="text-right font-medium text-ink">{value}</dd>
    </div>
  );
}
