"use client";

import Link from "next/link";
import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { listJobs, getCandidatesForJob } from "@/lib/api";
import { Topbar } from "@/components/shell/topbar";
import { Skeleton } from "@/components/ui/skeleton";
import { EmptyState } from "@/components/ui/empty-state";
import { StatusBadge } from "@/components/ui/status-badge";

export default function ApplicationsPage() {
  const { data: jobs, isLoading: jobsLoading } = useQuery({
    queryKey: ["jobs"],
    queryFn: listJobs,
  });

  const jobTitleById = useMemo(() => {
    const map = new Map<number, string>();
    for (const j of jobs ?? []) map.set(j.id, j.title);
    return map;
  }, [jobs]);

  const { data: candidates, isLoading: candidatesLoading } = useQuery({
    queryKey: ["all-candidates", jobs?.map((j) => j.id)],
    queryFn: async () => {
      const results = await Promise.all(
        (jobs ?? []).map((j) =>
          getCandidatesForJob(j.id).catch(() => [])
        )
      );
      return results.flat();
    },
    enabled: !!jobs,
  });

  const isLoading = jobsLoading || candidatesLoading;

  return (
    <>
      <Topbar title="Applications" />
      <div className="px-8 py-6">
        <p className="mb-5 text-sm text-secondary">
          All candidate applications across every job posting.
        </p>

        {isLoading && <Skeleton className="h-64 w-full" />}

        {!isLoading && candidates && candidates.length === 0 && (
          <EmptyState
            title="No applications yet"
            description="Applications will appear here once candidates apply or resumes are uploaded."
          />
        )}

        {!isLoading && candidates && candidates.length > 0 && (
          <div className="overflow-hidden rounded-card border border-border">
            <table className="w-full text-sm">
              <thead className="bg-canvas text-left text-xs font-medium uppercase tracking-wide text-muted">
                <tr>
                  <th className="px-4 py-2.5">Candidate</th>
                  <th className="px-4 py-2.5">Job</th>
                  <th className="px-4 py-2.5">Experience</th>
                  <th className="px-4 py-2.5">Stage</th>
                  <th className="px-4 py-2.5">Applied</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {candidates.map((c) => (
                  <tr key={c.id} className="hover:bg-canvas/60">
                    <td className="px-4 py-2.5">
                      <Link
                        href={`/candidates/${c.id}`}
                        className="font-medium text-ink hover:text-primary"
                      >
                        {c.name}
                      </Link>
                      <div className="text-xs text-muted">{c.email}</div>
                    </td>
                    <td className="px-4 py-2.5 text-secondary">
                      {jobTitleById.get(c.job_id) ?? `Job #${c.job_id}`}
                    </td>
                    <td className="px-4 py-2.5 text-secondary">
                      {c.experience_years ?? "—"} yrs
                    </td>
                    <td className="px-4 py-2.5">
                      <StatusBadge status={c.status} />
                    </td>
                    <td className="px-4 py-2.5 text-secondary">
                      {c.applied_at
                        ? new Date(c.applied_at).toLocaleDateString()
                        : "—"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </>
  );
}
