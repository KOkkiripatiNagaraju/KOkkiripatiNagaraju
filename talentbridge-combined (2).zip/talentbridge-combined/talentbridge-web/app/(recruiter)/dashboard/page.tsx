"use client";

import { Topbar } from "@/components/shell/topbar";
import { Skeleton } from "@/components/ui/skeleton";
import { EmptyState } from "@/components/ui/empty-state";
import { KpiCard } from "@/components/dashboard/kpi-card";
import { useDashboardKpis } from "@/lib/use-dashboard-kpis";

export default function DashboardPage() {
  const { kpis, isLoading, isError } = useDashboardKpis();

  return (
    <>
      <Topbar title="Recruitment Dashboard" />
      <div className="px-8 py-6">
        {isLoading && (
          <div className="grid grid-cols-3 gap-4">
            {Array.from({ length: 6 }).map((_, i) => (
              <Skeleton key={i} className="h-24 w-full" />
            ))}
          </div>
        )}

        {isError && (
          <EmptyState
            title="Couldn't load dashboard"
            description="There was a problem reaching the server. Try refreshing the page."
          />
        )}

        {kpis && (
          <div className="grid grid-cols-3 gap-4">
            <KpiCard
              label="Active job postings"
              value={kpis.activeJobs}
              href="/jobs"
              accent="primary"
            />
            <KpiCard
              label="Total candidates"
              value={kpis.totalCandidates}
              href="/candidates"
            />
            <KpiCard
              label="Interviews"
              value={kpis.interviewing}
              href="/interviews"
              accent="warning"
            />
            <KpiCard label="Offers" value={kpis.offered} href="/offers" />
            <KpiCard
              label="Hired"
              value={kpis.hired}
              href="/pipeline"
              accent="success"
            />
            <KpiCard
              label="Background verification"
              value={kpis.backgroundVerification}
              href="/pipeline"
            />
          </div>
        )}
      </div>
    </>
  );
}
