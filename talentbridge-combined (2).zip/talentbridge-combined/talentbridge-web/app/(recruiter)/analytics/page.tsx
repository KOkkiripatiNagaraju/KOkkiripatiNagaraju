"use client";

import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts";
import { listJobs, getCandidatesForJob } from "@/lib/api";
import { Topbar } from "@/components/shell/topbar";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { EmptyState } from "@/components/ui/empty-state";

const FUNNEL_ORDER = [
  "applied",
  "screening",
  "shortlisted",
  "interviewing",
  "offered",
  "hired",
];

const PIE_COLORS = ["#4F46E5", "#15803D", "#B45309", "#B91C1C", "#94A3B8", "#0EA5E9"];

export default function AnalyticsPage() {
  const { data: jobs, isLoading: jobsLoading } = useQuery({
    queryKey: ["jobs"],
    queryFn: listJobs,
  });

  const { data: candidates, isLoading: candidatesLoading } = useQuery({
    queryKey: ["all-candidates", jobs?.map((j) => j.id)],
    queryFn: async () => {
      const results = await Promise.all(
        (jobs ?? []).map((j) => getCandidatesForJob(j.id).catch(() => []))
      );
      return results.flat();
    },
    enabled: !!jobs,
  });

  const isLoading = jobsLoading || candidatesLoading;

  const statusCounts = useMemo(() => {
    const counts = new Map<string, number>();
    for (const c of candidates ?? []) {
      const key = c.status || "Unknown";
      counts.set(key, (counts.get(key) ?? 0) + 1);
    }
    return Array.from(counts.entries()).map(([status, count]) => ({
      status,
      count,
    }));
  }, [candidates]);

  const funnelData = useMemo(() => {
    const counts = new Map<string, number>();
    for (const stage of FUNNEL_ORDER) counts.set(stage, 0);
    for (const c of candidates ?? []) {
      const s = c.status?.toLowerCase() ?? "";
      const matched = FUNNEL_ORDER.find((stage) => s.includes(stage));
      if (matched) counts.set(matched, (counts.get(matched) ?? 0) + 1);
    }
    return FUNNEL_ORDER.map((stage) => ({
      stage: stage.charAt(0).toUpperCase() + stage.slice(1),
      count: counts.get(stage) ?? 0,
    }));
  }, [candidates]);

  const offerStats = useMemo(() => {
    const offered = (candidates ?? []).filter((c) =>
      c.status?.toLowerCase().includes("offer")
    );
    const accepted = offered.filter((c) =>
      c.status?.toLowerCase().includes("accept")
    ).length;
    return { offered: offered.length, accepted };
  }, [candidates]);

  return (
    <>
      <Topbar title="Analytics" />
      <div className="space-y-5 px-8 py-6">
        {isLoading && <Skeleton className="h-96 w-full" />}

        {!isLoading && (!candidates || candidates.length === 0) && (
          <EmptyState
            title="No data yet"
            description="Analytics will populate once candidates start applying."
          />
        )}

        {!isLoading && candidates && candidates.length > 0 && (
          <div className="grid grid-cols-2 gap-5">
            <Card className="p-5">
              <h3 className="mb-4 text-sm font-semibold text-ink">
                Hiring funnel
              </h3>
              <ResponsiveContainer width="100%" height={240}>
                <BarChart data={funnelData} layout="vertical" margin={{ left: 16 }}>
                  <XAxis type="number" hide />
                  <YAxis
                    dataKey="stage"
                    type="category"
                    width={120}
                    tick={{ fontSize: 12, fill: "#475569" }}
                    axisLine={false}
                    tickLine={false}
                  />
                  <Tooltip />
                  <Bar dataKey="count" fill="#4F46E5" radius={[0, 4, 4, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </Card>

            <Card className="p-5">
              <h3 className="mb-4 text-sm font-semibold text-ink">
                Applications by status
              </h3>
              <ResponsiveContainer width="100%" height={240}>
                <PieChart>
                  <Pie
                    data={statusCounts}
                    dataKey="count"
                    nameKey="status"
                    innerRadius={50}
                    outerRadius={90}
                  >
                    {statusCounts.map((_, i) => (
                      <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </Card>

            <Card className="p-5">
              <h3 className="mb-2 text-sm font-semibold text-ink">
                Offer acceptance rate
              </h3>
              <p className="text-2xl font-semibold tabular text-ink">
                {offerStats.offered > 0
                  ? `${((offerStats.accepted / offerStats.offered) * 100).toFixed(0)}%`
                  : "—"}
              </p>
              <p className="mt-1 text-xs text-muted">
                {offerStats.accepted} of {offerStats.offered} offers accepted
              </p>
            </Card>

            <Card className="p-5">
              <h3 className="mb-2 text-sm font-semibold text-ink">
                Candidate sources
              </h3>
              <p className="text-sm text-muted">
                Source attribution isn&apos;t tracked by the backend yet — all
                candidates currently come through direct application or
                recruiter upload.
              </p>
            </Card>
          </div>
        )}
      </div>
    </>
  );
}
