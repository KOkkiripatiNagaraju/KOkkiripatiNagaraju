"use client";

import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { listJobs, getInterviewPanelForJob } from "@/lib/api";
import { Topbar } from "@/components/shell/topbar";
import { Skeleton } from "@/components/ui/skeleton";
import { EmptyState } from "@/components/ui/empty-state";
import { JobPicker } from "@/components/jobs/job-picker";
import { ScoreBar } from "@/components/ui/score-bar";

export default function InterviewsPage() {
  const [selectedJobId, setSelectedJobId] = useState<number | null>(null);

  const { data: jobs, isLoading: jobsLoading } = useQuery({
    queryKey: ["jobs"],
    queryFn: listJobs,
  });

  const { data: panel, isLoading: panelLoading, isError } = useQuery({
    queryKey: ["interview-panel", selectedJobId],
    queryFn: () => getInterviewPanelForJob(selectedJobId as number),
    enabled: selectedJobId !== null,
    retry: false,
  });

  return (
    <>
      <Topbar title="Interviews" />
      <div className="px-8 py-6">
        <div className="mb-5 flex items-center justify-between">
          <p className="text-sm text-secondary">
            Interview status and scores for each job's candidates.
          </p>
          {jobsLoading ? (
            <Skeleton className="h-9 w-64" />
          ) : (
            jobs && (
              <JobPicker
                jobs={jobs}
                selectedJobId={selectedJobId}
                onChange={setSelectedJobId}
              />
            )
          )}
        </div>

        {selectedJobId === null && (
          <EmptyState
            title="Select a job to view interviews"
            description="Choose a job posting from the dropdown above."
          />
        )}

        {selectedJobId !== null && panelLoading && (
          <Skeleton className="h-64 w-full" />
        )}

        {selectedJobId !== null && isError && (
          <EmptyState
            title="Couldn't load interview panel"
            description="You may need recruiter/manager permissions to view this."
          />
        )}

        {panel && panel.candidates.length === 0 && (
          <EmptyState
            title="No candidates yet for this job"
            description="Interview status will appear here once candidates apply."
          />
        )}

        {panel && panel.candidates.length > 0 && (
          <div className="overflow-hidden rounded-card border border-border">
            <table className="w-full text-sm">
              <thead className="bg-canvas text-left text-xs font-medium uppercase tracking-wide text-muted">
                <tr>
                  <th className="px-4 py-2.5">Rank</th>
                  <th className="px-4 py-2.5">Candidate</th>
                  <th className="px-4 py-2.5">Match score</th>
                  <th className="px-4 py-2.5">AI verdict</th>
                  <th className="px-4 py-2.5">Interview status</th>
                  <th className="px-4 py-2.5">Interview score</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {panel.candidates.map((c) => (
                  <tr key={c.candidate_id} className="hover:bg-canvas/60">
                    <td className="px-4 py-2.5 text-secondary">
                      {c.rank ?? "—"}
                    </td>
                    <td className="px-4 py-2.5">
                      <div className="font-medium text-ink">{c.name}</div>
                      <div className="text-xs text-muted">{c.email}</div>
                    </td>
                    <td className="px-4 py-2.5">
                      {c.ats_total_score != null ? (
                        <ScoreBar score={c.ats_total_score} size="sm" />
                      ) : (
                        "—"
                      )}
                    </td>
                    <td className="px-4 py-2.5 text-secondary">
                      {c.ai_verdict ?? "—"}
                    </td>
                    <td className="px-4 py-2.5">
                      {c.interview_done ? (
                        <span className="text-xs font-medium text-success">
                          Completed
                        </span>
                      ) : c.interview_id ? (
                        <span className="text-xs text-warning">
                          Scheduled
                        </span>
                      ) : (
                        <span className="text-xs text-muted">
                          Not scheduled
                        </span>
                      )}
                    </td>
                    <td className="px-4 py-2.5 tabular text-secondary">
                      {c.interview_score != null
                        ? c.interview_score.toFixed(1)
                        : "—"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </>
  );
}
