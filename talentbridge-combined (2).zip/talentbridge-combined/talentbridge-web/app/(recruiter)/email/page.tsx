"use client";

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getPendingEmails, reviewEmail } from "@/lib/api";
import { Topbar } from "@/components/shell/topbar";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { EmptyState } from "@/components/ui/empty-state";

export default function EmailCenterPage() {
  const queryClient = useQueryClient();
  const [editing, setEditing] = useState<Record<number, { subject: string; body: string }>>({});

  const { data: emails, isLoading } = useQuery({
    queryKey: ["pending-emails"],
    queryFn: getPendingEmails,
  });

  const mutation = useMutation({
    mutationFn: ({
      id,
      approve,
    }: {
      id: number;
      approve: boolean;
    }) =>
      reviewEmail(id, {
        approve,
        edited_subject: editing[id]?.subject,
        edited_body: editing[id]?.body,
      }),
    onSuccess: () =>
      queryClient.invalidateQueries({ queryKey: ["pending-emails"] }),
  });

  return (
    <>
      <Topbar title="Email Center" />
      <div className="px-8 py-6">
        <p className="mb-5 text-sm text-secondary">
          Review and send AI-drafted candidate emails.
        </p>

        {isLoading && <Skeleton className="h-48 w-full" />}

        {emails && emails.length === 0 && (
          <EmptyState
            title="No pending emails"
            description="AI-drafted emails awaiting review will appear here."
          />
        )}

        {emails && emails.length > 0 && (
          <div className="space-y-4">
            {emails.map((email) => {
              const draft = editing[email.id] ?? {
                subject: email.subject,
                body: email.body,
              };
              return (
                <Card key={email.id} className="p-5">
                  <p className="mb-2 text-xs font-medium uppercase tracking-wide text-muted">
                    Candidate #{email.candidate_id}
                  </p>
                  <input
                    value={draft.subject}
                    onChange={(e) =>
                      setEditing((prev) => ({
                        ...prev,
                        [email.id]: { ...draft, subject: e.target.value },
                      }))
                    }
                    className="mb-2 w-full rounded-md border border-border px-3 py-2 text-sm font-medium text-ink outline-none focus:border-primary"
                  />
                  <textarea
                    value={draft.body}
                    onChange={(e) =>
                      setEditing((prev) => ({
                        ...prev,
                        [email.id]: { ...draft, body: e.target.value },
                      }))
                    }
                    rows={5}
                    className="w-full resize-none rounded-md border border-border px-3 py-2 text-sm text-secondary outline-none focus:border-primary"
                  />
                  <div className="mt-3 flex gap-2">
                    <Button
                      variant="primary"
                      size="sm"
                      disabled={mutation.isPending}
                      onClick={() =>
                        mutation.mutate({ id: email.id, approve: true })
                      }
                    >
                      Send
                    </Button>
                    <Button
                      variant="danger"
                      size="sm"
                      disabled={mutation.isPending}
                      onClick={() =>
                        mutation.mutate({ id: email.id, approve: false })
                      }
                    >
                      Discard
                    </Button>
                  </div>
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </>
  );
}
