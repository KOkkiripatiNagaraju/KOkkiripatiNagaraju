"use client";

import { useQuery } from "@tanstack/react-query";
import { listJobs, getCandidatesForJob } from "@/lib/api";
import { Topbar } from "@/components/shell/topbar";
import { Skeleton } from "@/components/ui/skeleton";
import { EmptyState } from "@/components/ui/empty-state";
import { Card } from "@/components/ui/card";
import { CandidateStatusTracker } from "@/components/candidates/candidate-status-tracker";
import Link from "next/link";

export default function PipelinePage() {
  const { data: jobs, isLoading: jobsLoading } = useQuery({
    queryKey: ["jobs"],
    queryFn: listJobs,
  });

  const { data: candidates, isLoading: candidatesLoading } = useQuery({
    queryKey: ["all-candidates", jobs?.map((j) => j.id)],
    queryFn: async () => {
      const results = await Promise.all(
        (jobs ?? []).map((j) => getCandidatesForJob(j.id).catch(() => []))
      );
      return results.flat();
    },
    enabled: !!jobs,
  });

  const isLoading = jobsLoading || candidatesLoading;
  const active = (candidates ?? []).filter(
    (c) => !c.status?.toLowerCase().includes("reject")
  );

  return (
    <>
      <Topbar title="Hiring Pipeline" />
      <div className="px-8 py-6">
        <p className="mb-5 text-sm text-secondary">
          Where each active candidate stands in the hiring process.
        </p>

        {isLoading && <Skeleton className="h-64 w-full" />}

        {!isLoading && active.length === 0 && (
          <EmptyState title="No active candidates in the pipeline" />
        )}

        {!isLoading && active.length > 0 && (
          <div className="space-y-3">
            {active.map((c) => (
              <Card key={c.id} className="p-4">
                <div className="mb-2 flex items-center justify-between">
                  <Link
                    href={`/candidates/${c.id}`}
                    className="text-sm font-medium text-ink hover:text-primary"
                  >
                    {c.name}
                  </Link>
                  <span className="text-xs text-muted">{c.status}</span>
                </div>
                <CandidateStatusTracker status={c.status} />
              </Card>
            ))}
          </div>
        )}
      </div>
    </>
  );
}
