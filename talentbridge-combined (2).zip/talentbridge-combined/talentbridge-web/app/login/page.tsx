"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { login, ApiError } from "@/lib/api";
import { Button } from "@/components/ui/button";

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      await login(email, password);
      router.push("/dashboard");
    } catch (err) {
      setError(
        err instanceof ApiError ? err.message : "Could not sign in. Try again."
      );
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-canvas px-4">
      <div className="w-full max-w-sm">
        <div className="mb-8 text-center">
          <span className="text-lg font-semibold tracking-tight text-ink">
            TalentBridge
          </span>
        </div>
        <form
          onSubmit={handleSubmit}
          className="rounded-card border border-border bg-surface p-6 shadow-card"
        >
          <h1 className="mb-1 text-base font-semibold text-ink">Sign in</h1>
          <p className="mb-5 text-sm text-secondary">
            Use your recruiter account to continue.
          </p>

          <label className="mb-1 block text-xs font-medium text-secondary">
            Email
          </label>
          <input
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="mb-4 w-full rounded-md border border-border px-3 py-2 text-sm text-ink outline-none focus:border-primary"
            placeholder="you@company.com"
          />

          <label className="mb-1 block text-xs font-medium text-secondary">
            Password
          </label>
          <input
            type="password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="mb-4 w-full rounded-md border border-border px-3 py-2 text-sm text-ink outline-none focus:border-primary"
            placeholder="••••••••"
          />

          {error && (
            <p className="mb-4 rounded-md bg-danger-subtle px-3 py-2 text-xs text-danger">
              {error}
            </p>
          )}

          <Button
            type="submit"
            variant="primary"
            className="w-full"
            disabled={loading}
          >
            {loading ? "Signing in…" : "Sign in"}
          </Button>
        </form>
      </div>
    </div>
  );
}
