"use client";

import { useState } from "react";
import { useParams } from "next/navigation";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  getPublicInterview,
  submitPublicInterviewAnswer,
  closePublicInterview,
  ApiError,
} from "@/lib/api";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { InterviewCompletionScreen } from "@/components/careers/interview-completion-screen";

export default function PublicInterviewPage() {
  const params = useParams<{ joinToken: string }>();
  const joinToken = params.joinToken;
  const queryClient = useQueryClient();

  const [answer, setAnswer] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [justCompleted, setJustCompleted] = useState(false);

  const { data: interview, isLoading, isError, error: fetchError } = useQuery({
    queryKey: ["public-interview", joinToken],
    queryFn: () => getPublicInterview(joinToken),
    retry: false,
  });

  const submitAnswerMutation = useMutation({
    mutationFn: (questionId: number) =>
      submitPublicInterviewAnswer(joinToken, {
        question_id: questionId,
        transcript: answer,
      }),
    onSuccess: () => {
      setAnswer("");
      setError(null);
      queryClient.invalidateQueries({
        queryKey: ["public-interview", joinToken],
      });
    },
    onError: (err) => {
      setError(err instanceof ApiError ? err.message : "Could not submit answer.");
    },
  });

  const finishMutation = useMutation({
    mutationFn: () => closePublicInterview(joinToken),
    onSuccess: () => {
      setJustCompleted(true);
      queryClient.invalidateQueries({
        queryKey: ["public-interview", joinToken],
      });
    },
  });

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-canvas px-4">
        <Skeleton className="h-64 w-full max-w-lg" />
      </div>
    );
  }

  // Backend already gates re-entry (403 once started-and-abandoned, or
  // returns is_completed: true with empty questions). Surface that state
  // as the completion screen rather than a raw error wherever it maps
  // to "this interview is done" semantics.
  if (isError) {
    const message =
      fetchError instanceof ApiError ? fetchError.message : "";
    const alreadyCompleted = message.toLowerCase().includes("already");
    if (alreadyCompleted) {
      return <InterviewCompletionScreen />;
    }
    return (
      <div className="flex min-h-screen items-center justify-center bg-canvas px-4">
        <Card className="max-w-md p-6 text-center">
          <p className="text-sm text-danger">{message || "This interview link is invalid or has expired."}</p>
        </Card>
      </div>
    );
  }

  // Required behavior: once completed, never show the form again —
  // render the completion screen directly.
  if (interview?.is_completed || justCompleted) {
    return <InterviewCompletionScreen />;
  }

  const questions = interview?.questions ?? [];
  const nextQuestion = questions.find((q) => !q.answered);
  const allAnswered = questions.length > 0 && !nextQuestion;

  return (
    <div className="min-h-screen bg-canvas px-4 py-10">
      <div className="mx-auto max-w-lg">
        <div className="mb-6 text-center">
          <h1 className="text-lg font-semibold text-ink">
            {interview?.job_title} — Interview
          </h1>
          <p className="mt-1 text-sm text-secondary">
            {interview?.candidate_name}
          </p>
        </div>

        <Card className="p-6">
          {!allAnswered && nextQuestion && (
            <>
              <p className="mb-1 text-xs font-medium uppercase tracking-wide text-muted">
                {nextQuestion.category} · {nextQuestion.difficulty}
              </p>
              <p className="mb-4 text-sm font-medium text-ink">
                {nextQuestion.question_text}
              </p>

              <textarea
                value={answer}
                onChange={(e) => setAnswer(e.target.value)}
                rows={6}
                placeholder="Type your answer here…"
                className="w-full resize-none rounded-md border border-border px-3 py-2 text-sm text-ink outline-none focus:border-primary"
              />

              {error && (
                <p className="mt-2 text-sm text-danger">{error}</p>
              )}

              <Button
                variant="primary"
                className="mt-4 w-full"
                disabled={!answer.trim() || submitAnswerMutation.isPending}
                onClick={() => submitAnswerMutation.mutate(nextQuestion.id)}
              >
                {submitAnswerMutation.isPending
                  ? "Submitting…"
                  : "Submit answer"}
              </Button>

              <p className="mt-3 text-center text-xs text-muted">
                Question {questions.filter((q) => q.answered).length + 1} of{" "}
                {questions.length}
              </p>
            </>
          )}

          {allAnswered && (
            <div className="text-center">
              <p className="mb-4 text-sm text-secondary">
                You&apos;ve answered all questions. Submit your interview to
                finish.
              </p>
              <Button
                variant="primary"
                className="w-full"
                disabled={finishMutation.isPending}
                onClick={() => finishMutation.mutate()}
              >
                {finishMutation.isPending
                  ? "Submitting interview…"
                  : "Submit interview"}
              </Button>
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
