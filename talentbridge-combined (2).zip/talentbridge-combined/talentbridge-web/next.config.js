/** @type {import('next').NextConfig} */
const nextConfig = {
  output: "standalone",
  async rewrites() {
    return [
      {
        // Proxies browser calls to /backend/* through to the FastAPI service,
        // so the existing /api/* contract on the server stays untouched.
        source: "/backend/:path*",
        destination: `${process.env.BACKEND_BASE_URL || "http://localhost:8000"}/api/:path*`,
      },
    ];
  },
};

module.exports = nextConfig;
