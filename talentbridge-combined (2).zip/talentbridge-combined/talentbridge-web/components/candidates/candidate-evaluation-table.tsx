"use client";

import { useMemo, useState } from "react";
import {
  type ColumnDef,
  flexRender,
  getCoreRowModel,
  useReactTable,
} from "@tanstack/react-table";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { approveCandidate, rejectCandidate } from "@/lib/api";
import { StatusBadge } from "@/components/ui/status-badge";
import { ScoreBar } from "@/components/ui/score-bar";
import { Button } from "@/components/ui/button";
import { ResumePreviewDrawer } from "@/components/candidates/resume-preview-drawer";
import type { InterviewResultEntry, JobRankingEntry } from "@/lib/types";

interface Row extends JobRankingEntry {
  interviewCompleted: boolean;
  interviewId?: number;
}

export function CandidateEvaluationTable({
  jobId,
  rankings,
  interviewResults,
}: {
  jobId: number;
  rankings: JobRankingEntry[];
  interviewResults: InterviewResultEntry[];
}) {
  const queryClient = useQueryClient();
  const [previewCandidate, setPreviewCandidate] = useState<{
    id: number;
    name: string;
  } | null>(null);

  const interviewByCandidate = useMemo(() => {
    const map = new Map<number, InterviewResultEntry>();
    for (const r of interviewResults) map.set(r.candidate_id, r);
    return map;
  }, [interviewResults]);

  const rows: Row[] = useMemo(
    () =>
      rankings.map((r) => {
        const interview = interviewByCandidate.get(r.candidate_id);
        return {
          ...r,
          interviewCompleted: interview?.is_completed ?? false,
          interviewId: interview?.interview_id,
        };
      }),
    [rankings, interviewByCandidate]
  );

  const approveMutation = useMutation({
    mutationFn: approveCandidate,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["job-rankings", jobId] });
    },
  });
  const rejectMutation = useMutation({
    mutationFn: rejectCandidate,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["job-rankings", jobId] });
    },
  });

  const columns = useMemo<ColumnDef<Row>[]>(
    () => [
      {
        header: "Profile",
        accessorKey: "name",
        cell: ({ row }) => (
          <div>
            <div className="font-medium text-ink">{row.original.name}</div>
            <div className="text-xs text-muted">{row.original.email}</div>
          </div>
        ),
      },
      {
        header: "Resume",
        id: "resume",
        cell: ({ row }) => (
          <Button
            size="sm"
            variant="secondary"
            onClick={() =>
              setPreviewCandidate({
                id: row.original.candidate_id,
                name: row.original.name,
              })
            }
          >
            Preview
          </Button>
        ),
      },
      {
        header: "Match score",
        accessorKey: "final_score",
        cell: ({ row }) => <ScoreBar score={row.original.final_score ?? 0} />,
      },
      {
        header: "Stage",
        accessorKey: "status",
        cell: ({ row }) => <StatusBadge status={row.original.status} />,
      },
      {
        header: "Interview",
        id: "interview",
        cell: ({ row }) =>
          row.original.interviewCompleted ? (
            <span className="text-xs font-medium text-success">
              Completed
            </span>
          ) : (
            <span className="text-xs text-muted">Pending</span>
          ),
      },
      {
        header: "Experience",
        accessorKey: "experience_years",
        cell: ({ row }) => `${row.original.experience_years ?? 0} yrs`,
      },
      {
        header: "Skills",
        accessorKey: "skills",
        cell: ({ row }) => (
          <div className="flex max-w-[220px] flex-wrap gap-1">
            {(row.original.skills ?? []).slice(0, 3).map((s) => (
              <span
                key={s}
                className="rounded-full bg-canvas px-2 py-0.5 text-xs text-secondary"
              >
                {s}
              </span>
            ))}
          </div>
        ),
      },
      {
        header: "Actions",
        id: "actions",
        cell: ({ row }) => {
          const status = row.original.status?.toLowerCase() ?? "";
          const isDecided =
            status.includes("reject") ||
            status.includes("offer") ||
            status.includes("join");
          return (
            <div className="flex gap-2">
              <Button
                size="sm"
                variant="primary"
                disabled={
                  !row.original.interviewCompleted ||
                  isDecided ||
                  approveMutation.isPending
                }
                onClick={() => approveMutation.mutate(row.original.candidate_id)}
              >
                Approve
              </Button>
              <Button
                size="sm"
                variant="danger"
                disabled={isDecided || rejectMutation.isPending}
                onClick={() => rejectMutation.mutate(row.original.candidate_id)}
              >
                Reject
              </Button>
            </div>
          );
        },
      },
    ],
    [approveMutation, rejectMutation]
  );

  const table = useReactTable({
    data: rows,
    columns,
    getCoreRowModel: getCoreRowModel(),
  });

  return (
    <>
      <div className="overflow-x-auto rounded-card border border-border">
        <table className="w-full text-sm">
          <thead className="bg-canvas text-left text-xs font-medium uppercase tracking-wide text-muted">
            {table.getHeaderGroups().map((hg) => (
              <tr key={hg.id}>
                {hg.headers.map((header) => (
                  <th key={header.id} className="px-4 py-2.5">
                    {flexRender(header.column.columnDef.header, header.getContext())}
                  </th>
                ))}
              </tr>
            ))}
          </thead>
          <tbody className="divide-y divide-border">
            {table.getRowModel().rows.map((row) => (
              <tr key={row.id} className="hover:bg-canvas/60">
                {row.getVisibleCells().map((cell) => (
                  <td key={cell.id} className="px-4 py-3 align-middle">
                    {flexRender(cell.column.columnDef.cell, cell.getContext())}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <ResumePreviewDrawer
        candidateId={previewCandidate?.id ?? null}
        candidateName={previewCandidate?.name}
        open={previewCandidate !== null}
        onClose={() => setPreviewCandidate(null)}
      />
    </>
  );
}
