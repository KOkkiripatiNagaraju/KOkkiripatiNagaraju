import { cn } from "@/lib/utils";

const STAGES = [
  "Applied",
  "Resume Reviewed",
  "Interview Scheduled",
  "Technical Interview",
  "HR Interview",
  "Offer Released",
  "Background Verification",
  "Hired",
];

// Maps backend candidate.status values onto the fixed tracker stages.
// Backend statuses are flexible strings; this is a best-effort mapping
// kept intentionally conservative so we never overstate progress.
function stageIndexForStatus(status: string): number {
  const s = status?.toLowerCase() ?? "";
  if (s.includes("reject")) return -1; // tracker not shown for rejected
  if (s.includes("hired") || s.includes("join")) return 7;
  if (s.includes("bgv") || s.includes("background")) return 6;
  if (s.includes("offer")) return 5;
  if (s.includes("hr interview")) return 4;
  if (s.includes("technical")) return 3;
  if (s.includes("interview")) return 2;
  if (s.includes("screen") || s.includes("shortlist") || s.includes("review"))
    return 1;
  return 0;
}

export function CandidateStatusTracker({ status }: { status: string }) {
  const currentIndex = stageIndexForStatus(status);

  if (currentIndex === -1) {
    return (
      <div className="rounded-md bg-danger-subtle px-3 py-2 text-sm text-danger">
        Application closed — Rejected
      </div>
    );
  }

  return (
    <div className="flex items-center overflow-x-auto py-2">
      {STAGES.map((stage, i) => (
        <div key={stage} className="flex items-center">
          <div className="flex flex-col items-center">
            <div
              className={cn(
                "flex h-7 w-7 items-center justify-center rounded-full border-2 text-xs font-semibold",
                i < currentIndex &&
                  "border-success bg-success text-white",
                i === currentIndex &&
                  "border-primary bg-primary text-white",
                i > currentIndex &&
                  "border-border bg-surface text-muted"
              )}
            >
              {i < currentIndex ? "✓" : i + 1}
            </div>
            <span
              className={cn(
                "mt-1.5 w-20 text-center text-[11px] leading-tight",
                i <= currentIndex ? "font-medium text-ink" : "text-muted"
              )}
            >
              {stage}
            </span>
          </div>
          {i < STAGES.length - 1 && (
            <div
              className={cn(
                "mx-1 h-0.5 w-8 flex-shrink-0",
                i < currentIndex ? "bg-success" : "bg-border"
              )}
            />
          )}
        </div>
      ))}
    </div>
  );
}
