"use client";

import { useQuery } from "@tanstack/react-query";
import { getCandidateResumeUrl } from "@/lib/api";
import { Drawer } from "@/components/ui/drawer";
import { Skeleton } from "@/components/ui/skeleton";
import { EmptyState } from "@/components/ui/empty-state";

export function ResumePreviewDrawer({
  candidateId,
  candidateName,
  open,
  onClose,
}: {
  candidateId: number | null;
  candidateName?: string;
  open: boolean;
  onClose: () => void;
}) {
  const { data, isLoading } = useQuery({
    queryKey: ["resume-url", candidateId],
    queryFn: () => getCandidateResumeUrl(candidateId as number),
    enabled: open && candidateId !== null,
  });

  return (
    <Drawer
      open={open}
      onClose={onClose}
      title={candidateName ? `Resume — ${candidateName}` : "Resume preview"}
      widthClassName="w-[560px]"
    >
      {isLoading && <Skeleton className="h-[70vh] w-full" />}
      {!isLoading && data?.resume_url && (
        <iframe
          src={data.resume_url}
          title="Resume preview"
          className="h-[75vh] w-full rounded-md border border-border"
        />
      )}
      {!isLoading && !data?.resume_url && (
        <EmptyState
          title="Resume not available"
          description="This candidate's resume could not be located in storage."
        />
      )}
    </Drawer>
  );
}
