"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";

const NAV_ITEMS = [
  { label: "Dashboard", href: "/dashboard" },
  { label: "Jobs", href: "/jobs" },
  { label: "Applications", href: "/applications" },
  { label: "Candidates", href: "/candidates" },
  { label: "Interviews", href: "/interviews" },
  { label: "Offers", href: "/offers" },
  { label: "Hiring Pipeline", href: "/pipeline" },
  { label: "Analytics", href: "/analytics" },
  { label: "Settings", href: "/settings" },
];

export function Sidebar() {
  const pathname = usePathname();

  return (
    <aside className="flex h-screen w-60 flex-col border-r border-border bg-surface">
      <div className="flex h-16 items-center border-b border-border px-6">
        <span className="text-[15px] font-semibold tracking-tight text-ink">
          TalentBridge
        </span>
      </div>

      <nav className="flex-1 overflow-y-auto px-3 py-4">
        <ul className="flex flex-col gap-0.5">
          {NAV_ITEMS.map((item) => {
            const active =
              pathname === item.href || pathname?.startsWith(item.href + "/");
            return (
              <li key={item.href}>
                <Link
                  href={item.href}
                  className={cn(
                    "block rounded-md px-3 py-2 text-sm font-medium transition-colors",
                    active
                      ? "bg-primary-subtle text-primary"
                      : "text-secondary hover:bg-canvas hover:text-ink"
                  )}
                >
                  {item.label}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>

      <div className="border-t border-border px-3 py-3">
        <button
          type="button"
          onClick={() => {
            window.localStorage.removeItem("tb_auth_token");
            window.location.href = "/login";
          }}
          className="block w-full rounded-md px-3 py-2 text-left text-sm font-medium text-secondary hover:bg-canvas hover:text-ink"
        >
          Sign out
        </button>
      </div>
    </aside>
  );
}
