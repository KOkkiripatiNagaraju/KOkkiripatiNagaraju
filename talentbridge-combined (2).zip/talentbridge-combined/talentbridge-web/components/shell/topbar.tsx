"use client";

import { NotificationsBell } from "@/components/shell/notifications-bell";

export function Topbar({ title }: { title: string }) {
  return (
    <header className="flex h-16 items-center justify-between border-b border-border bg-surface px-8">
      <h1 className="text-lg font-semibold text-ink">{title}</h1>
      <NotificationsBell />
    </header>
  );
}
