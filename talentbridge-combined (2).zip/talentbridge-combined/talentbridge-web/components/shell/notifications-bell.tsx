"use client";

import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Bell } from "lucide-react";
import { getPendingEmails } from "@/lib/api";
import { cn } from "@/lib/utils";

export function NotificationsBell() {
  const [open, setOpen] = useState(false);

  // Built from existing endpoints only — there is no dedicated
  // notifications endpoint on the backend yet, so this surfaces the
  // one real-time signal we do have: pending email drafts awaiting review.
  const { data: emails } = useQuery({
    queryKey: ["pending-emails"],
    queryFn: getPendingEmails,
    refetchInterval: 60_000,
    retry: false,
  });

  const count = emails?.length ?? 0;

  return (
    <div className="relative">
      <button
        onClick={() => setOpen((o) => !o)}
        className="relative rounded-md p-2 text-secondary hover:bg-canvas hover:text-ink"
        aria-label="Notifications"
      >
        <Bell size={18} />
        {count > 0 && (
          <span className="absolute -right-0.5 -top-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-danger text-[10px] font-semibold text-white">
            {count > 9 ? "9+" : count}
          </span>
        )}
      </button>

      {open && (
        <div className="absolute right-0 z-20 mt-2 w-80 rounded-card border border-border bg-surface p-3 shadow-popover">
          <p className="mb-2 text-xs font-medium uppercase tracking-wide text-muted">
            Notifications
          </p>
          {count === 0 && (
            <p className="py-4 text-center text-sm text-muted">
              Nothing new right now.
            </p>
          )}
          {(emails ?? []).map((e) => (
            <div
              key={e.id}
              className={cn(
                "rounded-md px-2 py-2 text-sm hover:bg-canvas"
              )}
            >
              <p className="font-medium text-ink">Email draft pending review</p>
              <p className="truncate text-xs text-secondary">{e.subject}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
