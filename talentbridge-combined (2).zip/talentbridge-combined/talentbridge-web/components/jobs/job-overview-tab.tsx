import { Card } from "@/components/ui/card";
import type { Job } from "@/lib/types";

export function JobOverviewTab({ job }: { job: Job }) {
  const profile = (job.structured_profile ?? {}) as Record<string, unknown>;

  return (
    <div className="grid grid-cols-3 gap-5 py-5">
      <div className="col-span-2 space-y-5">
        <Card className="p-5">
          <h3 className="mb-2 text-sm font-semibold text-ink">
            Job description
          </h3>
          <p className="whitespace-pre-wrap text-sm leading-relaxed text-secondary">
            {job.full_description}
          </p>
        </Card>

        {Object.keys(profile).length > 0 && (
          <Card className="p-5">
            <h3 className="mb-2 text-sm font-semibold text-ink">
              AI job insights
            </h3>
            <dl className="grid grid-cols-2 gap-3 text-sm">
              {Object.entries(profile).map(([key, value]) => (
                <div key={key}>
                  <dt className="text-xs text-muted">
                    {key.replace(/_/g, " ")}
                  </dt>
                  <dd className="text-secondary">
                    {Array.isArray(value) ? value.join(", ") : String(value)}
                  </dd>
                </div>
              ))}
            </dl>
          </Card>
        )}
      </div>

      <div className="space-y-5">
        <Card className="p-5">
          <h3 className="mb-3 text-sm font-semibold text-ink">Details</h3>
          <dl className="space-y-2.5 text-sm">
            <Row label="Department" value={job.department} />
            <Row label="Location" value={job.location} />
            <Row label="Employment type" value={job.employment_type} />
            <Row label="Salary range" value={job.salary_range} />
            <Row
              label="Experience required"
              value={`${job.experience_required}+ years`}
            />
          </dl>
        </Card>

        <Card className="p-5">
          <h3 className="mb-3 text-sm font-semibold text-ink">
            Required skills
          </h3>
          <div className="flex flex-wrap gap-1.5">
            {(job.skills_required ?? []).map((skill) => (
              <span
                key={skill}
                className="rounded-full bg-canvas px-2.5 py-1 text-xs text-secondary"
              >
                {skill}
              </span>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between gap-3">
      <dt className="text-secondary">{label}</dt>
      <dd className="text-right font-medium text-ink">{value}</dd>
    </div>
  );
}
