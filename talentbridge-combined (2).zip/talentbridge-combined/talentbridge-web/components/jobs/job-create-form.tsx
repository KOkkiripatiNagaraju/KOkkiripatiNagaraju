"use client";

import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { createJob } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { useState } from "react";

const EMPLOYMENT_TYPES = ["Full-Time", "Part-Time", "Contract", "Internship"];

const schema = z.object({
  title: z.string().min(1, "Job title is required"),
  department: z.string().min(1, "Department is required"),
  location: z.string().min(1, "Location is required"),
  employment_type: z.string().min(1),
  salary_range: z.string().min(1, "Salary range is required"),
  experience_required: z.coerce.number().min(0).max(30),
  skills: z.string().min(1, "List at least one required skill"),
  full_description: z.string().min(1, "Job description is required"),
});

type FormValues = z.infer<typeof schema>;

export function JobCreateForm({ onCreated }: { onCreated?: () => void }) {
  const queryClient = useQueryClient();
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: { employment_type: "Full-Time", experience_required: 3 },
  });

  const mutation = useMutation({
    mutationFn: (values: FormValues) =>
      createJob({
        title: values.title,
        department: values.department,
        location: values.location,
        employment_type: values.employment_type,
        salary_range: values.salary_range,
        experience_required: values.experience_required,
        skills_required: values.skills
          .split(",")
          .map((s) => s.trim())
          .filter(Boolean),
        responsibilities: values.full_description,
        full_description: values.full_description,
      }),
    onSuccess: () => {
      setSuccessMessage("Job posting created. AI analysis is in progress.");
      reset();
      queryClient.invalidateQueries({ queryKey: ["jobs"] });
      onCreated?.();
    },
  });

  return (
    <form
      onSubmit={handleSubmit((values) => mutation.mutate(values))}
      className="space-y-5"
    >
      <div className="grid grid-cols-2 gap-4">
        <Field label="Job title" error={errors.title?.message}>
          <input
            {...register("title")}
            placeholder="Senior Python Engineer"
            className="input"
          />
        </Field>
        <Field label="Department" error={errors.department?.message}>
          <input
            {...register("department")}
            placeholder="Engineering"
            className="input"
          />
        </Field>
        <Field label="Location" error={errors.location?.message}>
          <input
            {...register("location")}
            placeholder="Remote (US / India)"
            className="input"
          />
        </Field>
        <Field label="Salary range" error={errors.salary_range?.message}>
          <input
            {...register("salary_range")}
            placeholder="$120,000 – $150,000"
            className="input"
          />
        </Field>
        <Field label="Employment type">
          <select {...register("employment_type")} className="input">
            {EMPLOYMENT_TYPES.map((t) => (
              <option key={t} value={t}>
                {t}
              </option>
            ))}
          </select>
        </Field>
        <Field
          label="Minimum experience (years)"
          error={errors.experience_required?.message}
        >
          <input
            type="number"
            min={0}
            max={30}
            {...register("experience_required")}
            className="input"
          />
        </Field>
      </div>

      <Field
        label="Required skills (comma-separated)"
        error={errors.skills?.message}
      >
        <input
          {...register("skills")}
          placeholder="Python, FastAPI, PostgreSQL, Docker"
          className="input"
        />
      </Field>

      <Field
        label="Job description"
        error={errors.full_description?.message}
      >
        <textarea
          {...register("full_description")}
          rows={5}
          placeholder="Describe the role, responsibilities, and requirements…"
          className="input resize-none"
        />
      </Field>

      {mutation.isError && (
        <p className="rounded-md bg-danger-subtle px-3 py-2 text-sm text-danger">
          Could not create job posting. Please try again.
        </p>
      )}
      {successMessage && !mutation.isPending && (
        <p className="rounded-md bg-success-subtle px-3 py-2 text-sm text-success">
          {successMessage}
        </p>
      )}

      <Button type="submit" variant="primary" disabled={mutation.isPending}>
        {mutation.isPending ? "Creating job posting…" : "Create job posting"}
      </Button>

      <style jsx>{`
        .input {
          width: 100%;
          border-radius: 6px;
          border: 1px solid #e2e8f0;
          padding: 0.5rem 0.75rem;
          font-size: 0.875rem;
          color: #0f172a;
          outline: none;
        }
        .input:focus {
          border-color: #4f46e5;
        }
      `}</style>
    </form>
  );
}

function Field({
  label,
  error,
  children,
}: {
  label: string;
  error?: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <label className="mb-1 block text-xs font-medium text-secondary">
        {label}
      </label>
      {children}
      {error && <p className="mt-1 text-xs text-danger">{error}</p>}
    </div>
  );
}
