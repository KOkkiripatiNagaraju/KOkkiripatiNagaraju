"use client";

import type { Job } from "@/lib/types";

export function JobPicker({
  jobs,
  selectedJobId,
  onChange,
}: {
  jobs: Job[];
  selectedJobId: number | null;
  onChange: (jobId: number) => void;
}) {
  return (
    <select
      value={selectedJobId ?? ""}
      onChange={(e) => onChange(Number(e.target.value))}
      className="rounded-md border border-border px-3 py-2 text-sm text-ink outline-none focus:border-primary"
    >
      <option value="" disabled>
        Select a job
      </option>
      {jobs.map((job) => (
        <option key={job.id} value={job.id}>
          {job.title} — {job.department} (ID {job.id})
        </option>
      ))}
    </select>
  );
}
