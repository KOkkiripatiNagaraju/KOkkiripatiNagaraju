import Link from "next/link";
import { Card } from "@/components/ui/card";
import { StatusBadge } from "@/components/ui/status-badge";
import type { Job } from "@/lib/types";

export function JobCard({ job }: { job: Job }) {
  const skills = job.skills_required ?? [];
  const skillsPreview = skills.slice(0, 5).join(", ");
  const seniority =
    (job.structured_profile as { seniority_level?: string } | null)
      ?.seniority_level ?? null;

  return (
    <Link href={`/jobs/${job.id}`}>
      <Card className="flex items-center justify-between p-5 transition-colors hover:border-primary/40">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-sm font-semibold text-ink">
              {job.title}
            </span>
            <span className="text-xs text-muted">#{job.id}</span>
            {seniority && (
              <span className="rounded-full bg-canvas px-2 py-0.5 text-xs text-secondary">
                {seniority}
              </span>
            )}
          </div>
          <div className="mt-1.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-secondary">
            <span>{job.location}</span>
            <span>·</span>
            <span>{job.department}</span>
            <span>·</span>
            <span>{job.salary_range}</span>
            <span>·</span>
            <span>{job.employment_type}</span>
            <span>·</span>
            <span>{job.experience_required}+ yrs</span>
          </div>
          {skillsPreview && (
            <p className="mt-2 text-xs text-muted">
              {skillsPreview}
              {skills.length > 5 ? "…" : ""}
            </p>
          )}
        </div>
        <StatusBadge status={job.status} />
      </Card>
    </Link>
  );
}
