"use client";

import Link from "next/link";
import { useQuery } from "@tanstack/react-query";
import { getCandidatesForJob } from "@/lib/api";
import { StatusBadge } from "@/components/ui/status-badge";
import { Skeleton } from "@/components/ui/skeleton";
import { EmptyState } from "@/components/ui/empty-state";
import { ResumeUploader } from "@/components/jobs/resume-uploader";

export function JobApplicantsTab({ jobId }: { jobId: number }) {
  const { data: candidates, isLoading } = useQuery({
    queryKey: ["job-candidates", jobId],
    queryFn: () => getCandidatesForJob(jobId),
  });

  return (
    <div className="space-y-5 py-5">
      <ResumeUploader jobId={jobId} />

      <div>
        <h3 className="mb-3 text-sm font-semibold text-ink">
          Applicants {candidates ? `(${candidates.length})` : ""}
        </h3>

        {isLoading && <Skeleton className="h-40 w-full" />}

        {candidates && candidates.length === 0 && (
          <EmptyState
            title="No applicants yet"
            description="Uploaded resumes will appear here once processed."
          />
        )}

        {candidates && candidates.length > 0 && (
          <div className="overflow-hidden rounded-card border border-border">
            <table className="w-full text-sm">
              <thead className="bg-canvas text-left text-xs font-medium uppercase tracking-wide text-muted">
                <tr>
                  <th className="px-4 py-2.5">Name</th>
                  <th className="px-4 py-2.5">Email</th>
                  <th className="px-4 py-2.5">Experience</th>
                  <th className="px-4 py-2.5">Stage</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {candidates.map((c) => (
                  <tr key={c.id} className="hover:bg-canvas/60">
                    <td className="px-4 py-2.5">
                      <Link
                        href={`/candidates/${c.id}`}
                        className="font-medium text-ink hover:text-primary"
                      >
                        {c.name}
                      </Link>
                    </td>
                    <td className="px-4 py-2.5 text-secondary">{c.email}</td>
                    <td className="px-4 py-2.5 text-secondary">
                      {c.experience_years ?? "—"} yrs
                    </td>
                    <td className="px-4 py-2.5">
                      <StatusBadge status={c.status} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
