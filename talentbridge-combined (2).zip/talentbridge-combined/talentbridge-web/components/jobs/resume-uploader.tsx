"use client";

import { useRef, useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { uploadResume } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

interface UploadResult {
  fileName: string;
  status: "success" | "error";
  detail?: string;
}

export function ResumeUploader({ jobId }: { jobId: number }) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [files, setFiles] = useState<File[]>([]);
  const [results, setResults] = useState<UploadResult[]>([]);
  const queryClient = useQueryClient();

  const mutation = useMutation({
    mutationFn: async (filesToUpload: File[]) => {
      const outcomes: UploadResult[] = [];
      for (const file of filesToUpload) {
        try {
          await uploadResume(jobId, file);
          outcomes.push({ fileName: file.name, status: "success" });
        } catch (err) {
          outcomes.push({
            fileName: file.name,
            status: "error",
            detail: err instanceof Error ? err.message : "Upload failed",
          });
        }
      }
      return outcomes;
    },
    onSuccess: (outcomes) => {
      setResults(outcomes);
      setFiles([]);
      queryClient.invalidateQueries({ queryKey: ["job-candidates", jobId] });
      queryClient.invalidateQueries({ queryKey: ["job-rankings", jobId] });
    },
  });

  return (
    <Card className="p-5">
      <h3 className="mb-1 text-sm font-semibold text-ink">Add candidates</h3>
      <p className="mb-4 text-sm text-secondary">
        Upload resumes to run the AI evaluation pipeline — parsing, matching,
        scoring, and ranking against this job.
      </p>

      <div
        onClick={() => inputRef.current?.click()}
        onDragOver={(e) => e.preventDefault()}
        onDrop={(e) => {
          e.preventDefault();
          const dropped = Array.from(e.dataTransfer.files);
          setFiles((prev) => [...prev, ...dropped]);
        }}
        className="cursor-pointer rounded-md border border-dashed border-border bg-canvas px-4 py-8 text-center text-sm text-secondary hover:border-primary/40"
      >
        Drag and drop resumes here, or click to browse (PDF or TXT)
        <input
          ref={inputRef}
          type="file"
          multiple
          accept=".pdf,.txt"
          className="hidden"
          onChange={(e) => {
            const selected = Array.from(e.target.files ?? []);
            setFiles((prev) => [...prev, ...selected]);
          }}
        />
      </div>

      {files.length > 0 && (
        <ul className="mt-3 space-y-1 text-sm text-secondary">
          {files.map((f, i) => (
            <li key={`${f.name}-${i}`}>{f.name}</li>
          ))}
        </ul>
      )}

      <div className="mt-4">
        <Button
          variant="primary"
          disabled={files.length === 0 || mutation.isPending}
          onClick={() => mutation.mutate(files)}
        >
          {mutation.isPending
            ? "Processing resumes…"
            : `Process ${files.length || ""} resume${
                files.length === 1 ? "" : "s"
              }`}
        </Button>
      </div>

      {results.length > 0 && (
        <ul className="mt-4 space-y-1.5 text-sm">
          {results.map((r, i) => (
            <li
              key={`${r.fileName}-${i}`}
              className={
                r.status === "success" ? "text-success" : "text-danger"
              }
            >
              {r.fileName} — {r.status === "success" ? "processed" : r.detail}
            </li>
          ))}
        </ul>
      )}
    </Card>
  );
}
