"use client";

import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

export function InterviewCompletionScreen({
  submittedAt,
}: {
  submittedAt?: string | null;
}) {
  const formattedTimestamp = submittedAt
    ? new Date(submittedAt).toLocaleString(undefined, {
        dateStyle: "medium",
        timeStyle: "short",
      })
    : new Date().toLocaleString(undefined, {
        dateStyle: "medium",
        timeStyle: "short",
      });

  return (
    <div className="flex min-h-screen items-center justify-center bg-canvas px-4">
      <Card className="w-full max-w-md p-8 text-center">
        <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-success-subtle">
          <span className="text-xl text-success">✓</span>
        </div>

        <h1 className="text-lg font-semibold text-ink">
          Thank you for attending the interview!
        </h1>

        <p className="mt-2 text-sm leading-relaxed text-secondary">
          Your interview has been submitted successfully. Our recruitment
          team will review your responses and contact you regarding the next
          steps.
        </p>

        <div className="mt-6 rounded-md bg-canvas px-4 py-3 text-left text-sm">
          <div className="flex items-center justify-between">
            <span className="text-secondary">Interview status</span>
            <span className="font-medium text-success">✅ Completed</span>
          </div>
          <div className="mt-1.5 flex items-center justify-between">
            <span className="text-secondary">Submitted</span>
            <span className="font-medium text-ink">{formattedTimestamp}</span>
          </div>
        </div>

        <Link href="/careers/applications" className="mt-6 block">
          <Button variant="primary" className="w-full">
            View my applications
          </Button>
        </Link>
      </Card>
    </div>
  );
}
