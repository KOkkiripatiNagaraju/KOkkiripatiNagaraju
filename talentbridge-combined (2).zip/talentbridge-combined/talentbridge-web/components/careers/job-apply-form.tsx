"use client";

import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { applyToJob, ApiError } from "@/lib/api";
import { Button } from "@/components/ui/button";

export function JobApplyForm({
  jobId,
  onSuccess,
}: {
  jobId: number;
  onSuccess: () => void;
}) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [error, setError] = useState<string | null>(null);

  const mutation = useMutation({
    mutationFn: () => {
      if (!file) throw new Error("Please attach your resume.");
      return applyToJob(jobId, { name, email, phone, file });
    },
    onSuccess,
    onError: (err) => {
      setError(
        err instanceof ApiError
          ? err.message
          : err instanceof Error
          ? err.message
          : "Could not submit application."
      );
    },
  });

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        setError(null);
        mutation.mutate();
      }}
      className="space-y-4"
    >
      <Field label="Full name">
        <input
          required
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="input"
        />
      </Field>
      <Field label="Email">
        <input
          type="email"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="input"
        />
      </Field>
      <Field label="Phone">
        <input
          required
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
          className="input"
        />
      </Field>
      <Field label="Resume (PDF)">
        <input
          type="file"
          accept=".pdf,.txt"
          required
          onChange={(e) => setFile(e.target.files?.[0] ?? null)}
          className="input"
        />
      </Field>

      {error && (
        <p className="rounded-md bg-danger-subtle px-3 py-2 text-sm text-danger">
          {error}
        </p>
      )}

      <Button type="submit" variant="primary" disabled={mutation.isPending}>
        {mutation.isPending ? "Submitting…" : "Submit application"}
      </Button>

      <style jsx>{`
        .input {
          width: 100%;
          border-radius: 6px;
          border: 1px solid #e2e8f0;
          padding: 0.5rem 0.75rem;
          font-size: 0.875rem;
          color: #0f172a;
          outline: none;
        }
        .input:focus {
          border-color: #4f46e5;
        }
      `}</style>
    </form>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="mb-1 block text-xs font-medium text-secondary">
        {label}
      </label>
      {children}
    </div>
  );
}
