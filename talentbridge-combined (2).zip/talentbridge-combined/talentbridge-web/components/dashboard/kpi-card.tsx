import Link from "next/link";
import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";

export function KpiCard({
  label,
  value,
  href,
  accent,
}: {
  label: string;
  value: number | string;
  href: string;
  accent?: "primary" | "success" | "warning";
}) {
  return (
    <Link href={href}>
      <Card className="p-5 transition-colors hover:border-primary/40">
        <p className="text-xs font-medium uppercase tracking-wide text-muted">
          {label}
        </p>
        <p
          className={cn(
            "mt-2 text-2xl font-semibold tabular",
            accent === "primary" && "text-primary",
            accent === "success" && "text-success",
            accent === "warning" && "text-warning",
            !accent && "text-ink"
          )}
        >
          {value}
        </p>
      </Card>
    </Link>
  );
}
