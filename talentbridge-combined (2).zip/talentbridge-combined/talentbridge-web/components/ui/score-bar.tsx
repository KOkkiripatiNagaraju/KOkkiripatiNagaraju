import { cn } from "@/lib/utils";

function scoreColor(score: number) {
  if (score >= 75) return "#15803D"; // success
  if (score >= 50) return "#B45309"; // warning
  return "#B91C1C"; // danger
}

export function ScoreBar({
  score,
  size = "md",
}: {
  score: number;
  size?: "sm" | "md";
}) {
  const clamped = Math.max(0, Math.min(100, score));
  const color = scoreColor(clamped);

  return (
    <div className="flex items-center gap-2">
      <span
        className={cn(
          "tabular font-semibold",
          size === "sm" ? "text-xs" : "text-sm"
        )}
        style={{ color }}
      >
        {clamped.toFixed(0)}%
      </span>
      <div
        className={cn(
          "flex-1 overflow-hidden rounded-full bg-border",
          size === "sm" ? "h-1 w-16" : "h-1.5 w-24"
        )}
      >
        <div
          className="h-full rounded-full transition-all"
          style={{ width: `${clamped}%`, background: color }}
        />
      </div>
    </div>
  );
}
