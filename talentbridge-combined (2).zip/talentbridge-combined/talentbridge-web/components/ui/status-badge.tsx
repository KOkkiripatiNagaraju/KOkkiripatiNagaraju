import { cn } from "@/lib/utils";

const STATUS_STYLES: Record<string, string> = {
  active: "bg-success-subtle text-success",
  applied: "bg-primary-subtle text-primary",
  screening: "bg-primary-subtle text-primary",
  shortlisted: "bg-primary-subtle text-primary",
  interviewing: "bg-warning-subtle text-warning",
  offered: "bg-success-subtle text-success",
  "offer accepted": "bg-success-subtle text-success",
  joined: "bg-success-subtle text-success",
  rejected: "bg-danger-subtle text-danger",
  "offer rejected": "bg-danger-subtle text-danger",
  "offer revoked": "bg-danger-subtle text-danger",
  archived: "bg-canvas text-secondary",
};

export function StatusBadge({ status }: { status: string }) {
  const key = status?.toLowerCase?.() ?? "";
  const style = STATUS_STYLES[key] ?? "bg-canvas text-secondary";
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium",
        style
      )}
    >
      {status}
    </span>
  );
}
