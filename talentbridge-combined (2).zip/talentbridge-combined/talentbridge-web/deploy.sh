#!/usr/bin/env bash
# Deploys the new recruiter Next.js frontend to Cloud Run.
#
# Run this from Cloud Shell, inside the talentbridge-web directory, after
# pulling/copying this code into your project's source tree. This mirrors
# the same deployment pattern already used for hr-backend / hr-recruiter-ui
# / hr-candidate-ui in project hr-portal-500307.
#
# IMPORTANT: review BACKEND_BASE_URL below before running — it must point
# at your existing hr-backend Cloud Run URL so the rewrite proxy in
# next.config.js can reach /api/* on the real backend.

set -euo pipefail

PROJECT_ID="hr-portal-500307"
REGION="asia-south1"
SERVICE_NAME="hr-recruiter-ui-v2"   # suffixed -v2 so it does not collide with
                                    # the existing hr-recruiter-ui service
                                    # while this migration is being validated.
BACKEND_BASE_URL="${BACKEND_BASE_URL:-}"  # e.g. https://hr-backend-xxxxx-el.a.run.app

if [[ -z "$BACKEND_BASE_URL" ]]; then
  echo "ERROR: set BACKEND_BASE_URL to your existing hr-backend Cloud Run URL." >&2
  echo "Example: BACKEND_BASE_URL=https://hr-backend-xxxxx-el.a.run.app ./deploy.sh" >&2
  exit 1
fi

gcloud config set project "$PROJECT_ID"

gcloud run deploy "$SERVICE_NAME" \
  --source . \
  --region "$REGION" \
  --allow-unauthenticated \
  --set-env-vars "BACKEND_BASE_URL=${BACKEND_BASE_URL}" \
  --port 8080

echo
echo "Deployed. Once you've validated this against the real backend, you can"
echo "promote it by re-deploying under the original hr-recruiter-ui service"
echo "name, or by updating traffic/DNS to point at this revision."
