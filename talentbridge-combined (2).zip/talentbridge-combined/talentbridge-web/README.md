# TalentBridge — Next.js Frontend (Full Recruitment Migration)

## What's in this archive

A complete, build-verified Next.js 15 (App Router, TypeScript, Tailwind)
frontend covering the recruitment-side spec:

**Recruiter app** (`/dashboard`, `/jobs`, `/applications`, `/candidates`,
`/interviews`, `/offers`, `/pipeline`, `/analytics`, `/settings`):
- Dashboard with clickable KPI cards (Active Jobs, Total Candidates,
  Interviews, Offers, Hired, Background Verification)
- Sidebar with the exact plain-text nav labels from the spec, no icons
- Jobs list, create-job drawer, job details with Overview / Applicants /
  Interviews / Offers / Analytics tabs
- Applications: cross-job flat candidate list
- Candidate Evaluation: status-bucketed table (Pending / Interviewed /
  Approved / Rejected), resume preview drawer, approve/reject actions
- Candidate Profile: profile, current hiring stage tracker, interview
  feedback, match score breakdown, skills/experience, notes and
  communication-history sections (UI built; backend has no endpoint for
  these last two yet — see "Known gaps" below)
- Interviews: per-job interview panel (rank, match score, AI verdict,
  interview status/score)
- Offers and Hiring Pipeline: cross-job views, pipeline shows the
  horizontal candidate status tracker
- Analytics: hiring funnel, applications-by-status, offer acceptance rate
  (computed client-side from existing endpoints — no new backend routes
  required)
- Email Center: review/edit/send AI-drafted candidate emails
- Notifications bell: surfaces pending email drafts (only real-time signal
  the backend currently exposes; no dedicated notifications endpoint)
- Settings: current account info

**Careers Portal** (`/careers`, public + candidate-authenticated):
- Home: public job listing
- Job details + apply form (multipart upload to `/public/jobs/{id}/apply`)
- My Applications: status per application, link into interview when ready
- Profile

**Public interview flow** (`/interview/[joinToken]`):
- Conditionally renders the interview form or the completion screen based
  on the backend's `is_completed` flag — exactly per spec
- Once submitted, shows "Thank you for attending the interview!", status,
  timestamp, and a "View my applications" button — no editable fields,
  no re-render of the form
- Re-visiting a completed/abandoned interview URL shows the completion
  screen directly (backend already enforces this server-side; frontend
  just respects it)

`npm run build` completes cleanly — no type errors, all 19 routes resolve.

## Known gaps / deliberately not built

- **HR Operations** (Policy Gen, Tickets, Training, Pulse Survey, Exit,
  Onboarding) — left out, per your "decide as we go" call. Not started.
- **Candidate notes and communication history** — UI sections exist on the
  Candidate Profile page but there's no backend endpoint for recruiter
  notes or a candidate-linked email log read API. Building real backend
  endpoints for these was outside "preserve all APIs, don't rewrite
  backend logic," so the section currently shows a placeholder rather than
  fabricated data.
- **Candidate Sources analytics** — backend doesn't track acquisition
  source, so this panel says so rather than inventing numbers.
- **Full audio/video interview recording UI** — the original
  `static/candidate_interview.html` does webcam + mic recording with
  speech-to-text. The Next.js version submits typed text answers against
  the same `/public/interviews/{token}/answer` contract (which accepts
  `transcript` + optional `audio`), since the spec's explicit ask for this
  flow was specifically the completion-screen behavior, not a re-build of
  the recording UI. The completion-screen requirement itself is fully
  implemented.

## How the backend connection works

All `/backend/*` requests are rewritten server-side (`next.config.js`) to
`${BACKEND_BASE_URL}/api/*`. Your existing `/api/*` paths, payloads, and
JWT auth are unchanged. Set one environment variable —
`BACKEND_BASE_URL` — pointing at your `hr-backend` Cloud Run URL.

## Deploying to your GCP project

I don't have credentials or network access to your GCP project, so I can't
run this deploy myself. To do it yourself in Cloud Shell:

1. Upload/copy this archive's contents into Cloud Shell, then `cd` into it.
2. Find your existing backend URL:
   ```
   gcloud run services describe hr-backend --region asia-south1 --format='value(status.url)'
   ```
3. Deploy:
   ```
   BACKEND_BASE_URL=https://<your-hr-backend-url> ./deploy.sh
   ```

This creates a **new** service, `hr-recruiter-ui-v2`, in `asia-south1`
under `hr-portal-500307` — it does not touch your existing
`hr-recruiter-ui` or `hr-candidate-ui` services, so you can validate this
against the real backend before cutting over traffic.

## Local run / build commands

```bash
npm install
export BACKEND_BASE_URL=http://localhost:8000   # or your deployed backend URL
npm run dev     # http://localhost:3000
# or, to test the production build:
npm run build && npm start
```

## Security note (unrelated to this build, but worth repeating)

The original uploaded archive contains what looks like a live GCP service
account key and real candidate PII. Worth rotating that key and not
re-sharing that archive as-is.
