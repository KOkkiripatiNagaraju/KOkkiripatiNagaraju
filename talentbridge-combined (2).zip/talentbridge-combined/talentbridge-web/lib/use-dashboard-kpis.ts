"use client";

import { useQuery } from "@tanstack/react-query";
import { listJobs, getCandidatesForJob } from "@/lib/api";

export interface DashboardKpis {
  activeJobs: number;
  totalCandidates: number;
  interviewing: number;
  offered: number;
  hired: number;
  backgroundVerification: number;
}

export function useDashboardKpis() {
  const jobsQuery = useQuery({ queryKey: ["jobs"], queryFn: listJobs });

  const candidatesQuery = useQuery({
    queryKey: ["all-candidates", jobsQuery.data?.map((j) => j.id)],
    queryFn: async () => {
      const jobs = jobsQuery.data ?? [];
      const results = await Promise.all(
        jobs.map((j) =>
          getCandidatesForJob(j.id).catch(() => [] as Awaited<
            ReturnType<typeof getCandidatesForJob>
          >)
        )
      );
      return results.flat();
    },
    enabled: !!jobsQuery.data,
  });

  const kpis: DashboardKpis | null = (() => {
    if (!jobsQuery.data || !candidatesQuery.data) return null;
    const candidates = candidatesQuery.data;
    const statusOf = (s: string) => s?.toLowerCase() ?? "";

    return {
      activeJobs: jobsQuery.data.filter((j) => j.status === "Active").length,
      totalCandidates: candidates.length,
      interviewing: candidates.filter((c) =>
        statusOf(c.status).includes("interview")
      ).length,
      offered: candidates.filter((c) => statusOf(c.status).includes("offer"))
        .length,
      hired: candidates.filter(
        (c) =>
          statusOf(c.status).includes("hired") ||
          statusOf(c.status).includes("join")
      ).length,
      backgroundVerification: candidates.filter((c) =>
        statusOf(c.status).includes("bgv")
      ).length,
    };
  })();

  return {
    kpis,
    isLoading: jobsQuery.isLoading || candidatesQuery.isLoading,
    isError: jobsQuery.isError || candidatesQuery.isError,
  };
}
