// Thin fetch client for the existing FastAPI backend.
//
// Requests go through /backend/* which next.config.js rewrites to
// {BACKEND_BASE_URL}/api/* — this keeps the existing backend's `/api`
// prefix and route paths completely unchanged (see routers/api.py).
//
// Auth: the backend issues a JWT from POST /api/login (OAuth2 password
// flow — form-encoded username/password) and expects
// `Authorization: Bearer <token>` on subsequent calls. We store the token
// in localStorage under the same mental model as the old Streamlit
// `st.session_state["auth_token"]`.

import type {
  AtsScore,
  Candidate,
  Decision,
  Job,
  JobCreateInput,
  JobRankingEntry,
  InterviewResultEntry,
  Recommendation,
} from "./types";

const TOKEN_KEY = "tb_auth_token";

export function getToken(): string | null {
  if (typeof window === "undefined") return null;
  return window.localStorage.getItem(TOKEN_KEY);
}

export function setToken(token: string) {
  window.localStorage.setItem(TOKEN_KEY, token);
}

export function clearToken() {
  window.localStorage.removeItem(TOKEN_KEY);
}

class ApiError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

async function request<T>(
  path: string,
  options: RequestInit = {}
): Promise<T> {
  const token = getToken();
  const headers = new Headers(options.headers);
  if (token) headers.set("Authorization", `Bearer ${token}`);
  if (
    options.body &&
    !(options.body instanceof FormData) &&
    !headers.has("Content-Type")
  ) {
    headers.set("Content-Type", "application/json");
  }

  const res = await fetch(`/backend${path}`, { ...options, headers });

  if (!res.ok) {
    let detail = res.statusText;
    try {
      const body = await res.json();
      detail = body.detail || detail;
    } catch {
      // ignore parse failure, fall back to statusText
    }
    throw new ApiError(res.status, detail);
  }

  if (res.status === 204) return undefined as T;

  const contentType = res.headers.get("content-type") || "";
  if (contentType.includes("application/json")) {
    return res.json() as Promise<T>;
  }
  return res.blob() as unknown as Promise<T>;
}

// ── Auth ─────────────────────────────────────────────────────────────────

export async function login(email: string, password: string) {
  const form = new URLSearchParams();
  form.set("username", email);
  form.set("password", password);
  const data = await request<{ access_token: string; token_type: string }>(
    "/login",
    {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: form.toString(),
    }
  );
  setToken(data.access_token);
  return data;
}

// ── Jobs ─────────────────────────────────────────────────────────────────

export function listJobs() {
  return request<Job[]>("/jobs");
}

export function getJob(jobId: number) {
  return request<Job>(`/jobs/${jobId}`);
}

export function createJob(payload: JobCreateInput) {
  return request<Job>("/jobs", {
    method: "POST",
    body: JSON.stringify(payload),
  });
}

export function archiveJob(jobId: number) {
  return request<{ message: string }>(`/jobs/${jobId}/archive`, {
    method: "PATCH",
  });
}

export function getCandidatesForJob(jobId: number) {
  return request<Candidate[]>(`/jobs/${jobId}/candidates`);
}

export function getJobRankings(jobId: number) {
  return request<JobRankingEntry[]>(`/jobs/${jobId}/rankings`);
}

export function getInterviewResultsForJob(jobId: number) {
  return request<{ results: InterviewResultEntry[] }>(
    `/interviews/job/${jobId}/results`
  );
}

// ── Candidates ───────────────────────────────────────────────────────────

export function getCandidate(candidateId: number) {
  return request<Candidate>(`/candidates/${candidateId}`);
}

export function getCandidateResumeUrl(candidateId: number) {
  return request<{ resume_url: string | null }>(
    `/candidates/${candidateId}/resume-url`
  );
}

export function getAtsScore(candidateId: number) {
  return request<AtsScore>(`/candidates/${candidateId}/ats-score`);
}

export function getRecommendation(candidateId: number) {
  return request<Recommendation>(`/candidates/${candidateId}/recommendation`);
}

export function getDecision(candidateId: number) {
  return request<Decision>(`/candidates/${candidateId}/decision`);
}

export function approveCandidate(candidateId: number) {
  return request<{ message: string }>(`/candidates/${candidateId}/approve`, {
    method: "POST",
  });
}

export function rejectCandidate(candidateId: number) {
  return request<{ message: string }>(`/candidates/${candidateId}/reject`, {
    method: "POST",
  });
}

export function uploadResume(jobId: number, file: File) {
  const form = new FormData();
  form.set("job_id", String(jobId));
  form.set("file", file);
  return request<{
    message: string;
    candidate_id: number;
    name: string;
    email: string;
    s3_stored: boolean;
  }>("/resumes/upload", {
    method: "POST",
    body: form,
  });
}

export function forceCompleteInterview(interviewId: number) {
  return request<{ message: string }>(
    `/interviews/${interviewId}/force-complete`,
    { method: "POST" }
  );
}

export function downloadPdfReport(candidateId: number) {
  return request<Blob>(`/candidates/${candidateId}/report/pdf`);
}

export function downloadExcelReport(candidateId: number) {
  return request<Blob>(`/candidates/${candidateId}/report/excel`);
}

// ── Interview panel (recruiter-side, per job) ───────────────────────────────

export function getInterviewPanelForJob(jobId: number) {
  return request<import("./types").InterviewPanel>(
    `/interviews/job/${jobId}/panel`
  );
}

export function getInterviewHrPreview(interviewId: number) {
  return request<Record<string, unknown>>(
    `/interviews/${interviewId}/hr-preview`
  );
}

// ── Email Center ─────────────────────────────────────────────────────────

export function getPendingEmails() {
  return request<import("./types").PendingEmail[]>("/emails/pending");
}

export function reviewEmail(
  emailLogId: number,
  payload: { approve: boolean; edited_subject?: string; edited_body?: string }
) {
  return request<{ status: string }>(`/emails/${emailLogId}/review`, {
    method: "POST",
    body: JSON.stringify(payload),
  });
}

// ── Candidate self-service (Careers Portal) ────────────────────────────────

export function getMyApplications() {
  return request<import("./types").MyApplication[]>("/candidates/me");
}

export function getMe() {
  return request<{
    id: number;
    email: string;
    full_name: string;
    is_manager: boolean;
    created_at?: string;
  }>("/users/me");
}

export function acceptOffer() {
  return request<{ message: string; status: string }>(
    "/candidates/me/accept-offer",
    { method: "POST" }
  );
}

export function rejectOffer() {
  return request<{ message: string; status: string }>(
    "/candidates/me/reject-offer",
    { method: "POST" }
  );
}

export function getMyOffer() {
  return request<Record<string, unknown>>("/candidates/me/offer");
}

// ── Public careers portal (unauthenticated) ────────────────────────────────

export function listPublicJobs() {
  return request<import("./types").PublicJob[]>("/public/jobs");
}

export function applyToJob(
  jobId: number,
  payload: { name: string; email: string; phone: string; file: File }
) {
  const form = new FormData();
  form.set("name", payload.name);
  form.set("email", payload.email);
  form.set("phone", payload.phone);
  form.set("file", payload.file);
  return request<{
    message: string;
    candidate_id: number;
    name: string;
    email: string;
  }>(`/public/jobs/${jobId}/apply`, { method: "POST", body: form });
}

// ── Public interview-taking flow ────────────────────────────────────────

export function getPublicInterview(joinToken: string) {
  return request<import("./types").PublicInterviewState>(
    `/public/interviews/${joinToken}`
  );
}

export function submitPublicInterviewAnswer(
  joinToken: string,
  payload: { question_id: number; transcript: string; audio?: File | null }
) {
  const form = new FormData();
  form.set("question_id", String(payload.question_id));
  form.set("transcript", payload.transcript);
  if (payload.audio) form.set("audio", payload.audio);
  return request<{ message: string; audio_stored: boolean }>(
    `/public/interviews/${joinToken}/answer`,
    { method: "POST", body: form }
  );
}

export function closePublicInterview(joinToken: string) {
  return request<{ message: string; overall_score: number | null }>(
    `/public/interviews/${joinToken}/close`,
    { method: "POST" }
  );
}

export { ApiError };
