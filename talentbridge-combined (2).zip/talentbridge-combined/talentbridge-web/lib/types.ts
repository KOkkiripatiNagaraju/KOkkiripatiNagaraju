// Mirrors models/schemas.py. Field names and shapes match the FastAPI
// response models exactly — do not rename fields here without checking
// the backend, since the UI binds directly to these contracts.

export interface Job {
  id: number;
  title: string;
  department: string;
  location: string;
  employment_type: string;
  salary_range: string;
  experience_required: number;
  skills_required: string[];
  responsibilities: string;
  full_description: string;
  status: string; // "Active" | "Archived"
  structured_profile?: Record<string, unknown> | null;
  created_at?: string;
}

export interface JobCreateInput {
  title: string;
  department: string;
  location: string;
  employment_type: string;
  salary_range: string;
  experience_required: number;
  skills_required: string[];
  responsibilities: string;
  full_description: string;
}

export interface Candidate {
  id: number;
  job_id: number;
  name: string;
  email: string;
  phone?: string | null;
  skills?: string[] | null;
  experience_years?: number | null;
  status: string; // Applied, Screening, Shortlisted, Interviewing, Offered, Rejected, ...
  applied_at?: string | null;
}

export interface AtsScoreBreakdown {
  skills_match: number | null;
  experience_match: number | null;
  semantic_similarity: number | null;
  total_score: number | null;
  strengths: string[];
  skill_gaps: string[];
}

export interface AtsScore {
  candidate_id: number;
  skills_match: number;
  experience_match: number;
  project_relevance: number;
  education_score: number;
  certification_score: number;
  semantic_similarity: number;
  total_score: number;
  strengths?: string[] | null;
  skill_gaps?: string[] | null;
  recommendation?: string | null;
}

// Shape returned by GET /jobs/{job_id}/rankings — note this is a richer,
// denormalized payload (not the bare RankingResponse schema) per the
// "BUG FIX" comment in routers/api.py.
export interface JobRankingEntry {
  rank: number;
  final_score: number;
  candidate_id: number;
  name: string;
  email: string;
  phone: string;
  status: string;
  experience_years: number;
  skills: string[];
  applied_at: string | null;
  ats_breakdown: AtsScoreBreakdown | null;
  ai_verdict: string | null;
  ai_rating: number | null;
}

export interface InterviewResultEntry {
  candidate_id: number;
  interview_id: number;
  is_completed: boolean;
  [key: string]: unknown;
}

export interface Recommendation {
  ai_verdict?: string | null;
  ai_rating?: number | null;
  [key: string]: unknown;
}

export interface Decision {
  final_decision?: string | null;
  verdict?: string | null;
  confidence_score?: number | null;
  confidence?: number | null;
  reasoning?: string | null;
  justification?: string | null;
  recommended_action?: string | null;
  [key: string]: unknown;
}

// ── Additional entities for Dashboard, Pipeline, Profile, Analytics,
// Notifications, Careers Portal, and Interview flow ────────────────────────

export interface CandidateDetail extends Candidate {
  education?: string[] | Record<string, unknown>[] | null;
  parsed_data?: Record<string, unknown> | null;
}

export interface InterviewPanelCandidate {
  candidate_id: number;
  name: string;
  email: string;
  phone: string | null;
  status: string;
  experience_years: number | null;
  skills: string[];
  education: unknown[];
  applied_at: string | null;
  rank: number | null;
  ats_total_score: number | null;
  ai_verdict: string | null;
  interview_id: number | null;
  interview_done: boolean;
  interview_score: number | null;
}

export interface InterviewPanel {
  job_id: number;
  job_title: string;
  job_description: string;
  structured_profile: Record<string, unknown> | null;
  total_candidates: number;
  candidates: InterviewPanelCandidate[];
}

export interface PendingEmail {
  id: number;
  candidate_id: number;
  subject: string;
  body: string;
  status: string;
  created_at?: string | null;
  [key: string]: unknown;
}

export interface MyApplication {
  candidate_id: number;
  job_id: number;
  job_title: string;
  department: string;
  location: string;
  status: string;
  applied_at: string | null;
  interview_id: number | null;
  interview_scheduled_at: string | null;
  interview_completed: boolean;
  interview_join_token: string | null;
  parsed_data: Record<string, unknown> | null;
}

export interface PublicJob {
  id: number;
  title: string;
  department: string;
  location: string;
  employment_type: string;
  salary_range: string;
  experience_required: number;
  skills_required: string[];
  responsibilities: string;
  full_description: string;
}

export interface PublicInterviewQuestion {
  id: number;
  category: string;
  difficulty: string;
  question_text: string;
  answered: boolean;
}

export interface PublicInterviewState {
  interview_id: number;
  candidate_name: string;
  job_title: string;
  is_completed: boolean;
  scheduled_at?: string | null;
  answered_count?: number;
  questions: PublicInterviewQuestion[];
}

