/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./lib/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        ink: "#0F172A",
        secondary: "#475569",
        muted: "#94A3B8",
        border: "#E2E8F0",
        canvas: "#F8FAFC",
        surface: "#FFFFFF",
        primary: {
          DEFAULT: "#4F46E5",
          hover: "#4338CA",
          subtle: "#EEF2FF",
        },
        success: {
          DEFAULT: "#15803D",
          subtle: "#F0FDF4",
        },
        warning: {
          DEFAULT: "#B45309",
          subtle: "#FFFBEB",
        },
        danger: {
          DEFAULT: "#B91C1C",
          subtle: "#FEF2F2",
        },
      },
      fontFamily: {
        sans: ["Inter", "-apple-system", "BlinkMacSystemFont", "sans-serif"],
        mono: ["'JetBrains Mono'", "monospace"],
      },
      boxShadow: {
        card: "0 1px 2px 0 rgba(15, 23, 42, 0.05)",
        popover: "0 4px 16px -2px rgba(15, 23, 42, 0.12)",
      },
      borderRadius: {
        card: "10px",
      },
    },
  },
  plugins: [],
};
