"""
Pydantic request/response schemas for HR Policy Generator & Chatbot.
"""
from typing import Any, Dict, List, Optional
from pydantic import BaseModel


class HRPolicyGenerateRequest(BaseModel):
    policy_type: str
    title: str
    requirements: str
    department: Optional[str] = None
    location: Optional[str] = None
    effective_date: Optional[str] = None


class HRPolicySaveRequest(BaseModel):
    policy_id: Optional[str] = None
    title: str
    policy_type: str
    content: str
    version_number: str = "1.0"
    status: str = "draft"
    compliance_score: Optional[float] = None
    risks: Optional[Dict[str, Any]] = None
    change_summary: Optional[str] = None
    effective_date: Optional[str] = None
    review_date: Optional[str] = None


class HRChatAskRequest(BaseModel):
    question: str


class HRTicketUpdateRequest(BaseModel):
    status: str
    resolution_response: Optional[str] = None
    assigned_to: Optional[str] = None
