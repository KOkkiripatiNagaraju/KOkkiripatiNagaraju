"""
Onboarding ORM Models — integrated into the base recruitment system.
Uses SQLAlchemy 1.x Column-style to match models/schemas.py.
"""
import datetime
from sqlalchemy import Column, Integer, String, Text, Float, DateTime, ForeignKey, JSON
from config.database import Base


class OnboardingOffer(Base):
    """Stores AI-generated offer letters for candidates."""
    __tablename__ = "onboarding_offers"

    id = Column(Integer, primary_key=True, index=True)
    candidate_id = Column(Integer, ForeignKey("candidates.id"), nullable=False)
    job_id = Column(Integer, ForeignKey("jobs.id"), nullable=False)

    # Salary recommendation from Bedrock
    recommended_salary = Column(Float, nullable=True)
    salary_notes = Column(JSON, nullable=True)            # Bedrock reasoning dict

    # The generated offer letter
    offer_letter_text = Column(Text, nullable=True)       # AI-generated plain text
    offer_letter_uri = Column(Text, nullable=True)        # S3 URI or local path to PDF

    # Status: pending | generated | sent | accepted | rejected
    status = Column(String(40), default="pending")

    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    sent_at = Column(DateTime, nullable=True)
    accepted_at = Column(DateTime, nullable=True)


class OnboardingBGVDocument(Base):
    """AI-verified BGV documents uploaded by candidates."""
    __tablename__ = "onboarding_bgv_documents"

    id = Column(Integer, primary_key=True, index=True)
    candidate_id = Column(Integer, ForeignKey("candidates.id"), nullable=False)
    doc_type = Column(String(50), nullable=False)         # aadhaar | pan | offer_letter
    file_name = Column(String(255), nullable=False)
    storage_uri = Column(Text, nullable=False)            # S3 URI or local path

    # AI verification result
    verification_status = Column(String(32), default="pending")  # pending | accepted | rejected | review
    agent_result = Column(JSON, nullable=True)            # Full Bedrock JSON response

    uploaded_at = Column(DateTime, default=datetime.datetime.utcnow)
    verified_at = Column(DateTime, nullable=True)


class OnboardingAccessAssignment(Base):
    """Birthright access assignments for newly onboarded employees."""
    __tablename__ = "onboarding_access_assignments"

    id = Column(Integer, primary_key=True, index=True)
    candidate_id = Column(Integer, ForeignKey("candidates.id"), nullable=False)
    employee_id = Column(Integer, ForeignKey("employees.id"), nullable=True)
    access_name = Column(String(120), nullable=False)
    access_type = Column(String(80), nullable=False)
    justification = Column(Text, nullable=False)
    status = Column(String(32), default="assigned")
    assigned_at = Column(DateTime, default=datetime.datetime.utcnow)


class OnboardingEmailLog(Base):
    """Email audit log for onboarding communications."""
    __tablename__ = "onboarding_email_logs"

    id = Column(Integer, primary_key=True, index=True)
    candidate_id = Column(Integer, ForeignKey("candidates.id"), nullable=True)
    recipient = Column(String(255), nullable=False)
    subject = Column(String(255), nullable=False)
    provider = Column(String(32), nullable=False)         # local | gmail | ses
    status = Column(String(32), nullable=False)           # sent | failed
    provider_message_id = Column(String(255), nullable=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
