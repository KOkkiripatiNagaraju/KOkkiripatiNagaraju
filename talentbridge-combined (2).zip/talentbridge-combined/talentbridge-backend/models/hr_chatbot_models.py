"""
HR Chatbot & Policy Generator ORM models.
These are SEPARATE from the existing recruitment/onboarding models
and use their own table names (hr_policies, hr_policy_versions,
hr_chat_messages, hr_tickets, hr_audit_trail) so as NOT to disturb
any existing tables.
"""
import datetime
import uuid

from sqlalchemy import (
    Boolean, Column, DateTime, Float, ForeignKey,
    Integer, JSON, String, Text,
)
from sqlalchemy.dialects.postgresql import UUID as PG_UUID
from sqlalchemy.orm import relationship

from config.database import Base


class HRPolicy(Base):
    __tablename__ = "hr_policies"

    id               = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    title            = Column(String(255), nullable=False)
    policy_type      = Column(String(100), nullable=False)
    status           = Column(String(50), default="draft")        # draft | review | published
    review_date      = Column(String(100), nullable=True)
    current_version_id = Column(PG_UUID(as_uuid=True), nullable=True)
    s3_key           = Column(Text, nullable=True)
    created_by       = Column(String(255), nullable=True)
    created_at       = Column(DateTime, default=datetime.datetime.utcnow)
    updated_at       = Column(DateTime, default=datetime.datetime.utcnow,
                              onupdate=datetime.datetime.utcnow)

    versions = relationship(
        "HRPolicyVersion",
        back_populates="policy",
        cascade="all, delete-orphan",
        foreign_keys="HRPolicyVersion.policy_id",
    )


class HRPolicyVersion(Base):
    __tablename__ = "hr_policy_versions"

    id               = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    policy_id        = Column(PG_UUID(as_uuid=True), ForeignKey("hr_policies.id"), nullable=False)
    version_number   = Column(String(50), default="1.0")
    content          = Column(Text, nullable=True)
    s3_key           = Column(Text, nullable=True)
    status           = Column(String(50), default="draft")
    compliance_score = Column(Float, nullable=True)
    risks            = Column(JSON, nullable=True)
    change_summary   = Column(Text, nullable=True)
    effective_date   = Column(String(100), nullable=True)
    created_by       = Column(String(255), nullable=True)
    created_at       = Column(DateTime, default=datetime.datetime.utcnow)

    policy = relationship(
        "HRPolicy",
        back_populates="versions",
        foreign_keys=[policy_id],
    )


class HRChatMessage(Base):
    __tablename__ = "hr_chat_messages"

    id              = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    employee_id     = Column(String(50), index=True, nullable=True)
    employee_email  = Column(String(255), index=True, nullable=True)
    question        = Column(Text, nullable=False)
    answer          = Column(Text, nullable=True)
    confidence      = Column(String(50), default="low")
    sources         = Column(JSON, nullable=True)
    ticket_created  = Column(Boolean, default=False)
    ticket_id       = Column(String(100), nullable=True)
    escalated_ticket_id = Column(PG_UUID(as_uuid=True), nullable=True)
    created_at      = Column(DateTime, default=datetime.datetime.utcnow)


class HRTicket(Base):
    __tablename__ = "hr_tickets"

    id                  = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    employee_id         = Column(String(50), index=True, nullable=True)
    employee_email      = Column(String(255), index=True, nullable=True)
    question            = Column(Text, nullable=False)
    category            = Column(String(100), default="General HR Query")
    priority            = Column(String(50), default="Medium")
    status              = Column(String(50), default="Open")         # Open | In Progress | Closed
    ai_summary          = Column(Text, nullable=True)
    suggested_response  = Column(Text, nullable=True)
    resolution_response = Column(Text, nullable=True)
    assigned_to         = Column(String(150), nullable=True)
    resolved_by         = Column(String(150), nullable=True)
    resolved_at         = Column(DateTime, nullable=True)
    updated_at          = Column(DateTime, default=datetime.datetime.utcnow,
                                 onupdate=datetime.datetime.utcnow)
    created_at          = Column(DateTime, default=datetime.datetime.utcnow)


class HRAuditTrail(Base):
    """Separate audit trail for HR chatbot / policy events (does not touch existing audit_logs)."""
    __tablename__ = "hr_audit_trail"

    id          = Column(Integer, primary_key=True, index=True)
    actor       = Column(String(255), nullable=True)
    action      = Column(String(255), nullable=False)
    entity_type = Column(String(100), nullable=True)
    entity_id   = Column(String(100), nullable=True)
    details     = Column(JSON, nullable=True)
    created_at  = Column(DateTime, default=datetime.datetime.utcnow)
