import datetime
from sqlalchemy import Column, Integer, String, Text, Float, DateTime, ForeignKey, JSON, Boolean
from config.database import Base
from pydantic import BaseModel, EmailStr, field_validator
from typing import List, Optional, Dict, Any


# ─────────────────────────────────────────────
# SQLAlchemy ORM Models
# ─────────────────────────────────────────────

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    full_name = Column(String, nullable=False)
    is_manager = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)


class Job(Base):
    __tablename__ = "jobs"
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, nullable=False)
    department = Column(String, nullable=False)
    location = Column(String, nullable=False)
    employment_type = Column(String, nullable=False)
    salary_range = Column(String, nullable=False)
    experience_required = Column(Integer, nullable=False)
    skills_required = Column(JSON, nullable=False)
    responsibilities = Column(Text, nullable=False)
    full_description = Column(Text, nullable=False)
    status = Column(String, default="Active")  # Active, Archived
    structured_profile = Column(JSON, nullable=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)


class Candidate(Base):
    __tablename__ = "candidates"
    id = Column(Integer, primary_key=True, index=True)
    job_id = Column(Integer, ForeignKey("jobs.id"), nullable=False)
    name = Column(String, nullable=False)
    email = Column(String, nullable=False)
    phone = Column(String, nullable=True)
    skills = Column(JSON, nullable=True)
    experience_years = Column(Float, nullable=True)
    education = Column(JSON, nullable=True)
    parsed_data = Column(JSON, nullable=True)
    s3_key = Column(String, nullable=True)
    # FIX: corrected typo "Offerd" → "Offered"
    status = Column(String, default="Applied")  # Applied, Screening, Shortlisted, Interviewing, Offered, Rejected
    applied_at = Column(DateTime, default=datetime.datetime.utcnow)


class ATSScore(Base):
    __tablename__ = "ats_scores"
    id = Column(Integer, primary_key=True, index=True)
    candidate_id = Column(Integer, ForeignKey("candidates.id"), unique=True)
    skills_match = Column(Float)
    experience_match = Column(Float)
    project_relevance = Column(Float)
    education_score = Column(Float)
    certification_score = Column(Float)
    semantic_similarity = Column(Float)
    total_score = Column(Float)
    strengths = Column(JSON)
    skill_gaps = Column(JSON)
    recommendation = Column(Text)
    scored_at = Column(DateTime, default=datetime.datetime.utcnow)


class CandidateRanking(Base):
    __tablename__ = "candidate_rankings"
    id = Column(Integer, primary_key=True, index=True)
    job_id = Column(Integer, ForeignKey("jobs.id"))
    candidate_id = Column(Integer, ForeignKey("candidates.id"))
    rank = Column(Integer)
    final_score = Column(Float)


class Interview(Base):
    __tablename__ = "interviews"
    id = Column(Integer, primary_key=True, index=True)
    candidate_id = Column(Integer, ForeignKey("candidates.id"))
    current_question_index = Column(Integer, default=0)
    is_completed = Column(Boolean, default=False)
    overall_score = Column(Float, nullable=True)
    evaluation_summary = Column(Text, nullable=True)
    scheduled_at = Column(DateTime, nullable=True)
    join_token = Column(String, unique=True, index=True, nullable=True)
    join_token_created_at = Column(DateTime, nullable=True)
    join_token_expires_at = Column(DateTime, nullable=True)
    started_at = Column(DateTime, nullable=True)
    completed_at = Column(DateTime, nullable=True)


class InterviewQuestion(Base):
    __tablename__ = "interview_questions"
    id = Column(Integer, primary_key=True, index=True)
    interview_id = Column(Integer, ForeignKey("interviews.id"))
    category = Column(String)
    difficulty = Column(String)
    question_text = Column(Text)
    expected_answer = Column(Text)
    rubric = Column(JSON)


class InterviewAnswer(Base):
    __tablename__ = "interview_answers"
    id = Column(Integer, primary_key=True, index=True)
    interview_id = Column(Integer, ForeignKey("interviews.id"))
    interview_question_id = Column(Integer, ForeignKey("interview_questions.id"))
    candidate_answer = Column(Text)
    transcript = Column(Text, nullable=True)
    audio_file_path = Column(String, nullable=True)
    audio_mime_type = Column(String, nullable=True)
    score = Column(Float, nullable=True)
    feedback = Column(Text, nullable=True)
    answered_at = Column(DateTime, default=datetime.datetime.utcnow)


class Recommendation(Base):
    __tablename__ = "recommendations"
    id = Column(Integer, primary_key=True, index=True)
    candidate_id = Column(Integer, ForeignKey("candidates.id"))
    ai_rating = Column(Float)
    ai_verdict = Column(String)  # Strong Hire, Hire, Consider, Borderline, Reject
    ai_justification = Column(Text)
    hr_override_verdict = Column(String, nullable=True)
    hr_notes = Column(Text, nullable=True)
    updated_at = Column(DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)


class EmailLog(Base):
    __tablename__ = "email_logs"
    id = Column(Integer, primary_key=True, index=True)
    candidate_id = Column(Integer, ForeignKey("candidates.id"))
    email_type = Column(String)
    subject = Column(String)
    body = Column(Text)
    status = Column(String, default="Draft")  # Draft, Sent, Failed, Rejected_By_HR
    sent_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)


class AuditLog(Base):
    __tablename__ = "audit_logs"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    action = Column(String)
    timestamp = Column(DateTime, default=datetime.datetime.utcnow)
    details = Column(Text)


# ─────────────────────────────────────────────
# NEW MODULES ORM MODELS
# ─────────────────────────────────────────────

class OnboardingProcess(Base):
    __tablename__ = "onboarding_processes"
    id = Column(Integer, primary_key=True, index=True)
    candidate_id = Column(Integer, ForeignKey("candidates.id"), unique=True, nullable=False)
    employee_id = Column(Integer, ForeignKey("employees.id"), unique=True, nullable=True)
    status = Column(String, default="In_Progress")  # In_Progress, Completed, Failed
    created_at = Column(DateTime, default=datetime.datetime.utcnow)


class OnboardingDocument(Base):
    __tablename__ = "onboarding_documents"
    id = Column(Integer, primary_key=True, index=True)
    onboarding_process_id = Column(Integer, ForeignKey("onboarding_processes.id"), nullable=False)
    document_type = Column(String, nullable=False)  # ID_Proof, Signed_Contract, Tax_Form
    s3_key = Column(String, nullable=False)
    verification_status = Column(String, default="Pending")  # Pending, Approved, Rejected
    uploaded_at = Column(DateTime, default=datetime.datetime.utcnow)


class Employee(Base):
    __tablename__ = "employees"
    id = Column(Integer, primary_key=True, index=True)
    employee_code = Column(String, unique=True, index=True, nullable=False)
    name = Column(String, nullable=False)
    email = Column(String, unique=True, index=True, nullable=False)
    status = Column(String, default="Active")  # Active, Onboarding, Terminated
    designation = Column(String, nullable=True)   # Job title / role
    department = Column(String, nullable=True)    # Department from the job
    location = Column(String, nullable=True)      # Work location from the job
    skills_profile = Column(JSON, nullable=True)  # {"python": 5, "sql": 4, "communication": 3}
    joined_at = Column(DateTime, default=datetime.datetime.utcnow)
    
    # Training & Development addition
    current_role = Column(String, nullable=True)
    experience_years = Column(Integer, nullable=True)
    training_plan = Column(JSON, nullable=True)
    last_survey_submission = Column(DateTime, nullable=True)


# ─────────────────────────────────────────────
# Exit Management / Offboarding
# ─────────────────────────────────────────────
class Resignation(Base):
    """Stores resigned employees. Populated when employee clicks Proceed on resignation letter.
    Employee is removed from `employees` table after insertion here.
    HR uses this table to upload exit interview audio and run AI analysis."""
    __tablename__ = "resignations"
    id = Column(Integer, primary_key=True, index=True)
    employee_id = Column(Integer, nullable=False)            # Original employees.id (preserved)
    employee_code = Column(String, nullable=False)
    name = Column(String, nullable=False)
    email = Column(String, nullable=False, index=True)
    department = Column(String, nullable=True)
    designation = Column(String, nullable=True)
    resigned_at = Column(DateTime, default=datetime.datetime.utcnow)
    # Exit interview analysis tracking
    audio_uploaded = Column(Boolean, default=False)          # Has HR uploaded audio?
    analysis_done = Column(Boolean, default=False)           # Has AI analysis completed?
    transcript = Column(Text, nullable=True)                 # Whisper transcription output
    sentiment_score = Column(Float, nullable=True)           # -1.0 to 1.0
    hr_report = Column(Text, nullable=True)                  # Bedrock Nova HR analysis report
    s3_report_path = Column(String, nullable=True)           # S3 path: reports/exit_report_*.txt


class OrganizationalStructure(Base):
    __tablename__ = "organizational_structures"
    id = Column(Integer, primary_key=True, index=True)
    employee_id = Column(Integer, ForeignKey("employees.id"), unique=True, nullable=False)
    manager_id = Column(Integer, ForeignKey("employees.id"), nullable=True)


class RoleTemplate(Base):
    __tablename__ = "role_templates"
    id = Column(Integer, primary_key=True, index=True)
    role_title = Column(String, nullable=False, unique=True)
    required_skills = Column(JSON, nullable=False)
    
    # Training & Development addition
    department = Column(String, nullable=True)
    description = Column(Text, nullable=True)


class SkillGapAnalysis(Base):
    __tablename__ = "skill_gap_analyses"
    id = Column(Integer, primary_key=True, index=True)
    employee_id = Column(Integer, ForeignKey("employees.id"), nullable=False)
    target_role_template_id = Column(Integer, ForeignKey("role_templates.id"), nullable=False)
    readiness_score = Column(Float, nullable=False)
    analyzed_at = Column(DateTime, default=datetime.datetime.utcnow)


class Course(Base):
    __tablename__ = "courses"
    id = Column(Integer, primary_key=True, index=True)
    course_title = Column(String, nullable=False, unique=True)
    skills_covered = Column(JSON, nullable=False)
    description = Column(Text, nullable=True)
    
    # Training & Development addition
    url = Column(String, nullable=True)


class CourseAssignment(Base):
    __tablename__ = "course_assignments"
    id = Column(Integer, primary_key=True, index=True)
    employee_id = Column(Integer, ForeignKey("employees.id"), nullable=False)
    course_id = Column(Integer, ForeignKey("courses.id"), nullable=False)
    gap_analysis_id = Column(Integer, ForeignKey("skill_gap_analyses.id"), nullable=False)
    status = Column(String, default="Assigned")  # Assigned, In_Progress, Completed
    assigned_at = Column(DateTime, default=datetime.datetime.utcnow)


class Policy(Base):
    __tablename__ = "policies"
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, nullable=False, unique=True)
    content_markdown = Column(Text, nullable=False)
    category = Column(String, nullable=True, default="general")  # wellbeing, workspace, career_growth, etc.
    embedding = Column(JSON, nullable=True)  # Float list vector for RAG matching
    created_at = Column(DateTime, default=datetime.datetime.utcnow)


class ChatbotTicket(Base):
    __tablename__ = "chatbot_tickets"
    id = Column(Integer, primary_key=True, index=True)
    employee_id = Column(Integer, ForeignKey("employees.id"), nullable=False)
    original_query = Column(Text, nullable=False)
    status = Column(String, default="Escalated")  # Escalated, Resolved
    created_at = Column(DateTime, default=datetime.datetime.utcnow)


class SurveyDefinition(Base):
    __tablename__ = "survey_definitions"
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, nullable=False)
    is_anonymous = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)


class SurveyQuestion(Base):
    __tablename__ = "survey_questions"
    id = Column(Integer, primary_key=True, index=True)
    survey_id = Column(Integer, ForeignKey("survey_definitions.id"), nullable=False)
    question_text = Column(Text, nullable=False)
    type = Column(String, nullable=True, default="text")  # "text", "mcq", "rating"
    options = Column(JSON, nullable=True)  # JSON list for MCQ options
    sequence = Column(Integer, nullable=True, default=1)


class SurveyResponse(Base):
    __tablename__ = "survey_responses"
    id = Column(Integer, primary_key=True, index=True)
    survey_id = Column(Integer, ForeignKey("survey_definitions.id"), nullable=False)
    question_id = Column(Integer, ForeignKey("survey_questions.id"), nullable=False)
    employee_id = Column(Integer, ForeignKey("employees.id"), nullable=True)  # NULL if anonymous
    response_value = Column(Text, nullable=False)
    sentiment_score = Column(Float, nullable=True)
    submitted_at = Column(DateTime, default=datetime.datetime.utcnow)


class OffboardingProcess(Base):
    __tablename__ = "offboarding_processes"
    id = Column(Integer, primary_key=True, index=True)
    employee_id = Column(Integer, ForeignKey("employees.id"), unique=True, nullable=False)
    exit_reason = Column(Text, nullable=True)
    status = Column(String, default="Initiated")  # Initiated, Exit_Interview_Scheduled, Completed
    created_at = Column(DateTime, default=datetime.datetime.utcnow)


class ExitInterview(Base):
    __tablename__ = "exit_interviews"
    id = Column(Integer, primary_key=True, index=True)
    offboarding_process_id = Column(Integer, ForeignKey("offboarding_processes.id"), unique=True, nullable=False)
    audio_file_path = Column(String, nullable=True)
    transcript = Column(Text, nullable=True)
    sentiment_score = Column(Float, nullable=True)
    completed_at = Column(DateTime, default=datetime.datetime.utcnow)


# ─────────────────────────────────────────────
# Pulse Survey ORM Models
# ─────────────────────────────────────────────

class PulseSurveyResponse(Base):
    __tablename__ = "pulse_survey_responses"
    id = Column(Integer, primary_key=True, index=True)
    employee_id = Column(Integer, ForeignKey("employees.id"), nullable=True)  # NULL for anonymous
    survey_id = Column(Integer, ForeignKey("survey_definitions.id"), nullable=False)
    response_data = Column(JSON, nullable=False)  # {question_id: answer_value}
    timestamp = Column(DateTime, default=datetime.datetime.utcnow)


class AIInsight(Base):
    __tablename__ = "ai_insights"
    id = Column(Integer, primary_key=True, index=True)
    response_id = Column(Integer, ForeignKey("pulse_survey_responses.id"), nullable=False)
    sentiment_score = Column(Float, nullable=False)  # -1.0 to 1.0
    emotion_scores = Column(JSON, nullable=False)  # {"Stress": 0.4, "Burnout": 0.1, ...}
    topics = Column(JSON, nullable=False)  # ["compensation", "management"]
    retention_risk = Column(String, nullable=False)  # "High", "Medium", "Low"
    recommendations = Column(JSON, nullable=False)  # {"employee": [...], "manager": [...], "hr": [...]}
    timestamp = Column(DateTime, default=datetime.datetime.utcnow)


class DashboardMetric(Base):
    __tablename__ = "dashboard_metrics"
    id = Column(Integer, primary_key=True, index=True)
    department = Column(String, nullable=False)  # "Engineering", "HR", "All"
    survey_id = Column(Integer, ForeignKey("survey_definitions.id"), nullable=False)
    aggregated_sentiment = Column(Float, nullable=False)
    aggregated_topics = Column(JSON, nullable=False)  # Top topics and frequencies
    risk_summary = Column(JSON, nullable=False)  # {"High": N, "Medium": N, "Low": N}
    last_updated = Column(DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)


# ─────────────────────────────────────────────
# Pydantic Request / Response Schemas
# ─────────────────────────────────────────────

class UserCreate(BaseModel):
    email: EmailStr
    password: str
    full_name: str
    is_manager: bool = False

    @field_validator("password")
    @classmethod
    def password_strength(cls, v: str) -> str:
        if len(v) < 8:
            raise ValueError("Password must be at least 8 characters long.")
        return v


class TokenSchema(BaseModel):
    access_token: str
    token_type: str


class JobCreate(BaseModel):
    title: str
    department: str
    location: str
    employment_type: str
    salary_range: str
    experience_required: int
    skills_required: List[str]
    responsibilities: str
    full_description: str


class JobResponse(JobCreate):
    id: int
    status: str
    structured_profile: Optional[Dict[str, Any]] = None

    # FIX: was `registrar = True` (typo/wrong key); correct key is from_attributes
    class Config:
        from_attributes = True


class CandidateResponse(BaseModel):
    id: int
    name: str
    email: str
    phone: Optional[str]
    skills: Optional[List[str]]
    experience_years: Optional[float]
    status: str
    job_id: int

    class Config:
        from_attributes = True


class ATSScoreResponse(BaseModel):
    candidate_id: int
    skills_match: float
    experience_match: float
    project_relevance: float
    education_score: float
    certification_score: float
    semantic_similarity: float
    total_score: float
    strengths: Optional[List[str]]
    skill_gaps: Optional[List[str]]
    recommendation: Optional[str]

    class Config:
        from_attributes = True


class RankingResponse(BaseModel):
    rank: int
    candidate_id: int
    final_score: float

    class Config:
        from_attributes = True


class InterviewAnswerSubmit(BaseModel):
    question_id: int
    candidate_answer: str


class InterviewScheduleRequest(BaseModel):
    scheduled_at: datetime.datetime
    base_join_url: Optional[str] = None


class PublicInterviewAnswerSubmit(BaseModel):
    question_id: int
    transcript: str


class RecommendationResponse(BaseModel):
    id: int
    candidate_id: int
    ai_rating: float
    ai_verdict: str
    ai_justification: str
    hr_override_verdict: Optional[str]
    hr_notes: Optional[str]

    class Config:
        from_attributes = True


class HROverrideRequest(BaseModel):
    hr_override_verdict: str
    hr_notes: str

    @field_validator("hr_override_verdict")
    @classmethod
    def valid_verdict(cls, v: str) -> str:
        allowed = {"Strong Hire", "Hire", "Consider", "Borderline", "Reject"}
        if v not in allowed:
            raise ValueError(f"hr_override_verdict must be one of: {allowed}")
        return v


class EmailDecision(BaseModel):
    approve: bool
    edited_subject: Optional[str] = None
    edited_body: Optional[str] = None


class QuestionUpdate(BaseModel):
    question_text: str


# ─────────────────────────────────────────────
# Training & Development Request Schemas
# ─────────────────────────────────────────────

class TrainingAnalyzeRequest(BaseModel):
    employee_id: int
    role_template_id: int


class TrainingGeneratePlanRequest(BaseModel):
    employee_id: int
    role_template_id: int


class TrainingAssignRequest(BaseModel):
    gap_analysis_id: int
    course_ids: List[int]


# ─────────────────────────────────────────────
# Pulse Survey Request / Response Schemas
# ─────────────────────────────────────────────

class PulseSurveyStartRequest(BaseModel):
    employee_id: Optional[int] = None
    survey_id: int


class PulseSurveyQuestionSchema(BaseModel):
    id: int
    survey_id: int
    question_text: str
    type: Optional[str] = "text"
    options: Optional[List[str]] = None
    sequence: Optional[int] = 1

    class Config:
        from_attributes = True


class PulseSurveyStartResponse(BaseModel):
    survey_id: int
    title: str
    description: Optional[str] = None
    type: Optional[str] = "form"
    questions: List[PulseSurveyQuestionSchema]
    employee_name: Optional[str] = None


class PulseSurveyResponseCreate(BaseModel):
    employee_id: Optional[int] = None
    survey_id: int
    response_data: Dict[str, Any]  # {question_id_str: answer_value}
    is_anonymous: Optional[bool] = False


class PulseEmployeeDashboardResponse(BaseModel):
    employee_id: Optional[int] = None
    employee_name: Optional[str] = None
    department: Optional[str] = None
    sentiment_summary: str
    emotion_chart_data: Dict[str, float]
    recommendations: List[str]
    resources: List[Dict[str, Any]]
    history: List[Dict[str, Any]]
    has_anonymous_submission: Optional[bool] = False


class PulseHRDashboardResponse(BaseModel):
    total_employees: int
    total_responses: int
    overall_sentiment: float
    department_sentiment: Dict[str, float]
    department_stress_levels: Dict[str, float]
    risk_by_department: Dict[str, Dict[str, int]]
    top_topics: List[Dict[str, Any]]
    strategic_priorities: List[str]
    policy_recommendations: List[Dict[str, Any]]
    historical_sentiment_trend: List[Dict[str, Any]]


class PulseSurveyCheckResponse(BaseModel):
    is_allowed: bool
    remaining_days: Optional[int] = None
    remaining_hours: Optional[int] = None
    remaining_minutes: Optional[int] = None


class SurveyQuestionCreateSchema(BaseModel):
    question_text: str
    type: str  # "rating", "text", "mcq"
    options: Optional[List[str]] = None
    sequence: Optional[int] = None


class SurveyCreateSchema(BaseModel):
    title: str
    is_anonymous: bool = True
    questions: List[SurveyQuestionCreateSchema]
