

import os
import json
import requests
import streamlit as st
from datetime import datetime

def clean_html(html_str):
    return " ".join([line.strip() for line in html_str.split("\n") if line.strip()])


# ─────────────────────────────────────────────────────────────────────────────
# Page Config
# ─────────────────────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="AI Recruitment Hub",
    page_icon="🚀",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ─────────────────────────────────────────────────────────────────────────────
# Premium Theme — Dark Mode Enforced CSS
# ─────────────────────────────────────────────────────────────────────────────
st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=JetBrains+Mono:wght@400;500;600;700&display=swap');

    html, body {
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif !important;
    }

    .main, .stApp, [data-testid="stAppViewContainer"],
    [data-testid="stAppViewBlockContainer"],
    section[data-testid="stSidebar"] {
        background: #060918 !important;
    }

    .stApp > header {
        background: transparent !important;
    }

    /* Premium sidebar collapse/expand controls */
    [data-testid="collapsedControl"],
    [data-testid="stSidebarCollapseButton"] {
        background: rgba(99, 102, 241, 0.15) !important;
        border: 1px solid rgba(99, 102, 241, 0.3) !important;
        border-radius: 8px !important;
        color: #e0e7ff !important;
        z-index: 999999 !important;
        transition: all 0.3s ease !important;
    }
    [data-testid="collapsedControl"] svg,
    [data-testid="stSidebarCollapseButton"] svg {
        fill: #e0e7ff !important;
        color: #e0e7ff !important;
    }
    [data-testid="collapsedControl"]:hover,
    [data-testid="stSidebarCollapseButton"]:hover {
        background: rgba(99, 102, 241, 0.35) !important;
        border-color: rgba(99, 102, 241, 0.6) !important;
        box-shadow: 0 0 12px rgba(99, 102, 241, 0.4) !important;
    }

    .main::before {
        content: '';
        position: fixed;
        top: -50%; left: -50%;
        width: 200%; height: 200%;
        background:
            radial-gradient(ellipse at 20% 50%, rgba(99, 102, 241, 0.08) 0%, transparent 50%),
            radial-gradient(ellipse at 80% 20%, rgba(139, 92, 246, 0.06) 0%, transparent 50%),
            radial-gradient(ellipse at 40% 80%, rgba(6, 182, 212, 0.05) 0%, transparent 50%);
        animation: auroraShift 20s ease-in-out infinite alternate;
        z-index: 0;
        pointer-events: none;
    }

    @keyframes auroraShift {
        0%   { transform: translate(0%, 0%) rotate(0deg); }
        50%  { transform: translate(2%, -1%) rotate(1deg); }
        100% { transform: translate(-2%, 1%) rotate(-1deg); }
    }

    .block-container {
        padding-top: 2rem;
        padding-bottom: 3rem;
        position: relative;
        z-index: 1;
    }

    .stApp p, .stApp span, .stApp label, .stApp div,
    .stMarkdown, .stMarkdown p, .stMarkdown span,
    [data-testid="stMarkdownContainer"],
    [data-testid="stMarkdownContainer"] p,
    [data-testid="stMarkdownContainer"] span,
    [data-testid="stMarkdownContainer"] li {
        color: #cbd5e1 !important;
    }

    strong, b { color: #f1f5f9 !important; }

    ::-webkit-scrollbar { width: 6px; height: 6px; }
    ::-webkit-scrollbar-track { background: rgba(15, 23, 42, 0.3); }
    ::-webkit-scrollbar-thumb { background: linear-gradient(180deg, #6366f1, #8b5cf6); border-radius: 10px; }

    [data-testid="stSidebar"],
    [data-testid="stSidebar"] > div:first-child {
        background: linear-gradient(180deg, #07091a 0%, #0c0e27 40%, #111340 100%) !important;
        border-right: 1px solid rgba(99, 102, 241, 0.1);
    }

    [data-testid="stSidebar"] * { color: #c7d2fe !important; }
    [data-testid="stSidebar"] .stRadio > div { gap: 2px; }
    [data-testid="stSidebar"] .stRadio label {
        font-size: 0.92rem; font-weight: 500;
        padding: 11px 16px; border-radius: 12px;
        transition: all 0.3s ease;
        border: 1px solid transparent;
    }
    [data-testid="stSidebar"] .stRadio label:hover {
        background: rgba(99, 102, 241, 0.1) !important;
        border-color: rgba(99, 102, 241, 0.2);
        color: #e0e7ff !important;
        transform: translateX(4px);
    }

    h1 {
        background: linear-gradient(135deg, #e0e7ff 0%, #a78bfa 40%, #818cf8 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        font-weight: 800 !important;
        letter-spacing: -0.04em;
        font-size: 2.4rem !important;
    }
    h2 { color: #e0e7ff !important; -webkit-text-fill-color: #e0e7ff !important; font-weight: 700 !important; font-size: 1.35rem !important; }
    h3 { color: #c7d2fe !important; -webkit-text-fill-color: #c7d2fe !important; font-weight: 600 !important; font-size: 1.1rem !important; }
    h4 { color: #a5b4fc !important; -webkit-text-fill-color: #a5b4fc !important; font-weight: 600 !important; }

    .glass-card {
        background: rgba(15, 23, 42, 0.88) !important;
        backdrop-filter: blur(24px);
        border: 1px solid rgba(99, 102, 241, 0.15);
        border-radius: 20px;
        padding: 28px 32px;
        margin-bottom: 20px;
        transition: all 0.4s ease;
        box-shadow: 0 4px 24px rgba(0, 0, 0, 0.3);
    }
    .glass-card:hover {
        border-color: rgba(99, 102, 241, 0.3);
        box-shadow: 0 8px 40px rgba(99, 102, 241, 0.12);
        transform: translateY(-3px);
    }

    .metric-card {
        background: #0f1129 !important;
        border: 1px solid rgba(99, 102, 241, 0.15);
        border-radius: 20px;
        padding: 28px 24px;
        text-align: center;
        transition: all 0.4s ease;
        position: relative; overflow: hidden;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.25);
    }
    .metric-card::before {
        content: '';
        position: absolute; top: 0; left: 0; right: 0;
        height: 3px;
        border-radius: 20px 20px 0 0;
    }
    .metric-card.purple::before { background: linear-gradient(90deg, #8b5cf6, #a78bfa, #c4b5fd); }
    .metric-card.blue::before   { background: linear-gradient(90deg, #3b82f6, #60a5fa, #93c5fd); }
    .metric-card.emerald::before { background: linear-gradient(90deg, #10b981, #34d399, #6ee7b7); }
    .metric-card.amber::before  { background: linear-gradient(90deg, #f59e0b, #fbbf24, #fde68a); }
    .metric-card:hover { transform: translateY(-6px) scale(1.02); box-shadow: 0 16px 48px rgba(0, 0, 0, 0.35); border-color: rgba(99, 102, 241, 0.25); }
    .metric-icon { font-size: 2.2rem; margin-bottom: 12px; display: block; }
    .metric-value { font-family: 'JetBrains Mono', monospace !important; font-size: 2.8rem !important; font-weight: 800 !important; color: #f1f5f9 !important; -webkit-text-fill-color: #f1f5f9 !important; line-height: 1.1; }
    .metric-label { font-size: 0.78rem !important; color: #94a3b8 !important; text-transform: uppercase; letter-spacing: 0.1em; font-weight: 600; margin-top: 10px; }
    .metric-delta { display: inline-flex; align-items: center; gap: 4px; font-size: 0.75rem; font-weight: 600; padding: 4px 12px; border-radius: 20px; margin-top: 14px; }
    .delta-green  { background: rgba(16, 185, 129, 0.15); color: #34d399 !important; }
    .delta-blue   { background: rgba(59, 130, 246, 0.15); color: #60a5fa !important; }
    .delta-amber  { background: rgba(245, 158, 11, 0.15); color: #fbbf24 !important; }

    .stButton > button,
    [data-testid="stFormSubmitButton"] > button {
        background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 50%, #6366f1 100%) !important;
        color: #ffffff !important;
        border: none !important;
        border-radius: 14px;
        padding: 12px 32px;
        font-weight: 600; font-size: 0.9rem;
        transition: all 0.35s ease;
        box-shadow: 0 4px 16px rgba(79, 70, 229, 0.35);
    }
    .stButton > button span,
    [data-testid="stFormSubmitButton"] > button span { color: #ffffff !important; }
    .stButton > button:hover,
    [data-testid="stFormSubmitButton"] > button:hover {
        background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 50%, #a78bfa 100%) !important;
        box-shadow: 0 8px 28px rgba(99, 102, 241, 0.45);
        transform: translateY(-2px);
    }
    .stButton > button:active { transform: translateY(0); }

    .stTextInput > div > div > input,
    .stTextArea > div > div > textarea,
    .stNumberInput > div > div > input {
        background: #0c0e27 !important;
        border: 1px solid rgba(99, 102, 241, 0.2) !important;
        border-radius: 12px !important;
        color: #e2e8f0 !important;
        padding: 12px 16px !important;
    }
    .stTextInput > div > div > input:focus,
    .stTextArea > div > div > textarea:focus,
    .stNumberInput > div > div > input:focus {
        border-color: rgba(99, 102, 241, 0.5) !important;
        box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.12) !important;
    }
    .stSelectbox > div > div,
    .stSelectbox > div > div > div {
        background: #0c0e27 !important;
        border: 1px solid rgba(99, 102, 241, 0.2) !important;
        border-radius: 12px !important;
        color: #e2e8f0 !important;
    }
    .stTextInput label, .stTextArea label,
    .stNumberInput label, .stSelectbox label { color: #94a3b8 !important; font-weight: 500 !important; }
    .stNumberInput button { background: rgba(99, 102, 241, 0.15) !important; color: #c7d2fe !important; border: 1px solid rgba(99, 102, 241, 0.2) !important; }

    .stTabs [data-baseweb="tab-list"] { background: #0c0e27 !important; border-radius: 16px; padding: 6px; gap: 4px; border: 1px solid rgba(99, 102, 241, 0.12); }
    .stTabs [data-baseweb="tab"] { border-radius: 12px; padding: 10px 24px; font-weight: 500; color: #94a3b8 !important; background: transparent !important; }
    .stTabs [data-baseweb="tab"] span, .stTabs [data-baseweb="tab"] p { color: #94a3b8 !important; }
    .stTabs [data-baseweb="tab"]:hover, .stTabs [data-baseweb="tab"]:hover span { color: #e0e7ff !important; }
    .stTabs [aria-selected="true"] { background: rgba(99, 102, 241, 0.15) !important; }
    .stTabs [aria-selected="true"] span, .stTabs [aria-selected="true"] p { color: #e0e7ff !important; font-weight: 600; }
    .stTabs [data-baseweb="tab-highlight"] { background: linear-gradient(90deg, #6366f1, #8b5cf6) !important; height: 3px; border-radius: 3px; }
    .stTabs [data-baseweb="tab-border"] { display: none; }
    .stTabs [data-baseweb="tab-panel"] { background: transparent !important; }

    [data-testid="stFileUploader"] { background: rgba(15, 23, 42, 0.6) !important; border: 2px dashed rgba(99, 102, 241, 0.3) !important; border-radius: 20px; padding: 20px; margin-bottom: 24px !important; }
    [data-testid="stFileUploader"]:hover { border-color: rgba(99, 102, 241, 0.5) !important; }
    [data-testid="stFileUploader"] * { color: #94a3b8 !important; }
    [data-testid="stFileUploader"] [data-testid="stFileUploaderDropzone"] button { background: linear-gradient(135deg, #4f46e5, #7c3aed) !important; color: #ffffff !important; border: none !important; border-radius: 10px; padding: 8px 20px !important; margin: 0 4px !important; display: inline-flex !important; align-items: center !important; justify-content: center !important; min-width: 130px !important; position: relative !important; z-index: 10 !important; }
    
    .resume-uploader [data-testid="stFileUploader"] [data-testid="stFileUploaderDropzone"] button span { display: none !important; }
    .resume-uploader [data-testid="stFileUploader"] [data-testid="stFileUploaderDropzone"] button::after { content: "Upload Resume" !important; color: #ffffff !important; font-weight: 600 !important; font-size: 0.9rem !important; display: inline-block !important; }
    
    .audio-uploader [data-testid="stFileUploader"] [data-testid="stFileUploaderDropzone"] button span { display: none !important; }
    .audio-uploader [data-testid="stFileUploader"] [data-testid="stFileUploaderDropzone"] button::after { content: "Upload Audio" !important; color: #ffffff !important; font-weight: 600 !important; font-size: 0.9rem !important; display: inline-block !important; }
    
    [data-testid="stFileUploader"] section { background: transparent !important; display: flex !important; align-items: center !important; justify-content: center !important; gap: 10px !important; flex-wrap: wrap !important; }
    [data-testid="stFileUploader"] section > div { display: flex !important; align-items: center !important; gap: 10px !important; flex-wrap: wrap !important; color: transparent !important; }
    [data-testid="stFileUploader"] section > div * { color: #94a3b8 !important; }
    [data-testid="stFileUploader"] [data-testid="stFileUploaderDropzoneInstructions"] { display: none !important; }
    [data-testid="stFileUploader"] [data-testid="stFileUploaderDropzoneInstructions"] * { display: none !important; }
    [data-testid="stFileUploader"] section > div > span { display: none !important; }

    .status-bar { display: flex; align-items: center; gap: 12px; background: rgba(16, 185, 129, 0.08) !important; border: 1px solid rgba(16, 185, 129, 0.2); border-radius: 14px; padding: 16px 22px; margin: 16px 0; }
    .status-dot { width: 10px; height: 10px; border-radius: 50%; background: #34d399; box-shadow: 0 0 10px rgba(52, 211, 153, 0.6); animation: breathe 3s ease-in-out infinite; flex-shrink: 0; }
    @keyframes breathe { 0%, 100% { opacity: 1; transform: scale(1); } 50% { opacity: 0.7; transform: scale(0.85); } }
    .status-text { color: #34d399 !important; font-weight: 500; font-size: 0.88rem; }

    .section-divider { height: 1px; background: linear-gradient(90deg, transparent, rgba(99, 102, 241, 0.25), transparent); margin: 32px 0; border: none; }

    .badge { display: inline-flex; align-items: center; gap: 5px; padding: 5px 14px; border-radius: 20px; font-size: 0.73rem; font-weight: 600; letter-spacing: 0.03em; text-transform: uppercase; white-space: nowrap; }
    .badge-draft   { background: rgba(245, 158, 11, 0.15); color: #fbbf24 !important; border: 1px solid rgba(245, 158, 11, 0.2); }
    .badge-sent    { background: rgba(16, 185, 129, 0.15); color: #34d399 !important; border: 1px solid rgba(16, 185, 129, 0.2); }
    .badge-pending { background: rgba(99, 102, 241, 0.15); color: #a78bfa !important; border: 1px solid rgba(99, 102, 241, 0.2); }
    .badge-danger  { background: rgba(239, 68, 68, 0.15); color: #f87171 !important; border: 1px solid rgba(239, 68, 68, 0.2); }

    .email-card { background: rgba(15, 23, 42, 0.88) !important; border: 1px solid rgba(99, 102, 241, 0.12); border-left: 4px solid #6366f1; border-radius: 16px; padding: 24px; margin-bottom: 16px; transition: all 0.35s ease; }
    .email-card:hover { border-left-color: #a78bfa; box-shadow: 0 8px 32px rgba(99, 102, 241, 0.12); transform: translateX(4px); }
    .email-card h4 { color: #e0e7ff !important; -webkit-text-fill-color: #e0e7ff !important; font-weight: 600; margin-bottom: 8px; }

    .login-wrapper { display: flex; align-items: center; justify-content: center; min-height: 70vh; padding: 2rem; }
    .login-container { max-width: 460px; width: 100%; margin: 0 auto; background: rgba(15, 23, 42, 0.92) !important; backdrop-filter: blur(30px); border: 1px solid rgba(99, 102, 241, 0.2); border-radius: 28px; padding: 48px 40px; box-shadow: 0 24px 80px rgba(0, 0, 0, 0.5); position: relative; animation: loginSlideUp 0.6s ease-out; }
    .login-container::before { content: ''; position: absolute; top: -2px; left: -2px; right: -2px; bottom: -2px; background: linear-gradient(135deg, #6366f1, #8b5cf6, #06b6d4, #6366f1); background-size: 300% 300%; border-radius: 30px; z-index: -1; animation: borderGlow 6s ease-in-out infinite; opacity: 0.5; }
    @keyframes borderGlow { 0% { background-position: 0% 50%; } 50% { background-position: 100% 50%; } 100% { background-position: 0% 50%; } }
    @keyframes loginSlideUp { from { opacity: 0; transform: translateY(30px); } to { opacity: 1; transform: translateY(0); } }
    .login-header { text-align: center; margin-bottom: 36px; }
    .login-header .logo { font-size: 3.5rem; display: block; margin-bottom: 16px; animation: logoPulse 3s ease-in-out infinite; }
    @keyframes logoPulse { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.08); } }
    .login-header h2 { background: linear-gradient(135deg, #c7d2fe, #a78bfa); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; font-weight: 800; font-size: 1.6rem !important; margin: 0; }
    .login-header p { color: #64748b !important; font-size: 0.88rem; margin-top: 8px; }
    .login-footer { text-align: center; margin-top: 28px; padding-top: 20px; border-top: 1px solid rgba(99, 102, 241, 0.1); }
    .login-footer p { color: #475569 !important; font-size: 0.75rem; }

    .page-header { display: flex; align-items: center; gap: 16px; margin-bottom: 6px; animation: fadeInLeft 0.5s ease-out; }
    @keyframes fadeInLeft { from { opacity: 0; transform: translateX(-16px); } to { opacity: 1; transform: translateX(0); } }
    .page-header-icon { font-size: 2.2rem; background: rgba(99, 102, 241, 0.1); border-radius: 16px; padding: 12px 14px; border: 1px solid rgba(99, 102, 241, 0.15); line-height: 1; }
    .page-subtitle { color: #64748b !important; font-size: 0.92rem; margin-top: -2px; margin-bottom: 28px; }

    .sidebar-brand { text-align: center; padding: 24px 16px 20px; border-bottom: 1px solid rgba(99, 102, 241, 0.1); margin-bottom: 24px; }
    .sidebar-brand .brand-icon { font-size: 2.4rem; display: block; margin-bottom: 8px; }
    .sidebar-brand h3 { background: linear-gradient(135deg, #c7d2fe, #a78bfa); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; font-weight: 800; font-size: 1.05rem !important; margin: 0 0 4px; }
    .sidebar-brand p { color: #475569 !important; font-size: 0.68rem; text-transform: uppercase; letter-spacing: 0.16em; }
    .sidebar-user { display: flex; align-items: center; gap: 12px; background: rgba(99, 102, 241, 0.06); border: 1px solid rgba(99, 102, 241, 0.1); border-radius: 14px; padding: 14px 16px; margin: 0 8px 20px; }
    .sidebar-user-avatar { width: 38px; height: 38px; border-radius: 12px; background: linear-gradient(135deg, #6366f1, #8b5cf6); display: flex; align-items: center; justify-content: center; font-size: 0.85rem; color: white !important; font-weight: 700; flex-shrink: 0; }
    .sidebar-user-name { color: #e0e7ff !important; font-weight: 600; font-size: 0.85rem; }
    .sidebar-user-role { color: #475569 !important; font-size: 0.72rem; text-transform: uppercase; letter-spacing: 0.06em; }

    .pipeline-timeline { position: relative; padding-left: 32px; }
    .pipeline-timeline::before { content: ''; position: absolute; left: 15px; top: 8px; bottom: 8px; width: 2px; background: linear-gradient(180deg, #6366f1, #8b5cf6, #06b6d4); }
    .pipeline-node { display: flex; align-items: flex-start; gap: 16px; padding: 14px 18px 14px 0; position: relative; }
    .pipeline-node::before { content: ''; position: absolute; left: -24px; top: 20px; width: 12px; height: 12px; border-radius: 50%; background: linear-gradient(135deg, #6366f1, #8b5cf6); border: 3px solid #0c0e27; box-shadow: 0 0 10px rgba(99, 102, 241, 0.4); z-index: 1; }
    .pipeline-node-content { background: rgba(15, 23, 42, 0.75) !important; border: 1px solid rgba(99, 102, 241, 0.1); border-radius: 14px; padding: 14px 20px; flex: 1; transition: all 0.25s ease; }
    .pipeline-node:hover .pipeline-node-content { background: rgba(15, 23, 42, 0.95) !important; border-color: rgba(99, 102, 241, 0.2); transform: translateX(4px); }
    .pipeline-label { color: #e0e7ff !important; font-size: 0.9rem; font-weight: 600; margin-bottom: 2px; }
    .pipeline-desc { color: #64748b !important; font-size: 0.78rem; }

    .sys-status-row { display: flex; justify-content: space-between; align-items: center; padding: 14px 0; border-bottom: 1px solid rgba(99, 102, 241, 0.06); }
    .sys-status-row:last-child { border-bottom: none; }
    .sys-status-name { color: #94a3b8 !important; font-size: 0.85rem; font-weight: 500; }

    .welcome-banner { background: linear-gradient(135deg, rgba(99, 102, 241, 0.12), rgba(139, 92, 246, 0.08), rgba(6, 182, 212, 0.05)) !important; border: 1px solid rgba(99, 102, 241, 0.15); border-radius: 24px; padding: 32px 36px; margin-bottom: 32px; animation: fadeInUp 0.6s ease-out; }
    .welcome-banner h2 { font-size: 1.5rem !important; color: #e0e7ff !important; -webkit-text-fill-color: #e0e7ff !important; }
    .welcome-banner p { color: #94a3b8 !important; }

    .job-card { background: rgba(15, 23, 42, 0.88) !important; border: 1px solid rgba(99, 102, 241, 0.12); border-radius: 20px; padding: 28px; margin-bottom: 16px; transition: all 0.35s ease; position: relative; overflow: hidden; }
    .job-card::before { content: ''; position: absolute; left: 0; top: 0; bottom: 0; width: 4px; background: linear-gradient(180deg, #6366f1, #8b5cf6); }
    .job-card:hover { border-color: rgba(99, 102, 241, 0.25); box-shadow: 0 8px 32px rgba(99, 102, 241, 0.1); transform: translateY(-2px); }
    .job-card-header { display: flex; justify-content: space-between; align-items: flex-start; gap: 16px; }
    .job-card-title { color: #e0e7ff !important; font-weight: 700; font-size: 1.05rem; margin-bottom: 8px; }
    .job-card-meta { display: flex; flex-wrap: wrap; gap: 16px; margin-top: 4px; }
    .job-card-meta-item { color: #94a3b8 !important; font-size: 0.82rem; }

    .form-section { display: flex; align-items: center; gap: 12px; margin-bottom: 20px; padding-bottom: 12px; border-bottom: 1px solid rgba(99, 102, 241, 0.1); }
    .form-section-icon { width: 36px; height: 36px; border-radius: 10px; background: rgba(99, 102, 241, 0.1); display: flex; align-items: center; justify-content: center; font-size: 1.1rem; border: 1px solid rgba(99, 102, 241, 0.12); }
    .form-section-text { color: #c7d2fe !important; font-weight: 600; font-size: 0.95rem; }

    .empty-state { text-align: center; padding: 64px 32px; background: rgba(15, 23, 42, 0.5) !important; border: 1px dashed rgba(99, 102, 241, 0.2); border-radius: 24px; }
    .empty-state .empty-icon { font-size: 4rem; display: block; margin-bottom: 16px; animation: float 4s ease-in-out infinite; }
    @keyframes float { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-8px); } }
    .empty-state h3 { color: #c7d2fe !important; -webkit-text-fill-color: #c7d2fe !important; font-size: 1.1rem; font-weight: 600; }
    .empty-state p { color: #64748b !important; font-size: 0.88rem; }

    .podium-wrapper { display: flex; justify-content: center; align-items: flex-end; gap: 16px; padding: 20px 0; margin-bottom: 32px; }
    .podium-place { text-align: center; border-radius: 20px 20px 0 0; padding: 24px 20px 20px; transition: all 0.4s ease; flex: 1; max-width: 220px; }
    .podium-place:hover { transform: translateY(-8px); }
    .podium-1 { background: linear-gradient(180deg, rgba(250, 204, 21, 0.12), rgba(250, 204, 21, 0.04)) !important; border: 1px solid rgba(250, 204, 21, 0.25); border-bottom: 4px solid #facc15; min-height: 200px; order: 2; }
    .podium-2 { background: linear-gradient(180deg, rgba(148, 163, 184, 0.1), rgba(148, 163, 184, 0.03)) !important; border: 1px solid rgba(148, 163, 184, 0.2); border-bottom: 4px solid #94a3b8; min-height: 170px; order: 1; }
    .podium-3 { background: linear-gradient(180deg, rgba(180, 83, 9, 0.1), rgba(180, 83, 9, 0.03)) !important; border: 1px solid rgba(180, 83, 9, 0.2); border-bottom: 4px solid #b45309; min-height: 150px; order: 3; }
    .podium-medal { font-size: 2.4rem; margin-bottom: 8px; display: block; }
    .podium-name { color: #e0e7ff !important; font-weight: 700; font-size: 0.95rem; margin-bottom: 4px; }
    .podium-score { font-family: 'JetBrains Mono', monospace; font-size: 1.6rem; font-weight: 800; margin: 8px 0 4px; }
    .podium-score-label { color: #64748b !important; font-size: 0.7rem; text-transform: uppercase; letter-spacing: 0.08em; }

    .rank-card { background: rgba(15, 23, 42, 0.8) !important; border: 1px solid rgba(99, 102, 241, 0.12); border-radius: 20px; padding: 22px 28px; margin-bottom: 12px; display: flex; justify-content: space-between; align-items: center; transition: all 0.35s ease; cursor: pointer; }
    .rank-card:hover { border-color: rgba(99, 102, 241, 0.35); transform: translateX(4px); box-shadow: 0 4px 24px rgba(99,102,241,0.15); }
    .rank-info { display: flex; align-items: center; gap: 18px; }
    .rank-medal { font-size: 2rem; min-width: 48px; text-align: center; }
    .rank-number { font-family: 'JetBrains Mono', monospace; font-weight: 800; font-size: 1.2rem; color: #94a3b8 !important; min-width: 48px; text-align: center; background: rgba(99, 102, 241, 0.08); padding: 6px 12px; border-radius: 10px; }
    .rank-name { color: #e0e7ff !important; font-weight: 600; font-size: 1rem; }
    .rank-email { color: #64748b !important; font-size: 0.8rem; }
    .rank-score-block { text-align: right; }
    .rank-score-value { font-family: 'JetBrains Mono', monospace; font-size: 1.6rem; font-weight: 800; line-height: 1; }
    .rank-score-label { color: #64748b !important; font-size: 0.7rem; text-transform: uppercase; letter-spacing: 0.08em; margin-top: 4px; }
    .rank-score-bar { width: 120px; height: 6px; background: rgba(99, 102, 241, 0.12); border-radius: 3px; margin-top: 8px; overflow: hidden; }
    .rank-score-bar-fill { height: 100%; border-radius: 3px; }

    /* ── ATS Grammarly-style Score Card ─────────────────────────────────── */
    .ats-score-panel {
        background: rgba(10, 12, 30, 0.96) !important;
        border: 1px solid rgba(99, 102, 241, 0.25);
        border-radius: 24px;
        padding: 32px;
        margin: 20px 0;
        animation: fadeInUp 0.5s ease-out;
    }
    .ats-score-header {
        display: flex; align-items: center; justify-content: space-between;
        margin-bottom: 28px; padding-bottom: 20px;
        border-bottom: 1px solid rgba(99, 102, 241, 0.1);
    }
    .ats-candidate-name {
        font-size: 1.2rem; font-weight: 700; color: #e0e7ff !important;
    }
    .ats-candidate-meta {
        font-size: 0.82rem; color: #64748b !important; margin-top: 4px;
    }
    .ats-total-ring {
        position: relative; width: 100px; height: 100px;
    }
    .ats-total-ring svg { transform: rotate(-90deg); }
    .ats-total-label {
        position: absolute; top: 50%; left: 50%;
        transform: translate(-50%, -50%);
        text-align: center;
    }
    .ats-total-pct {
        font-family: 'JetBrains Mono', monospace;
        font-size: 1.4rem; font-weight: 800;
        line-height: 1;
    }
    .ats-total-sublabel {
        font-size: 0.58rem; color: #64748b !important;
        text-transform: uppercase; letter-spacing: 0.08em;
        margin-top: 2px;
    }

    /* Score bars Grammarly-style */
    .ats-metric-row {
        display: flex; align-items: center; gap: 14px;
        margin-bottom: 14px;
    }
    .ats-metric-label {
        color: #94a3b8 !important; font-size: 0.82rem; font-weight: 500;
        min-width: 160px; flex-shrink: 0;
    }
    .ats-metric-bar-track {
        flex: 1; height: 8px;
        background: rgba(99, 102, 241, 0.1);
        border-radius: 4px; overflow: hidden;
    }
    .ats-metric-bar-fill {
        height: 100%; border-radius: 4px;
        transition: width 1s ease-out;
    }
    .ats-metric-value {
        font-family: 'JetBrains Mono', monospace;
        font-size: 0.82rem; font-weight: 700;
        min-width: 42px; text-align: right;
    }

    /* Verdict chip */
    .ats-verdict {
        display: inline-flex; align-items: center; gap: 8px;
        padding: 8px 20px; border-radius: 30px;
        font-weight: 700; font-size: 0.88rem;
    }
    .verdict-strong-hire { background: rgba(16,185,129,0.15); color: #34d399 !important; border: 1px solid rgba(16,185,129,0.25); }
    .verdict-hire        { background: rgba(59,130,246,0.15); color: #60a5fa !important; border: 1px solid rgba(59,130,246,0.25); }
    .verdict-consider    { background: rgba(245,158,11,0.15); color: #fbbf24 !important; border: 1px solid rgba(245,158,11,0.25); }
    .verdict-borderline  { background: rgba(249,115,22,0.15); color: #fb923c !important; border: 1px solid rgba(249,115,22,0.25); }
    .verdict-reject      { background: rgba(239,68,68,0.15);  color: #f87171 !important; border: 1px solid rgba(239,68,68,0.25); }

    /* Strengths / gaps pills */
    .skill-pill {
        display: inline-block; padding: 4px 12px;
        border-radius: 20px; font-size: 0.76rem; font-weight: 500;
        margin: 3px 2px;
    }
    .skill-strength { background: rgba(16,185,129,0.12); color: #34d399 !important; border: 1px solid rgba(16,185,129,0.2); }
    .skill-gap      { background: rgba(239,68,68,0.12);  color: #f87171 !important; border: 1px solid rgba(239,68,68,0.2); }

    /* Chat interview styles */
    .chat-question { background: rgba(99, 102, 241, 0.1) !important; border: 1px solid rgba(99, 102, 241, 0.2); border-radius: 20px 20px 20px 4px; padding: 20px 24px; margin-bottom: 16px; max-width: 85%; animation: chatSlideIn 0.4s ease-out; }
    @keyframes chatSlideIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
    .chat-question .q-category { display: inline-flex; gap: 6px; margin-bottom: 12px; }
    .chat-question .q-text { color: #e0e7ff !important; font-size: 1rem; font-weight: 500; line-height: 1.6; }
    .chat-answer-result { background: rgba(16, 185, 129, 0.06) !important; border: 1px solid rgba(16, 185, 129, 0.15); border-radius: 4px 20px 20px 20px; padding: 20px 24px; margin-bottom: 16px; margin-left: auto; max-width: 85%; }

    /* Q progress tracker */
    .q-tracker { display: flex; gap: 8px; margin-bottom: 20px; }
    .q-dot { width: 32px; height: 32px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 0.75rem; font-weight: 700; transition: all 0.3s ease; border: 2px solid; }
    .q-dot-done    { background: rgba(16,185,129,0.15); color: #34d399 !important; border-color: rgba(16,185,129,0.4); }
    .q-dot-current { background: rgba(99,102,241,0.25); color: #a78bfa !important; border-color: rgba(99,102,241,0.6); box-shadow: 0 0 12px rgba(99,102,241,0.3); }
    .q-dot-todo    { background: rgba(71,85,105,0.2);   color: #475569 !important; border-color: rgba(71,85,105,0.3); }

    /* Interview completion card */
    .interview-complete-card { background: linear-gradient(135deg, rgba(16,185,129,0.12), rgba(6,182,212,0.08)) !important; border: 1px solid rgba(16,185,129,0.25); border-radius: 20px; padding: 32px; text-align: center; }

    .process-step { display: flex; align-items: center; gap: 12px; padding: 10px 16px; background: rgba(99, 102, 241, 0.06) !important; border: 1px solid rgba(99, 102, 241, 0.1); border-radius: 12px; margin-bottom: 6px; }
    .process-step-icon { font-size: 1.2rem; min-width: 28px; text-align: center; }
    .process-step-text { color: #c7d2fe !important; font-size: 0.88rem; font-weight: 500; }

    .stSuccess { background: rgba(16, 185, 129, 0.08) !important; border: 1px solid rgba(16, 185, 129, 0.2) !important; border-radius: 14px !important; }
    .stAlert { border-radius: 14px !important; }
    .stProgress > div > div > div { background: linear-gradient(90deg, #6366f1, #8b5cf6, #a78bfa) !important; border-radius: 8px; }

    #MainMenu { visibility: hidden; }
    footer { visibility: hidden; }

    .main .block-container { animation: fadeInUp 0.5s ease-out; }
    @keyframes fadeInUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }

    [data-testid="stExpander"] { background: rgba(15, 23, 42, 0.7) !important; border: 1px solid rgba(99, 102, 241, 0.1) !important; border-radius: 14px !important; }

    /* Job description preview in rankings */
    .job-desc-banner {
        background: rgba(99,102,241,0.07) !important;
        border: 1px solid rgba(99,102,241,0.15);
        border-left: 4px solid #6366f1;
        border-radius: 14px; padding: 18px 22px; margin-bottom: 24px;
    }
    .job-desc-banner h4 { color: #a78bfa !important; -webkit-text-fill-color: #a78bfa !important; margin: 0 0 6px; font-size: 1rem !important; }
    .job-desc-banner p { color: #94a3b8 !important; font-size: 0.85rem; margin: 0; line-height: 1.5; }
</style>
""", unsafe_allow_html=True)


# ─────────────────────────────────────────────────────────────────────────────
# Session State
# ─────────────────────────────────────────────────────────────────────────────
if "auth_token" not in st.session_state:
    st.session_state["auth_token"] = None
if "interview_session" not in st.session_state:
    st.session_state["interview_session"] = {}   # {interview_id: {questions, answers, current_idx}}
if "apply_for_job_id" not in st.session_state:
    st.session_state["apply_for_job_id"] = None
if "apply_for_job_title" not in st.session_state:
    st.session_state["apply_for_job_title"] = None
if "portal_view" not in st.session_state:
    st.session_state["portal_view"] = "🏢 Recruiter Portal"
if "rec_nav_page" not in st.session_state:
    st.session_state["rec_nav_page"] = "Dashboard"

BASE_URL = os.environ.get("BASE_URL", "http://localhost:8000/api")


def render_careers_portal():
    st.markdown("""
    <div class="page-header">
        <div class="page-header-icon">🔍</div>
        <div><h1 style="margin:0; font-size:1.8rem !important;">Careers Portal</h1></div>
    </div>
    <p class="page-subtitle">View open positions and submit your application online</p>
    """, unsafe_allow_html=True)

    # Fetch active jobs from public API
    try:
        res = requests.get(f"{BASE_URL}/public/jobs")
        if res.status_code == 200:
            jobs = res.json()
        else:
            st.error("Could not fetch job postings.")
            jobs = []
    except Exception:
        st.error("Unable to connect to the backend server. Is it running?")
        jobs = []

    if not jobs:
        st.info("There are currently no active job postings. Please check back later.")
        return

    # Choose a job to apply
    st.markdown("### Open Positions")
    for job in jobs:
        st.markdown(f"""
        <div class="glass-card" style="margin-bottom: 16px; padding: 16px; border: 1px solid rgba(99,102,241,0.08);">
            <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 8px;">
                <div>
                    <h3 style="margin: 0; color: #a5b4fc !important; font-size: 1.15rem;">💼 {job['title']}</h3>
                    <p style="margin: 4px 0 0 0; color: #94a3b8 !important; font-size: 0.85rem;">
                        🏢 {job['department']} &nbsp;·&nbsp; 📍 {job['location']} &nbsp;·&nbsp; ⏱️ {job['employment_type']} &nbsp;·&nbsp; 💰 {job['salary_range']}
                    </p>
                </div>
            </div>
            <div style="margin-top: 12px; color: #cbd5e1 !important; font-size: 0.88rem; line-height: 1.5;">
                {job['full_description'][:300]}...
            </div>
        </div>
        """, unsafe_allow_html=True)
        
        # Render apply button in streamlit column
        col_btn, _ = st.columns([1.5, 4.5])
        with col_btn:
            if st.button(f"Apply for {job['title']}", key=f"apply_{job['id']}", use_container_width=True):
                st.session_state["apply_for_job_id"] = job['id']
                st.session_state["apply_for_job_title"] = job['title']
                st.rerun()

    # If a job is selected, show the application form
    if st.session_state.get("apply_for_job_id"):
        job_id = st.session_state["apply_for_job_id"]
        job_title = st.session_state["apply_for_job_title"]

        st.markdown('<div class="section-divider"></div>', unsafe_allow_html=True)
        st.markdown(f'<div class="glass-card" style="padding: 24px; border: 1px solid rgba(99,102,241,0.15);">', unsafe_allow_html=True)
        st.markdown(f"""<div class="form-section"><div class="form-section-icon">📝</div><span class="form-section-text">Apply for {job_title}</span></div>""", unsafe_allow_html=True)

        col_cancel, _ = st.columns([1.5, 4.5])
        with col_cancel:
            if st.button("❌ Cancel", key="cancel_apply", use_container_width=True):
                st.session_state["apply_for_job_id"] = None
                st.session_state["apply_for_job_title"] = None
                st.rerun()

        st.write("")
        name = st.text_input("Full Name *", placeholder="John Doe", key="app_name")
        email = st.text_input("Email Address *", placeholder="john.doe@email.com", key="app_email")
        phone = st.text_input("Phone Number *", placeholder="+1 (555) 019-2834", key="app_phone")
        
        st.write("")
        st.markdown('<div class="resume-uploader">', unsafe_allow_html=True)
        uploaded_file = st.file_uploader("Upload Resume (PDF or TXT) *", type=["pdf", "txt"], key="app_file")
        st.markdown('</div>', unsafe_allow_html=True)

        st.write("")
        if st.button("⚡ Submit Application", use_container_width=True, disabled=not (name and email and phone and uploaded_file)):
            with st.spinner("Submitting and processing your application..."):
                try:
                    files_payload = {"file": (uploaded_file.name, uploaded_file.getvalue(), "application/pdf" if uploaded_file.name.endswith(".pdf") else "text/plain")}
                    data_payload = {"name": name, "email": email, "phone": phone}
                    res = requests.post(f"{BASE_URL}/public/jobs/{job_id}/apply", files=files_payload, data=data_payload)
                    
                    if res.status_code == 200:
                        st.success(f"🎉 Thank you, {name}! Your application for '{job_title}' was submitted successfully.")
                        st.session_state["apply_for_job_id"] = None
                        st.session_state["apply_for_job_title"] = None
                        st.rerun()
                    else:
                        st.error(f"Error submitting application: {res.json().get('detail', 'Unknown error')}")
                except Exception as exc:
                    st.error(f"Failed to connect to server: {exc}")
        
        st.markdown('</div>', unsafe_allow_html=True)


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────
def api_headers():
    return {"Authorization": f"Bearer {st.session_state['auth_token']}"}


def login_user(email, password):
    try:
        res = requests.post(f"{BASE_URL}/login", data={"username": email, "password": password})
        if res.status_code == 200:
            st.session_state["auth_token"] = res.json()["access_token"]
            st.session_state["user_profile"] = None  # Force reload user profile
            st.rerun()
        else:
            st.error("Invalid email or password. Please try again.")
    except Exception:
        st.error("Unable to connect to the backend server. Is it running?")


def get_greeting():
    hour = datetime.now().hour
    if hour < 12: return "Good Morning", "☀️"
    elif hour < 17: return "Good Afternoon", "🌤️"
    else: return "Good Evening", "🌙"


def score_color(score):
    if score >= 80: return "#34d399"
    elif score >= 60: return "#fbbf24"
    else: return "#f87171"


def score_gradient(score):
    if score >= 80: return "linear-gradient(135deg, #10b981, #34d399)"
    elif score >= 60: return "linear-gradient(135deg, #f59e0b, #fbbf24)"
    else: return "linear-gradient(135deg, #ef4444, #f87171)"


def bar_color(score):
    if score >= 80: return "#34d399"
    elif score >= 60: return "#fbbf24"
    else: return "#f87171"


def verdict_css_class(verdict: str) -> str:
    mapping = {
        "Strong Hire": "verdict-strong-hire",
        "Hire": "verdict-hire",
        "Consider": "verdict-consider",
        "Borderline": "verdict-borderline",
        "Reject": "verdict-reject",
    }
    return mapping.get(verdict, "verdict-consider")


def render_ats_score_panel(cand_data: dict, ats_data: dict, rec_data: dict | None = None):
    """Render the Grammarly-style ATS score breakdown panel with a visual scale."""
    name = cand_data.get("name", "Unknown Candidate")
    email = cand_data.get("email", "—")
    status = cand_data.get("status", "—")
    exp = cand_data.get("experience_years") or 0
    skills = cand_data.get("skills") or []

    total = ats_data.get("total_score", 0)
    sc = score_color(total)

    # circular ring via SVG
    radius = 42
    circumference = 2 * 3.14159 * radius
    dash = circumference * (total / 100)
    gap = circumference - dash

    ring_color = sc

    metrics = [
        ("Skills Match",        ats_data.get("skills_match", 0)),
        ("Experience Match",    ats_data.get("experience_match", 0)),
        ("Project Relevance",   ats_data.get("project_relevance", 0)),
        ("Education",           ats_data.get("education_score", 0)),
        ("Certifications",      ats_data.get("certification_score", 0)),
        ("Semantic Similarity", ats_data.get("semantic_similarity", 0)),
    ]

    metrics_html = ""
    for label, val in metrics:
        bc = bar_color(val)
        metrics_html += f"""<div class="ats-metric-row">
<div class="ats-metric-label">{label}</div>
<div class="ats-metric-bar-track">
<div class="ats-metric-bar-fill" style="width:{min(val,100):.1f}%; background:{score_gradient(val)};"></div>
</div>
<div class="ats-metric-value" style="color:{bc} !important;">{val:.1f}%</div>
</div>"""

    # Strengths / Gaps
    strengths = ats_data.get("strengths") or []
    gaps = ats_data.get("skill_gaps") or []
    strength_pills = "".join(f'<span class="skill-pill skill-strength">✓ {s}</span>' for s in strengths[:4])
    gap_pills      = "".join(f'<span class="skill-pill skill-gap">✗ {g}</span>' for g in gaps[:5])

    # Recommendation from ats
    ats_rec = ats_data.get("recommendation") or ""

    # Generate a descriptive explanation for the ATS report
    if total >= 80:
        explanation_text = "Strong Technical & Professional Alignment: The candidate demonstrates highly relevant experience and skills matching the core requirements. Very high likelihood of performance success in this role."
    elif total >= 60:
        explanation_text = "Moderate Alignment with Minor Skill Gaps: Meets the primary qualification requirements. However, there are minor gaps in secondary skill sets or domain-specific experience that should be clarified."
    else:
        explanation_text = "Low Alignment / Substantial Gaps: Significant misalignment found in required skills, qualifications, or experience. The candidate does not meet the baseline threshold for this role."

    # Spectrum scale from red (#ef4444) to orange (#fbbf24) to green (#34d399) - LEFT ALIGNED
    spectrum_html = f"""<div style="margin: 20px 0 24px; padding: 20px; background: rgba(255, 255, 255, 0.03) !important; border: 1px solid rgba(99, 102, 241, 0.15); border-radius: 16px;">
<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
<span style="font-size: 0.8rem; font-weight: 600; color: #94a3b8 !important; text-transform: uppercase; letter-spacing: 0.05em;">ATS Alignment Scale</span>
<span style="font-family: 'JetBrains Mono', monospace; font-size: 0.95rem; font-weight: 800; color: {sc} !important;">Score: {total:.1f}%</span>
</div>
<div style="position: relative; height: 10px; background: linear-gradient(90deg, #ef4444 0%, #fbbf24 50%, #34d399 100%); border-radius: 5px; margin: 12px 0;">
<div style="position: absolute; left: calc({min(max(total, 0.0), 100.0)}% - 6px); top: -3px; width: 12px; height: 16px; background: #ffffff; border: 2px solid #060918; border-radius: 3px; box-shadow: 0 0 8px rgba(255, 255, 255, 0.9); z-index: 2;"></div>
</div>
<div style="display: flex; justify-content: space-between; font-size: 0.72rem; color: #64748b !important;">
<span>Reject (0-59%)</span>
<span>Consider (60-79%)</span>
<span>Hire (80-100%)</span>
</div>
<div style="margin-top: 14px; font-size: 0.82rem; line-height: 1.5; color: #cbd5e1 !important; border-top: 1px dashed rgba(99, 102, 241, 0.1); padding-top: 10px;">
📋 <b>ATS Verdict Explanation:</b> {explanation_text}
</div>
</div>"""

    # AI verdict from rec_data - LEFT ALIGNED
    verdict_html = ""
    if rec_data:
        verdict = rec_data.get("ai_verdict", "—")
        ai_rating = rec_data.get("ai_rating", total)
        justification = rec_data.get("ai_justification", "")
        vc = verdict_css_class(verdict)
        hr_override = rec_data.get("hr_override_verdict")
        hr_notes = rec_data.get("hr_notes") or ""
        verdict_html = f"""<div style="margin-top:20px; padding-top:16px; border-top:1px solid rgba(99,102,241,0.1);">
<div style="display:flex; align-items:center; gap:12px; flex-wrap:wrap; margin-bottom:10px;">
<span style="color:#64748b !important; font-size:0.8rem; font-weight:600; text-transform:uppercase; letter-spacing:0.08em;">AI Verdict</span>
<span class="ats-verdict {vc}">{verdict}</span>
<span style="color:#64748b !important; font-size:0.8rem;">AI Rating: <b style="color:{score_color(ai_rating)} !important;">{ai_rating:.1f}%</b></span>
</div>
<div style="color:#94a3b8 !important; font-size:0.85rem; line-height:1.6;">{justification}</div>"""
        if hr_override:
            verdict_html += f"""<div style="margin-top:12px; padding:10px 14px; background:rgba(245,158,11,0.08) !important; border:1px solid rgba(245,158,11,0.2); border-radius:10px;">
<span style="color:#fbbf24 !important; font-size:0.78rem; font-weight:600;">🔄 HR Override: {hr_override}</span>
{f'<div style="color:#94a3b8 !important; font-size:0.78rem; margin-top:4px;">{hr_notes}</div>' if hr_notes else ''}
</div>"""
        verdict_html += "</div>"

    skills_display = ", ".join(skills[:6]) if skills else "—"

    # Main markdown - LEFT ALIGNED
    st.markdown(f"""<div class="ats-score-panel">
<div class="ats-score-header">
<div>
<div class="ats-candidate-name">👤 {name}</div>
<div class="ats-candidate-meta">📧 {email} &nbsp;·&nbsp; 💼 {exp} yrs exp &nbsp;·&nbsp; 📊 {status}</div>
<div class="ats-candidate-meta" style="margin-top:4px;">🛠 {skills_display}</div>
</div>
<div class="ats-total-ring">
<svg width="100" height="100" viewBox="0 0 100 100">
<circle cx="50" cy="50" r="{radius}" fill="none" stroke="rgba(99,102,241,0.1)" stroke-width="8"/>
<circle cx="50" cy="50" r="{radius}" fill="none" stroke="{ring_color}" stroke-width="8" stroke-linecap="round" stroke-dasharray="{dash:.1f} {gap:.1f}"/>
</svg>
<div class="ats-total-label">
<div class="ats-total-pct" style="color:{sc} !important;">{total:.0f}%</div>
<div class="ats-total-sublabel">ATS</div>
</div>
</div>
</div>
{spectrum_html}
<div style="margin-bottom:20px;">
<div style="color:#64748b !important; font-size:0.75rem; text-transform:uppercase; letter-spacing:0.1em; margin-bottom:14px; font-weight:600;">Score Breakdown</div>
{metrics_html}
</div>
{f'<div style="margin-bottom:16px;"><div style="color:#64748b !important; font-size:0.75rem; text-transform:uppercase; letter-spacing:0.1em; font-weight:600; margin-bottom:8px;">Strengths</div><div>{strength_pills}</div></div>' if strength_pills else ''}
{f'<div style="margin-bottom:16px;"><div style="color:#64748b !important; font-size:0.75rem; text-transform:uppercase; letter-spacing:0.1em; font-weight:600; margin-bottom:8px;">Skill Gaps</div><div>{gap_pills}</div></div>' if gap_pills else ''}
{f'<div style="padding:12px 16px; background:rgba(99,102,241,0.06) !important; border:1px solid rgba(99,102,241,0.12); border-radius:10px; color:#a5b4fc !important; font-size:0.85rem; margin-bottom:12px;"><b>💡 Recommendation:</b> {ats_rec}</div>' if ats_rec else ''}
{verdict_html}
</div>""", unsafe_allow_html=True)


def render_employee_dashboard(user_profile):
    fullname = user_profile.get("full_name", "Valued Employee")
    email = user_profile.get("email", "employee@company.com")
    
    # Stable Employee ID based on hash of email
    import hashlib
    emp_hash = int(hashlib.md5(email.encode()).hexdigest(), 16)
    emp_code = f"EMP-{emp_hash % 900000 + 100000}"
    
    # Session state variables for Employee Portal
    if "emp_chatbot_messages" not in st.session_state:
        st.session_state["emp_chatbot_messages"] = [
            {"role": "assistant", "content": f"Hello {fullname}! I am your HR Assistant. How can I help you today?"}
        ]
    if "emp_tickets" not in st.session_state:
        st.session_state["emp_tickets"] = []
    if "emp_courses" not in st.session_state:
        st.session_state["emp_courses"] = [
            {"title": "Advanced FastAPI Architectures", "hours": 12, "timeline": "Week 1", "status": "Not Started"},
            {"title": "Cloud Computing & AWS Bedrock SDK", "hours": 16, "timeline": "Week 2", "status": "Not Started"},
            {"title": "Enterprise DB Optimization (PostgreSQL)", "hours": 20, "timeline": "Week 3-4", "status": "Not Started"}
        ]
    if "emp_target_role" not in st.session_state:
        st.session_state["emp_target_role"] = "Senior Python Backend Engineer"
    if "emp_survey_submitted" not in st.session_state:
        st.session_state["emp_survey_submitted"] = False
    if "emp_offboarding_active" not in st.session_state:
        st.session_state["emp_offboarding_active"] = False

    # Fetch real employee data from /employees/me
    emp_data = {}
    try:
        emp_res = requests.get(f"{BASE_URL}/employees/me", headers={"Authorization": f"Bearer {st.session_state['auth_token']}"})
        if emp_res.status_code == 200:
            emp_data = emp_res.json()
    except Exception:
        pass

    # Check for active roadmap/analysis
    has_active_roadmap = False
    if emp_data.get("id"):
        try:
            a_res = requests.get(
                f"{BASE_URL}/training/analyses?employee_id={emp_data.get('id')}",
                headers={"Authorization": f"Bearer {st.session_state['auth_token']}"}
            )
            if a_res.status_code == 200:
                analyses = a_res.json()
                if analyses:
                    has_active_roadmap = True
        except Exception:
            pass

    # TCS Ultimatix CSS Theme Overrides
    st.markdown("""
    <style>
        .stApp, [data-testid="stAppViewContainer"], .main,
        [data-testid="stAppViewBlockContainer"] {
            background-color: #f3f4f6 !important;
            background: #f3f4f6 !important;
        }
        
        .main::before {
            display: none !important;
        }

        /* Ensure header background is transparent in Employee Portal too */
        .stApp > header {
            background: transparent !important;
        }

        /* High-contrast dark blue sidebar toggle buttons for light themed Employee Portal */
        [data-testid="collapsedControl"],
        [data-testid="stSidebarCollapseButton"] {
            background: rgba(0, 42, 84, 0.08) !important;
            border: 1px solid rgba(0, 42, 84, 0.2) !important;
            border-radius: 8px !important;
            color: #002a54 !important;
            z-index: 999999 !important;
            transition: all 0.3s ease !important;
        }
        [data-testid="collapsedControl"] svg,
        [data-testid="stSidebarCollapseButton"] svg {
            fill: #002a54 !important;
            color: #002a54 !important;
        }
        [data-testid="collapsedControl"]:hover,
        [data-testid="stSidebarCollapseButton"]:hover {
            background: rgba(0, 42, 84, 0.15) !important;
            border-color: rgba(0, 42, 84, 0.4) !important;
            box-shadow: 0 0 10px rgba(0, 42, 84, 0.15) !important;
        }
        
        /* Sidebar layout styling override */
        [data-testid="stSidebar"], [data-testid="stSidebar"] > div:first-child {
            background: linear-gradient(180deg, #001e3d 0%, #002a54 100%) !important;
            border-right: 2px solid #00152b;
        }
        
        /* Specificity override for all texts and controls inside the sidebar to ensure they are visible (white/light gray) */
        .stApp [data-testid="stSidebar"] p,
        .stApp [data-testid="stSidebar"] span,
        .stApp [data-testid="stSidebar"] label,
        .stApp [data-testid="stSidebar"] div,
        .stApp [data-testid="stSidebar"] button,
        .stApp [data-testid="stSidebar"] h3 {
            color: #e5e7eb !important;
            -webkit-text-fill-color: #e5e7eb !important;
        }

        [data-testid="stSidebar"] .stRadio label {
            background-color: transparent !important;
            border: 1px solid transparent;
            color: #d1d5db !important;
            padding: 10px 14px;
            font-size: 0.9rem;
            border-radius: 6px;
        }
        
        [data-testid="stSidebar"] .stRadio label:hover {
            background-color: rgba(255, 255, 255, 0.1) !important;
            color: #ffffff !important;
        }

        /* Global Text color defaults in Employee Portal (confined to main content) */
        .stApp .block-container p,
        .stApp .block-container span,
        .stApp .block-container label,
        .stApp .block-container li,
        .stApp .block-container .stMarkdown,
        .stApp .block-container .stMarkdown p,
        .stApp .block-container .stMarkdown span,
        .stApp .block-container [data-testid="stMarkdownContainer"],
        .stApp .block-container [data-testid="stMarkdownContainer"] p,
        .stApp .block-container [data-testid="stMarkdownContainer"] span,
        .stApp .block-container [data-testid="stMarkdownContainer"] li,
        .stApp .block-container [data-testid="stWidgetLabel"] p {
            color: #1f2937 !important;
            -webkit-text-fill-color: #1f2937 !important;
        }

        /* High-contrast alert text color (e.g. st.info blue warning box) */
        .stApp .block-container .stAlert p,
        .stApp .block-container .stAlert span,
        .stApp .block-container .stAlert div,
        .stApp .block-container .stAlert li {
            color: #1e3a8a !important;
            -webkit-text-fill-color: #1e3a8a !important;
        }


        /* Headings - override both color and fill properties to avoid dark-mode gradient bleeding */
        h1, h2, h3, h4, h5, h6,
        .main h1, .main h2, .main h3, .main h4 {
            color: #002a54 !important;
            -webkit-text-fill-color: #002a54 !important;
            background: none !important;
            font-weight: 700 !important;
        }

        /* Strong/Bold tags - override dark-mode light colors */
        strong, b,
        .main strong, .main b {
            color: #111827 !important;
            -webkit-text-fill-color: #111827 !important;
            font-weight: 700 !important;
        }
        
        /* Card design styling */
        .ux-card {
            background-color: #ffffff !important;
            border: 1px solid #e5e7eb !important;
            border-top: 4px solid #002a54 !important;
            border-radius: 8px;
            padding: 22px;
            margin-bottom: 20px;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03) !important;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .ux-card:hover {
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.08) !important;
            transform: translateY(-2px);
        }

        /* Override text inside cards to ensure full visibility */
        .ux-card p, .ux-card span, .ux-card div, .ux-card li {
            color: #374151 !important;
            -webkit-text-fill-color: #374151 !important;
        }
        .ux-card h3, .ux-card h4 {
            color: #002a54 !important;
            -webkit-text-fill-color: #002a54 !important;
        }
        .ux-card strong, .ux-card b {
            color: #111827 !important;
            -webkit-text-fill-color: #111827 !important;
        }
        
        /* TCS Ultimatix Header Bar */
        .ux-header-bar {
            background-color: #002a54 !important;
            border-radius: 8px;
            padding: 18px 24px;
            margin-bottom: 24px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 4px 12px rgba(0, 42, 84, 0.15);
        }
        .ux-header-bar * {
            background: none !important;
        }
        .stApp .block-container .ux-header-bar h1,
        .stApp .block-container .ux-header-bar h1 span,
        .stApp .block-container .ux-header-bar .ux-header-title,
        .stApp .block-container .ux-header-bar .ux-header-title span {
            color: #ffffff !important;
            background: none !important;
            background-clip: border-box !important;
            -webkit-background-clip: border-box !important;
            -webkit-text-fill-color: #ffffff !important;
            margin: 0 !important;
            font-size: 1.6rem !important;
            font-weight: 700 !important;
        }
        .stApp .block-container .ux-header-bar p,
        .stApp .block-container .ux-header-bar p span,
        .stApp .block-container .ux-header-bar .ux-header-subtitle,
        .stApp .block-container .ux-header-bar .ux-header-subtitle span {
            color: #93c5fd !important;
            background: none !important;
            background-clip: border-box !important;
            -webkit-background-clip: border-box !important;
            -webkit-text-fill-color: #93c5fd !important;
            font-size: 0.85rem !important;
            margin: 2px 0 0 0 !important;
        }
        .ux-header-profile {
            text-align: right;
        }
        .stApp .block-container .ux-header-bar .ux-header-profile-name,
        .stApp .block-container .ux-header-bar .ux-header-profile-name span,
        .stApp .block-container .ux-header-bar .ux-header-profile-name div {
            color: #ffffff !important;
            background: none !important;
            background-clip: border-box !important;
            -webkit-background-clip: border-box !important;
            -webkit-text-fill-color: #ffffff !important;
            font-weight: 600 !important;
            font-size: 0.95rem !important;
        }
        .stApp .block-container .ux-header-bar .ux-header-profile-code,
        .stApp .block-container .ux-header-bar .ux-header-profile-code span,
        .stApp .block-container .ux-header-bar .ux-header-profile-code div {
            color: #93c5fd !important;
            background: none !important;
            background-clip: border-box !important;
            -webkit-background-clip: border-box !important;
            -webkit-text-fill-color: #93c5fd !important;
            font-size: 0.78rem !important;
        }
        
        /* Form, button and badge overrides */
        .badge-ux {
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 0.75rem;
            font-weight: 600;
        }
        .badge-ux-green { background-color: #def7ec !important; color: #03543f !important; -webkit-text-fill-color: #03543f !important; }
        .badge-ux-yellow { background-color: #fef3c7 !important; color: #92400e !important; -webkit-text-fill-color: #92400e !important; }
        .badge-ux-blue { background-color: #e0f2fe !important; color: #0369a1 !important; -webkit-text-fill-color: #0369a1 !important; }
        .badge-ux-red { background-color: #fde8e8 !important; color: #9b1c1c !important; -webkit-text-fill-color: #9b1c1c !important; }
        
        /* High contrast button and link button styles */
        .stButton button,
        [data-testid="stLinkButton"] a,
        [data-testid="stBaseButton-secondary"] {
            background-color: #004b87 !important;
            color: #ffffff !important;
            -webkit-text-fill-color: #ffffff !important;
            border: 1px solid #003a6b !important;
            text-decoration: none !important;
        }
        .stButton button:hover,
        [data-testid="stLinkButton"] a:hover,
        [data-testid="stBaseButton-secondary"]:hover {
            background-color: #002a54 !important;
            color: #ffffff !important;
            -webkit-text-fill-color: #ffffff !important;
        }
        .stButton button p,
        .stButton button span,
        [data-testid="stLinkButton"] a p,
        [data-testid="stLinkButton"] a span,
        [data-testid="stBaseButton-secondary"] p,
        [data-testid="stBaseButton-secondary"] span {
            color: #ffffff !important;
            -webkit-text-fill-color: #ffffff !important;
            background: none !important;
            background-clip: border-box !important;
            -webkit-background-clip: border-box !important;
        }

        /* Complete premium tabs override for Employee Portal */
        .stApp .stTabs [data-baseweb="tab-list"] {
            background: #f1f5f9 !important;
            border-radius: 12px !important;
            padding: 6px !important;
            gap: 6px !important;
            border: 1px solid #cbd5e1 !important;
            box-shadow: inset 0 1px 2px rgba(0,0,0,0.02) !important;
        }
        .stApp .stTabs [data-baseweb="tab"] {
            border-radius: 8px !important;
            padding: 8px 18px !important;
            background: transparent !important;
            transition: all 0.2s ease !important;
            border: none !important;
            margin: 0 !important;
        }
        .stApp .stTabs [data-baseweb="tab"] * {
            color: #475569 !important;
            -webkit-text-fill-color: #475569 !important;
            font-weight: 600 !important;
            font-size: 0.88rem !important;
        }
        .stApp .stTabs [data-baseweb="tab"]:hover {
            background: rgba(255, 255, 255, 0.5) !important;
        }
        .stApp .stTabs [data-baseweb="tab"]:hover * {
            color: #002a54 !important;
            -webkit-text-fill-color: #002a54 !important;
        }
        .stApp .stTabs [aria-selected="true"] {
            background: #ffffff !important;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1) !important;
        }
        .stApp .stTabs [aria-selected="true"] * {
            color: #004b87 !important;
            -webkit-text-fill-color: #004b87 !important;
            font-weight: 700 !important;
        }
        .stApp .stTabs [data-baseweb="tab-highlight"] {
            display: none !important;
        }
        .stApp .stTabs [data-baseweb="tab-border"] {
            display: none !important;
        }

        /* Widget Label color fixes to prevent fading */
        .stApp .main [data-testid="stWidgetLabel"] p,
        .stApp .main [data-testid="stWidgetLabel"] span {
            color: #1e293b !important;
            -webkit-text-fill-color: #1e293b !important;
            font-weight: 600 !important;
        }

        /* Rating circles styling for preview skill gap */
        .rating-circle-green {
            display: inline-block !important;
            width: 10px !important;
            height: 10px !important;
            border-radius: 50% !important;
            background-color: #10b981 !important;
            margin-right: 4px !important;
            vertical-align: middle !important;
        }
        .rating-circle-red {
            display: inline-block !important;
            width: 10px !important;
            height: 10px !important;
            border-radius: 50% !important;
            background-color: #ef4444 !important;
            margin-right: 4px !important;
            vertical-align: middle !important;
        }

        /* Direct global overrides for Employee Portal text elements to defeat recruiter dark overrides */
        .stApp .block-container p, 
        .stApp .block-container span, 
        .stApp .block-container label, 
        .stApp .block-container li,
        .stApp .block-container [data-testid="stMarkdownContainer"] p,
        .stApp .block-container [data-testid="stMarkdownContainer"] span,
        .stApp .block-container [data-testid="stMarkdownContainer"] li {
            color: #1f2937 !important;
            -webkit-text-fill-color: #1f2937 !important;
        }

        /* High-contrast alert text color (restores native theme colors for info/success/warning/error alerts) */
        .stApp .block-container .stAlert p,
        .stApp .block-container .stAlert span,
        .stApp .block-container .stAlert div,
        .stApp .block-container .stAlert li {
            color: #1e3a8a !important;
            -webkit-text-fill-color: #1e3a8a !important;
        }

        /* Custom badge and pill tags to bypass global recruiter CSS overrides */
        phasebadge {
            display: inline-block !important;
            font-size: 0.7rem !important;
            font-weight: 800 !important;
            padding: 2px 8px !important;
            border-radius: 6px !important;
            margin-bottom: 2px !important;
            vertical-align: middle !important;
        }
        skillpill {
            display: inline-block !important;
            padding: 3px 10px !important;
            border-radius: 12px !important;
            font-size: 0.72rem !important;
            font-weight: 500 !important;
            margin: 2px !important;
            vertical-align: middle !important;
        }
        gapbadge {
            display: inline-block !important;
            padding: 3px 10px !important;
            border-radius: 20px !important;
            font-size: 0.72rem !important;
            font-weight: 700 !important;
            vertical-align: middle !important;
        }
    </style>
    """, unsafe_allow_html=True)

    # Sidebar for employee portal
    with st.sidebar:
        st.markdown(f"""
        <div style="text-align:center; padding: 10px 0; border-bottom: 1px solid #003366;">
            <div style="font-size: 2.2rem;">🏢</div>
            <h3 style="color: #ffffff !important; margin: 4px 0 0 0; font-size: 1.15rem;">Employee Portal</h3>
            <p style="color: #93c5fd !important; font-size: 0.72rem; margin:0;">Employee Self-Service</p>
        </div>
        """, unsafe_allow_html=True)
        
        st.markdown("<br>", unsafe_allow_html=True)
        
        emp_nav_options = {
            "🏠  Home & Profile": "Home",
            "✏️  Manage & Rate Skills": "RateSkills"
        }
        if has_active_roadmap:
            emp_nav_options["🎓  Upskilling & Training"] = "Training"
        else:
            emp_nav_options["🔒  Upskilling & Training (Locked)"] = "TrainingLocked"
            
        emp_nav_options.update({
            "💬  HR Chatbot Helpdesk": "Chatbot",
            "📊  Pulse Survey": "Survey",
            "🚪  Exit & Clearance": "Offboarding"
        })
        
        selected_emp_label = st.radio(
            "Navigation",
            list(emp_nav_options.keys()),
            label_visibility="collapsed",
            key="emp_nav_radio"
        )
        selected_emp_page = emp_nav_options[selected_emp_label]
        
        st.markdown("<br><br><br>", unsafe_allow_html=True)
        st.markdown('<div style="border-top:1px solid #003366; padding-top: 15px;"></div>', unsafe_allow_html=True)
        
        if st.button("🚪 Sign Out", use_container_width=True, key="emp_signout_btn"):
            st.session_state["auth_token"] = None
            st.session_state["user_profile"] = None
            st.rerun()

    # Render TCS Ultimatix Header Bar
    st.markdown(f"""
    <div class="ux-header-bar">
        <div>
            <h1 class="ux-header-title">Employee Hub</h1>
            <p class="ux-header-subtitle">Enterprise Connected Ecosystem</p>
        </div>
        <div class="ux-header-profile">
            <div class="ux-header-profile-name">👤 {fullname}</div>
            <div class="ux-header-profile-code">{emp_code} &nbsp;·&nbsp; {email}</div>
        </div>
    </div>
    """, unsafe_allow_html=True)

    # Fetch real employee data from /employees/me
    emp_data = {}
    try:
        emp_res = requests.get(f"{BASE_URL}/employees/me", headers={"Authorization": f"Bearer {st.session_state['auth_token']}"})
        if emp_res.status_code == 200:
            emp_data = emp_res.json()
    except Exception:
        pass

    real_designation = emp_data.get("designation") or "—"
    real_department = emp_data.get("department") or "—"
    real_location = emp_data.get("location") or "—"
    real_emp_code = emp_data.get("employee_code") or emp_code
    real_status = emp_data.get("status") or "Active"
    joined_at_raw = emp_data.get("joined_at")
    real_joined = joined_at_raw[:10] if joined_at_raw else "—"
    status_badge_class = "badge-ux-green" if real_status == "Active" else "badge-ux-blue"

    # PAGE: Home & Profile
    if selected_emp_page == "Home":
        st.markdown("## Employee Self-Service Dashboard")
        
        col_l, col_r = st.columns([2, 1])
        
        with col_l:
            st.markdown(f"""
            <div class="ux-card">
                <h3 style="margin-top:0;">Welcome back, {fullname}! 👋</h3>
                <p style="color:#4b5563 !important; margin-bottom:20px;">Here is a summary of your employee profile in the system.</p>
                <div style="display:grid; grid-template-columns: 1fr 1fr; gap:20px; margin-top:16px;">
                    <div style="background:#f9fafb; border-radius:8px; padding:14px; border-left:4px solid #002a54;">
                        <span style="color:#6b7280 !important; font-size:0.75rem; text-transform:uppercase; font-weight:600; display:block; margin-bottom:4px;">Designation</span>
                        <strong style="font-size:0.95rem; color:#111827 !important;">{real_designation}</strong>
                    </div>
                    <div style="background:#f9fafb; border-radius:8px; padding:14px; border-left:4px solid #0369a1;">
                        <span style="color:#6b7280 !important; font-size:0.75rem; text-transform:uppercase; font-weight:600; display:block; margin-bottom:4px;">Department</span>
                        <strong style="font-size:0.95rem; color:#111827 !important;">{real_department}</strong>
                    </div>
                    <div style="background:#f9fafb; border-radius:8px; padding:14px; border-left:4px solid #059669;">
                        <span style="color:#6b7280 !important; font-size:0.75rem; text-transform:uppercase; font-weight:600; display:block; margin-bottom:4px;">Location</span>
                        <strong style="font-size:0.95rem; color:#111827 !important;">{real_location}</strong>
                    </div>
                    <div style="background:#f9fafb; border-radius:8px; padding:14px; border-left:4px solid #7c3aed;">
                        <span style="color:#6b7280 !important; font-size:0.75rem; text-transform:uppercase; font-weight:600; display:block; margin-bottom:4px;">Date of Joining</span>
                        <strong style="font-size:0.95rem; color:#111827 !important;">{real_joined}</strong>
                    </div>
                </div>
                <div style="margin-top:20px; display:flex; align-items:center; gap:12px;">
                    <div>
                        <span style="color:#6b7280 !important; font-size:0.75rem; text-transform:uppercase; font-weight:600;">Employee ID</span>
                        <strong style="font-size:0.9rem; color:#002a54 !important; display:block;">{real_emp_code}</strong>
                    </div>
                    <div style="margin-left:auto;">
                        <span class="badge-ux {status_badge_class}">{real_status}</span>
                    </div>
                </div>
            </div>
            """, unsafe_allow_html=True)

        with col_r:
            st.markdown("""
            <div class="ux-card">
                <h3 style="margin-top:0;">📢 Announcements</h3>
                <div style="border-bottom: 1px dashed #e5e7eb; padding-bottom:10px; margin-bottom:10px;">
                    <span class="badge-ux badge-ux-blue" style="font-size:0.68rem;">COMPLIANCE</span>
                    <h4 style="margin:4px 0; font-size:0.9rem;">Annual Code of Conduct Training</h4>
                    <p style="font-size:0.78rem; color:#6b7280 !important; margin:0;">All employees are requested to complete the annual Code of Conduct training on iON by June 30, 2026.</p>
                </div>
                <div>
                    <span class="badge-ux badge-ux-green" style="font-size:0.68rem;">REMINDER</span>
                    <h4 style="margin:4px 0; font-size:0.9rem;">Quarterly Performance Review</h4>
                    <p style="font-size:0.78rem; color:#6b7280 !important; margin:0;">Q2 performance ratings are due by July 15. Please complete your self-assessment on the appraisal portal.</p>
                </div>
            </div>
            """, unsafe_allow_html=True)




    # PAGE: Manage & Rate Skills
    elif selected_emp_page == "RateSkills":
        st.markdown("## ✏️ Manage & Rate My Skills")
        st.markdown("Assess your current skills profile and set your self-ratings. Once saved, your profile will be locked for editing.")
        
        # Retrieve current skills profile
        raw_skills = emp_data.get("skills_profile")
        if isinstance(raw_skills, list):
            skills_profile = {skill: 5 for skill in raw_skills}
            skills_locked = False
        elif isinstance(raw_skills, dict):
            skills_locked = raw_skills.get("_locked", False)
            skills_profile = {k: v for k, v in raw_skills.items() if k != "_locked"}
        else:
            skills_profile = {}
            skills_locked = False

        # De-duplicate skills case-insensitively and clean up names
        clean_profile = {}
        acronyms = {"aws", "sql", "api", "llm", "llms", "gpt", "faiss", "ci/cd", "ocr", "bgv", "id", "db", "k8s"}
        for skill_name, val in skills_profile.items():
            title_name = skill_name.strip()
            if not title_name:
                continue
            lower_name = title_name.lower()
            
            # Format nicely
            words = title_name.split()
            formatted_words = []
            for w in words:
                if w.lower() in acronyms:
                    formatted_words.append(w.upper())
                elif "-" in w: # e.g. GPT-4o
                    formatted_words.append("-".join(sub.upper() if sub.lower() in acronyms else sub.capitalize() for sub in w.split("-")))
                else:
                    formatted_words.append(w.capitalize())
            formatted_name = " ".join(formatted_words)
            
            # Check for existing case-insensitive key
            found_key = None
            for k in clean_profile.keys():
                if k.lower() == lower_name:
                    found_key = k
                    break
            
            if found_key:
                clean_profile[found_key] = max(clean_profile[found_key], int(val))
            else:
                clean_profile[formatted_name] = int(val)
        
        skills_profile = clean_profile

        if skills_locked:
            st.info("🔒 Your skills profile has been saved and locked. Modifying or adding new skills is disabled.")

            # Inject dedicated CSS for skill cards — must override dark-mode globals
            st.markdown("""<style>
.skill-card-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(210px, 1fr)); gap: 18px; margin-top: 20px; width: 100%; }
.skill-card { background: #ffffff !important; border: 1px solid #cbd5e1 !important; border-top: 4px solid #004b87 !important; border-radius: 10px !important; padding: 16px 18px !important; box-shadow: 0 2px 8px rgba(0,0,0,0.07) !important; transition: transform 0.2s ease, box-shadow 0.2s ease; }
.skill-card:hover { transform: translateY(-3px); box-shadow: 0 6px 20px rgba(0,0,0,0.14) !important; }
.skill-card-name { font-weight: 700 !important; font-size: 0.92rem !important; margin-bottom: 8px !important; color: #004b87 !important; -webkit-text-fill-color: #004b87 !important; line-height: 1.3; }
.skill-card-meta { display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; }
.skill-card-rating { font-size: 0.76rem; font-weight: 600; color: #374151 !important; -webkit-text-fill-color: #374151 !important; }
.skill-card-pct { font-size: 0.82rem; font-weight: 800; color: inherit !important; -webkit-text-fill-color: inherit !important; }
.skill-bar-track { width: 100%; height: 8px; background: #e2e8f0; border-radius: 4px; overflow: hidden; margin-top: 2px; }
.skill-bar-fill { height: 100%; border-radius: 4px; }
</style>""", unsafe_allow_html=True)

            st.markdown("### Your Rated Skills Profile")

            # Build cards — single-line concat, no !important in inline background
            cards = []
            for skill_name, val in skills_profile.items():
                pct = int(val) * 10
                if pct > 70:
                    color = "#10b981"   # green
                elif pct >= 40:
                    color = "#f59e0b"   # amber
                else:
                    color = "#ef4444"   # red
                cards.append(
                    f'<div class="skill-card">'
                    f'<div class="skill-card-name">{skill_name}</div>'
                    f'<div class="skill-card-meta">'
                    f'<span class="skill-card-rating">Rating: {val}/10</span>'
                    f'<span class="skill-card-pct" style="color:{color};-webkit-text-fill-color:{color};">{pct}%</span>'
                    f'</div>'
                    f'<div class="skill-bar-track">'
                    f'<div class="skill-bar-fill" style="width:{pct}%;background-color:{color};"></div>'
                    f'</div>'
                    f'</div>'
                )
            grid_html = '<div class="skill-card-grid">' + "".join(cards) + '</div>'
            st.markdown(grid_html, unsafe_allow_html=True)
        else:
            # Inject CSS for interactive skill rating cards
            st.markdown("""<style>
.stApp .skill-rate-card {
    background: #ffffff !important;
    border: 1px solid #cbd5e1 !important;
    border-top: 4px solid #004b87 !important;
    border-radius: 10px !important;
    padding: 14px 16px !important;
    box-shadow: 0 2px 6px rgba(0,0,0,0.05) !important;
    margin-bottom: 8px !important;
}
.stApp .skill-rate-name {
    font-weight: 700 !important;
    font-size: 0.92rem !important;
    color: #004b87 !important;
    -webkit-text-fill-color: #004b87 !important;
    margin-bottom: 6px !important;
}
.stApp .skill-rate-val {
    font-size: 0.8rem !important;
    font-weight: 600 !important;
    margin-top: 4px !important;
}
</style>""", unsafe_allow_html=True)

            st.markdown("### Update Your Skill Ratings:")
            updated_skills = {}
            skills_list = list(skills_profile.items())
            
            if not skills_list:
                st.info("💡 Your skills profile is currently empty. Add your core skills using the input below.")
            else:
                cols = st.columns(3)
                for idx, (skill_name, val) in enumerate(skills_list):
                    col = cols[idx % 3]
                    with col:
                        # Wrap slider with premium styled header and rating value badge
                        st.markdown(f'<div class="skill-rate-card"><div class="skill-rate-name">{skill_name}</div></div>', unsafe_allow_html=True)
                        
                        updated_val = st.slider(
                            f"Rating for {skill_name}", 
                            1, 10, int(val), 
                            key=f"slider_page_{skill_name}",
                            label_visibility="collapsed"
                        )
                        
                        pct = updated_val * 10
                        if pct > 70:
                            color = "#10b981"   # green
                        elif pct >= 40:
                            color = "#f59e0b"   # amber
                        else:
                            color = "#ef4444"   # red
                            
                        st.markdown(f'<div style="text-align: right; margin-top: -12px; margin-bottom: 18px; font-weight: 700; font-size: 0.82rem; color: {color} !important; -webkit-text-fill-color: {color} !important;">{updated_val}/10 ({pct}%)</div>', unsafe_allow_html=True)
                        updated_skills[skill_name] = updated_val
            
            st.markdown("<div style='margin-top: 15px;'></div>", unsafe_allow_html=True)
            
            # Add new skill input
            new_col1, new_col2 = st.columns([3, 1])
            with new_col1:
                new_skill = st.text_input("Add a new skill to your profile", placeholder="e.g. PyTorch, Kubernetes, React", key="new_skill_input_page")
            with new_col2:
                st.markdown("<div style='margin-top: 28px;'></div>", unsafe_allow_html=True)
                if st.button("➕ Add Skill", use_container_width=True, key="add_skill_btn_page"):
                    if new_skill and new_skill.strip():
                        new_skill_clean = new_skill.strip()
                        if new_skill_clean not in updated_skills:
                            updated_skills[new_skill_clean] = 5
                            # Send to backend
                            try:
                                res = requests.post(
                                    f"{BASE_URL}/training/skills/self-rate",
                                    json=updated_skills,
                                    headers={"Authorization": f"Bearer {st.session_state['auth_token']}"}
                                )
                                if res.status_code == 200:
                                    st.success(f"Added '{new_skill_clean}' with default rating of 5.")
                                    st.rerun()
                            except Exception as e:
                                st.error(f"Error: {e}")
                        else:
                            st.warning("Skill already exists in your profile.")

            st.markdown("<hr style='margin: 15px 0;'>", unsafe_allow_html=True)
            if st.button("🔒 Save & Lock Ratings", type="primary", use_container_width=True, key="save_lock_btn_page"):
                # Mark as locked
                updated_skills["_locked"] = True
                try:
                    res = requests.post(
                        f"{BASE_URL}/training/skills/self-rate",
                        json=updated_skills,
                        headers={"Authorization": f"Bearer {st.session_state['auth_token']}"}
                    )
                    if res.status_code == 200:
                        st.success("🎉 Skills self-ratings updated and locked successfully!")
                        st.rerun()
                    else:
                        st.error(f"Failed to update skills profile: {res.text}")
                except Exception as e:
                    st.error(f"Failed to connect to server: {e}")


    # PAGE: Training & Development (Locked State)
    elif selected_emp_page == "TrainingLocked":
        st.markdown("## AI-Driven Training & Development")
        st.markdown("Review your customized training plan, skill gaps, and recommended learning path.")
        
        locked_html = """
        <div class="ux-card" style="padding: 24px !important; border-left: 5px solid #ef4444 !important; background-color: #ffffff !important; border-top: 1px solid #cbd5e1 !important; border-right: 1px solid #cbd5e1 !important; border-bottom: 1px solid #cbd5e1 !important; margin-bottom: 20px !important; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05) !important;">
            <h3 style="margin-top:0 !important; color:#ef4444 !important; -webkit-text-fill-color:#ef4444 !important; font-size: 1.25rem !important; font-weight: 700 !important;">🔒 Training Path Not Generated</h3>
            <p style="margin: 8px 0 0 0 !important; color: #1f2937 !important; -webkit-text-fill-color: #1f2937 !important; font-size: 0.92rem !important; line-height: 1.5 !important;">
                Your personalized upskilling and training roadmap has not been generated by HR yet. 
                Please contact your HR Manager to initiate a **Skill Gap Analysis** and assign your target role learning path.
            </p>
        </div>
        """
        st.markdown(clean_html(locked_html), unsafe_allow_html=True)


    # PAGE: Training & Development
    elif selected_emp_page == "Training":
        st.markdown("## AI-Driven Training & Development")
        st.markdown("Review your customized training plan, skill gaps, and recommended learning path.")

        # Fetch active gap analysis/learning plan from database
        analysis_data = None
        try:
            a_res = requests.get(
                f"{BASE_URL}/training/analyses?employee_id={emp_data.get('id')}",
                headers={"Authorization": f"Bearer {st.session_state['auth_token']}"}
            )
            if a_res.status_code == 200:
                analyses = a_res.json()
                if analyses:
                    analysis_data = analyses[0]
        except Exception:
            pass

        if analysis_data:
            role_card_html = f"""
            <div class="ux-card" style="padding: 20px !important; border-left: 5px solid #004b87 !important; background-color: #ffffff !important; border-top: 1px solid #e5e7eb !important; border-right: 1px solid #e5e7eb !important; border-bottom: 1px solid #e5e7eb !important; margin-bottom: 20px !important; box-shadow: 0 1px 3px rgba(0,0,0,0.05) !important;">
                <h3 style="margin-top:0 !important; color:#004b87 !important; -webkit-text-fill-color:#004b87 !important; font-size: 1.2rem !important; font-weight: 600 !important;">🎯 Target Role: {analysis_data.get('role_title', 'Assigned target role')}</h3>
                <p style="margin: 4px 0 0 0 !important; color: #475569 !important; -webkit-text-fill-color: #475569 !important; font-size: 0.85rem !important;">Assigned by your HR Manager on {analysis_data.get('analyzed_at', '')[:10]}</p>
            </div>
            """
            st.markdown(clean_html(role_card_html), unsafe_allow_html=True)
 
            # Define tabs to separate sections
            tab_gap, tab_path, tab_courses = st.tabs([
                "🔍 Skill Gap Assessment", 
                "🗺️ AI Learning Path", 
                "🎓 Assigned & Recommended Courses"
            ])
 
            # --- SHARED CSS for Training tabs ---
            st.markdown("""<style>
.stApp .emp-gap-row { display:flex !important; align-items:center !important; justify-content:space-between !important; padding:14px 20px !important; border-bottom:1px solid #e2e8f0 !important; background:#ffffff !important; flex-wrap:wrap !important; gap:10px !important; }
.stApp .emp-gap-row:last-child { border-bottom:none !important; }
.stApp .emp-gap-skill { font-weight:700 !important; font-size:0.95rem !important; color:#0f172a !important; -webkit-text-fill-color:#0f172a !important; }
.stApp .emp-gap-meta { font-size:0.78rem !important; color:#1e293b !important; -webkit-text-fill-color:#1e293b !important; margin-top:2px !important; font-weight:500 !important; }
.stApp .emp-bar-label { font-size:0.7rem !important; font-weight:700 !important; color:#1e293b !important; -webkit-text-fill-color:#1e293b !important; min-width:50px !important; }
.stApp .emp-phase-card { border-radius:10px !important; padding:16px 20px !important; margin-bottom:14px !important; border:1px solid #e5e7eb !important; box-shadow:0 1px 3px rgba(0,0,0,0.05) !important; }
.stApp .emp-phase-header { display:flex !important; justify-content:space-between !important; align-items:center !important; margin-bottom:8px !important; flex-wrap:wrap !important; gap:6px !important; }
.stApp .emp-phase-badge { font-size:0.7rem !important; font-weight:800 !important; padding:2px 8px !important; border-radius:6px !important; }
.stApp .emp-phase-title { font-weight:700 !important; font-size:0.92rem !important; color:#002a54 !important; -webkit-text-fill-color:#002a54 !important; }
.stApp .emp-phase-duration { font-size:0.72rem !important; color:#374151 !important; -webkit-text-fill-color:#374151 !important; background:rgba(99,102,241,0.07) !important; padding:2px 8px !important; border-radius:6px !important; }
.stApp .emp-phase-desc { font-size:0.82rem !important; color:#374151 !important; -webkit-text-fill-color:#374151 !important; line-height:1.5 !important; margin-bottom:8px !important; }
.stApp .emp-skill-pill { display:inline-block !important; padding:3px 10px !important; border-radius:12px !important; font-size:0.72rem !important; font-weight:500 !important; margin:2px !important; }
.stApp .emp-stat-card { text-align:center !important; padding:14px 10px !important; background:#ffffff !important; border:1px solid #cbd5e1 !important; border-radius:10px !important; box-shadow:0 1px 3px rgba(0,0,0,0.05) !important; }
.stApp .emp-stat-val { font-size:1.2rem !important; font-weight:800 !important; color:#002a54 !important; -webkit-text-fill-color:#002a54 !important; }
.stApp .emp-stat-lbl { font-size:0.7rem !important; color:#1e293b !important; -webkit-text-fill-color:#1e293b !important; text-transform:uppercase !important; letter-spacing:0.05em !important; margin-top:4px !important; font-weight:600 !important; }
.stApp .emp-gap-badge { display:inline-block !important; padding:3px 10px !important; border-radius:20px !important; font-size:0.72rem !important; font-weight:700 !important; color: inherit !important; -webkit-text-fill-color: inherit !important; }
.stApp .emp-readiness-card { background:#ffffff !important; border:1px solid #cbd5e1 !important; border-radius:10px !important; padding:15px !important; box-shadow:0 1px 3px rgba(0,0,0,0.05) !important; }
.stApp .emp-escalabel { font-size:0.75rem !important; color:#1e293b !important; -webkit-text-fill-color:#1e293b !important; font-weight:600 !important; text-transform:uppercase !important; }
.stApp .emp-escalevel { font-size:1.8rem !important; font-weight:800 !important; color:#002a54 !important; -webkit-text-fill-color:#002a54 !important; margin:6px 0 !important; }
.stApp .emp-escasubtitle { font-size:0.75rem !important; color:#1e293b !important; -webkit-text-fill-color:#1e293b !important; font-weight:600 !important; }
.stApp .emp-rec-item { font-size:0.84rem !important; color:#374151 !important; -webkit-text-fill-color:#374151 !important; padding:6px 0 !important; border-bottom:1px solid #f1f5f9 !important; }
.stApp .emp-readiness-val { color: inherit !important; -webkit-text-fill-color: inherit !important; }
.stApp .emp-readiness-sub { color: #1e293b !important; -webkit-text-fill-color: #1e293b !important; }

/* Fallback rating circles override */
.rating-circle-green {
    display: inline-block !important;
    width: 10px !important;
    height: 10px !important;
    border-radius: 50% !important;
    background-color: #10b981 !important;
    margin-right: 4px !important;
    vertical-align: middle !important;
}
.rating-circle-red {
    display: inline-block !important;
    width: 10px !important;
    height: 10px !important;
    border-radius: 50% !important;
    background-color: #ef4444 !important;
    margin-right: 4px !important;
    vertical-align: middle !important;
}

/* Custom badge and pill tags */
phasebadge {
    display: inline-block !important;
    font-size: 0.7rem !important;
    font-weight: 800 !important;
    padding: 2px 8px !important;
    border-radius: 6px !important;
    margin-bottom: 2px !important;
    vertical-align: middle !important;
}
skillpill {
    display: inline-block !important;
    padding: 3px 10px !important;
    border-radius: 12px !important;
    font-size: 0.72rem !important;
    font-weight: 500 !important;
    margin: 2px !important;
    vertical-align: middle !important;
}
gapbadge {
    display: inline-block !important;
    padding: 3px 10px !important;
    border-radius: 20px !important;
    font-size: 0.72rem !important;
    font-weight: 700 !important;
    vertical-align: middle !important;
}
</style>""", unsafe_allow_html=True)

            # --- TAB 1: Skill Gap Assessment ---
            with tab_gap:
                st.markdown("<br>", unsafe_allow_html=True)
                readiness_pct = analysis_data.get('readiness_score', 0.0)
                
                col_scale1, col_scale2 = st.columns([1, 2])
                with col_scale1:
                    st.markdown(
                        f'<div class="emp-readiness-card" style="text-align:center;height:110px;">'
                        f'<div class="emp-escalabel">E-Scale Level</div>'
                        f'<div class="emp-escalevel">E2</div>'
                        f'<div class="emp-escasubtitle">Systems Engineer</div>'
                        f'</div>', unsafe_allow_html=True)
                with col_scale2:
                    bar_w = min(readiness_pct, 100)
                    r_color = "#10b981" if readiness_pct >= 70 else ("#f59e0b" if readiness_pct >= 40 else "#ef4444")
                    st.markdown(
                        f'<div class="emp-readiness-card" style="height:110px;">'
                        f'<div class="emp-escalabel">Readiness Index</div>'
                        f'<div style="display:flex;align-items:center;gap:12px;margin:8px 0;">'
                        f'<div class="emp-readiness-val" style="font-size:1.6rem;font-weight:800;color:{r_color} !important;-webkit-text-fill-color:{r_color} !important;">{readiness_pct:.1f}%</div>'
                        f'<div style="flex-grow:1;background:#e2e8f0;height:10px;border-radius:5px;overflow:hidden;">'
                        f'<div style="width:{bar_w}%;background:{r_color};height:100%;border-radius:5px;"></div></div></div>'
                        f'<div class="emp-readiness-sub" style="font-size:0.75rem;color:#475569 !important;-webkit-text-fill-color:#475569 !important;">Based on your self-rated skills vs role requirements.</div>'
                        f'</div>', unsafe_allow_html=True)

                st.markdown("<br>", unsafe_allow_html=True)
                st.markdown("### 🔍 Skill Gap Assessment")
                
                gaps_list = analysis_data.get('skill_gaps', [])
                if not gaps_list:
                    st.success("🎉 You meet or exceed all skill requirements for this role!")
                else:
                    PRIORITY_COLOR = {"Critical": "#ef4444", "High": "#f59e0b", "Medium": "#3b82f6", "Low": "#10b981"}
                    PRIORITY_BG    = {"Critical": "#fef2f2", "High": "#fffbeb", "Medium": "#eff6ff", "Low": "#f0fdf4"}
                    rows = []
                    for gap in gaps_list:
                        sn  = gap.get("skill_name", gap.get("skill", ""))
                        req = gap.get("required_level", gap.get("required", 0))
                        curr= gap.get("current_level", gap.get("current", 0))
                        diff= gap.get("gap", max(0, req - curr))
                        pri = gap.get("priority", "Medium")
                        pc  = PRIORITY_COLOR.get(pri, "#3b82f6")
                        pb  = PRIORITY_BG.get(pri, "#eff6ff")
                        curr_pct = min(int(curr) * 10, 100) if int(curr) <= 10 else min(int(curr), 100)
                        req_pct  = min(int(req)  * 10, 100) if int(req)  <= 10 else min(int(req),  100)
                        badge = (f'<gapbadge class="emp-gap-badge" style="background:{pb};color:{pc};border:1px solid {pc}55;">-{diff} Gap · {pri}</gapbadge>'
                                 if diff > 0 else
                                 '<gapbadge class="emp-gap-badge" style="background:#f0fdf4;color:#10b981;border:1px solid #10b98155;">✓ Aligned</gapbadge>')
                        rows.append(
                            f'<div class="emp-gap-row">'
                            f'<div style="flex:2;min-width:160px;">'
                            f'<div class="emp-gap-skill">{sn}</div>'
                            f'<div class="emp-gap-meta">Required: {req} &nbsp;·&nbsp; Current: {curr}</div>'
                            f'<div style="margin-top:8px;display:flex;align-items:center;gap:8px;">'
                            f'<span class="emp-bar-label">Current</span>'
                            f'<div style="flex:1;height:6px;background:#e2e8f0;border-radius:3px;overflow:hidden;">'
                            f'<div style="width:{curr_pct}%;height:100%;background-color:#6366f1;border-radius:3px;"></div></div>'
                            f'<span style="font-size:0.75rem;font-weight:700;color:#1e293b !important;-webkit-text-fill-color:#1e293b !important;min-width:18px;text-align:right;">{curr}</span></div>'
                            f'<div style="display:flex;align-items:center;gap:8px;margin-top:4px;">'
                            f'<span class="emp-bar-label">Required</span>'
                            f'<div style="flex:1;height:6px;background:#e2e8f0;border-radius:3px;overflow:hidden;">'
                            f'<div style="width:{req_pct}%;height:100%;background-color:{pc};border-radius:3px;"></div></div>'
                            f'<span style="font-size:0.75rem;font-weight:700;color:#1e293b !important;-webkit-text-fill-color:#1e293b !important;min-width:18px;text-align:right;">{req}</span></div>'
                            f'</div>'
                            f'<div style="flex:0 0 auto;padding-left:12px;">{badge}</div>'
                            f'</div>'
                        )
                    st.markdown(
                        '<div style="border:1px solid #cbd5e1;border-radius:10px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,0.05);">'
                        + "".join(rows) + "</div>",
                        unsafe_allow_html=True)
 
            # --- TAB 2: AI Learning Path ---
            with tab_path:
                st.markdown("<br>", unsafe_allow_html=True)
                st.markdown("### 🗺️ AI-Generated Training Roadmap")
                
                ai_path = analysis_data.get('ai_learning_path')
                if ai_path:
                    if isinstance(ai_path, str):
                        with st.expander("🤖 AI-Generated Training Roadmap", expanded=True):
                            st.markdown(ai_path)
                    elif isinstance(ai_path, dict):
                        phases = ai_path.get("phases", ai_path.get("learning_phases", []))
                        weekly  = ai_path.get("weekly_schedule", "")
                        t_hours = ai_path.get("total_hours", "")
                        est_wks = ai_path.get("estimated_weeks", "")
                        recommendations = ai_path.get("recommendations", ai_path.get("ai_recommendations", []))
                        
                        # Summary stat cards
                        cols = st.columns(3)
                        for col, (icon, val, lbl) in zip(cols, [
                            ("📅", weekly  or "—", "Weekly Schedule"),
                            ("⏰", str(t_hours) if t_hours else "—", "Total Hours"),
                            ("📆", str(est_wks) if est_wks else "—", "Est. Weeks"),
                        ]):
                            with col:
                                st.markdown(
                                    f'<div class="emp-stat-card">'
                                    f'<div style="font-size:1.4rem;margin-bottom:4px;">{icon}</div>'
                                    f'<div class="emp-stat-val">{val}</div>'
                                    f'<div class="emp-stat-lbl">{lbl}</div>'
                                    f'</div>', unsafe_allow_html=True)
                        
                        st.markdown("<br>", unsafe_allow_html=True)
                        
                        # Create course URL map
                        course_url_map = {c.get("course_title",""): c.get("url","") for c in analysis_data.get('recommended_courses', [])}
                        
                        # Timeline Phases
                        if phases:
                            PHASE_COLORS = ["#6366f1","#8b5cf6","#06b6d4","#10b981","#f59e0b","#ec4899"]
                            PHASE_BGS    = ["rgba(99,102,241,0.06)","rgba(139,92,246,0.06)","rgba(6,182,212,0.06)","rgba(16,185,129,0.06)","rgba(245,158,11,0.06)","rgba(236,72,153,0.06)"]
                            phase_cards = []
                            for i, phase in enumerate(phases):
                                pnum   = phase.get("phase", phase.get("phase_number", i+1))
                                ptitle = phase.get("title", phase.get("phase_title", f"Phase {pnum}"))
                                pdesc  = phase.get("description", "")
                                pskills= phase.get("skills", phase.get("skills_covered", []))
                                pcourses=phase.get("courses", phase.get("course_names", []))
                                pdur   = phase.get("duration", phase.get("duration_weeks", ""))
                                ac     = PHASE_COLORS[i % len(PHASE_COLORS)]
                                abg    = PHASE_BGS[i % len(PHASE_BGS)]
                                
                                dur_html    = f'<span class="emp-phase-duration">⏱ {pdur} weeks</span>' if pdur else ""
                                desc_html   = f'<div class="emp-phase-desc">{pdesc}</div>' if pdesc else ""
                                
                                pills = "".join(
                                    f'<skillpill class="emp-skill-pill" style="background:rgba(99,102,241,0.08);color:{ac};-webkit-text-fill-color:{ac};border:1px solid rgba(99,102,241,0.15);">{s}</skillpill>'
                                    for s in (pskills if isinstance(pskills, list) else [])
                                )
                                skills_section = f'<div style="margin-bottom:6px;">{pills}</div>' if pills else ""
                                
                                clinks = ""
                                for c in (pcourses if isinstance(pcourses, list) else []):
                                    curl = course_url_map.get(c, "")
                                    if curl:
                                        clinks += (f'<div style="font-size:0.82rem;margin-top:4px;color:#1f2937 !important;-webkit-text-fill-color:#1f2937 !important;">'
                                                   f'<span style="color:{ac} !important;-webkit-text-fill-color:{ac} !important;margin-right:6px;">▸</span>'
                                                   f'<a href="{curl}" target="_blank" style="color:#004b87 !important;-webkit-text-fill-color:#004b87 !important;font-weight:600;text-decoration:none;">{c} ↗</a></div>')
                                    else:
                                        clinks += (f'<div style="font-size:0.82rem;margin-top:4px;color:#374151 !important;-webkit-text-fill-color:#374151 !important;">'
                                                   f'<span style="color:{ac} !important;-webkit-text-fill-color:{ac} !important;margin-right:6px;">▸</span>{c}</div>')
                                courses_section = f'<div style="margin-top:6px;padding-top:6px;border-top:1px solid rgba(0,0,0,0.05);">{clinks}</div>' if clinks else ""
                                
                                phase_cards.append(
                                    f'<div class="emp-phase-card" style="border-left:4px solid {ac};background:{abg};">'
                                    f'<div class="emp-phase-header">'
                                    f'<div style="display:flex;align-items:center;gap:8px;">'
                                    f'<phasebadge class="emp-phase-badge" style="color:{ac};background:{ac}18;border:1px solid {ac}33;">PHASE {pnum}</phasebadge>'
                                    f'<span class="emp-phase-title">{ptitle}</span>'
                                    f'</div>{dur_html}</div>'
                                    f'{desc_html}{skills_section}{courses_section}'
                                    f'</div>'
                                )
                            st.markdown("".join(phase_cards), unsafe_allow_html=True)
                        
                        # Recommendations
                        if recommendations:
                            st.markdown("##### 💡 AI Recommendations")
                            rec_items = "".join(
                                f'<div class="emp-rec-item"><span style="color:#6366f1;margin-right:8px;">◆</span>{r}</div>'
                                for r in recommendations if isinstance(r, str)
                            )
                            st.markdown(
                                f'<div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:16px 20px;">{rec_items}</div>',
                                unsafe_allow_html=True)
                else:
                    st.info("No AI roadmap generated yet. Ask your HR Manager to generate a personalized learning plan.")
 
            # --- TAB 3: Assigned & Recommended Courses ---
            with tab_courses:
                st.markdown("<br>", unsafe_allow_html=True)
                st.markdown("### 🎓 Assigned & Recommended Courses")
                
                recommended_courses = analysis_data.get('recommended_courses', [])
                if not recommended_courses:
                    st.info("No courses have been recommended or assigned yet.")
                else:
                    for idx, course in enumerate(recommended_courses):
                        title  = course.get("course_title", "")
                        desc   = course.get("description", "")
                        url    = course.get("url", "#")
                        status = course.get("status", "Recommended")
                        
                        c_col1, c_col2, c_col3 = st.columns([3, 1, 1])
                        with c_col1:
                            st.markdown(f"**{idx+1}. {title}**")
                            st.markdown(f'<span style="font-size:0.78rem;color:#4b5563 !important;-webkit-text-fill-color:#4b5563 !important;">{desc}</span>', unsafe_allow_html=True)
                        with c_col2:
                            if status == "Completed":
                                st.markdown("<span class='badge-ux badge-ux-green'>Completed</span>", unsafe_allow_html=True)
                            elif status == "In Progress":
                                st.markdown("<span class='badge-ux badge-ux-blue'>In Progress</span>", unsafe_allow_html=True)
                            elif status == "Assigned":
                                st.markdown("<span class='badge-ux badge-ux-yellow'>Assigned</span>", unsafe_allow_html=True)
                            else:
                                st.markdown("<span class='badge-ux badge-ux-blue'>Recommended</span>", unsafe_allow_html=True)
                        with c_col3:
                            st.link_button("Launch 🚀", url, use_container_width=True, key=f"launch_link_{idx}")
                        st.markdown("<hr style='margin:10px 0;border:0;border-top:1px solid #e5e7eb;'>", unsafe_allow_html=True)
 
        else:
            # Fallback mockup with target alignment selectbox so the employee can preview alignment
            fallback_html = """
            <div class="ux-card" style="padding: 20px !important; border-left: 5px solid #004b87 !important; background-color: #ffffff !important; border-top: 1px solid #e5e7eb !important; border-right: 1px solid #e5e7eb !important; border-bottom: 1px solid #e5e7eb !important; margin-bottom: 20px !important; box-shadow: 0 1px 3px rgba(0,0,0,0.05) !important;">
                <h3 style="margin-top:0 !important; color:#002a54 !important; -webkit-text-fill-color:#002a54 !important; font-size: 1.15rem !important; font-weight: 600 !important;">🎯 Alignment Preview</h3>
                <p style="margin: 0 !important; color: #475569 !important; -webkit-text-fill-color: #475569 !important; font-size: 0.85rem !important;">Your HR Manager has not assigned a target learning plan for you yet. In the meantime, you can select a target role below to preview your skill readiness index based on your self-ratings.</p>
            </div>
            """
            st.markdown(clean_html(fallback_html), unsafe_allow_html=True)
            
            st.markdown("<div style='margin-top: 15px;'></div>", unsafe_allow_html=True)
            
            role_opts = ["Senior Python Backend Engineer", "Solutions Architect", "AI/ML Tech Lead", "Full-Stack Engineer"]
            
            if "emp_target_role" not in st.session_state:
                st.session_state["emp_target_role"] = role_opts[0]
            
            curr_role_idx = role_opts.index(st.session_state["emp_target_role"]) if st.session_state["emp_target_role"] in role_opts else 0
            
            target_role = st.selectbox("Preview Target Role Alignment", role_opts, index=curr_role_idx)
            if target_role != st.session_state["emp_target_role"]:
                st.session_state["emp_target_role"] = target_role
                st.rerun()
                
            readiness_map = {
                "Senior Python Backend Engineer": ("E2 (Systems Engineer)", 85.5, ["Python", "FastAPI", "PostgreSQL"]),
                "Solutions Architect": ("E3 (Associate Consultant)", 62.0, ["AWS Architecture", "Kubernetes", "System Design"]),
                "AI/ML Tech Lead": ("E3 (Associate Consultant)", 55.0, ["PyTorch", "LLM Fine-tuning", "Vector DBs"]),
                "Full-Stack Engineer": ("E1 (Assistant Systems Engineer)", 90.0, ["React", "JavaScript", "REST APIs"])
            }
            
            e_scale, readiness_pct, preview_skills = readiness_map.get(target_role, ("E1", 70.0, []))
            
            col_scale1, col_scale2 = st.columns([1, 2])
            with col_scale1:
                card1_html = f"""
                <div style="background-color:#ffffff !important; border:1px solid #cbd5e1 !important; border-radius:10px !important; padding:15px !important; text-align:center !important; height: 110px !important; box-shadow: 0 1px 3px rgba(0,0,0,0.05) !important;">
                    <span style="font-size:0.75rem !important; color:#475569 !important; -webkit-text-fill-color:#475569 !important; font-weight:600 !important; text-transform:uppercase !important;">E-Scale Rating</span>
                    <div style="font-size:1.8rem !important; font-weight:800 !important; color:#002a54 !important; -webkit-text-fill-color:#002a54 !important; margin:6px 0 !important;">{e_scale.split(' ')[0]}</div>
                    <span style="font-size:0.75rem !important; color:#1e293b !important; -webkit-text-fill-color:#1e293b !important; font-weight:600 !important;">{e_scale.split(' ')[1] if len(e_scale.split(' ')) > 1 else ''}</span>
                </div>
                """
                st.markdown(clean_html(card1_html), unsafe_allow_html=True)
            with col_scale2:
                card2_html = f"""
                <div style="background-color:#ffffff !important; border:1px solid #cbd5e1 !important; border-radius:10px !important; padding:15px !important; height: 110px !important; box-shadow: 0 1px 3px rgba(0,0,0,0.05) !important;">
                    <span style="font-size:0.75rem !important; color:#475569 !important; -webkit-text-fill-color:#475569 !important; font-weight:600 !important; text-transform:uppercase !important;">Readiness Index</span>
                    <div style="display:flex !important; align-items:center !important; gap:12px !important; margin: 8px 0 !important;">
                        <div class="emp-readiness-val" style="font-size: 1.6rem !important; font-weight:800 !important; color:#004b87 !important; -webkit-text-fill-color:#004b87 !important;">{readiness_pct}%</div>
                        <div style="flex-grow:1 !important; background-color:#e2e8f0 !important; height:10px !important; border-radius:5px !important; overflow:hidden !important; position:relative !important;">
                            <div style="width:{readiness_pct}% !important; background-color:#004b87 !important; height:100% !important; border-radius:5px !important;"></div>
                        </div>
                    </div>
                    <span class="emp-readiness-sub" style="font-size:0.75rem !important; color:#475569 !important; -webkit-text-fill-color:#475569 !important;">Preview based on standard mock profiles.</span>
                </div>
                """
                st.markdown(clean_html(card2_html), unsafe_allow_html=True)
                
            st.markdown("<br>", unsafe_allow_html=True)
            st.markdown("### Skill Gap Assessment (Preview)")
            
            # Define tabs for fallback
            tab_gap, tab_path, tab_courses = st.tabs([
                "🔍 Skill Gap Assessment (Preview)", 
                "🗺️ AI Learning Path (Preview)", 
                "🎓 Assigned & Recommended Courses (Preview)"
            ])

            # --- TAB 1: Skill Gap Assessment (Preview) ---
            with tab_gap:
                st.markdown("<br>", unsafe_allow_html=True)
                skill_gaps = {
                    "Senior Python Backend Engineer": [("Python / OOP", 5, 5), ("FastAPI APIs", 5, 4), ("PostgreSQL Databases", 4, 3), ("AWS Cloud", 4, 2), ("Docker & K8s", 3, 2)],
                    "Solutions Architect": [("System Design", 5, 3), ("AWS Cloud", 5, 2), ("Kubernetes", 4, 2), ("Enterprise Security", 4, 2), ("Microservices", 5, 4)],
                    "AI/ML Tech Lead": [("LLM Engineering", 5, 1), ("PyTorch / ML Libs", 5, 2), ("Vector Databases", 4, 1), ("Python Backend", 4, 4), ("Model Deployment", 4, 1)],
                    "Full-Stack Engineer": [("React Frontend", 5, 4), ("JavaScript/TS", 5, 5), ("CSS/Tailwind", 4, 4), ("REST APIs", 4, 4), ("Testing Frameworks", 3, 2)]
                }
                
                gaps_list = skill_gaps.get(target_role, [])
                gaps_html = "<div class='skill-gap-list-container' style='border: 1px solid #cbd5e1 !important; border-radius: 10px !important; overflow: hidden !important; box-shadow: 0 1px 3px rgba(0,0,0,0.05) !important; width: 100% !important;'>"
                for skill_name, req, curr in gaps_list:
                    diff = max(0, req - curr)
                    circle_html = ""
                    for i in range(1, req + 1):
                        c_class = 'rating-circle-green' if i <= curr else 'rating-circle-red'
                        circle_html += f'<span class="{c_class}">&#8203;</span>'
                    circle_html += f' &nbsp;<span style="font-size: 0.8rem !important; font-weight: 600 !important; color: #475569 !important; -webkit-text-fill-color: #475569 !important;">({curr} of {req})</span>'
                    
                    if diff > 0:
                        badge_html = f"<span class='badge-ux badge-ux-yellow' style='font-size: 0.72rem !important; font-weight: 600 !important;'>-{diff} Gap</span>"
                    else:
                        badge_html = "<span class='badge-ux badge-ux-green' style='font-size: 0.72rem !important; font-weight: 600 !important;'>Aligned</span>"
                    
                    gaps_html += f'''
                    <div style="display: flex !important; align-items: center !important; justify-content: space-between !important; padding: 14px 20px !important; border-bottom: 1px solid #e2e8f0 !important; background: #ffffff !important; flex-wrap: wrap !important; gap: 10px !important;">
                        <div style="flex: 2 !important; min-width: 180px !important;">
                            <div style="font-weight: 700 !important; font-size: 0.95rem !important; color: #0f172a !important; -webkit-text-fill-color: #0f172a !important;">{skill_name}</div>
                            <div style="font-size: 0.78rem !important; color: #475569 !important; -webkit-text-fill-color: #475569 !important; margin-top: 2px !important;">Required: {req} &bull; Current: {curr}</div>
                        </div>
                        <div style="flex: 3 !important; display: flex !important; align-items: center !important; justify-content: flex-start !important; min-width: 150px !important;">
                            <div style="display: flex !important; align-items: center !important;">{circle_html}</div>
                        </div>
                        <div style="flex: 1 !important; text-align: right !important; min-width: 110px !important;">
                            {badge_html}
                        </div>
                    </div>
                    '''
                gaps_html += "</div>"
                st.markdown(clean_html(gaps_html), unsafe_allow_html=True)

            # --- TAB 2: AI Learning Path (Preview) ---
            with tab_path:
                st.markdown("<br>", unsafe_allow_html=True)
                st.markdown("### AI-Generated Training Roadmap (Preview)")
                
                # Mock a dictionary training path for preview target role
                mock_ai_paths = {
                    "Senior Python Backend Engineer": {
                        "phases": [
                            {"phase_number": 1, "title": "AWS Cloud Integration", "description": "Focus on deploying FastAPI services to AWS, utilizing AWS Bedrock, IAM, and ECS.", "skills": ["AWS Cloud"], "courses": ["Ultimate AWS Certified Developer Associate"], "duration_weeks": 4},
                            {"phase_number": 2, "title": "Advanced Databases & Containers", "description": "Bridge gaps in Docker, Kubernetes, and deep database design in PostgreSQL.", "skills": ["PostgreSQL Databases", "Docker & K8s"], "courses": ["Docker & Kubernetes Mastery", "Database Optimization Deep-dive"], "duration_weeks": 4}
                        ],
                        "weekly_schedule": "6-8 hours",
                        "total_hours": 60,
                        "estimated_weeks": 8,
                        "recommendations": ["Spin up a local Kubernetes cluster using minikube.", "Implement advanced window queries in PostgreSQL."]
                    },
                    "Solutions Architect": {
                        "phases": [
                            {"phase_number": 1, "title": "Enterprise Cloud Architecture", "description": "Learn complex multi-tier cloud deployments, microservices design, and network security.", "skills": ["System Design", "AWS Cloud"], "courses": ["AWS Certified Solutions Architect Professional"], "duration_weeks": 6},
                            {"phase_number": 2, "title": "Container Management & DevSecOps", "description": "Master orchestrators and automated secure CI/CD configurations.", "skills": ["Kubernetes", "Enterprise Security"], "courses": ["Certified Kubernetes Administrator (CKA)"], "duration_weeks": 6}
                        ],
                        "weekly_schedule": "8-10 hours",
                        "total_hours": 100,
                        "estimated_weeks": 12,
                        "recommendations": ["Draw microservice templates in Draw.io.", "Setup secure Cognito configurations."]
                    }
                }
                
                ai_path = mock_ai_paths.get(target_role, mock_ai_paths["Senior Python Backend Engineer"])
                
                # Render using the beautiful structured timeline
                phases = ai_path.get("phases", [])
                summary = {
                    "weekly_schedule": ai_path.get("weekly_schedule", ""),
                    "total_hours": ai_path.get("total_hours", ""),
                    "estimated_weeks": ai_path.get("estimated_weeks", ""),
                }
                recommendations = ai_path.get("recommendations", [])
                
                # Summary Cards
                cols = st.columns(3)
                summary_items = [
                    ("📅", summary.get("weekly_schedule") or "—", "Weekly Schedule"),
                    ("⏰", str(summary.get("total_hours")) if summary.get("total_hours") else "—", "Total Hours"),
                    ("📆", str(summary.get("estimated_weeks")) if summary.get("estimated_weeks") else "—", "Est. Weeks"),
                ]
                for col, (icon, val, label) in zip(cols, summary_items):
                    with col:
                        stat_card_html = f'''
                        <div class="summary-stat" style="text-align: center !important; padding: 12px 8px !important; background: #ffffff !important; border: 1px solid #cbd5e1 !important; border-radius: 10px !important; box-shadow: 0 1px 3px rgba(0,0,0,0.05) !important;">
                            <div style="font-size: 1.5rem !important; margin-bottom: 4px !important;">{icon}</div>
                            <div style="font-family: 'JetBrains Mono', monospace !important; font-size: 1.15rem !important; font-weight: 700 !important; color: #002a54 !important; -webkit-text-fill-color: #002a54 !important;">{val}</div>
                            <div class="summary-stat-label" style="font-size: 0.72rem !important; color: #475569 !important; -webkit-text-fill-color: #475569 !important; text-transform: uppercase !important; letter-spacing: 0.05em !important; margin-top: 4px !important; font-weight: 600 !important;">{label}</div>
                        </div>
                        '''
                        st.markdown(clean_html(stat_card_html), unsafe_allow_html=True)
                
                st.markdown("<br>", unsafe_allow_html=True)
                
                if phases:
                    timeline_html = '<div class="phase-timeline" style="position: relative !important; padding-left: 32px !important; margin-top: 15px !important; width: 100% !important;">'
                    phase_colors = [("#6366f1", "rgba(99,102,241,0.04)"), ("#8b5cf6", "rgba(139,92,246,0.04)"), ("#06b6d4", "rgba(6,182,212,0.04)"), ("#10b981", "rgba(16,185,129,0.04)")]
                    for i, phase in enumerate(phases):
                        phase_num = phase.get("phase", phase.get("phase_number", i + 1))
                        phase_title = phase.get("title", phase.get("phase_title", f"Phase {phase_num}"))
                        phase_desc = phase.get("description", "")
                        phase_skills = phase.get("skills", [])
                        phase_courses = phase.get("courses", [])
                        duration = phase.get("duration_weeks", "")
                        accent, accent_bg = phase_colors[i % len(phase_colors)]
                        
                        skills_html = ""
                        for s in phase_skills:
                            skills_html += f'<skillpill style="background: rgba(99,102,241,0.08) !important; color: {accent} !important; -webkit-text-fill-color: {accent} !important; border: 1px solid rgba(99,102,241,0.15) !important;">{s}</skillpill>'
                            
                        courses_html = ""
                        for c in phase_courses:
                            courses_html += f'<div style="font-size: 0.82rem !important; margin-top: 4px !important; color: #1f2937 !important; -webkit-text-fill-color: #1f2937 !important;"><span style="color: {accent} !important; -webkit-text-fill-color: {accent} !important; margin-right: 6px !important;">▸</span><a href="https://www.udemy.com" target="_blank" style="color:#004b87 !important; -webkit-text-fill-color:#004b87 !important; font-weight:600 !important; text-decoration:none !important;">{c} ↗</a></div>'
                                
                        timeline_html += f'''
                        <div class="phase-node" style="position: relative !important; margin-bottom: 18px !important;">
                            <div class="training-phase-card" style="border-left: 4px solid {accent} !important; border-top: 1px solid #e5e7eb !important; border-right: 1px solid #e5e7eb !important; border-bottom: 1px solid #e5e7eb !important; background: {accent_bg} !important; border-radius: 10px !important; padding: 16px 20px !important; box-shadow: 0 1px 3px rgba(0,0,0,0.05) !important;">
                                <div style="display: flex !important; justify-content: space-between !important; align-items: center !important; margin-bottom: 8px !important;">
                                    <div style="display: flex !important; align-items: center !important; gap: 8px !important;">
                                        <phasebadge style="font-family: 'JetBrains Mono', monospace !important; color: {accent} !important; -webkit-text-fill-color: {accent} !important; background: {accent}18 !important; border: 1px solid {accent}33 !important;">PHASE {phase_num}</phasebadge>
                                        <span style="color: #002a54 !important; -webkit-text-fill-color: #002a54 !important; font-weight: 700 !important; font-size: 0.92rem !important;">{phase_title}</span>
                                    </div>
                                    {{f'<span style="font-size: 0.72rem !important; color: #1f2937 !important; -webkit-text-fill-color: #1f2937 !important; background: rgba(99,102,241,0.06) !important; padding: 2px 8px !important; border-radius: 6px !important;">⏱ {{duration}} weeks</span>' if duration else ''}}
                                </div>
                                {{f'<div style="color: #1f2937 !important; -webkit-text-fill-color: #1f2937 !important; font-size: 0.82rem !important; line-height: 1.5 !important; margin-bottom: 8px !important;">{{phase_desc}}</div>' if phase_desc else ''}}
                                {{f'<div style="margin-bottom: 6px !important;">{{skills_html}}</div>' if skills_html else ''}}
                                {{f'<div style="margin-top: 6px !important; padding-top: 6px !important; border-top: 1px solid rgba(0,0,0,0.05) !important;">{{courses_html}}</div>' if courses_html else ''}}
                            </div>
                        </div>
                        '''
                    timeline_html += '</div>'
                    st.markdown(clean_html(timeline_html), unsafe_allow_html=True)

                if recommendations:
                    st.markdown("<br>", unsafe_allow_html=True)
                    st.markdown("##### 💡 AI Recommendations")
                    rec_html = '<ul style="margin: 4px 0 0 16px !important; padding: 0 !important; font-size: 0.82rem !important; color: #4b5563 !important; -webkit-text-fill-color: #4b5563 !important; line-height: 1.5 !important;">'
                    for rec in recommendations:
                        rec_html += f'<li style="margin-bottom: 6px !important;">{rec}</li>'
                    rec_html += '</ul>'
                    st.markdown(clean_html(rec_html), unsafe_allow_html=True)

            # --- TAB 3: Assigned & Recommended Courses (Preview) ---
            with tab_courses:
                st.markdown("<br>", unsafe_allow_html=True)
                st.markdown("### Preview Assigned & Recommended Courses")
                
                # Mock courses
                mock_courses = [
                    {"title": "Ultimate AWS Certified Developer Associate", "desc": "Prepares you for the Developer Associate exam and AWS SDK integration.", "url": "https://www.udemy.com"},
                    {"title": "Docker & Kubernetes Mastery", "desc": "Containerize services and deploy orchestrators locally and in production.", "url": "https://www.udemy.com"}
                ]
                for idx, c in enumerate(mock_courses):
                    c_col1, c_col2, c_col3 = st.columns([3, 1, 1])
                    with c_col1:
                        st.markdown(f"**{idx+1}. {c['title']}**")
                        st.markdown(f"<span style='font-size:0.78rem !important; color:#4b5563 !important; -webkit-text-fill-color:#4b5563 !important;'>{c['desc']}</span>", unsafe_allow_html=True)
                    with c_col2:
                        st.markdown("<span class='badge-ux badge-ux-blue'>Recommended</span>", unsafe_allow_html=True)
                    with c_col3:
                        st.link_button("Launch 🚀", c['url'], use_container_width=True, key=f"preview_launch_link_{idx}")
                    st.markdown("<hr style='margin:10px 0; border:0; border-top:1px solid #e5e7eb;'>", unsafe_allow_html=True)

    # PAGE: Chatbot
    elif selected_emp_page == "Chatbot":
        HR_BASE = f"{BASE_URL}/hr"
        _auth = {"Authorization": f"Bearer {st.session_state['auth_token']}"}

        # Premium CSS
        st.markdown("""
        <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
        .hrc-wrap { font-family: 'Inter', sans-serif; }
        .hrc-welcome { text-align:center; padding:36px 24px 20px; animation:hrc-fadein .5s ease; }
        .hrc-robot-icon { font-size:3.6rem; display:inline-block; animation:hrc-bounce 2.4s infinite ease-in-out; }
        @keyframes hrc-bounce { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-8px)} }
        @keyframes hrc-fadein { from{opacity:0;transform:translateY(12px)} to{opacity:1;transform:none} }
        .hrc-welcome-title { font-size:1.25rem; font-weight:700; color:#0f0f1a; margin:14px 0 6px; }
        .hrc-welcome-sub { font-size:0.84rem; color:#5e5e72; line-height:1.65; max-width:440px; margin:0 auto 28px; }
        .hrc-card { background:#fff; border:1.5px solid #e4e4f0; border-radius:14px; padding:14px 16px;
                    cursor:pointer; transition:all .2s ease; margin-bottom:12px; }
        .hrc-card:hover { border-color:#6366f1; box-shadow:0 4px 18px rgba(99,102,241,.13); transform:translateY(-2px); }
        .hrc-card-title { font-size:0.84rem; font-weight:700; color:#1a1a2e; margin-bottom:4px; }
        .hrc-card-sub   { font-size:0.77rem; color:#7070a0; }
        .hrc-user-bubble { background:linear-gradient(135deg,#4f46e5 0%,#7c3aed 100%); color:#fff;
            border-radius:20px 20px 4px 20px; padding:11px 18px; margin:8px 0 2px 60px;
            font-size:0.875rem; line-height:1.6; box-shadow:0 3px 14px rgba(99,102,241,.30);
            animation:hrc-fadein .3s ease; }
        .hrc-bot-bubble { background:#ffffff; color:#1a1a2e; border:1.5px solid #e4e4f0;
            border-radius:20px 20px 20px 4px; padding:11px 18px; margin:8px 60px 2px 0;
            font-size:0.875rem; line-height:1.6; box-shadow:0 2px 10px rgba(0,0,0,.05);
            animation:hrc-fadein .3s ease; white-space:pre-line; }
        .hrc-bot-bubble.hrc-info { background:linear-gradient(135deg,#f0f4ff,#f5f0ff); border-color:#c7d2fe; }
        .hrc-meta { font-size:0.69rem; color:#a0a0b8; margin:0 0 14px; padding:0 4px; }
        .hrc-meta.right { text-align:right; }
        .hrc-pill { display:inline-block; padding:2px 10px; border-radius:99px; font-size:0.70rem; font-weight:600; }
        .hrc-pill-high   { background:#dcfce7; color:#166534; }
        .hrc-pill-medium { background:#fef9c3; color:#854d0e; }
        .hrc-pill-low    { background:#fee2e2; color:#991b1b; }
        .hrc-source { font-size:0.73rem; color:#7070a0; margin-top:6px; }
        .hrc-ticket-tag { display:inline-block; margin-top:6px; background:#fef3c7; color:#a16207;
            border-radius:8px; padding:2px 10px; font-size:0.72rem; font-weight:600; }
        div[data-testid="stForm"] input[type="text"] {
            border-radius:14px !important; border:1.5px solid #e4e4f0 !important;
            font-size:0.875rem !important; padding:10px 16px !important; transition:border-color .2s; }
        div[data-testid="stForm"] input[type="text"]:focus {
            border-color:#6366f1 !important; box-shadow:0 0 0 3px rgba(99,102,241,.12) !important; }
        div[data-testid="stForm"] button[kind="primaryFormSubmit"],
        div[data-testid="stForm"] button[kind="primary"] {
            background:linear-gradient(135deg,#4f46e5,#7c3aed) !important; color:#fff !important;
            border:none !important; border-radius:12px !important; font-weight:600 !important; }
        div[data-testid="stForm"] button:not([kind="primary"]):not([kind="primaryFormSubmit"]) {
            background:#1a1a2e !important; color:#fff !important; border:none !important;
            border-radius:12px !important; font-weight:600 !important; }
        .hrc-guardrail { margin-top:14px; padding:10px 16px; background:#f5f5ff;
            border-left:4px solid #6366f1; border-radius:0 10px 10px 0;
            font-size:0.78rem; color:#3730a3; line-height:1.55; }
        .hrc-tkt { background:#fff; border:1.5px solid #e4e4f0; border-radius:14px;
            padding:14px 16px; margin-bottom:12px; transition:box-shadow .2s; }
        .hrc-tkt:hover { box-shadow:0 4px 16px rgba(0,0,0,.07); }
        </style>
        """, unsafe_allow_html=True)

        if "emp_chatbot_messages" not in st.session_state:
            st.session_state["emp_chatbot_messages"] = []

        def _call_chatbot(question: str):
            from datetime import datetime as _dt
            with st.spinner("🔍 Thinking..."):
                try:
                    res = requests.post(
                        f"{HR_BASE}/chatbot/ask",
                        json={"question": question},
                        headers=_auth, timeout=60,
                    )
                    if res.status_code == 200:
                        data = res.json()
                        st.session_state["emp_chatbot_messages"].append({
                            "role": "user", "content": question,
                            "time": _dt.now().strftime("%I:%M %p"),
                        })
                        st.session_state["emp_chatbot_messages"].append({
                            "role": "assistant",
                            "content": data.get("answer", "No answer returned."),
                            "confidence": data.get("confidence", "low"),
                            "sources": data.get("sources", []),
                            "ticket_created": data.get("ticket_created", False),
                            "ticket_id": data.get("ticket_id"),
                            "time": _dt.now().strftime("%I:%M %p"),
                        })
                        st.rerun()
                    elif res.status_code == 401:
                        st.error("Session expired — please sign in again.")
                    else:
                        st.error(f"Server error {res.status_code}: {res.text[:180]}")
                except requests.exceptions.Timeout:
                    st.warning("Request timed out. Please try again.")
                except Exception as ex:
                    st.error(f"Connection error: {ex}")

        chat_tab, ticket_tab = st.tabs(["💬 Chat with HR AI", "📋 My Support Tickets"])

        with chat_tab:
            if not st.session_state["emp_chatbot_messages"]:
                st.markdown("""
                <div class="hrc-wrap hrc-welcome">
                    <div class="hrc-robot-icon">🤖</div>
                    <div class="hrc-welcome-title">Welcome to your AI HR Assistant</div>
                    <div class="hrc-welcome-sub">
                        Ask anything about company HR policies — leave, WFH, benefits,
                        code of conduct. Answers come from approved, published policies only.
                    </div>
                </div>
                """, unsafe_allow_html=True)

                cc1, cc2 = st.columns(2)
                with cc1:
                    st.markdown('<div class="hrc-card"><div class="hrc-card-title">📋 Leave Policy</div><div class="hrc-card-sub">How many leaves am I entitled to per year?</div></div>', unsafe_allow_html=True)
                    b_leave = st.button("Ask →", key="tc_leave", use_container_width=True)
                    st.markdown('<div class="hrc-card"><div class="hrc-card-title">📜 Code of Conduct</div><div class="hrc-card-sub">What are the workplace conduct guidelines?</div></div>', unsafe_allow_html=True)
                    b_conduct = st.button("Ask →", key="tc_conduct", use_container_width=True)
                with cc2:
                    st.markdown('<div class="hrc-card"><div class="hrc-card-title">🏠 Work From Home</div><div class="hrc-card-sub">What is the WFH policy for my role?</div></div>', unsafe_allow_html=True)
                    b_wfh = st.button("Ask →", key="tc_wfh", use_container_width=True)
                    st.markdown('<div class="hrc-card"><div class="hrc-card-title">💼 Benefits & Perks</div><div class="hrc-card-sub">What employee benefits are available?</div></div>', unsafe_allow_html=True)
                    b_benefits = st.button("Ask →", key="tc_benefits", use_container_width=True)

                if b_leave:    _call_chatbot("What is the leave policy? How many leaves am I entitled to per year?")
                if b_wfh:      _call_chatbot("What is the WFH / work from home policy for employees?")
                if b_conduct:  _call_chatbot("What are the workplace code of conduct guidelines?")
                if b_benefits: _call_chatbot("What employee benefits and perks are available?")

            else:
                chat_box = st.container(height=400)
                with chat_box:
                    for turn in st.session_state["emp_chatbot_messages"]:
                        if turn["role"] == "user":
                            st.markdown(
                                f"<div class='hrc-user-bubble'>👤 {turn['content']}</div>"
                                f"<div class='hrc-meta right'>{turn.get('time','')}</div>",
                                unsafe_allow_html=True,
                            )
                        else:
                            conf = turn.get("confidence", "low")
                            is_info = conf == "n/a"
                            bubble_cls = "hrc-bot-bubble hrc-info" if is_info else "hrc-bot-bubble"
                            if is_info:
                                pill_html = ""
                            elif conf == "high":
                                pill_html = "<span class='hrc-pill hrc-pill-high'>✅ HIGH</span>"
                            elif conf == "medium":
                                pill_html = "<span class='hrc-pill hrc-pill-medium'>⚠️ MEDIUM</span>"
                            else:
                                pill_html = "<span class='hrc-pill hrc-pill-low'>🔴 LOW</span>"
                            extras = ""
                            if turn.get("sources"):
                                src_list = ", ".join(
                                    f"{s.get('title','')} v{s.get('version','')}"
                                    for s in turn["sources"][:2]
                                )
                                extras += f"<div class='hrc-source'>📖 Source: {src_list}</div>"
                            if turn.get("ticket_created"):
                                tid = str(turn.get("ticket_id", ""))[:8]
                                extras += f"<div class='hrc-ticket-tag'>🎫 HR ticket raised → {tid}…</div>"
                            meta_html = (
                                f"<div class='hrc-meta'>{turn.get('time','')} &nbsp;{pill_html}</div>"
                                if not is_info else
                                f"<div class='hrc-meta'>{turn.get('time','')}</div>"
                            )
                            st.markdown(
                                f"<div class='{bubble_cls}'>🤖 {turn['content']}{extras}</div>{meta_html}",
                                unsafe_allow_html=True,
                            )

            with st.form("emp_chat_form", clear_on_submit=True):
                user_msg = st.text_input(
                    "Ask HR AI",
                    placeholder="e.g. How many casual leaves am I entitled to per year?",
                    label_visibility="collapsed",
                )
                fc1, fc2 = st.columns([5, 1])
                with fc1:
                    send_btn = st.form_submit_button("➤ Send", type="primary", use_container_width=True)
                with fc2:
                    clear_btn = st.form_submit_button("🗑️", use_container_width=True)

            if clear_btn:
                st.session_state["emp_chatbot_messages"] = []
                st.rerun()

            if send_btn and user_msg.strip():
                _call_chatbot(user_msg.strip())

            st.markdown("""
            <div class="hrc-guardrail">
                🛡️ <strong>Strict guardrails active</strong> — Answers sourced exclusively from published HR policies.
                Off-topic, non-HR and general questions are filtered. Only genuine policy queries are escalated to HR Support.
            </div>
            """, unsafe_allow_html=True)

        with ticket_tab:
            st.markdown("""
            <div style="margin-bottom:18px;">
                <div style="font-size:1.05rem;font-weight:700;color:#0f0f1a;">🎫 My HR Support Tickets</div>
                <div style="font-size:0.8rem;color:#7070a0;margin-top:2px;">
                    Only raised for genuine HR policy queries that need HR team review.
                </div>
            </div>
            """, unsafe_allow_html=True)

            live_tickets = []
            try:
                tk_res = requests.get(f"{HR_BASE}/tickets/my", headers=_auth, timeout=15)
                if tk_res.status_code == 200:
                    live_tickets = tk_res.json()
            except Exception:
                pass

            if not live_tickets:
                st.markdown("""
                <div style="text-align:center;padding:40px 24px;background:#fff;
                            border:1.5px solid #e4e4f0;border-radius:16px;">
                    <div style="font-size:3rem;margin-bottom:12px;">🎫</div>
                    <div style="font-weight:700;color:#0f0f1a;margin-bottom:6px;">No tickets yet</div>
                    <div style="font-size:0.82rem;color:#7070a0;max-width:320px;margin:0 auto;line-height:1.6;">
                        HR support tickets are only created for genuine policy-related questions.
                        Off-topic questions are never ticketed.
                    </div>
                </div>
                """, unsafe_allow_html=True)
            else:
                STATUS_COLOR = {"Open":"#4f46e5","In Progress":"#d97706","Resolved":"#16a34a","Closed":"#64748b"}
                PRI_ICON = {"High":"🔴","Medium":"🟡","Low":"🟢"}
                for tkt in live_tickets:
                    status = tkt.get("status","Open")
                    s_color = STATUS_COLOR.get(status,"#4f46e5")
                    pri_icon = PRI_ICON.get(tkt.get("priority",""),"⚪")
                    res_html = ""
                    if tkt.get("resolution_response"):
                        res_html = (
                            "<div style='margin-top:10px;padding:9px 12px;background:#f0fdf4;"
                            "border-left:3px solid #16a34a;border-radius:0 8px 8px 0;"
                            f"font-size:0.78rem;color:#15803d;'>✅ {tkt['resolution_response'][:110]}"
                            f"{'…' if len(tkt.get('resolution_response',''))>110 else ''}</div>"
                        )
                    elif tkt.get("ai_summary"):
                        res_html = (
                            "<div style='margin-top:10px;padding:9px 12px;background:#fefce8;"
                            "border-left:3px solid #ca8a04;border-radius:0 8px 8px 0;"
                            f"font-size:0.78rem;color:#a16207;'>⏳ Awaiting HR — {tkt['ai_summary'][:90]}</div>"
                        )
                    st.markdown(f"""
                    <div class="hrc-tkt">
                        <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:8px;">
                            <span style="font-size:0.82rem;font-weight:700;color:#0f0f1a;">{tkt.get('category','HR Query')}</span>
                            <span style="font-size:0.73rem;font-weight:600;background:{s_color}1a;color:{s_color};padding:2px 10px;border-radius:99px;">{status}</span>
                        </div>
                        <div style="font-size:0.85rem;color:#1a1a2e;line-height:1.5;margin-bottom:6px;">
                            {tkt.get('question','')[:100]}{'…' if len(tkt.get('question',''))>100 else ''}
                        </div>
                        <div style="font-size:0.72rem;color:#a0a0b8;">
                            {pri_icon} {tkt.get('priority','—')} &nbsp;·&nbsp; {tkt['created_at'][:10] if tkt.get('created_at') else '—'}
                        </div>
                        {res_html}
                    </div>
                    """, unsafe_allow_html=True)

            if st.button("🔄 Refresh Tickets", key="emp_ticket_refresh", use_container_width=True):
                st.rerun()

    # PAGE: Survey
    elif selected_emp_page == "Survey":
        import plotly.graph_objects as go
        import pandas as pd

        st.markdown("## 📝 Employee Pulse Survey Portal")
        st.markdown("Share your honest feedback. Your responses are analyzed in real-time to generate coaching plans and policy improvements.")

        # Tab selection for survey vs insights
        survey_tab, insights_tab = st.tabs(["📝 Take Survey", "📊 My Insights Dashboard"])

        with survey_tab:
            emp_id_for_survey = emp_data.get("id")
            auth_token = st.session_state.get("auth_token", "")

            # 1. Fetch surveys from backend
            surveys_list = []
            try:
                surveys_resp = requests.get(f"{BASE_URL}/pulse-survey/surveys")
                if surveys_resp.status_code == 200:
                    surveys_list = surveys_resp.json()
            except Exception:
                pass

            if not surveys_list:
                st.warning("No active pulse surveys found. Please ensure the backend is running and survey data is seeded.")
            else:
                # Survey selector
                survey_options = {s["title"]: s for s in surveys_list}
                selected_survey_title = st.selectbox("Select Survey:", list(survey_options.keys()), key="pulse_survey_selector")
                active_survey = survey_options[selected_survey_title]

                # Frequency check
                freq_blocked = False
                if emp_id_for_survey:
                    try:
                        freq_resp = requests.get(f"{BASE_URL}/pulse-survey/frequency-check/{emp_id_for_survey}")
                        if freq_resp.status_code == 200:
                            freq_data = freq_resp.json()
                            if not freq_data["is_allowed"]:
                                st.warning(f"⏳ You've already submitted a survey recently. Next survey available in **{freq_data.get('remaining_days', 0)} day(s), {freq_data.get('remaining_hours', 0)} hour(s)**.")
                                freq_blocked = True
                    except Exception:
                        pass

                if not freq_blocked:
                    # Submission settings
                    st.markdown("### ⚙️ Submission Parameters")
                    s_col1, s_col2 = st.columns(2)
                    with s_col1:
                        anon_option = st.radio(
                            "Submission Type:",
                            options=["Identified Submission", "Anonymous Submission"],
                            index=0,
                            help="Anonymous surveys do not record your employee ID or name. Note: Anonymous submissions will NOT appear in your personal Insights Dashboard.",
                            key="pulse_anon_radio"
                        )
                        is_anonymous = anon_option == "Anonymous Submission"
                        if is_anonymous:
                            st.warning("⚠️ Anonymous submissions will **not** appear in your personal Insights Dashboard. Choose 'Identified Submission' if you want to track your sentiment history.")
                    with s_col2:
                        survey_mode = st.radio(
                            "Interface Selection:",
                            options=["Standard Form", "Conversational AI Chatbot"],
                            help="Standard Form displays all questions at once. Conversational Chatbot conducts a guided interview.",
                            key="pulse_mode_radio"
                        )

                    st.markdown("---")

                    # Fetch questions — always send employee_id for identified submissions
                    emp_id_to_send = emp_id_for_survey if not is_anonymous else None
                    questions = []
                    survey_details = {}
                    try:
                        start_payload = {"survey_id": active_survey["id"]}
                        if emp_id_to_send:
                            start_payload["employee_id"] = emp_id_to_send
                        start_resp = requests.post(f"{BASE_URL}/pulse-survey/start", json=start_payload)
                        if start_resp.status_code == 200:
                            survey_details = start_resp.json()
                            questions = survey_details.get("questions", [])
                    except Exception as e:
                        st.error(f"Failed to fetch survey questions: {e}")

                    if not questions:
                        st.info("No questions available for this survey.")
                    else:
                        # ──── STANDARD FORM MODE ────
                        if survey_mode == "Standard Form":
                            st.markdown(f"""
                            <div class="ux-card">
                                <h3 style="margin-top:0;">{survey_details.get('title', 'Pulse Survey')}</h3>
                                <p>All individual metrics are aggregated. Your honest feedback helps shape cultural improvements.</p>
                            </div>
                            """, unsafe_allow_html=True)

                            submitting_as = "Anonymous" if is_anonymous else fullname
                            st.info(f"Submitting as: **{submitting_as}**")

                            form_answers = {}
                            with st.form("pulse_survey_form"):
                                for q in questions:
                                    st.markdown(f"**Question {q.get('sequence', '')}:** {q['question_text']}")

                                    if q.get("type") == "rating":
                                        form_answers[str(q["id"])] = st.slider(
                                            "Rating (1 = Unsatisfied, 5 = Excellent):",
                                            min_value=1, max_value=5, value=3,
                                            key=f"pulse_rating_{q['id']}"
                                        )
                                    elif q.get("type") == "mcq":
                                        options_list = q.get("options") or ["Yes", "No"]
                                        form_answers[str(q["id"])] = st.selectbox(
                                            "Select one:",
                                            options=options_list,
                                            key=f"pulse_mcq_{q['id']}"
                                        )
                                    else:
                                        form_answers[str(q["id"])] = st.text_area(
                                            "Your comments:",
                                            placeholder="Type your response here...",
                                            key=f"pulse_text_{q['id']}"
                                        )
                                    st.markdown("<br>", unsafe_allow_html=True)

                                submitted = st.form_submit_button("Submit Survey Response", use_container_width=True)

                                if submitted:
                                    payload = {
                                        "employee_id": emp_id_for_survey,
                                        "survey_id": active_survey["id"],
                                        "response_data": form_answers,
                                        "is_anonymous": is_anonymous
                                    }
                                    with st.spinner("Analyzing survey sentiments and backing up responses..."):
                                        try:
                                            resp = requests.post(f"{BASE_URL}/pulse-survey/response", json=payload)
                                            if resp.status_code == 200:
                                                res_data = resp.json()
                                                st.success("🎉 Survey submitted successfully!")
                                                st.markdown(f"""
                                                **Insights Engine Results:**
                                                - Status: Active
                                                - S3 Secure Backup: `{res_data.get('backup_destination')}`
                                                - AI Insights Generated: **{res_data.get('insights_generated')}**
                                                """)
                                                st.info("💡 *Tip: Click the **My Insights Dashboard** tab above to view your updated sentiment history, emotional profile, and learning recommendations!*")
                                                st.balloons()
                                            else:
                                                detail = resp.json().get('detail', 'Unknown error') if resp.headers.get('content-type', '').startswith('application/json') else resp.text
                                                st.error(f"Submission failed: {detail}")
                                        except Exception as ex:
                                            st.error(f"Error submitting to API: {ex}")

                        # ──── CONVERSATIONAL CHAT MODE ────
                        else:
                            st.markdown(f"### Chat Survey: {survey_details.get('title', 'Pulse Survey')}")
                            submitting_as = "Anonymous" if is_anonymous else fullname
                            st.info(f"Submitting as: **{submitting_as}**")

                            # Initialize chat state
                            if "pulse_chat_history" not in st.session_state or st.session_state.get("pulse_active_survey_id") != active_survey["id"]:
                                st.session_state["pulse_chat_history"] = []
                                st.session_state["pulse_active_survey_id"] = active_survey["id"]
                                st.session_state["pulse_chat_q_index"] = 0
                                st.session_state["pulse_chat_answers"] = {}
                                st.session_state["pulse_survey_completed"] = False

                                welcome = f"Hi! I am the HR Pulse Orchestrator. I will help gather your feedback. Let's start with the first question:\n\n**{questions[0]['question_text']}**"
                                st.session_state["pulse_chat_history"].append({"role": "assistant", "content": welcome})

                            # Display chat log
                            for msg in st.session_state["pulse_chat_history"]:
                                with st.chat_message(msg["role"]):
                                    st.write(msg["content"])

                            if st.session_state.get("pulse_survey_completed"):
                                st.success("Feedback collection complete! Thank you.")
                                if st.button("Start New Chat Session", key="pulse_new_chat"):
                                    st.session_state.pop("pulse_chat_history", None)
                                    st.session_state.pop("pulse_survey_completed", None)
                                    st.rerun()
                            else:
                                q_index = st.session_state["pulse_chat_q_index"]
                                current_q = questions[q_index]

                                if current_q.get("type") == "rating":
                                    st.caption("💡 *Tip: Please type a number from 1 to 5.*")
                                elif current_q.get("type") == "mcq":
                                    st.caption(f"💡 *Tip: Choose one of: {', '.join(current_q.get('options', []))}*")

                                user_input = st.chat_input("Type your response here...", key="pulse_chat_input")

                                if user_input:
                                    st.session_state["pulse_chat_history"].append({"role": "user", "content": user_input})

                                    parsed_val = user_input
                                    if current_q.get("type") == "rating":
                                        try:
                                            parsed_val = int(user_input)
                                            if parsed_val < 1 or parsed_val > 5:
                                                parsed_val = 3
                                        except ValueError:
                                            parsed_val = 3

                                    st.session_state["pulse_chat_answers"][str(current_q["id"])] = parsed_val

                                    next_index = q_index + 1
                                    if next_index < len(questions):
                                        st.session_state["pulse_chat_q_index"] = next_index
                                        next_q = questions[next_index]

                                        agent_comment = "Thank you. "
                                        if current_q.get("type") == "rating" and isinstance(parsed_val, int) and parsed_val <= 2:
                                            agent_comment = "I'm sorry to hear that satisfaction level is low. Let's explore the causes. "
                                        elif current_q.get("type") == "rating" and isinstance(parsed_val, int) and parsed_val >= 4:
                                            agent_comment = "That's wonderful to hear! "

                                        follow_up = f"{agent_comment}Here is the next question:\n\n**{next_q['question_text']}**"
                                        st.session_state["pulse_chat_history"].append({"role": "assistant", "content": follow_up})
                                        st.rerun()
                                    else:
                                        st.session_state["pulse_survey_completed"] = True
                                        payload = {
                                            "employee_id": emp_id_for_survey,
                                            "survey_id": active_survey["id"],
                                            "response_data": st.session_state["pulse_chat_answers"],
                                            "is_anonymous": is_anonymous
                                        }
                                        st.session_state["pulse_chat_history"].append({"role": "assistant", "content": "Perfect! I have collected all answers. Transmitting feedback and running AI sentiment scores..."})

                                        try:
                                            resp = requests.post(f"{BASE_URL}/pulse-survey/response", json=payload)
                                            if resp.status_code == 200:
                                                res_data = resp.json()
                                                success_msg = f"🎉 **Feedback successfully submitted and backed up!**\n\n- S3 Backup: `{res_data.get('backup_destination')}`\n- Sentiment Processed: **Yes**"
                                                st.session_state["pulse_chat_history"].append({"role": "assistant", "content": success_msg})
                                            else:
                                                st.session_state["pulse_chat_history"].append({"role": "assistant", "content": f"⚠️ Submission failed: {resp.text}"})
                                        except Exception as ex:
                                            st.session_state["pulse_chat_history"].append({"role": "assistant", "content": f"⚠️ Network error: {ex}"})
                                        st.rerun()

        # ──── INSIGHTS DASHBOARD TAB ────
        with insights_tab:
            emp_id_for_insights = emp_data.get("id")
            if not emp_id_for_insights:
                st.info("Employee profile not found. Please ensure you are registered in the system.")
            else:
                with st.spinner("Fetching your personalized insights..."):
                    try:
                        insights_resp = requests.get(f"{BASE_URL}/pulse-survey/dashboard/employee/{emp_id_for_insights}")
                        if insights_resp.status_code == 200:
                            idata = insights_resp.json()
                        else:
                            idata = None
                            st.warning("Could not load insights data. Submit a survey first!")
                    except Exception:
                        idata = None
                        st.warning("Backend API not reachable for insights.")

                if idata:
                    # Metadata row
                    im1, im2, im3 = st.columns(3)
                    with im1:
                        st.metric("Logged In As", idata.get("employee_name", fullname))
                    with im2:
                        st.metric("Department", idata.get("department") or "General")
                    with im3:
                        st.metric("Engagement Status", idata.get("sentiment_summary", "N/A"))

                    st.markdown("---")

                    if not idata.get("history"):
                        if idata.get("has_anonymous_submission"):
                            st.warning("⚠️ **Your recent survey submission was Anonymous.**\n\nBecause you chose to submit anonymously, your responses are not linked to your account, and we cannot show your personal sentiment insights. To view your insights here, please choose **Identified Submission** in your future surveys.")
                        else:
                            st.info("👋 You haven't submitted any surveys yet! Submit your first feedback above to unlock insights.")
                    else:
                        left_col, right_col = st.columns([1, 1])

                        with left_col:
                            # Emotion profile chart
                            st.markdown('<div class="ux-card">', unsafe_allow_html=True)
                            st.markdown("#### 🧠 Your Emotional & Stress Profile")
                            emotions = idata.get("emotion_chart_data", {})
                            if emotions:
                                categories = list(emotions.keys())
                                values = list(emotions.values())
                                fig = go.Figure(data=[
                                    go.Bar(
                                        x=values, y=categories, orientation='h',
                                        marker_color=['#ef4444' if c in ['Stress', 'Burnout', 'Anxiety'] else '#10b981' for c in categories],
                                        text=[f"{v*100:.0f}%" for v in values],
                                        textposition='auto',
                                    )
                                ])
                                fig.update_layout(
                                    margin=dict(l=20, r=20, t=10, b=10), height=250,
                                    xaxis=dict(range=[0, 1.05], showgrid=True, gridcolor='rgba(0,0,0,0.05)', tickfont=dict(color='#1e293b')),
                                    yaxis=dict(autorange="reversed", tickfont=dict(color='#1e293b')),
                                    paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)',
                                    font=dict(color='#1e293b')
                                )
                                st.plotly_chart(fig, use_container_width=True)
                            st.markdown('</div>', unsafe_allow_html=True)

                            # Recommendations
                            st.markdown('<div class="ux-card">', unsafe_allow_html=True)
                            st.markdown("#### ✅ Recommended Actions For You")
                            for i, rec in enumerate(idata.get("recommendations", [])):
                                st.markdown(f"**{i+1}.** {rec}")
                            st.markdown('</div>', unsafe_allow_html=True)

                        with right_col:
                            # RAG policies
                            st.markdown('<div class="ux-card">', unsafe_allow_html=True)
                            st.markdown("#### 📚 RAG Policy & Learning Resources")
                            resources = idata.get("resources", [])
                            if not resources:
                                st.write("No matching documents found.")
                            else:
                                for resource in resources:
                                    cat_label = (resource.get("category", "policy") or "policy").upper().replace("_", " ")
                                    st.markdown(f"""
                                    <div style="background:#f8fafc; border:1px solid #cbd5e1; border-radius:8px; padding:1rem; margin-bottom:0.8rem; border-left:4px solid #3b82f6;">
                                        <span style="display:inline-block; background:#dbeafe; color:#1e40af; font-size:0.75rem; font-weight:600; padding:2px 8px; border-radius:4px; margin-bottom:0.5rem;">{cat_label}</span>
                                        <h4 style="margin:0 0 6px 0; color:#1e293b !important;">{resource['title']}</h4>
                                        <p style="margin:0; font-size:0.88rem; color:#475569 !important; line-height:1.4;">{resource['content'][:250]}...</p>
                                    </div>
                                    """, unsafe_allow_html=True)
                            st.markdown('</div>', unsafe_allow_html=True)

                        # Historical trends
                        st.markdown('<div class="ux-card">', unsafe_allow_html=True)
                        st.markdown("#### 📈 Your Historical Engagement Trends")
                        hist_df = pd.DataFrame(idata.get("history", []))
                        if not hist_df.empty:
                            fig_line = go.Figure()
                            fig_line.add_trace(go.Scatter(x=hist_df["date"], y=hist_df["satisfaction"], mode='lines+markers', name='Satisfaction', line=dict(color='#10b981', width=3), marker=dict(size=8)))
                            fig_line.add_trace(go.Scatter(x=hist_df["date"], y=hist_df["stress"], mode='lines+markers', name='Stress', line=dict(color='#ef4444', width=3), marker=dict(size=8)))
                            fig_line.add_trace(go.Scatter(x=hist_df["date"], y=hist_df["sentiment"], mode='lines+markers', name='Overall Sentiment', line=dict(color='#4f46e5', width=3, dash='dash'), marker=dict(size=8)))
                            fig_line.update_layout(
                                margin=dict(l=20, r=20, t=20, b=20), height=300,
                                xaxis=dict(type='category', showgrid=True, gridcolor='rgba(0,0,0,0.05)', tickfont=dict(color='#1e293b')),
                                yaxis=dict(range=[-1.1, 1.1], title=dict(text="Score (-1.0 to 1.0)", font=dict(color='#1e293b')), showgrid=True, gridcolor='rgba(0,0,0,0.05)', tickfont=dict(color='#1e293b')),
                                paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)',
                                legend=dict(orientation='h', yanchor='bottom', y=1.02, xanchor='right', x=1, font=dict(color='#1e293b')),
                                font=dict(color='#1e293b')
                            )
                            st.plotly_chart(fig_line, use_container_width=True)
                        else:
                            st.write("Insufficient data for timeline.")
                        st.markdown('</div>', unsafe_allow_html=True)

    # PAGE: Exit & Clearance (Offboarding)
    elif selected_emp_page == "Offboarding":
        st.markdown("""
        <div class="ux-card" style="border-top: 4px solid #002a54;">
            <h2 style="margin-top:0; color:#002a54 !important;">🚪 Exit & Clearance</h2>
            <p style="color:#4b5563 !important;">This section allows you to formally initiate your resignation from the organization.</p>
        </div>
        """, unsafe_allow_html=True)

        # ── State management ──
        if "resign_letter_shown" not in st.session_state:
            st.session_state["resign_letter_shown"] = False
        if "resign_confirmed" not in st.session_state:
            st.session_state["resign_confirmed"] = False
        if "resign_countdown_started" not in st.session_state:
            st.session_state["resign_countdown_started"] = False

        # ── PHASE 3: After resignation is confirmed ──
        if st.session_state.get("resign_confirmed"):
            resigned_name = st.session_state.get("resigned_name", fullname)
            st.markdown(f"""
            <div class="ux-card" style="
                border-top: 4px solid #16a34a !important;
                background: linear-gradient(135deg, rgba(22,163,74,0.06), rgba(5,150,105,0.04)) !important;
                text-align: center; padding: 40px 28px;">
                <div style="font-size: 3rem; margin-bottom: 16px;">🌟</div>
                <h2 style="color: #15803d !important; margin-bottom: 12px;">Thank You for Your Services, {resigned_name}!</h2>
                <p style="color: #374151 !important; font-size: 1.05rem; line-height: 1.7; max-width: 600px; margin: 0 auto 20px;">
                    Your resignation has been formally accepted. We deeply appreciate your contributions,
                    dedication, and the positive impact you have made during your time with us.
                </p>
                <p style="color: #374151 !important; font-size: 1rem; line-height: 1.6; max-width: 600px; margin: 0 auto 20px;">
                    We wish you all the very best in your future endeavors — may your next chapter bring
                    you great success, happiness, and fulfillment. 🎯
                </p>
                <div style="
                    background: rgba(22,163,74,0.1); border: 1px solid rgba(22,163,74,0.25);
                    border-radius: 12px; padding: 16px 24px; display: inline-block; margin-top: 8px;">
                    <p style="color: #15803d !important; font-size: 0.92rem; margin: 0;">
                        ⏳ You will be automatically signed out in <strong>2 minutes</strong>.
                        Please collect your belongings and return all company assets.
                    </p>
                </div>
            </div>
            """, unsafe_allow_html=True)

        # ── PHASE 2: Resignation Letter View ──
        elif st.session_state.get("resign_letter_shown"):
            import datetime
            today_str = datetime.date.today().strftime("%B %d, %Y")
            real_name = fullname
            real_desig = real_designation
            real_dept = real_department

            letter_html = f"""
            <div class="ux-card" style="border-top: 4px solid #dc2626 !important; max-width: 720px; margin: 0 auto;">
                <div style="text-align: center; margin-bottom: 24px; padding-bottom: 16px; border-bottom: 1px solid #e5e7eb;">
                    <h3 style="color: #111827 !important; margin: 0 0 6px; font-size: 1.3rem; font-weight: 700;">
                        📄 FORMAL RESIGNATION LETTER
                    </h3>
                    <p style="color: #6b7280 !important; font-size: 0.82rem; margin: 0;">Company Confidential — Employee Offboarding</p>
                </div>

                <p style="color:#6b7280 !important; font-size:0.88rem; text-align:right; margin:0 0 20px;">{today_str}</p>

                <p style="color:#374151 !important; margin-bottom:6px;"><strong>To:</strong> The Human Resources Department</p>
                <p style="color:#374151 !important; margin-bottom:6px;"><strong>From:</strong> {real_name}</p>
                <p style="color:#374151 !important; margin-bottom:6px;"><strong>Employee Code:</strong> {real_emp_code}</p>
                <p style="color:#374151 !important; margin-bottom:6px;"><strong>Department:</strong> {real_dept}</p>
                <p style="color:#374151 !important; margin-bottom:24px;"><strong>Designation:</strong> {real_desig}</p>

                <p style="color:#374151 !important; line-height:1.8; margin-bottom:16px;">
                    <strong>Subject: Formal Notice of Resignation</strong>
                </p>

                <p style="color:#374151 !important; line-height:1.8; margin-bottom:16px;">
                    Dear HR Team,
                </p>

                <p style="color:#374151 !important; line-height:1.8; margin-bottom:16px;">
                    I, <strong>{real_name}</strong>, am writing to formally notify you of my decision to resign from my
                    position as <strong>{real_desig}</strong> in the <strong>{real_dept}</strong> department, effective
                    from today, <strong>{today_str}</strong>.
                </p>

                <p style="color:#374151 !important; line-height:1.8; margin-bottom:16px;">
                    I am grateful for the opportunities for professional and personal development that I have been given
                    during my tenure at the company. I have greatly enjoyed and appreciated the support from my colleagues
                    and management throughout my time here.
                </p>

                <p style="color:#374151 !important; line-height:1.8; margin-bottom:16px;">
                    I will endeavor to ensure a smooth handover of my responsibilities. Please let me know how I can assist
                    in the transition process.
                </p>

                <p style="color:#374151 !important; line-height:1.8; margin-bottom:32px;">
                    Thank you once again for the opportunities provided. I wish the organization continued success.
                </p>

                <p style="color:#374151 !important; margin-bottom:4px;"><strong>Yours sincerely,</strong></p>
                <p style="color:#374151 !important; font-size:1.1rem; font-weight:700; margin-bottom:4px;">{real_name}</p>
                <p style="color:#6b7280 !important; font-size:0.82rem;">{real_emp_code} · {today_str}</p>
            </div>
            """
            st.markdown("\n".join([line.strip() for line in letter_html.split("\n")]), unsafe_allow_html=True)

            st.markdown("<br>", unsafe_allow_html=True)
            warning_html = """
            <div class="ux-card" style="border-left: 4px solid #dc2626; background: rgba(220,38,38,0.04) !important;">
                <p style="color: #7f1d1d !important; font-weight: 600; margin: 0 0 6px;">⚠️ Important: This action is irreversible.</p>
                <p style="color: #6b7280 !important; font-size: 0.88rem; margin: 0;">
                    Clicking <strong>"Proceed"</strong> will permanently submit your resignation.
                    Your employee account will be deactivated immediately and you will lose access to this portal.
                    Clicking <strong>"Reject"</strong> will cancel and keep you as an active employee.
                </p>
            </div>
            """
            st.markdown("\n".join([line.strip() for line in warning_html.split("\n")]), unsafe_allow_html=True)

            col_proceed, col_reject, col_spacer = st.columns([1.5, 1.5, 3])
            with col_proceed:
                if st.button("✅ Proceed — Confirm Resignation", use_container_width=True, type="primary", key="resign_proceed_btn"):
                    with st.spinner("Submitting resignation..."):
                        try:
                            res = requests.post(
                                f"{BASE_URL}/employees/resign",
                                headers={"Authorization": f"Bearer {st.session_state['auth_token']}"}
                            )
                            if res.status_code == 200:
                                data = res.json()
                                st.session_state["resigned_name"] = data.get("name", fullname)
                                st.session_state["resign_confirmed"] = True
                                st.session_state["resign_letter_shown"] = False
                                st.rerun()
                            else:
                                err = res.json().get("detail", "Resignation submission failed.")
                                st.error(f"❌ {err}")
                        except Exception as ex:
                            st.error(f"Connection error: {ex}")

            with col_reject:
                if st.button("❌ Reject — Stay as Employee", use_container_width=True, key="resign_reject_btn"):
                    st.session_state["resign_letter_shown"] = False
                    st.success("✅ Resignation cancelled. You remain an active employee.")
                    st.rerun()
            return

        # ── PHASE 1: Default view — Resign Button ──
        portal_html = """
        <div class="ux-card">
            <h3 style="margin-top:0; color:#111827 !important;">📋 Employee Exit & Clearance Portal</h3>
            <p style="color:#4b5563 !important; line-height:1.7; margin-bottom:16px;">
                If you have made the decision to leave the organization, you can formally submit your resignation
                through this portal. This will initiate the offboarding process.
            </p>
            <div style="display:grid; grid-template-columns: 1fr 1fr; gap:16px; margin-top:16px; margin-bottom:8px;">
                <div style="background:#f0fdf4; border-radius:8px; padding:14px; border-left:4px solid #16a34a;">
                    <span style="color:#15803d !important; font-weight:600; display:block; margin-bottom:4px;">✅ Before You Resign</span>
                    <ul style="color:#4b5563 !important; font-size:0.85rem; margin:0; padding-left:18px;">
                        <li>Complete all pending work assignments</li>
                        <li>Prepare knowledge transfer documentation</li>
                        <li>Settle all expense claims with Finance</li>
                        <li>Return all company-issued equipment</li>
                    </ul>
                </div>
                <div style="background:#fef2f2; border-radius:8px; padding:14px; border-left:4px solid #dc2626;">
                    <span style="color:#dc2626 !important; font-weight:600; display:block; margin-bottom:4px;">⚠️ After Resignation</span>
                    <ul style="color:#4b5563 !important; font-size:0.85rem; margin:0; padding-left:18px;">
                        <li>Access to this portal will be revoked immediately</li>
                        <li>HR will schedule an exit interview session</li>
                        <li>Final settlement will be processed by Finance</li>
                        <li>Experience letter will be issued within 30 days</li>
                    </ul>
                </div>
            </div>
        </div>
        """
        st.markdown("\n".join([line.strip() for line in portal_html.split("\n")]), unsafe_allow_html=True)

        st.markdown("<br>", unsafe_allow_html=True)

        col_btn, col_space = st.columns([2, 4])
        with col_btn:
            if st.button("🚪 Submit Resignation", use_container_width=True, key="resign_main_btn",
                         help="Click to view and submit your formal resignation letter"):
                st.session_state["resign_letter_shown"] = True
                st.rerun()



# ─────────────────────────────────────────────────────────────────────────────
# LOGIN PAGE
# ─────────────────────────────────────────────────────────────────────────────
if st.session_state["auth_token"] is None:
    st.markdown("""
    <div class="login-wrapper">
        <div class="login-container">
            <div class="login-header">
                <span class="logo">🏢</span>
                <h2>Enterprise HR & Employee Portal</h2>
                <p>Sign in to access your self-service or recruitment dashboard</p>
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)

    col_pad_l, col_form, col_pad_r = st.columns([1.5, 2, 1.5])
    with col_form:
        st.markdown("")
        email_input = st.text_input("Email Address/Username", placeholder="Enter Username", key="login_email")
        st.markdown("")
        pass_input = st.text_input("Password", type="password", placeholder="Enter your password", key="login_pass")
        st.markdown("<br>", unsafe_allow_html=True)
        if "login_error" in st.session_state and st.session_state["login_error"]:
            st.error(st.session_state["login_error"])
            st.session_state["login_error"] = None
        if st.button("🚀  Sign In", use_container_width=True, key="login_btn"):
            login_user(email_input, pass_input)
        st.markdown("""
        <div class="login-footer">
            <p>Secured with JWT Authentication · Unified Portal v2.0</p>
        </div>
        """, unsafe_allow_html=True)


# ─────────────────────────────────────────────────────────────────────────────
# MAIN APPLICATION (Authenticated)
# ─────────────────────────────────────────────────────────────────────────────
else:
    headers = api_headers()

    # Retrieve user profile if not loaded
    if "user_profile" not in st.session_state or st.session_state["user_profile"] is None:
        try:
            res = requests.get(f"{BASE_URL}/users/me", headers=headers)
            if res.status_code == 200:
                st.session_state["user_profile"] = res.json()
            else:
                st.session_state["user_profile"] = None
                st.session_state["auth_token"] = None
                st.error("Session expired. Please sign in again.")
                st.rerun()
        except Exception:
            # Fallback for offline mode or debug testing
            st.session_state["user_profile"] = {
                "email": "employee@company.com",
                "full_name": "Test Employee",
                "is_manager": False
            }

    user_profile = st.session_state.get("user_profile") or {}
    email = user_profile.get("email", "")
    is_manager = user_profile.get("is_manager", False)
    is_hr = is_manager or email in ["recruiter@company.com", "manager@company.com"]

    if not is_hr:
        # Check if the user is logging in with a corporate email
        if not email.strip().lower().endswith("@company.com"):
            st.session_state.clear()
            st.session_state["login_error"] = "Access denied: Regular employees must log in with their corporate (@company.com) email."
            st.rerun()

        # Check if the user exists in the employees table (Port 8501 is restricted to verified employees)
        try:
            emp_res = requests.get(f"{BASE_URL}/employees/me", headers=headers)
            if emp_res.status_code == 404:
                st.session_state.clear()
                st.session_state["login_error"] = "Incorrect email or password."
                st.rerun()
            elif emp_res.status_code != 200:
                st.error("Unable to verify employee onboarding status with backend database.")
                st.stop()
        except Exception:
            # Fallback for offline mode or debug testing
            pass

        render_employee_dashboard(user_profile)
        st.stop()

    with st.sidebar:
        # ── Brand header ──────────────────────────────────────────
        st.markdown("""
        <div class="sidebar-brand">
            <span class="brand-icon">🚀</span>
            <h3>AI HR Hub</h3>
            <p>TCS Intelligent Workforce Platform</p>
        </div>
        """, unsafe_allow_html=True)

        # Show logged-in user info
        _rec_name = user_profile.get("full_name", "HR Recruiter")
        _rec_role = "Manager" if is_manager else "Recruiter"
        st.markdown(f"""
        <div class="sidebar-user">
            <div class="sidebar-user-avatar">HR</div>
            <div class="sidebar-user-info">
                <div class="sidebar-user-name">{_rec_name}</div>
                <div class="sidebar-user-role">{_rec_role} · Administrator</div>
            </div>
        </div>
        """, unsafe_allow_html=True)

        # ── Custom grouped nav CSS matching original theme ───────────────────────────────────
        st.markdown("""
        <style>
        .sb-section-hdr {
            color: #4b5563 !important;
            font-size: 0.62rem !important;
            font-weight: 700 !important;
            text-transform: uppercase !important;
            letter-spacing: 0.15em !important;
            padding: 18px 16px 4px 16px !important;
            margin: 0 !important;
            -webkit-text-fill-color: #4b5563 !important;
            display: block !important;
        }
        /* Override Streamlit button defaults to look like the original radio items */
        div[data-testid="stSidebar"] .stButton > button {
            background: transparent !important;
            border: 1px solid transparent !important;
            box-shadow: none !important;
            color: #c7d2fe !important;
            -webkit-text-fill-color: #c7d2fe !important;
            text-align: left !important;
            justify-content: flex-start !important;
            padding: 11px 16px !important;
            border-radius: 12px !important;
            font-size: 0.92rem !important;
            font-weight: 500 !important;
            margin-bottom: 2px !important;
            width: 100% !important;
            transition: all 0.3s ease !important;
        }
        div[data-testid="stSidebar"] .stButton > button:hover {
            background: rgba(99,102,241,0.1) !important;
            border-color: rgba(99,102,241,0.2) !important;
            color: #e0e7ff !important;
            -webkit-text-fill-color: #e0e7ff !important;
            transform: translateX(4px) !important;
        }
        /* Active page button */
        div[data-testid="stSidebar"] .stButton > button[kind="primary"] {
            background: rgba(99,102,241,0.15) !important;
            border: 1px solid rgba(99,102,241,0.3) !important;
            color: #e0e7ff !important;
            -webkit-text-fill-color: #e0e7ff !important;
            font-weight: 600 !important;
            box-shadow: none !important;
        }
        </style>
        """, unsafe_allow_html=True)


        def nav_btn(label, page_key):
            """Render a sidebar nav button, highlighted if active."""
            is_active = st.session_state["rec_nav_page"] == page_key
            btn_type = "primary" if is_active else "secondary"
            if st.button(label, use_container_width=True, type=btn_type, key=f"nav_{page_key}"):
                st.session_state["rec_nav_page"] = page_key
                st.rerun()

        # ── SECTION 1: RECRUITMENT & HIRING ───────────────────────
        st.markdown('<p class="sb-section-hdr">🔍 Recruitment & Hiring</p>', unsafe_allow_html=True)
        nav_btn("📊  Dashboard",          "Dashboard")
        nav_btn("💼  Jobs Management",    "Jobs")
        nav_btn("📄  Resume Screening",   "Resume")
        nav_btn("🏆  Candidate Rankings", "Rankings")
        nav_btn("🎙️  AI Interview Panel", "Interview")
        nav_btn("✉️  Email Center",       "Email")

        # ── SECTION 2: ONBOARDING ──────────────────────────────────
        st.markdown('<p class="sb-section-hdr">👥 Onboarding</p>', unsafe_allow_html=True)
        nav_btn("🎯  Offer & Onboarding Pipeline", "Onboarding")

        # ── SECTION 3: HR OPERATIONS ──────────────────────────────
        st.markdown('<p class="sb-section-hdr">⚙️ HR Operations</p>', unsafe_allow_html=True)
        nav_btn("📝  Policy Generator",         "PolicyGen")
        nav_btn("🎫  HR Support Tickets",        "HRTickets")
        nav_btn("🎓  Training & Development",   "Training")
        nav_btn("📈  Workforce Analytics",      "Analytics")
        nav_btn("💬  Pulse Survey",             "PulseSurvey")
        nav_btn("🚪  Exit Management",          "ExitMgmt")

        # ── SECTION 4: ADMIN ───────────────────────────────────────
        st.markdown('<p class="sb-section-hdr">🔧 Admin</p>', unsafe_allow_html=True)
        st.markdown('<div style="padding:0 2px;">', unsafe_allow_html=True)
        st.markdown(f'<div style="color:#4ade80 !important; font-size:0.7rem; padding:4px 12px;">● All systems online · v2.0</div>', unsafe_allow_html=True)
        st.markdown('</div>', unsafe_allow_html=True)

        st.markdown('<div class="section-divider"></div>', unsafe_allow_html=True)
        if st.button("🗑️  Reset Database", use_container_width=True, key="reset_db_btn", help="DANGER: Purges all candidate data"):
            try:
                res = requests.delete(f"{BASE_URL}/admin/clear-db", headers=api_headers())
                if res.status_code == 200:
                    st.session_state["active_interview_cand_id"] = None
                    st.session_state["active_interview_cand_name"] = None
                    st.session_state["_rankings_data"] = None
                    st.session_state["_rankings_job_id"] = None
                    st.session_state["interview_session"] = {}
                    st.session_state["_last_created_interview_id"] = 1
                    st.success("Database cleared successfully!")
                    st.rerun()
                else:
                    st.error(f"Reset failed. Status: {res.status_code}")
            except Exception as e:
                st.error(f"Reset failed: {e}")

        if st.button("🔄  Refresh Dashboard", use_container_width=True, key="refresh_nav_btn"):
            st.rerun()

        if st.button("🚪  Sign Out", use_container_width=True, key="signout_btn"):
            st.session_state["auth_token"] = None
            st.rerun()

    selected_page = st.session_state["rec_nav_page"]

    # ══════════════════════════════════════════════════════════════════════
    # PAGE: DASHBOARD
    # ══════════════════════════════════════════════════════════════════════
    if selected_page == "Dashboard":
        greeting_text, greeting_icon = get_greeting()
        st.markdown(f"""
        <div class="welcome-banner">
            <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 4px;">
                <span style="font-size: 1.6rem;">{greeting_icon}</span>
                <h2 style="margin: 0;">{greeting_text}, Recruiter!</h2>
            </div>
            <p>Here's an overview of your AI-powered hiring pipeline. Stay on top of every candidate.</p>
        </div>
        """, unsafe_allow_html=True)

        refresh_col, updated_col = st.columns([1, 3])
        with refresh_col:
            if st.button("Refresh Dashboard", key="refresh_dashboard", use_container_width=True):
                st.rerun()
        with updated_col:
            st.caption(f"Last updated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

        dashboard_stats = {
            "active_jobs": 0,
            "total_applicants": 0,
            "interviews_done": 0,
            "pending_interviews": 0,
        }
        try:
            jobs_res = requests.get(f"{BASE_URL}/jobs", headers=headers)
            jobs = jobs_res.json() if jobs_res.status_code == 200 else []
            dashboard_stats["active_jobs"] = sum(1 for job in jobs if str(job.get("status", "Active")).lower() == "active")

            for job in jobs:
                job_id = job.get("id")
                
                # Fetch candidates for this job
                cands_res = requests.get(f"{BASE_URL}/jobs/{job_id}/candidates", headers=headers)
                candidates = cands_res.json() if cands_res.status_code == 200 else []
                dashboard_stats["total_applicants"] += len(candidates)

                # Fetch interview results to check completion status
                results_res = requests.get(f"{BASE_URL}/interviews/job/{job_id}/results", headers=headers)
                completed_cand_ids = set()
                if results_res.status_code == 200:
                    interview_results = results_res.json().get("results", [])
                    completed_cand_ids = {item.get("candidate_id") for item in interview_results if item.get("is_completed")}
                
                dashboard_stats["interviews_done"] += len(completed_cand_ids)
                
                # Count pending interviews (active candidates who haven't completed the interview)
                for c in candidates:
                    cid = c.get("id")
                    cstatus = c.get("status", "")
                    if cstatus not in ("Offered", "Rejected", "Offer Accepted", "Joined", "Offer Rejected", "Offer Revoked") and cid not in completed_cand_ids:
                        dashboard_stats["pending_interviews"] += 1
        except Exception as e:
            st.warning(f"Dashboard data could not be refreshed: {e}")

        lc1, lc2, lc3, lc4 = st.columns(4)
        with lc1:
            st.markdown(f"""<div class="metric-card live-metric-card purple"><span class="metric-icon">💼</span><div class="metric-value">{dashboard_stats['active_jobs']}</div><div class="metric-label">Active Job Postings</div><div class="metric-delta delta-green">Live</div></div>""", unsafe_allow_html=True)
        with lc2:
            st.markdown(f"""<div class="metric-card live-metric-card blue"><span class="metric-icon">👥</span><div class="metric-value">{dashboard_stats['total_applicants']}</div><div class="metric-label">Total Applicants</div><div class="metric-delta delta-blue">From All Jobs</div></div>""", unsafe_allow_html=True)
        with lc3:
            st.markdown(f"""<div class="metric-card live-metric-card emerald"><span class="metric-icon">🎙️</span><div class="metric-value">{dashboard_stats['interviews_done']}</div><div class="metric-label">Interviews Done</div><div class="metric-delta delta-green">Completed</div></div>""", unsafe_allow_html=True)
        with lc4:
            st.markdown(f"""<div class="metric-card live-metric-card amber"><span class="metric-icon">⏳</span><div class="metric-value">{dashboard_stats['pending_interviews']}</div><div class="metric-label">Pending Interview</div><div class="metric-delta delta-amber">Needs Attention</div></div>""", unsafe_allow_html=True)

        col_pipe, col_sys = st.columns([3, 2])
        with col_pipe:
            st.markdown('<h3 style="margin-bottom: 20px;">⚡ AI Pipeline Overview</h3>', unsafe_allow_html=True)
            st.markdown('<div class="pipeline-timeline">', unsafe_allow_html=True)
            pipeline_steps = [
                ("📄 Resume Upload", "Resume uploaded → S3 storage + text extraction"),
                ("🤖 AI Parsing", "LLM extracts skills, experience, education"),
                ("🔍 Semantic Match", "Titan embeddings compute resume-JD similarity"),
                ("📊 ATS Scoring", "Weighted multi-factor score calculated"),
                ("🏆 Candidate Ranking", "All candidates ranked for the job"),
                ("💡 AI Recommendation", "Verdict: Strong Hire / Hire / Consider / Reject"),
                ("✉️ Email Draft", "AI drafts candidate outreach email"),
            ]
            for label, desc in pipeline_steps:
                st.markdown(f"""
                <div class="pipeline-node">
                    <div class="pipeline-node-content">
                        <div class="pipeline-label">{label}</div>
                        <div class="pipeline-desc">{desc}</div>
                    </div>
                </div>""", unsafe_allow_html=True)
            st.markdown('</div>', unsafe_allow_html=True)

        with col_sys:
            st.markdown("""
            <div class="glass-card" style="padding: 20px 24px;">
                <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 16px;">
                    <span style="font-size: 1.2rem;">🖥️</span>
                    <div><h3 style="margin:0;">System Health</h3></div>
                </div>
            """, unsafe_allow_html=True)
            st.markdown("""<div class="status-bar" style="margin-top: 0;"><div class="status-dot"></div><div class="status-text">All systems operational</div></div>""", unsafe_allow_html=True)
            services = [("Google Gemini", "Connected"), ("PostgreSQL", "Connected"), ("Gmail API", "Ready"), ("GCS Storage", "Active")]
            st.markdown('<div class="glass-card" style="padding: 8px 22px;">', unsafe_allow_html=True)
            for svc_name, svc_status in services:
                st.markdown(f'<div class="sys-status-row"><span class="sys-status-name">{svc_name}</span><span class="badge badge-sent">● {svc_status}</span></div>', unsafe_allow_html=True)
            st.markdown('</div>', unsafe_allow_html=True)
            st.markdown('</div>', unsafe_allow_html=True)


    # ══════════════════════════════════════════════════════════════════════
    # PAGE: JOBS MANAGEMENT
    # ══════════════════════════════════════════════════════════════════════
    elif selected_page == "Jobs":
        st.markdown("""
        <div class="page-header">
            <div class="page-header-icon">💼</div>
            <div><h1 style="margin:0; font-size:1.8rem !important;">Jobs Management</h1></div>
        </div>
        <p class="page-subtitle">Create and manage job postings with AI-powered description analysis</p>
        """, unsafe_allow_html=True)

        tab_create, tab_view = st.tabs(["➕  Create New Job", "📋  View Existing Jobs"])

        with tab_create:
            st.markdown('<div class="glass-card">', unsafe_allow_html=True)
            with st.form("job_form", clear_on_submit=True):
                st.markdown("""<div class="form-section"><div class="form-section-icon">📝</div><span class="form-section-text">Basic Information</span></div>""", unsafe_allow_html=True)
                col1, col2 = st.columns(2)
                with col1:
                    title = st.text_input("Job Title *", placeholder="e.g. Senior Python Engineer")
                    dept = st.text_input("Department *", placeholder="e.g. Engineering")
                    emp_type = st.selectbox("Employment Type *", ["Full-Time", "Part-Time", "Contract", "Internship"])
                with col2:
                    loc = st.text_input("Location *", placeholder="e.g. Remote (US / India)")
                    sal = st.text_input("Salary Range *", placeholder="e.g. $120,000 - $150,000")
                    exp = st.number_input("Min. Experience (Years) *", min_value=0, max_value=30, value=3)
                st.markdown('<div class="section-divider"></div>', unsafe_allow_html=True)
                st.markdown("""<div class="form-section"><div class="form-section-icon">🎯</div><span class="form-section-text">Skills & Description</span></div>""", unsafe_allow_html=True)
                skills = st.text_input("Required Skills * (comma-separated)", placeholder="e.g. Python, FastAPI, PostgreSQL, Docker")
                desc = st.text_area("Job Description *", height=160, placeholder="Provide a detailed description of the role...")
                st.markdown("<br>", unsafe_allow_html=True)
                submitted = st.form_submit_button("🚀  Create Job Posting", use_container_width=True)
                if submitted:
                    if not title or not dept or not loc or not desc:
                        st.warning("Please fill in all required fields.")
                    else:
                        payload = {"title": title, "department": dept, "location": loc, "employment_type": emp_type, "salary_range": sal, "experience_required": int(exp), "skills_required": [s.strip() for s in skills.split(",") if s.strip()], "responsibilities": desc, "full_description": desc}
                        with st.spinner("Creating job and analyzing description..."):
                            res = requests.post(f"{BASE_URL}/jobs", json=payload, headers=headers)
                        if res.status_code == 200:
                            st.success("Job posting created successfully! AI has analyzed the description.")
                            st.json(res.json())
                        else:
                            st.error(f"Failed to create job. Server returned: {res.status_code}")
            st.markdown('</div>', unsafe_allow_html=True)

        with tab_view:
            with st.spinner("Loading jobs..."):
                try:
                    res = requests.get(f"{BASE_URL}/jobs", headers=headers)
                    if res.status_code == 200:
                        jobs = res.json()
                        if jobs:
                            for job in jobs:
                                status = job.get('status', 'Unknown')
                                badge_class = 'badge-sent' if status == 'Active' else 'badge-draft'
                                skills_list = job.get('skills_required', [])
                                skills_str = ", ".join(skills_list[:5]) + ("..." if len(skills_list) > 5 else "") if skills_list else "—"
                                structured = job.get('structured_profile') or {}
                                seniority = structured.get('seniority_level', '')
                                seniority_badge = f'<span class="job-card-meta-item">🎯 {seniority}</span>' if seniority else ''
                                html_content = (
                                    f'<div class="job-card">'
                                    f'<div class="job-card-header">'
                                    f'<div>'
                                    f'<div class="job-card-title">💼 {job.get("title", "Untitled")} &nbsp;<span style="font-size:0.75rem; color:#6366f1 !important; font-weight:500;">#{job.get("id","?")}</span></div>'
                                    f'<div class="job-card-meta">'
                                    f'<span class="job-card-meta-item">📍 {job.get("location", "N/A")}</span>'
                                    f'<span class="job-card-meta-item">🏢 {job.get("department", "N/A")}</span>'
                                    f'<span class="job-card-meta-item">💰 {job.get("salary_range", "N/A")}</span>'
                                    f'<span class="job-card-meta-item">📅 {job.get("employment_type", "N/A")}</span>'
                                    f'<span class="job-card-meta-item">⏳ {job.get("experience_required", 0)}+ yrs</span>'
                                    f'{seniority_badge}'
                                    f'</div>'
                                    f'<div style="margin-top:10px; color:#64748b !important; font-size:0.8rem;">🛠 {skills_str}</div>'
                                    f'</div>'
                                    f'<span class="badge {badge_class}">{status}</span>'
                                    f'</div>'
                                    f'</div>'
                                )
                                st.markdown(html_content, unsafe_allow_html=True)
                        else:
                            st.markdown("""<div class="empty-state"><span class="empty-icon">📭</span><h3>No jobs posted yet</h3><p>Create your first job posting to start receiving AI-evaluated candidates</p></div>""", unsafe_allow_html=True)
                    else:
                        st.warning("Could not fetch jobs from the server.")
                except Exception:
                    st.error("Backend connection failed.")


    # ══════════════════════════════════════════════════════════════════════
    # PAGE: RESUME SCREENING
    # ══════════════════════════════════════════════════════════════════════
    elif selected_page == "Resume":
        st.markdown("""
        <div class="page-header">
            <div class="page-header-icon">📄</div>
            <div><h1 style="margin:0; font-size:1.8rem !important;">Resume Screening</h1></div>
        </div>
        <p class="page-subtitle">Upload resumes and trigger the full AI evaluation pipeline</p>
        """, unsafe_allow_html=True)

        st.markdown('<div class="glass-card">', unsafe_allow_html=True)
        st.markdown("""<div class="form-section"><div class="form-section-icon">📂</div><span class="form-section-text">Upload Resume Files</span></div>""", unsafe_allow_html=True)

        st.markdown('<div class="resume-uploader">', unsafe_allow_html=True)
        uploaded_files = st.file_uploader("Drag and drop resume files (PDF or TXT)", accept_multiple_files=True, type=["txt", "pdf"], help="Supports .txt and .pdf formats")
        st.markdown('</div>', unsafe_allow_html=True)

        if uploaded_files:
            st.markdown(f"""
            <div class="status-bar" style="background: rgba(99, 102, 241, 0.06) !important; border-color: rgba(99, 102, 241, 0.15);">
                <span style="font-size: 1.1rem;">📎</span>
                <span style="color: #a78bfa !important; font-weight: 500; font-size: 0.88rem;">{len(uploaded_files)} file{'s' if len(uploaded_files) > 1 else ''} ready for processing</span>
            </div>
            """, unsafe_allow_html=True)

        st.markdown('<div class="section-divider"></div>', unsafe_allow_html=True)
        st.markdown("""<div class="form-section"><div class="form-section-icon">🎯</div><span class="form-section-text">Target Job Configuration</span></div>""", unsafe_allow_html=True)

        job_id_target = None
        try:
            jobs_res = requests.get(f"{BASE_URL}/jobs", headers=headers)
            if jobs_res.status_code == 200:
                jobs_list = jobs_res.json()
            else:
                jobs_list = []
        except Exception:
            jobs_list = []

        if jobs_list:
            job_options = {f"💼 {j.get('title')} (#{j.get('id')}) - {j.get('department')}": j.get('id') for j in jobs_list}
            selected_job_label = st.selectbox("Select Target Job *", list(job_options.keys()), help="Choose the job position this candidate is applying for")
            job_id_target = job_options[selected_job_label]
        else:
            col_jid, col_spacer = st.columns([1, 2])
            with col_jid:
                job_id_target = st.number_input("Target Job ID (Fallback)", min_value=1, value=1, help="The Job ID to evaluate candidates against")
            st.warning("No active jobs found. Please create a job posting first, or enter the ID manually.")
        
        st.markdown("<br>", unsafe_allow_html=True)

        if st.button("⚡  Process Resumes", use_container_width=True, disabled=not uploaded_files):
            if uploaded_files:
                progress_bar = st.progress(0, text="Starting pipeline...")
                total = len(uploaded_files)
                success_count = 0
                for i, file in enumerate(uploaded_files):
                    progress_bar.progress((i + 1) / total, text=f"Processing {file.name} ({i+1}/{total})...")
                    files_payload = {"file": (file.name, file.getvalue(), "text/plain")}
                    data_payload = {"job_id": job_id_target}
                    res = requests.post(f"{BASE_URL}/resumes/upload", files=files_payload, data=data_payload, headers=headers)
                    if res.status_code == 200:
                        success_count += 1
                        st.markdown(f"""<div class="process-step"><span class="process-step-icon">✅</span><span class="process-step-text">{file.name} — processed successfully</span></div>""", unsafe_allow_html=True)
                    else:
                        st.markdown(f"""<div class="process-step" style="background: rgba(239, 68, 68, 0.06) !important; border-color: rgba(239, 68, 68, 0.12);"><span class="process-step-icon">❌</span><span class="process-step-text" style="color: #f87171 !important;">{file.name} — failed (status {res.status_code})</span></div>""", unsafe_allow_html=True)
                progress_bar.progress(1.0, text="Pipeline complete!")
                st.markdown(f"""<div class="status-bar"><div class="status-dot"></div><div class="status-text">Pipeline complete — {success_count}/{total} resumes processed successfully</div></div>""", unsafe_allow_html=True)
        st.markdown('</div>', unsafe_allow_html=True)


    # ══════════════════════════════════════════════════════════════════════
    # PAGE: CANDIDATE RANKINGS  (UPGRADED)
    # ══════════════════════════════════════════════════════════════════════
    elif selected_page == "Rankings":
        st.markdown("""
        <div class="page-header">
            <div class="page-header-icon">🏆</div>
            <div><h1 style="margin:0; font-size:1.8rem !important;">Candidate Rankings</h1></div>
        </div>
        <p class="page-subtitle">AI-ranked candidates — pending interviews, completed interviews, and decision status in separate tabs</p>
        """, unsafe_allow_html=True)

        # ── Job selector: friendly dropdown instead of number input ─────
        _rank_jobs = []
        try:
            _rj2 = requests.get(f"{BASE_URL}/jobs", headers=headers)
            if _rj2.status_code == 200:
                _rank_jobs = _rj2.json()
        except Exception:
            pass

        ranking_job_id = None
        if not _rank_jobs:
            st.warning("No jobs found. Please create a job posting first.")
        else:
            _rank_job_opts = {f"{j.get('title', 'Untitled')} — {j.get('department', '')} (ID {j.get('id')})": j for j in _rank_jobs}
            _rank_job_label = st.selectbox("Select Job", list(_rank_job_opts.keys()), key="ranking_job_select")
            _rank_job_obj = _rank_job_opts[_rank_job_label]
            ranking_job_id = _rank_job_obj.get("id")

            # Show job banner
            job_desc  = _rank_job_obj.get("full_description", "")
            job_skills = _rank_job_obj.get("skills_required", [])
            skills_text = ", ".join(job_skills[:6]) if job_skills else "—"
            desc_preview = job_desc[:220] + "…" if len(job_desc) > 220 else job_desc
            st.markdown(f"""
            <div class="job-desc-banner">
                <h4>💼 {_rank_job_obj.get('title')} &nbsp;·&nbsp; {_rank_job_obj.get('department')} &nbsp;·&nbsp; {_rank_job_obj.get('location')}</h4>
                <p>{desc_preview}</p>
                <p style="margin-top:6px;">🛠 Required skills: <b style="color:#a78bfa !important;">{skills_text}</b></p>
            </div>
            """, unsafe_allow_html=True)

        # Auto-load rankings when job changes or if they are not loaded yet
        if ranking_job_id:
            if st.session_state.get("_rankings_job_id") != ranking_job_id or "_rankings_data" not in st.session_state:
                try:
                    res = requests.get(f"{BASE_URL}/jobs/{ranking_job_id}/rankings", headers=headers)
                    if res.status_code == 200:
                        st.session_state["_rankings_data"] = res.json()
                        st.session_state["_rankings_job_id"] = ranking_job_id
                    else:
                        st.session_state["_rankings_data"] = []
                        st.session_state["_rankings_job_id"] = ranking_job_id
                except Exception:
                    pass

        # Manual refresh button to force refetch rankings
        if ranking_job_id and st.button("🔄  Refresh Rankings List", key="refresh_rankings_btn", use_container_width=True):
            with st.spinner("Refreshing rankings..."):
                try:
                    res = requests.get(f"{BASE_URL}/jobs/{ranking_job_id}/rankings", headers=headers)
                    if res.status_code == 200:
                        st.session_state["_rankings_data"] = res.json()
                        st.session_state["_rankings_job_id"] = ranking_job_id
                        st.success("Rankings refreshed!")
                        st.rerun()
                    else:
                        st.session_state["_rankings_data"] = []
                        st.session_state["_rankings_job_id"] = ranking_job_id
                except Exception:
                    st.error("Backend connection failed.")

        rankings_raw = st.session_state.get("_rankings_data", [])
        rankings_job_id_cache = st.session_state.get("_rankings_job_id")

        if rankings_raw and rankings_job_id_cache == ranking_job_id:
            # Fetch all candidate details
            cand_cache = {}
            for r in rankings_raw:
                cid = r.get("candidate_id")
                if cid and cid not in cand_cache:
                    try:
                        cr = requests.get(f"{BASE_URL}/candidates/{cid}", headers=headers)
                        cand_cache[cid] = cr.json() if cr.status_code == 200 else {}
                    except Exception:
                        cand_cache[cid] = {}

            # Load interview results to check completion status
            interview_status = {}
            try:
                ir = requests.get(f"{BASE_URL}/interviews/job/{ranking_job_id}/results", headers=headers)
                if ir.status_code == 200:
                    results_data = ir.json().get("results", [])
                    for item in results_data:
                        interview_status[item.get("candidate_id")] = item
            except Exception:
                pass

            # Separate into 4 buckets: pending-interview / completed-interview / approved / rejected
            pending_rankings = []
            completed_rankings = []
            approved_rankings = []
            rejected_rankings = []
            for r in rankings_raw:
                cid = r.get("candidate_id")
                cdata = cand_cache.get(cid, {})
                status_raw = str(cdata.get("status", "")).lower()
                
                int_state = interview_status.get(cid, {})
                is_completed = int_state.get("is_completed", False)
                
                if "reject" in status_raw:
                    rejected_rankings.append(r)
                elif "offer" in status_raw or "join" in status_raw or "approved" in status_raw:
                    approved_rankings.append(r)
                elif is_completed:
                    completed_rankings.append(r)
                else:
                    pending_rankings.append(r)

            tab_pending, tab_completed, tab_approved, tab_rejected = st.tabs([
                f"⏳ Pending Interview ({len(pending_rankings)})",
                f"✅ Interviewed ({len(completed_rankings)})",
                f"🎉 Approved ({len(approved_rankings)})",
                f"❌ Rejected ({len(rejected_rankings)})"
            ])

            def render_rankings_list(rank_list, show_podium=True, show_decision_buttons=False):
                if not rank_list:
                    st.markdown('<div class="empty-state"><span class="empty-icon">🏆</span><h3>No candidates in this category</h3><p>They will appear here once their status is updated.</p></div>', unsafe_allow_html=True)
                    return

                if show_podium and len(rank_list) >= 1:
                    podium_items = [x for x in rank_list if x.get("rank", 99) <= 3]
                    if podium_items:
                        podium_html = '<div class="podium-wrapper">'
                        for r in podium_items:
                            rank = r.get("rank", 1)
                            cand_id = r.get("candidate_id")
                            s = r.get("final_score", 0)
                            cand_data = cand_cache.get(cand_id, {})
                            name = cand_data.get("name", f"Candidate #{cand_id}")
                            exp_yrs = cand_data.get("experience_years") or 0
                            sc = score_color(s)
                            if rank == 1: medal, pc = "🥇", "podium-1"
                            elif rank == 2: medal, pc = "🥈", "podium-2"
                            else: medal, pc = "🥉", "podium-3"
                            podium_html += f"""
                            <div class="podium-place {pc}">
                                <span class="podium-medal">{medal}</span>
                                <div class="podium-name">{name}</div>
                                <div style="color:#64748b !important; font-size:0.7rem; margin-bottom:4px;">{exp_yrs} yrs exp</div>
                                <div class="podium-score" style="color: {sc} !important;">{s:.1f}%</div>
                                <div class="podium-score-label">ATS Score</div>
                            </div>"""
                        podium_html += '</div>'
                        st.markdown(podium_html, unsafe_allow_html=True)
                    st.markdown('<div class="section-divider"></div>', unsafe_allow_html=True)

                st.markdown('<h3 style="margin-bottom: 16px;">📋 Full List — Expand a candidate to see ATS details & reports</h3>', unsafe_allow_html=True)

                for r in rank_list:
                    rank = r.get("rank", "—")
                    cand_id = r.get("candidate_id", "—")
                    s = r.get("final_score", 0)
                    cand_data = cand_cache.get(cand_id, {})
                    name = cand_data.get("name", f"Candidate #{cand_id}")
                    email_addr = cand_data.get("email", "—")
                    cand_status = cand_data.get("status", "—")
                    sc = score_color(s)
                    if rank == 1: rank_display = '<span class="rank-medal">🥇</span>'
                    elif rank == 2: rank_display = '<span class="rank-medal">🥈</span>'
                    elif rank == 3: rank_display = '<span class="rank-medal">🥉</span>'
                    else: rank_display = f'<span class="rank-number">#{rank}</span>'
                    bar_width = min(s, 100)

                    st.markdown(f"""
                    <div class="rank-card">
                        <div class="rank-info">
                            {rank_display}
                            <div>
                                <div class="rank-name">{name}</div>
                                <div class="rank-email">{email_addr} · {cand_status}</div>
                            </div>
                        </div>
                        <div class="rank-score-block">
                            <div class="rank-score-value" style="color: {sc} !important;">{s:.1f}%</div>
                            <div class="rank-score-label">ATS Score</div>
                            <div class="rank-score-bar">
                                <div class="rank-score-bar-fill" style="width: {bar_width}%; background: {score_gradient(s)};"></div>
                            </div>
                        </div>
                    </div>
                    """, unsafe_allow_html=True)

                    with st.expander(f"📊 Full ATS Report — {name}", expanded=False):
                        try:
                            ats_res = requests.get(f"{BASE_URL}/candidates/{cand_id}/ats-score", headers=headers)
                            rec_res = requests.get(f"{BASE_URL}/candidates/{cand_id}/recommendation", headers=headers)
                            dec_res = requests.get(f"{BASE_URL}/candidates/{cand_id}/decision", headers=headers)
                            if ats_res.status_code == 200:
                                ats_data = ats_res.json()
                                rec_data = rec_res.json() if rec_res.status_code == 200 else None
                                dec_data = dec_res.json() if dec_res.status_code == 200 else None

                                render_ats_score_panel(cand_data, ats_data, rec_data)

                                # ── Decision Agent verdict ────────────────
                                if dec_data:
                                    d_verdict = dec_data.get("final_decision") or dec_data.get("verdict") or "—"
                                    d_confidence = dec_data.get("confidence_score") or dec_data.get("confidence") or 0
                                    d_reasoning = dec_data.get("reasoning") or dec_data.get("justification") or ""
                                    d_action = dec_data.get("recommended_action") or ""
                                    vc = verdict_css_class(d_verdict)
                                    
                                    reasoning_html = f'<div style="color:#94a3b8 !important; font-size:0.85rem; line-height:1.6; margin-bottom:10px;">{d_reasoning}</div>' if d_reasoning else ''
                                    action_html = f'<div style="padding:8px 14px; background:rgba(99,102,241,0.07) !important; border:1px solid rgba(99,102,241,0.15); border-radius:10px; color:#a5b4fc !important; font-size:0.82rem;">📋 Recommended Action: <b>{d_action}</b></div>' if d_action else ''
                                    
                                    st.markdown(f"""
                                    <div class="decision-card">
                                        <div class="decision-card-header">
                                            <span class="decision-card-icon">🤖</span>
                                            <div>
                                                <div class="decision-title">Decision Agent Recommendation</div>
                                                <div class="decision-subtitle">AI-driven hiring decision based on full profile analysis</div>
                                            </div>
                                        </div>
                                        <div style="display:flex; align-items:center; gap:14px; flex-wrap:wrap; margin-bottom:14px;">
                                            <span class="ats-verdict {vc}">🎯 {d_verdict}</span>
                                            <span style="color:#64748b !important; font-size:0.82rem;">Confidence: <b style="color:{score_color(d_confidence)} !important;">{d_confidence:.1f}%</b></span>
                                        </div>
                                        {reasoning_html}
                                        {action_html}
                                    </div>
                                    """, unsafe_allow_html=True)

                                # ── HR Candidate Decisions ────────────────
                                if show_decision_buttons:
                                    st.markdown("##### 💼 HR Candidate Decision")
                                    
                                    # Check if the candidate has completed their interview
                                    int_state = interview_status.get(cand_id, {})
                                    is_int_completed = int_state.get("is_completed", False)
                                    
                                    dec_col1, dec_col2 = st.columns(2)
                                    with dec_col1:
                                        if is_int_completed:
                                            if st.button("👍 Approve & Offer", key=f"app_cand_{cand_id}_{rank}", use_container_width=True):
                                                with st.spinner("Approving candidate..."):
                                                    res = requests.post(f"{BASE_URL}/candidates/{cand_id}/approve", headers=headers)
                                                if res.status_code == 200:
                                                    st.success(f"{name} status updated to Offered!")
                                                    if "_rankings_data" in st.session_state:
                                                        del st.session_state["_rankings_data"]
                                                    st.rerun()
                                                else:
                                                    st.error("Failed to approve.")
                                        else:
                                            st.button("👍 Approve & Offer", key=f"app_cand_{cand_id}_{rank}", disabled=True, use_container_width=True, help="Candidates must complete their AI interview before they can be approved.")
                                    with dec_col2:
                                        if st.button("👎 Reject Candidate", key=f"rej_cand_{cand_id}_{rank}", use_container_width=True):
                                            with st.spinner("Rejecting candidate..."):
                                                res = requests.post(f"{BASE_URL}/candidates/{cand_id}/reject", headers=headers)
                                            if res.status_code == 200:
                                                st.info(f"{name} status updated to Rejected.")
                                                if "_rankings_data" in st.session_state:
                                                    del st.session_state["_rankings_data"]
                                                st.rerun()
                                            else:
                                                st.error("Failed to reject.")

                                # ── Force-Complete Interview ──────────────
                                int_state = interview_status.get(cand_id, {})
                                if int_state and not int_state.get("is_completed", False):
                                    st.markdown("<br>", unsafe_allow_html=True)
                                    if st.button("🎙️ Force-Complete Interview", key=f"force_int_{cand_id}_{rank}", use_container_width=True, help="Force-close the interview and score unanswered questions as 0."):
                                        with st.spinner("Force closing interview..."):
                                            res = requests.post(f"{BASE_URL}/interviews/{int_state.get('interview_id')}/force-complete", headers=headers)
                                        if res.status_code == 200:
                                            st.success("Interview completed and scored successfully!")
                                            if "_rankings_data" in st.session_state:
                                                del st.session_state["_rankings_data"]
                                            st.rerun()
                                        else:
                                            st.error("Failed to force-complete interview.")

                                st.markdown("<br>", unsafe_allow_html=True)

                                # ── Download buttons (direct download) ────
                                resume_url = None
                                try:
                                    r_res = requests.get(f"{BASE_URL}/candidates/{cand_id}/resume-url", headers=headers)
                                    if r_res.status_code == 200:
                                        resume_url = r_res.json().get("resume_url")
                                except Exception:
                                    pass

                                dl_col1, dl_col2, dl_col3 = st.columns([1, 1, 1.2])
                                with dl_col1:
                                    pdf_res = requests.get(f"{BASE_URL}/candidates/{cand_id}/report/pdf", headers=headers)
                                    if pdf_res.status_code == 200:
                                        st.download_button(
                                            "📄 Download PDF Report",
                                            pdf_res.content,
                                            file_name=f"ats_report_{name.replace(' ','_')}_{cand_id}.pdf",
                                            mime="application/pdf",
                                            key=f"dl_pdf_{cand_id}_{rank}",
                                            use_container_width=True
                                        )
                                    else:
                                        st.button("📄 PDF Report", disabled=True, key=f"no_pdf_{cand_id}", use_container_width=True, help="PDF not available")
                                with dl_col2:
                                    xl_res = requests.get(f"{BASE_URL}/candidates/{cand_id}/report/excel", headers=headers)
                                    if xl_res.status_code == 200:
                                        st.download_button(
                                            "📊 Download Excel Report",
                                            xl_res.content,
                                            file_name=f"ats_report_{name.replace(' ','_')}_{cand_id}.xlsx",
                                            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                            key=f"dl_xl_{cand_id}_{rank}",
                                            use_container_width=True
                                        )
                                    else:
                                        st.button("📊 Excel Report", disabled=True, key=f"no_xl_{cand_id}", use_container_width=True, help="Excel not available")
                                with dl_col3:
                                    if resume_url:
                                        st.link_button("📄 View Resume", resume_url, use_container_width=True)
                                    else:
                                        st.button("📄 View Resume", disabled=True, key=f"no_res_{cand_id}_{rank}", use_container_width=True)
                            else:
                                st.warning("ATS score not yet available. Ensure the resume has been fully processed.")
                        except Exception as ex:
                            st.error(f"Could not load ATS data: {ex}")

            with tab_pending:
                render_rankings_list(pending_rankings, show_podium=True, show_decision_buttons=True)
            with tab_completed:
                render_rankings_list(completed_rankings, show_podium=False, show_decision_buttons=True)
            with tab_approved:
                render_rankings_list(approved_rankings, show_podium=False, show_decision_buttons=False)
            with tab_rejected:
                render_rankings_list(rejected_rankings, show_podium=False, show_decision_buttons=False)

        elif ranking_job_id:
            st.markdown('<div class="empty-state"><span class="empty-icon">🏆</span><h3>No rankings loaded</h3><p>Click "Load Rankings" to fetch AI-ranked candidates for this job.</p></div>', unsafe_allow_html=True)


    elif selected_page == "Interview":
        st.markdown("""
        <div class="page-header">
            <div class="page-header-icon">🎙️</div>
            <div><h1 style="margin:0; font-size:1.8rem !important;">AI Interview Panel</h1></div>
        </div>
        <p class="page-subtitle">5–6 tailored questions per candidate · AI-scored answers · automatic completion</p>
        """, unsafe_allow_html=True)

        tab_setup, tab_conduct, tab_interviewed, tab_results = st.tabs([
            "🔧  Setup Interview", 
            "💬  Conduct Interview", 
            "📋  All Interviewed Candidates",
            "📊  Results"
        ])

        # ── Tab 1: Setup ──────────────────────────────────────────────────
        with tab_setup:
            st.markdown('<div class="glass-card">', unsafe_allow_html=True)
            
            # If a candidate is NOT selected for setup yet, show candidate list
            active_cid = st.session_state.get("active_interview_cand_id")
            if not active_cid:
                st.markdown("""<div class="form-section"><div class="form-section-icon">🎯</div><span class="form-section-text">Select Job to View Candidates</span></div>""", unsafe_allow_html=True)
                
                # Fetch list of jobs
                jobs_list = []
                try:
                    jobs_res = requests.get(f"{BASE_URL}/jobs", headers=headers)
                    if jobs_res.status_code == 200:
                        jobs_list = jobs_res.json()
                except Exception:
                    pass
                
                if not jobs_list:
                    st.warning("No jobs found. Please create a job posting first.")
                else:
                    job_options = {f"{j.get('title')} ({j.get('department')}) - ID {j.get('id')}": j for j in jobs_list}
                    selected_job_label = st.selectbox("Select a Job", list(job_options.keys()), key="setup_job_select")
                    selected_job = job_options[selected_job_label]
                    job_id = selected_job.get("id")
                    
                    # Show job description and required skills
                    skills_text = ", ".join(selected_job.get('skills_required', [])) or "—"
                    st.markdown(f"""
                    <div class="job-desc-banner">
                        <h4>💼 {selected_job.get('title')} &nbsp;·&nbsp; {selected_job.get('department')} &nbsp;·&nbsp; {selected_job.get('location')}</h4>
                        <p>{selected_job.get('full_description')}</p>
                        <p style="margin-top:6px;">🛠 Required skills: <b style="color:#a78bfa !important;">{skills_text}</b></p>
                    </div>
                    """, unsafe_allow_html=True)
                    
                    st.markdown('<div class="section-divider"></div>', unsafe_allow_html=True)
                    st.markdown("<h3 style='margin-bottom:12px;'>👥 Candidates Applied</h3>", unsafe_allow_html=True)
                    
                    # Fetch candidates
                    cands_list = []
                    try:
                        cands_res = requests.get(f"{BASE_URL}/jobs/{job_id}/candidates", headers=headers)
                        if cands_res.status_code == 200:
                            cands_list = cands_res.json()
                    except Exception:
                        pass
                    
                    # Fetch rankings
                    rankings_list = []
                    try:
                        rank_res = requests.get(f"{BASE_URL}/jobs/{job_id}/rankings", headers=headers)
                        if rank_res.status_code == 200:
                            rankings_list = rank_res.json()
                    except Exception:
                        pass
                        
                    rank_map = {r.get("candidate_id"): (r.get("rank"), r.get("final_score")) for r in rankings_list}
                    
                    def get_candidate_sort_key(cand):
                        cid = cand.get("id")
                        if cid in rank_map:
                            return (0, rank_map[cid][0])
                        return (1, cid)
                        
                    sorted_candidates = sorted(cands_list, key=get_candidate_sort_key)
                    
                    if "hide_interviewed_in_setup" not in st.session_state:
                        st.session_state["hide_interviewed_in_setup"] = False
                    
                    # Fetch interview results to know if interview is completed
                    interview_results = []
                    try:
                        results_res = requests.get(f"{BASE_URL}/interviews/job/{job_id}/results", headers=headers)
                        if results_res.status_code == 200:
                            interview_results = results_res.json().get("results", [])
                    except Exception:
                        pass
                    completed_cand_ids = {item.get("candidate_id") for item in interview_results if item.get("is_completed")}
                    
                    display_candidates = []
                    for cand in sorted_candidates:
                        cid = cand.get("id")
                        is_interview_done = (cid in completed_cand_ids) or (cand.get('status') in ("Offered", "Rejected", "Interview Completed"))
                        if st.session_state["hide_interviewed_in_setup"] and is_interview_done:
                            continue
                        display_candidates.append((cand, is_interview_done))
                    
                    if sorted_candidates:
                        btn_col_archive, _ = st.columns([5, 3])
                        with btn_col_archive:
                            btn_label = "📁 Move Interviewed Candidates to Separate Tab" if not st.session_state["hide_interviewed_in_setup"] else "🔓 Show All Candidates in Setup List"
                            if st.button(btn_label, key="toggle_archive_btn"):
                                st.session_state["hide_interviewed_in_setup"] = not st.session_state["hide_interviewed_in_setup"]
                                st.rerun()
                    
                    if not display_candidates:
                        st.markdown("""<div class="empty-state"><span class="empty-icon">👥</span><h3>No candidates applied</h3><p>Upload resumes for this job to start screening candidates.</p></div>""", unsafe_allow_html=True)
                    else:
                        for cand, is_interview_done in display_candidates:
                            cid = cand.get("id")
                            c_rank, c_score = rank_map.get(cid, ("—", None))
                            score_str = f"ATS Score: {c_score:.1f}%" if c_score is not None else "ATS Score: Pending"
                            
                            # Get resume url
                            resume_url = None
                            if cand.get("s3_key"):
                                try:
                                    r_res = requests.get(f"{BASE_URL}/candidates/{cid}/resume-url", headers=headers)
                                    if r_res.status_code == 200:
                                        resume_url = r_res.json().get("resume_url")
                                except Exception:
                                    pass
                                    
                            skills_list = cand.get("skills") or []
                            skills_str = ", ".join(skills_list[:6]) or "—"
                            exp_yrs = cand.get("experience_years") or 0.0
                            
                            st.markdown(f"""
                            <div style="background:rgba(99,102,241,0.04) !important; border:1px solid rgba(99,102,241,0.1); border-radius:12px; padding:16px 20px; margin:16px 0;">
                                <div style="display:flex; justify-content:space-between; align-items:center;">
                                    <span style="color:#e0e7ff !important; font-weight:600; font-size:0.95rem;">👤 {cand.get('name')}</span>
                                    <span class="badge badge-sent" style="padding: 4px 10px; font-size: 0.75rem;">Rank #{c_rank} ({score_str})</span>
                                </div>
                                <div style="color:#94a3b8 !important; font-size:0.82rem; margin-top:6px;">📧 {cand.get('email')} &nbsp;·&nbsp; 💼 {exp_yrs} yrs exp &nbsp;·&nbsp; 📊 Status: {cand.get('status')}</div>
                                <div style="color:#64748b !important; font-size:0.82rem; margin-top:4px;">🛠 Skills: {skills_str}</div>
                            </div>
                            """, unsafe_allow_html=True)
                            
                            btn_col1, btn_col2, _ = st.columns([2.5, 2.5, 3])
                            with btn_col1:
                                if is_interview_done:
                                    st.button("🎙️ Setup Interview", key=f"setup_btn_{cid}", disabled=True, use_container_width=True, help="Interview has already been completed.")
                                else:
                                    if st.button("🎙️ Setup Interview", key=f"setup_btn_{cid}", use_container_width=True):
                                        st.session_state["active_interview_cand_id"] = cid
                                        st.session_state["active_interview_cand_name"] = cand.get('name')
                                        st.rerun()
                            with btn_col2:
                                if resume_url:
                                    st.link_button("📄 View Resume", resume_url, use_container_width=True)
                                else:
                                    st.button("📄 View Resume", disabled=True, key=f"setup_view_res_dis_{cid}", use_container_width=True)
            
            else:
                st.markdown("""<div class="form-section"><div class="form-section-icon">⚙️</div><span class="form-section-text">Preview and Edit Interview Questions</span></div>""", unsafe_allow_html=True)
                st.markdown(f"#### Candidate: **{st.session_state.get('active_interview_cand_name')}** (ID: {active_cid})")
                
                # Fetch/setup interview questions
                # Call setup_interview API endpoint
                with st.spinner("AI is generating/loading tailored interview questions..."):
                    try:
                        res = requests.post(f"{BASE_URL}/interviews/setup/{active_cid}", headers=headers)
                        if res.status_code == 200:
                            result = res.json()
                            iid = result.get("interview_id")

                            # Retry fetching questions — LLM generation may take a few seconds
                            # after setup returns, especially on first-time generation.
                            import time as _time
                            MAX_RETRIES = 6
                            RETRY_DELAY = 2  # seconds between each retry
                            questions = None
                            for attempt in range(1, MAX_RETRIES + 1):
                                qs_res = requests.get(f"{BASE_URL}/interviews/{iid}/questions", headers=headers)
                                if qs_res.status_code == 200:
                                    questions = qs_res.json()
                                    if questions:
                                        break
                                # Questions not ready yet — wait and retry
                                if attempt < MAX_RETRIES:
                                    _time.sleep(RETRY_DELAY)

                            if questions:
                                st.markdown("""
                                <div style="background: rgba(99, 102, 241, 0.06) !important; border: 1px solid rgba(99, 102, 241, 0.1); border-radius: 14px; padding: 16px 20px; margin-bottom: 20px;">
                                    <p style="margin: 0; font-size: 0.85rem; color: #94a3b8 !important;">
                                        🤖 AI generated <b>exactly 6 questions</b>: 3 Technical · 1 Behavioral · 1 Situational · 1 System Design. You can preview and edit any question text below.
                                    </p>
                                </div>
                                """, unsafe_allow_html=True)
                                
                                for idx, q in enumerate(questions):
                                    q_id = q.get("id")
                                    q_text = q.get("question_text")
                                    q_category = q.get("category", "Technical")
                                    q_diff = q.get("difficulty", "Medium")
                                    
                                    st.markdown(f"**Question {idx+1} ({q_category} - {q_diff})**")
                                    new_q_text = st.text_area(
                                        f"Question text for Q{idx+1}",
                                        value=q_text,
                                        key=f"edit_q_{q_id}",
                                        height=80,
                                        label_visibility="collapsed"
                                    )
                                    
                                    if new_q_text != q_text:
                                        if st.button("💾 Save Question Changes", key=f"save_q_btn_{q_id}"):
                                            with st.spinner("Saving question..."):
                                                put_res = requests.put(
                                                    f"{BASE_URL}/interviews/questions/{q_id}",
                                                    json={"question_text": new_q_text},
                                                    headers=headers
                                                )
                                            if put_res.status_code == 200:
                                                st.success("Question updated successfully in database!")
                                                st.rerun()
                                            else:
                                                st.error("Failed to update question.")
                                
                                st.markdown('<div class="section-divider"></div>', unsafe_allow_html=True)

                                st.markdown("#### Schedule candidate video interview")
                                sched_col1, sched_col2, sched_tz_col, sched_col3 = st.columns([1, 1, 1, 1.5])
                                with sched_col1:
                                    scheduled_date = st.date_input("Interview date", value=datetime.now().date(), key=f"sched_date_{iid}")
                                with sched_col2:
                                    scheduled_time = st.time_input("Interview time", value=datetime.now().time().replace(second=0, microsecond=0), key=f"sched_time_{iid}")
                                with sched_tz_col:
                                    timezone_options = ["Asia/Kolkata (IST)", "UTC", "America/New_York (EST/EDT)", "Europe/London (GMT/BST)"]
                                    tz_selection = st.selectbox("Timezone", timezone_options, index=0, key=f"sched_tz_{iid}")
                                with sched_col3:
                                    base_join_url = st.text_input(
                                        "Public backend URL",
                                        value=os.environ.get("INTERVIEW_PUBLIC_BASE_URL", "http://localhost:8000"),
                                        key=f"sched_base_url_{iid}",
                                        help="Use your deployed backend URL when emailing real candidates. Set INTERVIEW_PUBLIC_BASE_URL env var to avoid typing this each time."
                                    )
                                if st.button("Send Unique Candidate Join Link", key=f"schedule_interview_{iid}", use_container_width=True):
                                    from zoneinfo import ZoneInfo
                                    from datetime import timezone
                                    scheduled_dt = datetime.combine(scheduled_date, scheduled_time)
                                    tz_map = {
                                        "Asia/Kolkata (IST)": "Asia/Kolkata",
                                        "UTC": "UTC",
                                        "America/New_York (EST/EDT)": "America/New_York",
                                        "Europe/London (GMT/BST)": "Europe/London"
                                    }
                                    tz_name = tz_map[tz_selection]
                                    local_dt = scheduled_dt.replace(tzinfo=ZoneInfo(tz_name))
                                    utc_dt = local_dt.astimezone(timezone.utc)
                                    payload = {
                                        "scheduled_at": utc_dt.replace(tzinfo=None).isoformat(),
                                        "base_join_url": base_join_url.strip() or "http://localhost:8000",
                                    }
                                    with st.spinner("Scheduling interview and sending interview invitation..."):
                                        schedule_res = requests.post(
                                            f"{BASE_URL}/interviews/{iid}/schedule",
                                            json=payload,
                                            headers=headers,
                                        )
                                    if schedule_res.status_code == 200:
                                        schedule_data = schedule_res.json()
                                        st.success("Interview scheduled. Invitation email sent." if schedule_data.get("email_sent") else "Interview scheduled, but email failed. Check Gmail API configuration.")
                                        st.code(schedule_data.get("join_link", ""), language="text")
                                    else:
                                        st.error(f"Failed to schedule interview: {schedule_res.text}")
                                
                                # Go to conduct interview or back to list
                                action_col1, action_col2, _ = st.columns([2.5, 2.5, 3])
                                with action_col1:
                                    if st.button("🔙 Back to Candidates List", key="back_to_cands"):
                                        st.session_state["active_interview_cand_id"] = None
                                        st.rerun()
                                with action_col2:
                                    if st.button("🎙️ Conduct Interview Now", key="go_to_conduct"):
                                        st.session_state["_last_created_interview_id"] = iid
                                        st.session_state["active_interview_cand_id"] = None
                                        # Force load of the interview on next refresh
                                        sess_key = int(iid)
                                        st.session_state["interview_session"][sess_key] = {"loaded": False, "questions": [], "current_idx": 0, "answers": []}
                                        st.rerun()
                            else:
                                st.error("⚠️ Questions could not be loaded after multiple retries. The AI may still be generating them — please wait a moment and refresh this page.")
                        else:
                            if res.status_code == 404:
                                st.warning("⚠️ The selected candidate could not be found in the database (they may have been deleted during a database reset).")
                                if st.button("🔙 Return to Candidates List", key="ret_to_cands"):
                                    st.session_state["active_interview_cand_id"] = None
                                    st.rerun()
                            else:
                                st.error(f"Failed to generate questions. Status: {res.status_code}")
                    except Exception as e:
                        st.error(f"Error setting up interview: {e}")
            
            st.markdown('</div>', unsafe_allow_html=True)


        # ── Tab 2: Conduct ────────────────────────────────────────────────
        with tab_conduct:
            st.markdown('<div class="glass-card">', unsafe_allow_html=True)
            st.markdown("""<div class="form-section"><div class="form-section-icon">📋</div><span class="form-section-text">Interview Session</span></div>""", unsafe_allow_html=True)

            col_iid, _ = st.columns([1, 2])
            with col_iid:
                default_iid = st.session_state.get("_last_created_interview_id", 1)
                interview_id = st.number_input("Interview ID", min_value=1, value=int(default_iid), key="conduct_iid")

            # Initialize session for this interview
            sess_key = int(interview_id)
            if sess_key not in st.session_state["interview_session"]:
                st.session_state["interview_session"][sess_key] = {"loaded": False, "questions": [], "current_idx": 0, "answers": []}
            sess = st.session_state["interview_session"][sess_key]

            load_col, _ = st.columns([1, 2])
            with load_col:
                load_btn = st.button("📥  Load / Refresh Interview", key="load_interview_btn")

            if load_btn:
                with st.spinner("Loading interview..."):
                    try:
                        state_res = requests.get(f"{BASE_URL}/interviews/{interview_id}", headers=headers)
                        qs_res = requests.get(f"{BASE_URL}/interviews/{interview_id}/questions", headers=headers)
                        ans_res = requests.get(f"{BASE_URL}/interviews/{interview_id}/answers", headers=headers)

                        if state_res.status_code == 200:
                            state = state_res.json()
                            questions = qs_res.json() if qs_res.status_code == 200 else []
                            sess["questions"] = questions
                            sess["current_idx"] = state.get("answered_count", 0)
                            sess["total"] = state.get("total_questions", len(questions))
                            sess["is_completed"] = state.get("is_completed", False)
                            sess["overall_score"] = state.get("overall_score", None)
                            sess["loaded"] = True
                            
                            if ans_res.status_code == 200:
                                sess["answers"] = [
                                    {
                                        "question_text": a.get("question_text"),
                                        "answer": a.get("candidate_answer"),
                                        "score": a.get("score"),
                                        "feedback": a.get("feedback"),
                                    }
                                    for a in ans_res.json()
                                ]
                            else:
                                sess["answers"] = []
                            st.rerun()
                        else:
                            st.warning(f"Could not load interview. Status: {state_res.status_code}")
                    except Exception as e:
                        st.error(f"Backend connection failed: {e}")

            if sess.get("loaded"):
                questions = sess.get("questions", [])
                total_q = len(questions)
                current_idx = sess.get("current_idx", 0)
                is_completed = sess.get("is_completed", False)

                # ── Completion state ──────────────────────────────────────
                if is_completed:
                    overall = sess.get("overall_score") or 0
                    sc = score_color(overall)
                    radius = 50
                    circ = 2 * 3.14159 * radius
                    dash = circ * (overall / 100)
                    gap = circ - dash
                    st.markdown(f"""
                    <div class="interview-complete-card">
                        <div style="font-size:2.5rem; margin-bottom:12px;">🎉</div>
                        <div style="color:#e0e7ff !important; font-weight:700; font-size:1.3rem; margin-bottom:6px;">Interview Complete!</div>
                        <div style="display:flex; justify-content:center; margin:16px 0;">
                            <div style="position:relative; width:120px; height:120px;">
                                <svg width="120" height="120" viewBox="0 0 120 120" style="transform:rotate(-90deg)">
                                    <circle cx="60" cy="60" r="{radius}" fill="none" stroke="rgba(99,102,241,0.1)" stroke-width="10"/>
                                    <circle cx="60" cy="60" r="{radius}" fill="none" stroke="{sc}" stroke-width="10" stroke-linecap="round" stroke-dasharray="{dash:.1f} {gap:.1f}"/>
                                </svg>
                                <div style="position:absolute; top:50%; left:50%; transform:translate(-50%,-50%); text-align:center;">
                                    <div style="font-family:'JetBrains Mono',monospace; font-size:1.6rem; font-weight:800; color:{sc} !important;">{overall:.0f}%</div>
                                    <div style="font-size:0.6rem; color:#64748b !important; text-transform:uppercase; letter-spacing:0.08em;">Score</div>
                                </div>
                            </div>
                        </div>
                        <div style="color:#94a3b8 !important; font-size:0.88rem;">All {total_q} questions answered · AI recommendation has been updated</div>
                    </div>
                    """, unsafe_allow_html=True)
                    
                    st.markdown("<br><h3 style='margin-bottom:16px;'>📋 Interview Transcript</h3>", unsafe_allow_html=True)
                    for idx, ans in enumerate(sess.get("answers", [])):
                        q_text = ans.get("question_text", "")
                        cand_ans = ans.get("answer", "")
                        score = ans.get("score") or 0.0
                        feedback = ans.get("feedback", "")
                        st.markdown(f"""
                        <div style="margin-bottom:16px; padding:16px 20px; background:rgba(99,102,241,0.04) !important; border:1px solid rgba(99,102,241,0.1); border-radius:12px;">
                            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
                                <span style="color:#a78bfa !important; font-weight:600; font-size:0.9rem;">Question {idx+1}</span>
                                <span class="badge" style="background:rgba(99,102,241,0.1); color:#c7d2fe; border:1px solid rgba(99,102,241,0.25);">Score: {score:.1f}%</span>
                            </div>
                            <div style="color:#e0e7ff !important; font-size:0.88rem; margin-bottom:10px; font-weight:500;">Q: {q_text}</div>
                            <div style="color:#94a3b8 !important; font-size:0.85rem; margin-bottom:8px; line-height:1.5;"><b>Answer:</b> {cand_ans}</div>
                            <div style="color:#64748b !important; font-size:0.8rem; border-top:1px dashed rgba(99,102,241,0.1); padding-top:6px; margin-top:6px;">💡 <b>Feedback:</b> {feedback}</div>
                        </div>
                        """, unsafe_allow_html=True)

                else:
                    # ── Question progress tracker ─────────────────────────
                    tracker_html = '<div class="q-tracker">'
                    for i in range(total_q):
                        if i < current_idx:
                            cls = "q-dot q-dot-done"
                            label = "✓"
                        elif i == current_idx:
                            cls = "q-dot q-dot-current"
                            label = str(i + 1)
                        else:
                            cls = "q-dot q-dot-todo"
                            label = str(i + 1)
                        tracker_html += f'<div class="{cls}">{label}</div>'
                    tracker_html += f'<span style="color:#64748b !important; font-size:0.8rem; margin-left:8px; align-self:center;">{current_idx}/{total_q} done</span>'
                    tracker_html += '</div>'
                    st.markdown(tracker_html, unsafe_allow_html=True)

                    # Progress bar
                    st.progress(current_idx / total_q if total_q > 0 else 0,
                                text=f"Question {current_idx + 1} of {total_q}")

                    if current_idx < total_q:
                        current_q = questions[current_idx]
                        q_text     = current_q.get("question_text", "")
                        q_category = current_q.get("category", "General")
                        q_diff     = current_q.get("difficulty", "Medium")
                        q_id       = current_q.get("id")
                        diff_class = {"Easy": "badge-sent", "Medium": "badge-pending", "Hard": "badge-danger"}.get(q_diff, "badge-pending")

                        # Show all previous Q&A history
                        if sess.get("answers"):
                            with st.expander(f"📜 Previous answers ({len(sess['answers'])} answered)", expanded=False):
                                for prev in sess["answers"]:
                                    prev_q = prev.get("question_text", "")
                                    prev_a = prev.get("answer", "")
                                    prev_s = prev.get("score", 0)
                                    prev_f = prev.get("feedback", "")
                                    prev_sc = score_color(prev_s)
                                    st.markdown(f"""
                                    <div style="margin-bottom:14px; padding:12px 16px; background:rgba(15,23,42,0.6) !important; border:1px solid rgba(99,102,241,0.1); border-radius:12px;">
                                        <div style="color:#a78bfa !important; font-size:0.8rem; font-weight:600; margin-bottom:6px;">Q: {prev_q[:80]}{'…' if len(prev_q)>80 else ''}</div>
                                        <div style="color:#64748b !important; font-size:0.78rem; margin-bottom:6px;">A: {prev_a[:100]}{'…' if len(prev_a)>100 else ''}</div>
                                        <div style="display:flex; align-items:center; gap:8px;">
                                            <span style="color:{prev_sc} !important; font-family:'JetBrains Mono',monospace; font-size:0.88rem; font-weight:700;">{prev_s:.0f}/100</span>
                                            <span style="color:#475569 !important; font-size:0.75rem;">{prev_f[:60]}{'…' if len(prev_f)>60 else ''}</span>
                                        </div>
                                    </div>
                                    """, unsafe_allow_html=True)

                        # Current question bubble
                        st.markdown(f"""
                        <div class="chat-question">
                            <div class="q-category">
                                <span class="badge badge-pending">{q_category}</span>
                                <span class="badge {diff_class}">{q_diff}</span>
                                <span style="color:#475569 !important; font-size:0.75rem; margin-left:4px;">Q{current_idx+1}/{total_q}</span>
                            </div>
                            <div class="q-text">{q_text}</div>
                        </div>
                        """, unsafe_allow_html=True)

                        # Answer input
                        answer_text = st.text_area(
                            "Candidate's Answer",
                            height=130,
                            placeholder="Type the candidate's response here...",
                            key=f"answer_input_{interview_id}_{current_idx}"
                        )

                        submit_col, skip_col, _ = st.columns([1.5, 1, 2])
                        with submit_col:
                            submit_btn = st.button("📨  Submit & Evaluate", use_container_width=True, key=f"submit_btn_{interview_id}_{current_idx}")
                        with skip_col:
                            skip_btn = st.button("⏭ Skip", use_container_width=True, key=f"skip_btn_{interview_id}_{current_idx}")

                        if submit_btn:
                            if not answer_text.strip():
                                st.warning("Please enter an answer before submitting.")
                            else:
                                with st.spinner("AI is evaluating the answer..."):
                                    payload = {"question_id": q_id, "candidate_answer": answer_text}
                                    res = requests.post(f"{BASE_URL}/interviews/{interview_id}/answer", json=payload, headers=headers)

                                if res.status_code == 200:
                                    result = res.json()
                                    eval_score = result.get("score", 0)
                                    feedback   = result.get("feedback", "")
                                    sc_color   = score_color(eval_score)

                                    # Store in session
                                    sess["answers"].append({
                                        "question_text": q_text,
                                        "answer": answer_text,
                                        "score": eval_score,
                                        "feedback": feedback,
                                    })
                                    sess["current_idx"] = current_idx + 1

                                    # Show result
                                    st.markdown(f"""
                                    <div class="chat-answer-result">
                                        <div style="display: flex; align-items: center; gap: 16px; margin-bottom: 14px;">
                                            <div style="width:64px; height:64px; border-radius:50%; background:conic-gradient({sc_color} {eval_score*3.6}deg, rgba(99,102,241,0.1) 0deg); display:flex; align-items:center; justify-content:center; flex-shrink:0;">
                                                <div style="width:52px; height:52px; border-radius:50%; background:#0c0e27; display:flex; align-items:center; justify-content:center; font-family:'JetBrains Mono',monospace; font-weight:800; font-size:1rem; color:{sc_color} !important;">{eval_score:.0f}</div>
                                            </div>
                                            <div>
                                                <div style="color:{sc_color} !important; font-weight:700; font-size:0.95rem;">Score: {eval_score:.0f}/100</div>
                                                <div style="color:#475569 !important; font-size:0.78rem;">AI Evaluation Result</div>
                                            </div>
                                        </div>
                                        <div style="color:#94a3b8 !important; font-size:0.9rem; line-height:1.7;">{feedback}</div>
                                    </div>
                                    """, unsafe_allow_html=True)

                                    # Check if completed
                                    if sess["current_idx"] >= total_q:
                                        sess["is_completed"] = True
                                        st.success("🎉 All questions answered! The interview is now complete.")

                                    st.rerun()
                                else:
                                    st.error(f"Submission failed. Status: {res.status_code} — {res.text[:200]}")

                        if skip_btn:
                            # Submit empty answer to advance
                            with st.spinner("Skipping question..."):
                                payload = {"question_id": q_id, "candidate_answer": "[Skipped]"}
                                requests.post(f"{BASE_URL}/interviews/{interview_id}/answer", json=payload, headers=headers)
                            sess["answers"].append({"question_text": q_text, "answer": "[Skipped]", "score": 0, "feedback": "Question was skipped."})
                            sess["current_idx"] = current_idx + 1
                            if sess["current_idx"] >= total_q:
                                sess["is_completed"] = True
                            st.rerun()

                    else:
                        # All answered but not yet marked complete by server
                        st.info("All questions have been submitted. Waiting for the server to finalise the interview score...")
                        if st.button("🔄 Refresh Status", key="refresh_status_btn"):
                            try:
                                state_res = requests.get(f"{BASE_URL}/interviews/{interview_id}", headers=headers)
                                if state_res.status_code == 200:
                                    state = state_res.json()
                                    sess["is_completed"] = state.get("is_completed", False)
                                    sess["overall_score"] = state.get("overall_score", None)
                                    st.rerun()
                            except Exception:
                                st.error("Backend connection failed.")

            else:
                st.markdown("""
                <div class="empty-state">
                    <span class="empty-icon">🎙️</span>
                    <h3>No interview loaded</h3>
                    <p>Enter an Interview ID and click "Load / Refresh Interview" to begin</p>
                </div>
                """, unsafe_allow_html=True)

            st.markdown('</div>', unsafe_allow_html=True)


    # ══════════════════════════════════════════════════════════════════════

        # ── Tab 3: All Interviewed Candidates ─────────────────────────────
        with tab_interviewed:
            st.markdown('<div class="glass-card">', unsafe_allow_html=True)
            st.markdown("""<div class="form-section"><div class="form-section-icon">📋</div><span class="form-section-text">All Interviewed Candidates</span></div>""", unsafe_allow_html=True)
            
            jobs_list = []
            try:
                jobs_res = requests.get(f"{BASE_URL}/jobs", headers=headers)
                if jobs_res.status_code == 200:
                    jobs_list = jobs_res.json()
            except Exception:
                pass
            
            if not jobs_list:
                st.warning("No jobs found. Please create a job posting first.")
            else:
                job_options = {f"{j.get('title')} ({j.get('department')}) - ID {j.get('id')}": j for j in jobs_list}
                selected_job_label = st.selectbox("Select a Job to View Interviewed Candidates", list(job_options.keys()), key="interviewed_job_select")
                selected_job = job_options[selected_job_label]
                job_id = selected_job.get("id")
                
                # Fetch candidates
                cands_list = []
                try:
                    cands_res = requests.get(f"{BASE_URL}/jobs/{job_id}/candidates", headers=headers)
                    if cands_res.status_code == 200:
                        cands_list = cands_res.json()
                except Exception:
                    pass
                
                # Fetch rankings
                rankings_list = []
                try:
                    rank_res = requests.get(f"{BASE_URL}/jobs/{job_id}/rankings", headers=headers)
                    if rank_res.status_code == 200:
                        rankings_list = rank_res.json()
                except Exception:
                    pass
                
                rank_map = {r.get("candidate_id"): (r.get("rank"), r.get("final_score")) for r in rankings_list}
                
                # Fetch interview results
                interview_results = []
                try:
                    results_res = requests.get(f"{BASE_URL}/interviews/job/{job_id}/results", headers=headers)
                    if results_res.status_code == 200:
                        interview_results = results_res.json().get("results", [])
                except Exception:
                    pass
                completed_cand_ids = {item.get("candidate_id") for item in interview_results if item.get("is_completed")}
                
                interviewed_candidates = []
                for cand in cands_list:
                    cid = cand.get("id")
                    is_interview_done = (cid in completed_cand_ids) or (cand.get('status') in ("Offered", "Rejected", "Interview Completed"))
                    if is_interview_done:
                        interviewed_candidates.append(cand)
                
                def get_candidate_sort_key_interviewed(cand):
                    cid = cand.get("id")
                    if cid in rank_map:
                        return (0, rank_map[cid][0])
                    return (1, cid)
                
                sorted_interviewed = sorted(interviewed_candidates, key=get_candidate_sort_key_interviewed)
                
                if not sorted_interviewed:
                    st.markdown("""<div class="empty-state"><span class="empty-icon">👥</span><h3>No interviewed candidates</h3><p>Interviewed candidates for this job will appear here.</p></div>""", unsafe_allow_html=True)
                else:
                    for cand in sorted_interviewed:
                        cid = cand.get("id")
                        c_rank, c_score = rank_map.get(cid, ("—", None))
                        score_str = f"ATS Score: {c_score:.1f}%" if c_score is not None else "ATS Score: Pending"
                        
                        resume_url = None
                        if cand.get("s3_key"):
                            try:
                                r_res = requests.get(f"{BASE_URL}/candidates/{cid}/resume-url", headers=headers)
                                if r_res.status_code == 200:
                                    resume_url = r_res.json().get("resume_url")
                            except Exception:
                                pass
                                
                        skills_list = cand.get("skills") or []
                        skills_str = ", ".join(skills_list[:6]) or "—"
                        exp_yrs = cand.get("experience_years") or 0.0
                        
                        st.markdown(f"""
                        <div style="background:rgba(99,102,241,0.04) !important; border:1px solid rgba(99,102,241,0.1); border-radius:12px; padding:16px 20px; margin:16px 0;">
                            <div style="display:flex; justify-content:space-between; align-items:center;">
                                <span style="color:#e0e7ff !important; font-weight:600; font-size:0.95rem;">👤 {cand.get('name')}</span>
                                <span class="badge badge-sent" style="padding: 4px 10px; font-size: 0.75rem;">Rank #{c_rank} ({score_str})</span>
                            </div>
                            <div style="color:#94a3b8 !important; font-size:0.82rem; margin-top:6px;">📧 {cand.get('email')} &nbsp;·&nbsp; 💼 {exp_yrs} yrs exp &nbsp;·&nbsp; 📊 Status: {cand.get('status')}</div>
                            <div style="color:#64748b !important; font-size:0.82rem; margin-top:4px;">🛠 Skills: {skills_str}</div>
                        </div>
                        """, unsafe_allow_html=True)
                        
                        btn_col1, btn_col2, _ = st.columns([2.5, 2.5, 3])
                        with btn_col1:
                            st.button("🎙️ Setup Interview", key=f"setup_btn_interviewed_page_{cid}", disabled=True, use_container_width=True, help="Interview has already been completed.")
                        with btn_col2:
                            if resume_url:
                                st.link_button("📄 View Resume", resume_url, use_container_width=True, key=f"view_res_interviewed_page_{cid}")
                            else:
                                st.button("📄 View Resume", disabled=True, key=f"setup_view_res_dis_interviewed_page_{cid}", use_container_width=True)
            st.markdown('</div>', unsafe_allow_html=True)

        with tab_results:
            st.markdown('<div class="glass-card">', unsafe_allow_html=True)
            st.markdown("""<div class="form-section"><div class="form-section-icon">📊</div><span class="form-section-text">Interview Results</span></div>""", unsafe_allow_html=True)

            jobs_list = []
            try:
                jobs_res = requests.get(f"{BASE_URL}/jobs", headers=headers)
                if jobs_res.status_code == 200:
                    jobs_list = jobs_res.json()
            except Exception as e:
                st.error(f"Backend connection failed: {e}")

            if not jobs_list:
                st.warning("No jobs found. Create a job and schedule interviews first.")
            else:
                job_options = {f"{j.get('title')} ({j.get('department')}) - ID {j.get('id')}": j for j in jobs_list}
                selected_results_job_label = st.selectbox("Select job for results", list(job_options.keys()), key="results_job_select")
                selected_results_job = job_options[selected_results_job_label]
                results_job_id = selected_results_job.get("id")

                if st.button("Load Interview Results", key="load_interview_results", use_container_width=True):
                    with st.spinner("Loading interview results..."):
                        try:
                            results_res = requests.get(f"{BASE_URL}/interviews/job/{results_job_id}/results", headers=headers)
                            if results_res.status_code == 200:
                                st.session_state["interview_results_payload"] = results_res.json()
                            else:
                                st.error(f"Could not load results: {results_res.text}")
                        except Exception as e:
                            st.error(f"Backend connection failed: {e}")

                results_payload = st.session_state.get("interview_results_payload")
                if results_payload and results_payload.get("job_id") == results_job_id:
                    results = results_payload.get("results", [])
                    if not results:
                        st.markdown("""<div class="empty-state"><span class="empty-icon">📭</span><h3>No interview results yet</h3><p>Completed candidate interviews will appear here.</p></div>""", unsafe_allow_html=True)
                    else:
                        st.caption("Sorted by interview evaluation score, highest first.")
                        for rank_idx, item in enumerate(results, start=1):
                            overall = item.get("overall_score")
                            score_text = f"{overall:.1f}%" if overall is not None else "Pending"
                            score_value = overall or 0
                            sc = score_color(score_value)
                            completed_label = "Completed" if item.get("is_completed") else f"{item.get('answered_count', 0)}/{item.get('total_questions', 0)} answered"

                            st.markdown(f"""
                            <div style="background:rgba(99,102,241,0.04) !important; border:1px solid rgba(99,102,241,0.1); border-radius:12px; padding:16px 20px; margin:16px 0;">
                                <div style="display:flex; justify-content:space-between; gap:16px; align-items:center;">
                                    <div>
                                        <div style="color:#e0e7ff !important; font-weight:700;">#{rank_idx} {item.get('candidate_name')} <span style="color:#64748b !important; font-weight:500;">({item.get('candidate_email')})</span></div>
                                        <div style="color:#94a3b8 !important; font-size:0.82rem; margin-top:4px;">Interview ID: {item.get('interview_id')} · Status: {completed_label}</div>
                                    </div>
                                    <div style="text-align:right;">
                                        <div style="font-family:'JetBrains Mono',monospace; color:{sc} !important; font-size:1.4rem; font-weight:800;">{score_text}</div>
                                        <div style="color:#64748b !important; font-size:0.72rem; text-transform:uppercase;">Interview Score</div>
                                    </div>
                                </div>
                            </div>
                            """, unsafe_allow_html=True)

                            with st.expander(f"View responses for {item.get('candidate_name')}", expanded=False):
                                summary = item.get("summary")
                                if summary:
                                    st.info(summary)
                                for q_idx, response in enumerate(item.get("responses", []), start=1):
                                    response_score = response.get("score")
                                    response_score_text = f"{response_score:.1f}/100" if response_score is not None else "Not scored"
                                    st.markdown(f"**Q{q_idx}. {response.get('question_text') or 'Question unavailable'}**")
                                    st.write(response.get("response") or "No response submitted.")
                                    meta_cols = st.columns([1, 3])
                                    with meta_cols[0]:
                                        st.metric("Score", response_score_text)
                                    with meta_cols[1]:
                                        feedback = response.get("feedback") or "No feedback available yet."
                                        st.caption(f"Feedback: {feedback}")
                                        audio_path = response.get("audio_file_path")
                                        if audio_path:
                                            st.caption(f"Audio stored at: {audio_path}")
                                    st.divider()
                else:
                    st.info("Select a job and load interview results.")

            st.markdown('</div>', unsafe_allow_html=True)


    # PAGE: EMAIL CENTER
    # ══════════════════════════════════════════════════════════════════════
    elif selected_page == "Email":
        st.markdown("""
        <div class="page-header">
            <div class="page-header-icon">✉️</div>
            <div><h1 style="margin:0; font-size:1.8rem !important;">Email Center</h1></div>
        </div>
        <p class="page-subtitle">Review AI-drafted outreach emails and candidate statuses by job role</p>
        """, unsafe_allow_html=True)

        # ── Job selector ───────────────────────────────────────────
        _email_jobs = []
        try:
            _ej2 = requests.get(f"{BASE_URL}/jobs", headers=headers)
            if _ej2.status_code == 200:
                _email_jobs = _ej2.json()
        except Exception:
            pass

        email_job_id = None
        if not _email_jobs:
            st.warning("No jobs found. Please create a job posting first.")
        else:
            _email_job_opts = {f"{j.get('title', 'Untitled')} — {j.get('department', '')} (ID {j.get('id')})": j for j in _email_jobs}
            _email_job_label = st.selectbox("Select Job Position", list(_email_job_opts.keys()), key="email_job_select")
            _email_job_obj = _email_job_opts[_email_job_label]
            email_job_id = _email_job_obj.get("id")

            # Show job banner
            job_desc = _email_job_obj.get("full_description", "")
            desc_preview = job_desc[:220] + "…" if len(job_desc) > 220 else job_desc
            st.markdown(f"""
            <div class="job-desc-banner">
                <h4>💼 {_email_job_obj.get('title')} &nbsp;·&nbsp; {_email_job_obj.get('department')} &nbsp;·&nbsp; {_email_job_obj.get('location')}</h4>
                <p>{desc_preview}</p>
            </div>
            """, unsafe_allow_html=True)

        if email_job_id:
            with st.spinner("Loading job emails..."):
                try:
                    # Load all pending drafts
                    pending_res = requests.get(f"{BASE_URL}/emails/pending", headers=headers)
                    pending_emails = pending_res.json() if pending_res.status_code == 200 else []

                    # Load all candidates for this job
                    cands_res = requests.get(f"{BASE_URL}/jobs/{email_job_id}/candidates", headers=headers)
                    candidates = cands_res.json() if cands_res.status_code == 200 else []

                    # Load interview results
                    int_res = requests.get(f"{BASE_URL}/interviews/job/{email_job_id}/results", headers=headers)
                    interview_results = int_res.json().get("results", []) if int_res.status_code == 200 else []
                    interview_map = {item.get("candidate_id"): item for item in interview_results}

                    # Filter emails for this job's candidates
                    job_cand_ids = {c.get("id") for c in candidates}
                    job_emails = [e for e in pending_emails if e.get("candidate_id") in job_cand_ids]

                    # Render Candidates and Email Drafts
                    st.markdown(f"### 📋 Candidates and Outreach drafts ({len(candidates)} candidates)")

                    if not candidates:
                        st.markdown('<div class="empty-state"><span class="empty-icon">👥</span><h3>No candidates applied yet</h3><p>Upload resumes in the Resume Screening section to add candidates.</p></div>', unsafe_allow_html=True)
                    else:
                        for cand in candidates:
                            cid = cand.get("id")
                            name = cand.get("name", "Unknown")
                            email_addr = cand.get("email", "—")
                            status = cand.get("status", "Applied")
                            exp = cand.get("experience_years") or 0
                            
                            # Find interview score
                            int_item = interview_map.get(cid, {})
                            int_score = int_item.get("overall_score")
                            int_score_text = f"{int_score:.1f}%" if int_score is not None else "Pending"
                            
                            # Find ATS score
                            ats_score = "—"
                            try:
                                ats_r = requests.get(f"{BASE_URL}/candidates/{cid}/ats-score", headers=headers)
                                if ats_r.status_code == 200:
                                    ats_score = f"{ats_r.json().get('total_score', 0.0):.1f}%"
                            except Exception:
                                pass
                            
                            # Find email draft for this candidate
                            cand_draft = next((e for e in job_emails if e.get("candidate_id") == cid), None)

                            # Build candidate card
                            st.markdown(f"""
                            <div class="email-card">
                                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
                                    <h4 style="margin:0; font-size:1.05rem;">👤 {name} &nbsp;<span style="font-size:0.75rem; color:#6366f1 !important; font-weight:500;">#ID {cid}</span></h4>
                                    <span class="badge badge-pending">{status}</span>
                                </div>
                                <div style="display:flex; flex-wrap:wrap; gap:16px; margin-bottom:12px; font-size:0.82rem; color:#94a3b8 !important;">
                                    <span>📧 {email_addr}</span>
                                    <span>💼 {exp} yrs exp</span>
                                    <span>📊 ATS: <strong style="color:#a78bfa !important;">{ats_score}</strong></span>
                                    <span>🎙️ Interview: <strong style="color:#34d399 !important;">{int_score_text}</strong></span>
                                </div>
                            </div>
                            """, unsafe_allow_html=True)

                            # Candidate Decisions
                            dec_cols = st.columns([1, 1, 3])
                            with dec_cols[0]:
                                if status not in ("Offered", "Rejected"):
                                    if st.button("👍 Approve (Offer)", key=f"email_app_cand_{cid}", use_container_width=True):
                                        with st.spinner("Approving candidate..."):
                                            res = requests.post(f"{BASE_URL}/candidates/{cid}/approve", headers=headers)
                                        if res.status_code == 200:
                                            st.success("Approved!")
                                            st.rerun()
                                        else:
                                            st.error("Failed to approve.")
                                else:
                                    st.button("Approved" if status == "Offered" else "Rejected", disabled=True, key=f"email_dec_dis_{cid}", use_container_width=True)
                            with dec_cols[1]:
                                if status not in ("Offered", "Rejected"):
                                    if st.button("❌ Reject", key=f"email_rej_cand_{cid}", use_container_width=True):
                                        with st.spinner("Rejecting candidate..."):
                                            res = requests.post(f"{BASE_URL}/candidates/{cid}/reject", headers=headers)
                                        if res.status_code == 200:
                                            st.info("Rejected.")
                                            st.rerun()
                                        else:
                                            st.error("Failed to reject.")
                            
                            # Draft Email section
                            if cand_draft:
                                email_id = cand_draft.get("id")
                                email_subject = cand_draft.get("subject", "")
                                email_body = cand_draft.get("body", "")
                                email_type = cand_draft.get("email_type", "General Notification")
                                
                                with st.expander(f"✉️ Review Draft: {email_type}", expanded=False):
                                    edited_subject = st.text_input("Subject", value=email_subject, key=f"subj_{email_id}")
                                    edited_body = st.text_area("Body (HTML)", value=email_body, height=180, key=f"body_{email_id}")
                                    
                                    btn_col1, btn_col2, btn_spacer = st.columns([1.2, 1, 2])
                                    with btn_col1:
                                        if st.button("📨 Approve & Send", key=f"app_email_{email_id}", use_container_width=True):
                                            with st.spinner("Sending email..."):
                                                res = requests.post(
                                                    f"{BASE_URL}/emails/{email_id}/review",
                                                    json={"approve": True, "edited_subject": edited_subject, "edited_body": edited_body},
                                                    headers=headers
                                                )
                                            if res.status_code == 200:
                                                st.success("Email sent!")
                                                st.rerun()
                                            else:
                                                st.error("Failed to send.")
                                    with btn_col2:
                                        if st.button("🗑️ Discard Draft", key=f"disc_email_{email_id}", use_container_width=True):
                                            with st.spinner("Discarding..."):
                                                res = requests.post(f"{BASE_URL}/emails/{email_id}/review", json={"approve": False}, headers=headers)
                                            if res.status_code == 200:
                                                st.info("Draft discarded.")
                                                st.rerun()
                                            else:
                                                st.error("Failed to discard.")
                            st.markdown('<div class="section-divider"></div>', unsafe_allow_html=True)

                except Exception as ex:
                    st.error(f"Failed to load page data: {ex}")


    # ══════════════════════════════════════════════════════════════════════
    # PAGE: ONBOARDING PIPELINE (HR View)
    # ══════════════════════════════════════════════════════════════════════
    elif selected_page == "Onboarding":
        st.markdown("""
        <div class="page-header">
            <div class="page-header-icon">🎯</div>
            <div><h1 style="margin:0; font-size:1.8rem !important;">Offer & Onboarding Pipeline</h1></div>
        </div>
        <p class="page-subtitle">Track candidates who have been offered positions and monitor their onboarding progress</p>
        """, unsafe_allow_html=True)

        try:
            # Fetch all jobs to resolve candidate job details
            jobs_res = requests.get(f"{BASE_URL}/jobs", headers=headers)
            all_jobs = jobs_res.json() if jobs_res.status_code == 200 else []
            job_map = {j["id"]: j for j in all_jobs}

            # Collect offered, accepted, and joined candidates
            offered_cands = []
            for job in all_jobs:
                cands_res = requests.get(f"{BASE_URL}/jobs/{job['id']}/candidates", headers=headers)
                if cands_res.status_code == 200:
                    for c in cands_res.json():
                        if c.get("status") in ("Offered", "Offer Accepted", "Joined", "Offer Rejected", "Offer Revoked"):
                            c["job_title"] = job.get("title", "—")
                            c["department"] = job.get("department", "—")
                            c["salary_range"] = job.get("salary_range", "—")
                            offered_cands.append(c)

            if not offered_cands:
                st.markdown('<div class="empty-state"><span class="empty-icon">🎯</span><h3>No active onboarding pipeline</h3><p>Approve candidates in the Email Center to extend offers and start the onboarding flow.</p></div>', unsafe_allow_html=True)
            else:
                # Summary KPIs
                total_offered     = sum(1 for c in offered_cands if c["status"] == "Offered")
                total_accepted    = sum(1 for c in offered_cands if c["status"] == "Offer Accepted")
                total_joined      = sum(1 for c in offered_cands if c["status"] == "Joined")

                k1, k2, k3 = st.columns(3)
                with k1:
                    st.markdown(f'<div class="metric-card live-metric-card amber"><span class="metric-icon">📨</span><div class="metric-value">{total_offered}</div><div class="metric-label">Offers Extended</div><div class="metric-delta delta-amber">Awaiting Response</div></div>', unsafe_allow_html=True)
                with k2:
                    st.markdown(f'<div class="metric-card live-metric-card blue"><span class="metric-icon">✅</span><div class="metric-value">{total_accepted}</div><div class="metric-label">Offers Accepted</div><div class="metric-delta delta-blue">BGV In Progress</div></div>', unsafe_allow_html=True)
                with k3:
                    st.markdown(f'<div class="metric-card live-metric-card emerald"><span class="metric-icon">🏢</span><div class="metric-value">{total_joined}</div><div class="metric-label">Joined / Active</div><div class="metric-delta delta-green">Birthright Access Ready</div></div>', unsafe_allow_html=True)

                st.markdown("<br>", unsafe_allow_html=True)
                st.markdown("### 📋 Candidate Onboarding Status")

                status_colors = {
                    "Offered":       ("#fef3c7", "#92400e", "📨"),
                    "Offer Accepted":("#dbeafe", "#1e40af", "✅"),
                    "Joined":        ("#d1fae5", "#065f46", "🏢"),
                    "Offer Rejected":("#ffe4e6", "#be123c", "❌"),
                    "Offer Revoked": ("#fee2e2", "#b91c1c", "🚫"),
                }

                for c in offered_cands:
                    candidate_id = c["id"]
                    status = c["status"]
                    bg, fg, ic = status_colors.get(status, ("#f3f4f6", "#374151", "👤"))

                    # Fetch current offer and BGV info from backend for each candidate
                    offer_info = None
                    bgv_docs = []
                    
                    offer_res = requests.get(f"{BASE_URL}/onboarding/{candidate_id}/offer", headers=headers)
                    if offer_res.status_code == 200:
                        offer_info = offer_res.json()
                        
                    bgv_res = requests.get(f"{BASE_URL}/onboarding/{candidate_id}/bgv", headers=headers)
                    if bgv_res.status_code == 200:
                        bgv_docs = bgv_res.json()

                    # Simple header card
                    expander_label = f"{ic} {c.get('name','—')} | {c.get('job_title','—')} ({status})"
                    with st.expander(expander_label, expanded=False):
                        # Use sub-tabs or sections for organized flow
                        sect_info, sect_salary, sect_offer, sect_bgv, sect_access = st.tabs([
                            "ℹ️ Profile", "💰 AI Salary", "📄 Offer Letter", "🔒 BGV Status", "🔑 Access"
                        ])

                        with sect_info:
                            st.markdown("##### Candidate Details")
                            st.write(f"**Name:** {c.get('name', '—')}")
                            st.write(f"**Email:** {c.get('email', '—')}")
                            st.write(f"**Role:** {c.get('job_title', '—')} ({c.get('department', '—')})")
                            st.write(f"**Experience:** {c.get('experience_years', '0')} years")
                            st.write(f"**Target Salary Range:** {c.get('salary_range', '—')}")
                            
                            # Parse expectations if present
                            pdata = c.get("parsed_data") or {}
                            st.write(f"**Current Salary (from resume):** {pdata.get('current_salary', 'Not specified')}")
                            st.write(f"**Expected Salary (from resume):** {pdata.get('expected_salary', 'Not specified')}")

                        with sect_salary:
                            st.markdown("##### AI Salary Recommendation")
                            st.caption("Agent: SalaryRecommendationAgent")

                            # Retrieve input values (default to parsed if available)
                            current_sal_input = st.number_input(
                                "Current Salary", min_value=0.0, 
                                value=float(pdata.get("current_salary") or 0.0), 
                                key=f"curr_sal_{candidate_id}"
                            )
                            expected_sal_input = st.number_input(
                                "Expected Salary", min_value=0.0, 
                                value=float(pdata.get("expected_salary") or 0.0), 
                                key=f"exp_sal_{candidate_id}"
                            )

                            if st.button("Calculate Recommended Salary", key=f"calc_sal_btn_{candidate_id}"):
                                with st.spinner("Invoking AI Compensation Agent..."):
                                    rec_res = requests.post(
                                        f"{BASE_URL}/onboarding/{candidate_id}/salary-recommendation",
                                        json={
                                            "current_salary": current_sal_input,
                                            "expected_salary": expected_sal_input
                                        },
                                        headers=headers
                                    )
                                    if rec_res.status_code == 200:
                                        rec_data = rec_res.json()
                                        st.session_state[f"rec_val_{candidate_id}"] = rec_data.get("recommended_salary")
                                        st.session_state[f"rec_notes_{candidate_id}"] = rec_data.get("notes", {})
                                        st.success(f"Recommended Salary: ${st.session_state[f'rec_val_{candidate_id}']:,}")
                                    else:
                                        st.error("AI recommendation failed. Please check backend settings or AWS Bedrock.")

                            rec_notes = st.session_state.get(f"rec_notes_{candidate_id}")
                            if rec_notes:
                                st.info(f"💡 **AI Justification:**\n\n{rec_notes.get('why', 'No reasoning notes provided.')}")

                        with sect_offer:
                            st.markdown("##### Generate & Dispatch Offer")
                            st.caption("Agent: OfferLetterAgent")

                            # Approved Salary Input
                            default_approved_sal = st.session_state.get(f"rec_val_{candidate_id}") or float(pdata.get("expected_salary") or 0.0)
                            approved_salary = st.number_input(
                                "Approved Salary for Offer ($)", min_value=0.0,
                                value=float(default_approved_sal),
                                key=f"app_sal_{candidate_id}"
                            )

                            col_o1, col_o2 = st.columns(2)
                            with col_o1:
                                if st.button("Generate AI Offer PDF", key=f"gen_offer_{candidate_id}", use_container_width=True):
                                    with st.spinner("Drafting letter and writing to S3..."):
                                        notes = st.session_state.get(f"rec_notes_{candidate_id}") or {}
                                        gen_res = requests.post(
                                            f"{BASE_URL}/onboarding/{candidate_id}/generate-offer-letter",
                                            json={
                                                "salary": approved_salary,
                                                "salary_notes": notes
                                            },
                                            headers=headers
                                        )
                                        if gen_res.status_code == 200:
                                            st.success("✅ Offer Letter PDF Generated!")
                                            st.rerun()
                                        else:
                                            st.error("Failed to generate PDF. Check backend log.")
                            
                            with col_o2:
                                email_disabled = not (offer_info and offer_info.get("status") in ("generated", "sent"))
                                if st.button("Email Offer to Candidate", key=f"send_email_{candidate_id}", use_container_width=True, disabled=email_disabled):
                                    with st.spinner("Sending email with PDF attachment..."):
                                        email_res = requests.post(
                                            f"{BASE_URL}/onboarding/{candidate_id}/send-offer-email",
                                            headers=headers
                                        )
                                        if email_res.status_code == 200:
                                            st.success("📨 Email sent successfully!")
                                            st.rerun()
                                        else:
                                            st.error("Email sending failed. Verify Gmail API configuration.")

                            if offer_info:
                                st.markdown("---")
                                st.write(f"**Offer Status:** {offer_info.get('status')}")
                                if offer_info.get("offer_letter_uri"):
                                    st.info(f"📂 **Storage Key:** `{offer_info.get('offer_letter_uri')}`")

                        with sect_bgv:
                            st.markdown("##### Background Verification Status")
                            st.caption("Agent: BGVVerificationAgent (OCR + Bedrock)")
                            
                            if not bgv_docs:
                                st.warning("No BGV documents uploaded by the candidate yet.")
                            else:
                                import base64
                                for doc in bgv_docs:
                                    v_status = doc["verification_status"]
                                    badge_bg = "#d1fae5" if v_status == "accepted" else "#ffe4e6" if v_status == "rejected" else "#fef3c7"
                                    badge_fg = "#065f46" if v_status == "accepted" else "#be123c" if v_status == "rejected" else "#92400e"
                                    
                                    st.markdown(f"""
                                    <div style="background:#0f172a; border:1px solid #334155; border-radius:8px; padding:12px; margin-bottom:8px;">
                                        <div style="display:flex; justify-content:space-between; align-items:center;">
                                            <strong style="color:#f8fafc;">{doc['doc_type'].upper()}: {doc['file_name']}</strong>
                                            <span style="background:{badge_bg}; color:{badge_fg}; padding:3px 10px; border-radius:12px; font-size:0.75rem; font-weight:600;">
                                                {v_status.upper()}
                                            </span>
                                        </div>
                                        <div style="margin-top:6px; font-size:0.8rem; color:#94a3b8;">
                                            Uploaded: {doc.get('uploaded_at','—')}
                                        </div>
                                    </div>
                                    """, unsafe_allow_html=True)
                                    
                                    agent_res = doc.get("agent_result")
                                    if agent_res:
                                        reason = agent_res.get("reason") or agent_res.get("notes") or agent_res.get("message")
                                        if reason:
                                            st.info(f"🤖 **BGV Agent Feedback:** {reason}")
                                        # Show HR decision if already reviewed
                                        hr_decision = agent_res.get("hr_decision")
                                        if hr_decision:
                                            hr_note = agent_res.get("hr_notes", "")
                                            if hr_decision == "approved":
                                                st.success(f"✅ **HR Decision:** Approved. {hr_note}")
                                            else:
                                                st.error(f"❌ **HR Decision:** Rejected. {hr_note}")

                                    # ── HR Manual Review Panel ──────────────────────────────────────────
                                    # Only show for 'review' docs AND candidate is NOT revoked
                                    if v_status == "review" and status != "Offer Revoked":
                                        doc_id = doc["id"]
                                        
                                        st.markdown("---")
                                        st.warning("⚠️ **Awaiting Manual Verification:** System flagged this document (e.g. blurry scan). Please inspect the document above and review below:")
                                        
                                        # ── Document Preview ──────────────────────────────────────────
                                        preview_key = f"bgv_preview_{doc_id}"
                                        if st.button(f"👁️ Load Document Preview", key=f"load_preview_{doc_id}_{candidate_id}"):
                                            st.session_state[preview_key] = True
                                        
                                        if st.session_state.get(preview_key, False):
                                            with st.spinner("Loading document..."):
                                                try:
                                                    prev_res = requests.get(
                                                        f"{BASE_URL}/onboarding/{candidate_id}/bgv/{doc_id}/preview",
                                                        headers=headers
                                                    )
                                                    if prev_res.status_code == 200:
                                                        content_type = prev_res.headers.get("content-type", "")
                                                        if "image" in content_type:
                                                            b64 = base64.b64encode(prev_res.content).decode()
                                                            st.markdown(
                                                                f'<img src="data:{content_type};base64,{b64}" '
                                                                f'style="max-width:100%; border-radius:8px; border:1px solid #334155; margin:8px 0;" />',
                                                                unsafe_allow_html=True
                                                            )
                                                        elif "pdf" in content_type:
                                                            b64 = base64.b64encode(prev_res.content).decode()
                                                            st.markdown(
                                                                f'<iframe src="data:application/pdf;base64,{b64}" '
                                                                f'width="100%" height="500px" style="border-radius:8px; border:1px solid #334155;"></iframe>',
                                                                unsafe_allow_html=True
                                                            )
                                                        else:
                                                            st.info("📄 Preview not available for this file type. File downloaded.")
                                                            st.download_button(
                                                                "⬇️ Download Document",
                                                                data=prev_res.content,
                                                                file_name=doc['file_name'],
                                                                key=f"dl_doc_{doc_id}_{candidate_id}"
                                                            )
                                                    else:
                                                        st.error("Failed to load document preview.")
                                                except Exception as ex:
                                                    st.error(f"Preview error: {ex}")
                                        
                                        # ── Approve / Reject buttons ──────────────────────────────────
                                        hr_notes_input = st.text_input(
                                            "HR Notes (optional)",
                                            key=f"hr_notes_{doc_id}_{candidate_id}",
                                            placeholder="Add a note about your decision..."
                                        )
                                        col_ap, col_rj = st.columns([1, 1])
                                        with col_ap:
                                            if st.button("✅ Approve Document", key=f"hr_approve_{doc_id}_{candidate_id}", use_container_width=True, type="primary"):
                                                with st.spinner("Submitting HR approval..."):
                                                    rev_res = requests.post(
                                                        f"{BASE_URL}/onboarding/{candidate_id}/bgv/{doc_id}/hr-review",
                                                        json={"decision": "approved", "hr_notes": hr_notes_input},
                                                        headers=headers
                                                    )
                                                    if rev_res.status_code == 200:
                                                        rdata = rev_res.json()
                                                        if rdata.get("all_clear"):
                                                            st.success("✅ Document approved! All BGV docs cleared — candidate promoted to **Joined**.")
                                                        else:
                                                            st.success("✅ Document approved by HR.")
                                                        st.session_state.pop(preview_key, None)
                                                        st.rerun()
                                                    else:
                                                        st.error(f"Failed: {rev_res.json().get('detail', 'Unknown error')}")
                                        with col_rj:
                                            with st.expander("❌ Reject Document ▾"):
                                                if st.button("Confirm Rejection", key=f"hr_reject_confirm_{doc_id}_{candidate_id}", type="secondary", use_container_width=True):
                                                    with st.spinner("Submitting HR rejection..."):
                                                        rev_res = requests.post(
                                                            f"{BASE_URL}/onboarding/{candidate_id}/bgv/{doc_id}/hr-review",
                                                            json={"decision": "rejected", "hr_notes": hr_notes_input},
                                                            headers=headers
                                                        )
                                                        if rev_res.status_code == 200:
                                                            rdata = rev_res.json()
                                                            if rdata.get("revoked"):
                                                                st.error("🚫 Document rejected. Candidate offer has been **revoked** (3 failed attempts).")
                                                            else:
                                                                st.warning(f"❌ Document rejected. Attempt {rdata.get('attempts',1)}/3.")
                                                            st.session_state.pop(preview_key, None)
                                                            st.rerun()
                                                        else:
                                                            st.error(f"Failed: {rev_res.json().get('detail', 'Unknown error')}")
                                        st.markdown("---")

                            # Show BGV attempts metadata and Grant Retry controls
                            cand_pdata = c.get("parsed_data") or {}
                            bgv_attempts = cand_pdata.get("bgv_attempts", 0)
                            bgv_locked = cand_pdata.get("bgv_locked", False)
                            bgv_retry_allowed = cand_pdata.get("bgv_retry_allowed", False)

                            st.markdown("---")
                            st.markdown("##### BGV Attempt History & Controls")
                            st.write(f"**Attempts Submitted:** {bgv_attempts} / 3")

                            if status == "Offer Revoked":
                                st.error("🚫 **Offer Revoked:** Candidate failed background verification. Offer letter has been revoked.")
                                revocation_details = cand_pdata.get("bgv_revocation_details", "Verification failed.")
                                st.info(f"ℹ️ **Revocation details shown to candidate:**\n\n{revocation_details}")

                                if st.button("🔄 Restore Offer & Grant BGV Retry", key=f"restore_retry_btn_{candidate_id}", type="primary"):
                                    with st.spinner("Restoring candidate offer and resetting BGV slots..."):
                                        retry_res = requests.post(
                                            f"{BASE_URL}/candidates/{candidate_id}/grant-bgv-retry",
                                            headers=headers
                                        )
                                        if retry_res.status_code == 200:
                                            st.success("✅ Offer restored and BGV retry granted.")
                                            st.rerun()
                                        else:
                                            st.error("Failed to restore offer. Please check API server logs.")
                            elif bgv_locked:
                                st.warning("🔒 **BGV Locked:** Candidate's attempts failed, and BGV access is currently locked.")

                                if st.button("🔄 Grant BGV Retry", key=f"grant_retry_btn_{candidate_id}", type="primary"):
                                    with st.spinner("Granting retry and resetting BGV document slots..."):
                                        retry_res = requests.post(
                                            f"{BASE_URL}/candidates/{candidate_id}/grant-bgv-retry",
                                            headers=headers
                                        )
                                        if retry_res.status_code == 200:
                                            st.success("✅ BGV retry granted. Candidate portal is unlocked.")
                                            st.rerun()
                                        else:
                                            st.error("Failed to grant retry. Please check API server logs.")
                            elif bgv_attempts > 0 and bgv_retry_allowed:
                                st.info("🔄 **Retry Granted:** Candidate has been granted a retry and can now re-upload BGV documents.")
                            elif status == "Joined":
                                st.success("✅ **BGV Passed:** Candidate successfully completed BGV and is now an active employee.")
                            else:
                                st.info("⏳ **Awaiting Submission:** Candidate has not yet completed document uploads.")

                        with sect_access:
                            st.markdown("##### Birthright Access Assignment")
                            st.caption("Agent: AccessRecommendationAgent")

                            # Fetch existing assignments if status is Joined
                            assign_disabled = status != "Joined"
                            if assign_disabled:
                                st.warning("⚠️ Access can only be assigned once the BGV is cleared and Candidate status is Joined.")

                            if st.button("Assign Birthright Access", key=f"assign_access_btn_{candidate_id}", disabled=assign_disabled, type="primary"):
                                with st.spinner("Provisioning role-based access permissions..."):
                                    acc_res = requests.post(
                                        f"{BASE_URL}/onboarding/{candidate_id}/assign-access",
                                        headers=headers
                                    )
                                    if acc_res.status_code == 200:
                                        st.success("✅ Birthright Access permissions successfully provisioned!")
                                        st.rerun()
                                    else:
                                        st.error("Failed to provision access.")

        except Exception as ex:
            st.error(f"Failed to load onboarding pipeline: {ex}")


    # ══════════════════════════════════════════════════════════════════════
    # PAGE: HR POLICY GENERATOR
    # ══════════════════════════════════════════════════════════════════════
    elif selected_page == "PolicyGen":
        st.markdown("""
        <div class="page-header">
            <div class="page-header-icon">📝</div>
            <div><h1 style="margin:0; font-size:1.8rem !important;">HR Policy Generator</h1></div>
        </div>
        <p class="page-subtitle">AI-powered policy creation, compliance auditing &amp; policy repository</p>
        """, unsafe_allow_html=True)

        st.markdown("""
        <style>
        .pg-result { background:#0f1117; border:1px solid #334155; border-radius:12px; padding:20px; margin-top:16px; }
        .pg-result pre { white-space:pre-wrap; color:#e2e8f0; font-size:0.82rem; line-height:1.7; font-family:monospace; }
        .repo-card { background:#1e2130; border:1px solid #2d3748; border-radius:14px;
                     padding:18px 20px; margin-bottom:14px; transition:box-shadow .2s; }
        .repo-card:hover { box-shadow:0 4px 20px rgba(99,102,241,.18); }
        .st-pub  { background:#14532d; color:#86efac; display:inline-block;
                   padding:3px 12px; border-radius:99px; font-size:0.72rem; font-weight:700; }
        .st-rev  { background:#78350f; color:#fcd34d; display:inline-block;
                   padding:3px 12px; border-radius:99px; font-size:0.72rem; font-weight:700; }
        .st-dft  { background:#1e293b; color:#94a3b8; display:inline-block;
                   padding:3px 12px; border-radius:99px; font-size:0.72rem; font-weight:700; }
        </style>
        """, unsafe_allow_html=True)

        pg_tab1, pg_tab2 = st.tabs(["🤖 Generate Policy", "📚 Policy Repository"])

        # ── TAB 1: Generate Policy ──────────────────────────────────────────
        with pg_tab1:
            st.markdown("""
            <div class="glass-card" style="padding:20px; margin-bottom:20px;">
                <div style="display:grid; grid-template-columns:1fr 1fr 1fr 1fr; gap:14px;">
                    <div style="background:rgba(99,102,241,0.08);border-radius:10px;padding:14px;border-left:4px solid #6366f1;">
                        <strong style="color:#a5b4fc;">✅ Generate</strong>
                        <p style="font-size:0.8rem;color:#94a3b8;margin:4px 0 0;">Create complete policies from requirements in minutes.</p>
                    </div>
                    <div style="background:rgba(99,102,241,0.08);border-radius:10px;padding:14px;border-left:4px solid #6366f1;">
                        <strong style="color:#a5b4fc;">🛡️ Compliance</strong>
                        <p style="font-size:0.8rem;color:#94a3b8;margin:4px 0 0;">AI audits drafts for legal &amp; HR risks automatically.</p>
                    </div>
                    <div style="background:rgba(99,102,241,0.08);border-radius:10px;padding:14px;border-left:4px solid #6366f1;">
                        <strong style="color:#a5b4fc;">📚 RAG Context</strong>
                        <p style="font-size:0.8rem;color:#94a3b8;margin:4px 0 0;">Draws on your existing policy library for consistency.</p>
                    </div>
                    <div style="background:rgba(99,102,241,0.08);border-radius:10px;padding:14px;border-left:4px solid #6366f1;">
                        <strong style="color:#a5b4fc;">🚀 Publish</strong>
                        <p style="font-size:0.8rem;color:#94a3b8;margin:4px 0 0;">Instantly makes policies visible to all employees &amp; the chatbot.</p>
                    </div>
                </div>
            </div>
            """, unsafe_allow_html=True)

            pg_col1, pg_col2 = st.columns(2)
            with pg_col1:
                pol_type = st.selectbox("Policy Type", [
                    "Leave & Attendance Policy", "Work-From-Home Policy",
                    "Code of Conduct", "Anti-Harassment Policy",
                    "Data Privacy Policy", "Performance Review Policy",
                    "Reimbursement Policy", "Travel & Expense Policy",
                ], key="pg_type")
                pol_title = st.text_input("Policy Title", placeholder="e.g. Annual Leave & Attendance Policy v2.0", key="pg_title")
            with pg_col2:
                pol_dept = st.multiselect(
                    "Applicable Departments",
                    ["All Departments", "Engineering", "HR", "Finance", "Operations", "Sales", "Legal"],
                    default=["All Departments"], key="pg_dept",
                )
                pol_effective = st.text_input("Effective Date", placeholder="e.g. 2025-07-01", key="pg_eff")

            pol_scope = st.text_area(
                "Key Requirements",
                placeholder="e.g. 12 days casual leave, 15 days sick leave, carry-forward rules up to 10 days, WFH 2 days per week for all roles...",
                height=110, key="pg_req",
            )

            st.info("💡 Policies are **published immediately** after generation and will be available to employees and the HR chatbot right away.", icon="ℹ️")

            if st.button("🤖 Generate & Publish Policy", type="primary", use_container_width=True, key="pg_gen_btn"):
                if not pol_title.strip():
                    st.warning("⚠️ Please enter a Policy Title before generating.")
                elif not pol_scope.strip():
                    st.warning("⚠️ Please enter Key Requirements before generating.")
                else:
                    with st.spinner("🔍 AI agents drafting policy, running compliance review & publishing…"):
                        try:
                            payload = {
                                "policy_type": pol_type,
                                "title": pol_title.strip(),
                                "requirements": pol_scope.strip(),
                                "department": ", ".join(pol_dept) if pol_dept else "All Departments",
                                "effective_date": pol_effective.strip() or None,
                            }
                            gen_res = requests.post(
                                f"{BASE_URL}/hr/agentic/policies/generate",
                                json=payload, headers=headers, timeout=120,
                            )
                            if gen_res.status_code == 200:
                                gen_data = gen_res.json()
                                review   = gen_data.get("review", {})
                                score    = review.get("compliance_score", 0)
                                risks    = review.get("risks", [])
                                pol_id   = gen_data.get("policy_id", "")

                                st.success(f"🎉 Policy **published** successfully! It is now live for employees and the chatbot. ID: `{pol_id[:8]}…`")

                                c1, c2, c3 = st.columns(3)
                                c1.metric("Compliance Score", f"{score}/100")
                                c2.metric("Status", "Published ✅")
                                c3.metric("Risks Flagged", len(risks) if isinstance(risks, list) else 0)

                                if risks and isinstance(risks, list):
                                    with st.expander("⚠️ Compliance Risks (for your reference)", expanded=False):
                                        for r in risks:
                                            st.markdown(f"- {r}")

                                st.markdown("#### 📄 Published Policy Draft")
                                st.markdown(
                                    f"<div class='pg-result'><pre>{gen_data.get('draft','')}</pre></div>",
                                    unsafe_allow_html=True,
                                )
                                st.caption("View, manage, or delete this policy in the **📚 Policy Repository** tab.")

                            elif gen_res.status_code == 403:
                                st.error("🔒 Permission denied. Only HR Admins can generate policies.")
                            else:
                                st.error(f"❌ Generation failed ({gen_res.status_code}): {gen_res.text[:200]}")
                        except requests.exceptions.Timeout:
                            st.warning("⏳ Generation is taking longer than expected. Please try again.")
                        except Exception as ex:
                            st.error(f"❌ Error: {ex}")

        # ── TAB 2: Policy Repository ────────────────────────────────────────
        with pg_tab2:
            st.markdown("### 📚 Policy Repository")
            st.markdown("All HR policies in the system — manage drafts, review, and publish from here.")

            # Load all policies
            all_pols = []
            try:
                pr_res = requests.get(f"{BASE_URL}/hr/policies", headers=headers, timeout=15)
                if pr_res.status_code == 200:
                    all_pols = pr_res.json()
            except Exception as ex:
                st.error(f"❌ Failed to load policies: {ex}")

            # Filter bar
            rf1, rf2, rf3 = st.columns([2, 2, 1])
            with rf1:
                repo_status_f = st.selectbox("Filter by Status", ["All", "published", "review", "draft"], key="repo_sf")
            with rf2:
                repo_type_f = st.selectbox(
                    "Filter by Type",
                    ["All"] + sorted(set(p.get("policy_type", "") for p in all_pols if p.get("policy_type"))),
                    key="repo_tf",
                )
            with rf3:
                if st.button("🔄 Refresh", use_container_width=True, key="repo_refresh"):
                    st.rerun()

            # Apply filter
            pols = all_pols
            if repo_status_f != "All":
                pols = [p for p in pols if p.get("status") == repo_status_f]
            if repo_type_f != "All":
                pols = [p for p in pols if p.get("policy_type") == repo_type_f]

            # Summary
            rm1, rm2, rm3, rm4 = st.columns(4)
            rm1.metric("Total Policies", len(all_pols))
            rm2.metric("Published", sum(1 for p in all_pols if p.get("status") == "published"))
            rm3.metric("In Review", sum(1 for p in all_pols if p.get("status") == "review"))
            rm4.metric("Drafts", sum(1 for p in all_pols if p.get("status") == "draft"))

            st.markdown("---")

            STATUS_BADGE = {
                "published": "<span class='st-pub'>✅ Published</span>",
                "review":    "<span class='st-rev'>🔍 In Review</span>",
                "draft":     "<span class='st-dft'>📝 Draft</span>",
            }

            if not pols:
                st.info("No policies found. Generate your first policy using the **Generate Policy** tab.")
            else:
                for pol in pols:
                    pid     = str(pol.get("id", ""))
                    pstatus = pol.get("status", "draft")
                    pvs     = pol.get("versions", [])
                    badge   = STATUS_BADGE.get(pstatus, f"<span class='st-dft'>{pstatus}</span>")
                    latest_v = pvs[-1] if pvs else {}
                    cscore  = latest_v.get("compliance_score", "—")

                    st.markdown(f"""
                    <div class="repo-card">
                        <div style="display:flex;justify-content:space-between;align-items:flex-start;">
                            <div>
                                <div style="font-size:1rem;font-weight:700;color:#e2e8f0;margin-bottom:4px;">
                                    {pol.get('title','Untitled Policy')}
                                </div>
                                <div style="font-size:0.78rem;color:#94a3b8;">
                                    {pol.get('policy_type','')} &nbsp;·&nbsp;
                                    v{latest_v.get('version_number','1.0')} &nbsp;·&nbsp;
                                    Compliance: <strong>{cscore}/100</strong> &nbsp;·&nbsp;
                                    Review: {pol.get('review_date','Annual')}
                                </div>
                            </div>
                            <div style="text-align:right;">
                                {badge}
                                <div style="font-size:0.72rem;color:#64748b;margin-top:4px;">
                                    {pol.get('created_at','')[:10] if pol.get('created_at') else ''}
                                </div>
                            </div>
                        </div>
                    </div>
                    """, unsafe_allow_html=True)

                    # Expandable actions
                    with st.expander(f"⚙️ Manage — {pol.get('title','')[:40]}", expanded=False, key=f"exp_{pid}"):
                        # Show full content from first version
                        if pvs:
                            full_pol = requests.get(
                                f"{BASE_URL}/hr/policies/{pid}", headers=headers, timeout=10
                            )
                            if full_pol.status_code == 200:
                                pol_detail = full_pol.json()
                                content_versions = pol_detail.get("versions", [])
                                if content_versions:
                                    last_content = content_versions[-1].get("content", "")
                                    if last_content:
                                        st.markdown("**📄 Policy Content:**")
                                        st.markdown(
                                            f"<div class='pg-result'><pre>{last_content[:3000]}{'…' if len(last_content)>3000 else ''}</pre></div>",
                                            unsafe_allow_html=True,
                                        )

                        act_c1, act_c2 = st.columns(2)
                        with act_c1:
                            if pstatus != "published":
                                if st.button("🚀 Publish", key=f"pub2_{pid}", type="primary", use_container_width=True):
                                    r = requests.post(f"{BASE_URL}/hr/policies/{pid}/publish", headers=headers, timeout=15)
                                    if r.status_code == 200:
                                        st.success("✅ Policy published! Now visible to employees and chatbot.")
                                        st.rerun()
                                    else:
                                        st.error(f"Failed: {r.text[:100]}")
                            else:
                                st.success("✅ This policy is already published and available to employees.", icon="✅")
                        with act_c2:
                            if st.button("🗑️ Delete", key=f"del_{pid}", type="secondary", use_container_width=True):
                                dr = requests.delete(f"{BASE_URL}/hr/policies/{pid}", headers=headers, timeout=15)
                                if dr.status_code == 200:
                                    st.success("🗑️ Policy deleted.")
                                    st.rerun()
                                else:
                                    st.error(f"Delete failed: {dr.text[:100]}")




    # ══════════════════════════════════════════════════════════════════════
    # PAGE: HR SUPPORT TICKETS (Admin View)
    # ══════════════════════════════════════════════════════════════════════
    elif selected_page == "HRTickets":
        HR_BASE = f"{BASE_URL}/hr"

        st.markdown("""
        <style>
        .htk-card { background:#1e2130; border:1px solid #2d3748; border-radius:14px;
                    padding:16px 18px; margin-bottom:14px; transition:box-shadow .2s; }
        .htk-card:hover { box-shadow:0 4px 20px rgba(99,102,241,.18); }
        .htk-badge { display:inline-block; padding:3px 12px; border-radius:99px;
                     font-size:0.72rem; font-weight:700; }
        .htk-open     { background:#312e81; color:#a5b4fc; }
        .htk-progress { background:#78350f; color:#fcd34d; }
        .htk-resolved { background:#14532d; color:#86efac; }
        .htk-closed   { background:#1e293b; color:#94a3b8; }
        .htk-hi { background:#fee2e2; color:#991b1b; }
        .htk-med{ background:#fef9c3; color:#854d0e; }
        .htk-low{ background:#dcfce7; color:#166534; }
        </style>
        """, unsafe_allow_html=True)

        st.markdown("""
        <div class="page-header">
            <div class="page-header-icon">🎫</div>
            <div><h1 style="margin:0;font-size:1.8rem !important;">HR Support Tickets</h1></div>
        </div>
        <p class="page-subtitle">Review, assign, and resolve employee HR support tickets raised via the chatbot</p>
        """, unsafe_allow_html=True)

        # Load all tickets
        all_tickets = []
        try:
            tk_res = requests.get(f"{HR_BASE}/tickets", headers=headers, timeout=15)
            if tk_res.status_code == 200:
                all_tickets = tk_res.json()
            elif tk_res.status_code == 403:
                st.error("🔒 Only HR Admins can view all tickets.")
                st.stop()
        except Exception as ex:
            st.error(f"❌ Failed to load tickets: {ex}")

        # Filters
        f1, f2, f3 = st.columns(3)
        with f1:
            status_filter = st.selectbox("Filter by Status", ["All", "Open", "In Progress", "Resolved", "Closed"])
        with f2:
            priority_filter = st.selectbox("Filter by Priority", ["All", "High", "Medium", "Low"])
        with f3:
            if st.button("🔄 Refresh", use_container_width=True):
                st.rerun()

        # Apply filters
        tickets = all_tickets
        if status_filter != "All":
            tickets = [t for t in tickets if t.get("status") == status_filter]
        if priority_filter != "All":
            tickets = [t for t in tickets if t.get("priority") == priority_filter]

        # Summary metrics
        m1, m2, m3, m4 = st.columns(4)
        m1.metric("Total Tickets", len(all_tickets))
        m2.metric("Open", sum(1 for t in all_tickets if t.get("status") == "Open"))
        m3.metric("In Progress", sum(1 for t in all_tickets if t.get("status") == "In Progress"))
        m4.metric("Resolved", sum(1 for t in all_tickets if t.get("status") in ("Resolved", "Closed")))

        st.markdown("---")

        if not tickets:
            st.markdown("""
            <div style="text-align:center;padding:48px;background:#1e2130;border:1px solid #2d3748;border-radius:16px;">
                <div style="font-size:3rem;margin-bottom:12px;">🎫</div>
                <div style="font-weight:700;color:#e2e8f0;margin-bottom:6px;">No tickets found</div>
                <div style="font-size:0.82rem;color:#64748b;">
                    Tickets are raised automatically when employees ask HR questions that need follow-up.
                </div>
            </div>
            """, unsafe_allow_html=True)
        else:
            PRI_BADGE = {"High": "htk-hi", "Medium": "htk-med", "Low": "htk-low"}
            ST_BADGE  = {"Open": "htk-open", "In Progress": "htk-progress",
                         "Resolved": "htk-resolved", "Closed": "htk-closed"}

            for idx, tkt in enumerate(tickets):
                tid      = str(tkt.get("id", ""))
                status   = tkt.get("status", "Open")
                priority = tkt.get("priority", "Medium")
                sb = ST_BADGE.get(status, "htk-open")
                pb = PRI_BADGE.get(priority, "htk-med")

                st.markdown(f"""
                <div class="htk-card">
                    <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:10px;">
                        <div>
                            <span style="font-size:0.78rem;color:#94a3b8;">#{tid[:8]}… &nbsp;·&nbsp;
                                {tkt['created_at'][:10] if tkt.get('created_at') else '—'}
                            </span><br>
                            <span style="font-size:0.95rem;font-weight:700;color:#e2e8f0;">
                                {tkt.get('category','HR Query')}
                            </span>
                        </div>
                        <div>
                            <span class="htk-badge {sb}">{status}</span>
                            &nbsp;<span class="htk-badge {pb}">{priority}</span>
                        </div>
                    </div>
                    <div style="font-size:0.85rem;color:#cbd5e1;line-height:1.5;margin-bottom:8px;">
                        <strong>Question:</strong> {tkt.get('question','')[:180]}{'…' if len(tkt.get('question',''))>180 else ''}
                    </div>
                    <div style="font-size:0.78rem;color:#64748b;">
                        👤 {tkt.get('employee_email','—')}
                        {f" &nbsp;·&nbsp; Assigned: {tkt.get('assigned_to','—')}" if tkt.get('assigned_to') else ''}
                    </div>
                </div>
                """, unsafe_allow_html=True)

                # Resolution form in an expander
                with st.expander(f"✏️ Update Ticket #{tid[:8]}…", expanded=False):
                    r1, r2 = st.columns(2)
                    with r1:
                        new_status = st.selectbox(
                            "Status",
                            ["Open", "In Progress", "Resolved", "Closed"],
                            index=["Open", "In Progress", "Resolved", "Closed"].index(status) if status in ["Open", "In Progress", "Resolved", "Closed"] else 0,
                            key=f"st_{tid}",
                        )
                    with r2:
                        assigned = st.text_input("Assign To (email)", value=tkt.get("assigned_to") or "", key=f"as_{tid}")

                    resolution = st.text_area(
                        "Resolution / Response",
                        value=tkt.get("resolution_response") or "",
                        placeholder="Type your response to the employee here…",
                        height=100,
                        key=f"res_{tid}",
                    )

                    if st.button("💾 Save Update", key=f"save_{tid}", type="primary"):
                        with st.spinner("Saving…"):
                            try:
                                patch_res = requests.patch(
                                    f"{HR_BASE}/tickets/{tid}",
                                    json={
                                        "status": new_status,
                                        "resolution_response": resolution.strip() or None,
                                        "assigned_to": assigned.strip() or None,
                                    },
                                    headers=headers, timeout=15,
                                )
                                if patch_res.status_code == 200:
                                    st.success(f"✅ Ticket updated to **{new_status}**")
                                    st.rerun()
                                else:
                                    st.error(f"Failed: {patch_res.text[:150]}")
                            except Exception as ex:
                                st.error(f"Error: {ex}")


    elif selected_page == "Training":
        # Delegate entirely to the full Training & Development view
        from views.training import render_training_view
        render_training_view(headers)




    # ══════════════════════════════════════════════════════════════════════
    # PAGE: WORKFORCE ANALYTICS
    # ══════════════════════════════════════════════════════════════════════
    elif selected_page == "Analytics":

        st.markdown("""
        <div class="page-header">
            <div class="page-header-icon">📈</div>
            <div><h1 style="margin:0; font-size:1.8rem !important;">Workforce Analytics</h1></div>
        </div>
        <p class="page-subtitle">Real-time HR data analysis — attrition insights, headcount trends, and performance intelligence</p>
        """, unsafe_allow_html=True)

        # Pull live stats from DB
        try:
            jobs_r = requests.get(f"{BASE_URL}/jobs", headers=headers)
            all_jobs = jobs_r.json() if jobs_r.status_code == 200 else []

            total_cands, by_status = 0, {}
            for job in all_jobs:
                cr = requests.get(f"{BASE_URL}/jobs/{job['id']}/candidates", headers=headers)
                if cr.status_code == 200:
                    for c in cr.json():
                        total_cands += 1
                        st_val = c.get("status", "Applied")
                        by_status[st_val] = by_status.get(st_val, 0) + 1

            active_jobs    = sum(1 for j in all_jobs if str(j.get("status", "Active")).lower() == "active")
            hired_count    = by_status.get("Joined", 0)
            offered_count  = by_status.get("Offered", 0) + by_status.get("Offer Accepted", 0)
            rejected_count = by_status.get("Rejected", 0)
            in_pipeline    = total_cands - hired_count - rejected_count

            k1, k2, k3, k4 = st.columns(4)
            with k1:
                st.markdown(f'<div class="metric-card live-metric-card purple"><span class="metric-icon">💼</span><div class="metric-value">{active_jobs}</div><div class="metric-label">Open Positions</div></div>', unsafe_allow_html=True)
            with k2:
                st.markdown(f'<div class="metric-card live-metric-card blue"><span class="metric-icon">👥</span><div class="metric-value">{total_cands}</div><div class="metric-label">Total Applicants</div></div>', unsafe_allow_html=True)
            with k3:
                st.markdown(f'<div class="metric-card live-metric-card emerald"><span class="metric-icon">🏢</span><div class="metric-value">{hired_count}</div><div class="metric-label">Employees Hired</div></div>', unsafe_allow_html=True)
            with k4:
                st.markdown(f'<div class="metric-card live-metric-card amber"><span class="metric-icon">⏳</span><div class="metric-value">{in_pipeline}</div><div class="metric-label">In Pipeline</div></div>', unsafe_allow_html=True)

            st.markdown("<br>", unsafe_allow_html=True)

            col_a, col_b = st.columns([3, 2])
            with col_a:
                st.markdown("""
                <div class="glass-card" style="padding:20px;">
                    <h3 style="margin-top:0;">📊 Candidate Status Breakdown</h3>
                """, unsafe_allow_html=True)
                status_order = ["Applied", "Screening", "Shortlisted", "Interviewing", "Offered", "Offer Accepted", "Joined", "Rejected"]
                status_colors_map = {"Applied":"#6366f1","Screening":"#8b5cf6","Shortlisted":"#0ea5e9","Interviewing":"#06b6d4","Offered":"#f59e0b","Offer Accepted":"#10b981","Joined":"#22c55e","Rejected":"#ef4444"}
                for s in status_order:
                    cnt = by_status.get(s, 0)
                    if cnt > 0:
                        pct = int((cnt / total_cands) * 100) if total_cands else 0
                        bar_color = status_colors_map.get(s, "#6366f1")
                        st.markdown(f"""
                        <div style="margin-bottom:10px;">
                            <div style="display:flex; justify-content:space-between; font-size:0.82rem; margin-bottom:3px;">
                                <span style="color:#e2e8f0;">{s}</span>
                                <span style="color:#94a3b8;">{cnt} ({pct}%)</span>
                            </div>
                            <div style="background:#1e293b; border-radius:4px; height:8px;">
                                <div style="width:{pct}%; background:{bar_color}; height:8px; border-radius:4px;"></div>
                            </div>
                        </div>
                        """, unsafe_allow_html=True)
                st.markdown('</div>', unsafe_allow_html=True)

            with col_b:
                st.markdown("""
                <div class="glass-card" style="padding:20px;">
                    <h3 style="margin-top:0;">🏛️ Open Roles by Department</h3>
                """, unsafe_allow_html=True)
                dept_counts = {}
                for j in all_jobs:
                    if str(j.get("status", "Active")).lower() == "active":
                        d = j.get("department", "Other")
                        dept_counts[d] = dept_counts.get(d, 0) + 1
                if dept_counts:
                    for dept, cnt in sorted(dept_counts.items(), key=lambda x: -x[1]):
                        st.markdown(f"""
                        <div style="display:flex; justify-content:space-between; padding:8px 0;
                                    border-bottom:1px solid #1e293b; font-size:0.85rem;">
                            <span style="color:#e2e8f0;">🏛️ {dept}</span>
                            <span style="background:#6366f1; color:white; padding:2px 10px;
                                        border-radius:12px; font-size:0.75rem;">{cnt}</span>
                        </div>""", unsafe_allow_html=True)
                else:
                    st.markdown('<p style="color:#94a3b8;">No active jobs found.</p>', unsafe_allow_html=True)
                st.markdown('</div>', unsafe_allow_html=True)

            st.info("🚧 **Advanced Analytics** — AI-powered attrition prediction, time-to-hire trends, and performance benchmarking coming soon.")

        except Exception as ex:
            st.error(f"Failed to load analytics data: {ex}")


    # ══════════════════════════════════════════════════════════════════════
    # PAGE: PULSE SURVEY DASHBOARD (HR View)
    # ══════════════════════════════════════════════════════════════════════
    elif selected_page == "PulseSurvey":
        import plotly.graph_objects as go
        import pandas as pd

        if "new_survey_questions" not in st.session_state:
            st.session_state["new_survey_questions"] = [{"question_text": "", "type": "rating", "options": "Yes, No"}]

        st.markdown("""
        <div class="page-header">
            <div class="page-header-icon">💬</div>
            <div><h1 style="margin:0; font-size:1.8rem !important;">Pulse Survey Dashboard</h1></div>
        </div>
        <p class="page-subtitle">Organization-wide sentiment trends, attrition risk signals, and employee wellbeing analytics</p>
        """, unsafe_allow_html=True)

        # Fetch available surveys from backend
        surveys_list = []
        try:
            surveys_resp = requests.get(f"{BASE_URL}/pulse-survey/surveys")
            if surveys_resp.status_code == 200:
                surveys_list = surveys_resp.json()
        except Exception:
            pass

        selected_survey_id = None
        if surveys_list:
            survey_options = {s["title"]: s["id"] for s in surveys_list}
            selected_survey_title = st.selectbox(
                "Select Survey to View Analytics:",
                options=list(survey_options.keys()),
                key="hr_dashboard_survey_selector"
            )
            selected_survey_id = survey_options[selected_survey_title]
        else:
            st.warning("⚠️ No active pulse surveys found. Please navigate to the 'Manage Surveys' tab to create one.")

        # Fetch HR dashboard data from backend
        hr_dash_data = None
        with st.spinner("Loading organization-wide pulse analytics..."):
            try:
                url = f"{BASE_URL}/pulse-survey/dashboard/hr"
                if selected_survey_id is not None:
                    url += f"?survey_id={selected_survey_id}"
                hr_resp = requests.get(url)
                if hr_resp.status_code == 200:
                    hr_dash_data = hr_resp.json()
            except Exception:
                pass

        if not hr_dash_data:
            st.warning("⚠️ Could not load pulse survey data. Ensure the backend is running and survey data has been seeded.")
            st.info("🚧 **Pulse Survey Analytics** — Connect this view to survey submission data to see live sentiment trends, emotion distribution charts, and AI-prioritized HR focus areas.")
        else:
            # ── KPI METRICS ROW ──
            kpi1, kpi2, kpi3, kpi4 = st.columns(4)
            overall_sent = hr_dash_data.get("overall_sentiment", 0.0)
            sent_label = "Positive" if overall_sent > 0.3 else ("Neutral" if overall_sent > -0.1 else "Concerning")
            sent_color = "#10b981" if overall_sent > 0.3 else ("#f59e0b" if overall_sent > -0.1 else "#ef4444")

            with kpi1:
                st.markdown(f"""
                <div class="glass-card" style="text-align:center; padding:20px;">
                    <div style="font-size:2.2rem; font-weight:700; color:{sent_color};">{overall_sent:+.2f}</div>
                    <div style="font-size:0.85rem; color:#94a3b8; margin-top:4px;">Overall Sentiment</div>
                    <div style="font-size:0.75rem; color:{sent_color}; font-weight:600; margin-top:2px;">{sent_label}</div>
                </div>
                """, unsafe_allow_html=True)
            with kpi2:
                st.markdown(f"""
                <div class="glass-card" style="text-align:center; padding:20px;">
                    <div style="font-size:2.2rem; font-weight:700; color:#6366f1;">{hr_dash_data.get('total_responses', 0)}</div>
                    <div style="font-size:0.85rem; color:#94a3b8; margin-top:4px;">Total Survey Responses</div>
                </div>
                """, unsafe_allow_html=True)
            with kpi3:
                st.markdown(f"""
                <div class="glass-card" style="text-align:center; padding:20px;">
                    <div style="font-size:2.2rem; font-weight:700; color:#8b5cf6;">{hr_dash_data.get('total_employees', 0)}</div>
                    <div style="font-size:0.85rem; color:#94a3b8; margin-top:4px;">Total Employees</div>
                </div>
                """, unsafe_allow_html=True)
            with kpi4:
                total_resp = hr_dash_data.get('total_responses', 0)
                total_emp = hr_dash_data.get('total_employees', 1)
                participation = round((total_resp / max(total_emp, 1)) * 100, 1)
                part_color = "#10b981" if participation > 60 else ("#f59e0b" if participation > 30 else "#ef4444")
                st.markdown(f"""
                <div class="glass-card" style="text-align:center; padding:20px;">
                    <div style="font-size:2.2rem; font-weight:700; color:{part_color};">{participation}%</div>
                    <div style="font-size:0.85rem; color:#94a3b8; margin-top:4px;">Participation Rate</div>
                </div>
                """, unsafe_allow_html=True)

            st.markdown("<br>", unsafe_allow_html=True)

            # ── TABS FOR DIFFERENT VIEWS ──
            org_tab, dept_tab, risk_tab, strategy_tab, manage_tab = st.tabs([
                "📊 Organization Overview",
                "🏢 Department Analysis",
                "⚠️ Retention Risk",
                "🎯 Strategic Priorities",
                "📋 Manage Surveys"
            ])

            # ────────────────────────────────────────────
            # TAB 1: Organization Overview
            # ────────────────────────────────────────────
            with org_tab:
                chart_col1, chart_col2 = st.columns([1, 1])

                with chart_col1:
                    # Department Sentiment Comparison
                    st.markdown('<div class="glass-card" style="padding:20px;">', unsafe_allow_html=True)
                    st.markdown("#### 📊 Department Sentiment Comparison")
                    dept_sent = hr_dash_data.get("department_sentiment", {})
                    if dept_sent:
                        depts = list(dept_sent.keys())
                        scores = list(dept_sent.values())
                        colors = ['#10b981' if s > 0.3 else ('#f59e0b' if s > -0.1 else '#ef4444') for s in scores]
                        fig_dept = go.Figure(data=[
                            go.Bar(
                                x=depts, y=scores,
                                marker_color=colors,
                                text=[f"{s:+.2f}" for s in scores],
                                textposition='outside',
                                textfont=dict(size=12, color='white')
                            )
                        ])
                        fig_dept.update_layout(
                            margin=dict(l=20, r=20, t=10, b=40), height=320,
                            yaxis=dict(range=[-1.1, 1.1], title="Sentiment Score", showgrid=True, gridcolor='rgba(255,255,255,0.08)'),
                            xaxis=dict(showgrid=False),
                            paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)',
                            font=dict(color='#e2e8f0')
                        )
                        st.plotly_chart(fig_dept, use_container_width=True)
                    else:
                        st.info("No department-level sentiment data available yet.")
                    st.markdown('</div>', unsafe_allow_html=True)

                with chart_col2:
                    # Historical Sentiment Trend
                    st.markdown('<div class="glass-card" style="padding:20px;">', unsafe_allow_html=True)
                    st.markdown("#### 📈 Sentiment Over Time")
                    hist_trend = hr_dash_data.get("historical_sentiment_trend", [])
                    if hist_trend:
                        trend_df = pd.DataFrame(hist_trend)
                        fig_trend = go.Figure()
                        fig_trend.add_trace(go.Scatter(
                            x=trend_df["date"], y=trend_df["sentiment"],
                            mode='lines+markers',
                            line=dict(color='#6366f1', width=3),
                            marker=dict(size=8, color='#818cf8'),
                            fill='tozeroy',
                            fillcolor='rgba(99,102,241,0.15)',
                            name='Org Sentiment'
                        ))
                        fig_trend.add_hline(y=0, line_dash="dash", line_color="rgba(255,255,255,0.3)")
                        fig_trend.update_layout(
                            margin=dict(l=20, r=20, t=10, b=40), height=320,
                            yaxis=dict(range=[-1.1, 1.1], title="Sentiment", showgrid=True, gridcolor='rgba(255,255,255,0.08)'),
                            xaxis=dict(type='category', showgrid=False),
                            paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)',
                            font=dict(color='#e2e8f0')
                        )
                        st.plotly_chart(fig_trend, use_container_width=True)
                    else:
                        st.info("No historical trend data available yet.")
                    st.markdown('</div>', unsafe_allow_html=True)

                # Top Topics
                st.markdown('<div class="glass-card" style="padding:20px;">', unsafe_allow_html=True)
                st.markdown("#### 🏷️ Most Discussed Topics Across Surveys")
                top_topics = hr_dash_data.get("top_topics", [])
                if top_topics:
                    topic_names = [t["topic"].replace("_", " ").title() for t in top_topics]
                    topic_counts = [t["count"] for t in top_topics]
                    fig_topics = go.Figure(data=[
                        go.Bar(
                            x=topic_counts, y=topic_names, orientation='h',
                            marker_color=['#6366f1', '#8b5cf6', '#a78bfa', '#c4b5fd', '#ddd6fe'][:len(topic_names)],
                            text=topic_counts, textposition='auto',
                            textfont=dict(color='white', size=13)
                        )
                    ])
                    fig_topics.update_layout(
                        margin=dict(l=20, r=20, t=10, b=10), height=250,
                        yaxis=dict(autorange="reversed", showgrid=False),
                        xaxis=dict(title="Mentions", showgrid=True, gridcolor='rgba(255,255,255,0.08)'),
                        paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)',
                        font=dict(color='#e2e8f0')
                    )
                    st.plotly_chart(fig_topics, use_container_width=True)
                else:
                    st.info("No topic data available yet.")
                st.markdown('</div>', unsafe_allow_html=True)

            # ────────────────────────────────────────────
            # TAB 2: Department Analysis
            # ────────────────────────────────────────────
            with dept_tab:
                # Department stress comparison
                stress_col, detail_col = st.columns([1, 1])

                with stress_col:
                    st.markdown('<div class="glass-card" style="padding:20px;">', unsafe_allow_html=True)
                    st.markdown("#### 🔥 Department Stress Levels")
                    dept_stress = hr_dash_data.get("department_stress_levels", {})
                    if dept_stress:
                        stress_depts = list(dept_stress.keys())
                        stress_vals = list(dept_stress.values())
                        stress_colors = ['#ef4444' if v > 0.6 else ('#f59e0b' if v > 0.3 else '#10b981') for v in stress_vals]
                        fig_stress = go.Figure(data=[
                            go.Bar(
                                x=stress_depts, y=stress_vals,
                                marker_color=stress_colors,
                                text=[f"{v*100:.0f}%" for v in stress_vals],
                                textposition='outside',
                                textfont=dict(size=12, color='white')
                            )
                        ])
                        fig_stress.update_layout(
                            margin=dict(l=20, r=20, t=10, b=40), height=320,
                            yaxis=dict(range=[0, 1.05], title="Stress Level", showgrid=True, gridcolor='rgba(255,255,255,0.08)'),
                            xaxis=dict(showgrid=False),
                            paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)',
                            font=dict(color='#e2e8f0')
                        )
                        st.plotly_chart(fig_stress, use_container_width=True)
                    else:
                        st.info("No department stress data available.")
                    st.markdown('</div>', unsafe_allow_html=True)

                with detail_col:
                    # Sentiment vs Stress scatter
                    st.markdown('<div class="glass-card" style="padding:20px;">', unsafe_allow_html=True)
                    st.markdown("#### 🎯 Sentiment vs Stress (Risk Quadrant)")
                    dept_sent = hr_dash_data.get("department_sentiment", {})
                    dept_stress = hr_dash_data.get("department_stress_levels", {})
                    common_depts = set(dept_sent.keys()) & set(dept_stress.keys())
                    if common_depts:
                        fig_scatter = go.Figure()
                        for d in common_depts:
                            s_val = dept_sent[d]
                            st_val = dept_stress[d]
                            marker_color = '#ef4444' if (s_val < 0 and st_val > 0.4) else ('#f59e0b' if st_val > 0.3 else '#10b981')
                            fig_scatter.add_trace(go.Scatter(
                                x=[s_val], y=[st_val],
                                mode='markers+text',
                                marker=dict(size=18, color=marker_color, line=dict(width=2, color='white')),
                                text=[d], textposition='top center',
                                textfont=dict(size=11, color='#e2e8f0'),
                                showlegend=False
                            ))
                        fig_scatter.add_hline(y=0.4, line_dash="dash", line_color="rgba(239,68,68,0.4)")
                        fig_scatter.add_vline(x=0, line_dash="dash", line_color="rgba(255,255,255,0.2)")
                        fig_scatter.update_layout(
                            margin=dict(l=20, r=20, t=10, b=40), height=320,
                            xaxis=dict(title="Sentiment Score", range=[-1.1, 1.1], showgrid=True, gridcolor='rgba(255,255,255,0.08)'),
                            yaxis=dict(title="Stress Level", range=[0, 1.05], showgrid=True, gridcolor='rgba(255,255,255,0.08)'),
                            paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)',
                            font=dict(color='#e2e8f0')
                        )
                        st.plotly_chart(fig_scatter, use_container_width=True)
                    else:
                        st.info("Not enough data for risk quadrant.")
                    st.markdown('</div>', unsafe_allow_html=True)

                # Department drill-down selector
                st.markdown("---")
                st.markdown("### 🔍 Department Deep Dive")
                all_depts = list(hr_dash_data.get("department_sentiment", {}).keys())
                if all_depts:
                    selected_dept = st.selectbox("Select department:", all_depts, key="hr_dept_drilldown")
                    dd = None
                    try:
                        params = {}
                        if selected_survey_id is not None:
                            params["survey_id"] = selected_survey_id
                        dept_resp = requests.get(f"{BASE_URL}/pulse-survey/dashboard/department/{selected_dept}", params=params)
                        if dept_resp.status_code == 200:
                            dd = dept_resp.json()
                        else:
                            dd = None
                    except Exception:
                        dd = None

                    if dd:
                        dd1, dd2, dd3, dd4 = st.columns(4)
                        with dd1:
                            st.metric("Team Size", dd.get("team_size", 0))
                        with dd2:
                            st.metric("Avg Sentiment", f"{dd.get('average_sentiment', 0):+.2f}")
                        with dd3:
                            st.metric("Survey Responses", dd.get("recent_responses_count", 0))
                        with dd4:
                            risk = dd.get("retention_risk_summary", {})
                            st.metric("High Risk Count", risk.get("High", 0))

                        # Emotion distribution radar
                        emotions = dd.get("emotion_distribution", {})
                        if emotions:
                            st.markdown('<div class="glass-card" style="padding:20px;">', unsafe_allow_html=True)
                            st.markdown(f"#### 🧠 {selected_dept} — Emotion Distribution")
                            cats = list(emotions.keys())
                            vals = list(emotions.values())
                            vals_closed = vals + [vals[0]]  # close the radar
                            cats_closed = cats + [cats[0]]
                            fig_radar = go.Figure(data=go.Scatterpolar(
                                r=vals_closed, theta=cats_closed,
                                fill='toself',
                                fillcolor='rgba(99,102,241,0.25)',
                                line=dict(color='#818cf8', width=2),
                                marker=dict(size=6)
                            ))
                            fig_radar.update_layout(
                                polar=dict(
                                    radialaxis=dict(range=[0, 1], showticklabels=True, tickfont=dict(color='#94a3b8')),
                                    angularaxis=dict(tickfont=dict(color='#e2e8f0'))
                                ),
                                margin=dict(l=60, r=60, t=20, b=20), height=320,
                                paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)',
                                font=dict(color='#e2e8f0')
                            )
                            st.plotly_chart(fig_radar, use_container_width=True)
                            st.markdown('</div>', unsafe_allow_html=True)

                        # Coaching tips
                        coaching = dd.get("coaching_tips", [])
                        if coaching:
                            st.markdown('<div class="glass-card" style="padding:20px;">', unsafe_allow_html=True)
                            st.markdown(f"#### 💡 AI Coaching Tips for {selected_dept} Managers")
                            for i, tip in enumerate(coaching):
                                st.markdown(f"**{i+1}.** {tip}")
                            st.markdown('</div>', unsafe_allow_html=True)
                else:
                    st.info("No department data available for drill-down.")

            # ────────────────────────────────────────────
            # TAB 3: Retention Risk
            # ────────────────────────────────────────────
            with risk_tab:
                st.markdown('<div class="glass-card" style="padding:20px;">', unsafe_allow_html=True)
                st.markdown("#### ⚠️ Retention Risk Distribution by Department")
                risk_by_dept = hr_dash_data.get("risk_by_department", {})
                if risk_by_dept:
                    risk_depts = list(risk_by_dept.keys())
                    high_vals = [risk_by_dept[d].get("High", 0) for d in risk_depts]
                    med_vals = [risk_by_dept[d].get("Medium", 0) for d in risk_depts]
                    low_vals = [risk_by_dept[d].get("Low", 0) for d in risk_depts]

                    fig_risk = go.Figure()
                    fig_risk.add_trace(go.Bar(name='High Risk', x=risk_depts, y=high_vals, marker_color='#ef4444', text=high_vals, textposition='auto', textfont=dict(color='white')))
                    fig_risk.add_trace(go.Bar(name='Medium Risk', x=risk_depts, y=med_vals, marker_color='#f59e0b', text=med_vals, textposition='auto', textfont=dict(color='white')))
                    fig_risk.add_trace(go.Bar(name='Low Risk', x=risk_depts, y=low_vals, marker_color='#10b981', text=low_vals, textposition='auto', textfont=dict(color='white')))
                    fig_risk.update_layout(
                        barmode='stack',
                        margin=dict(l=20, r=20, t=10, b=40), height=350,
                        yaxis=dict(title="Employee Count", showgrid=True, gridcolor='rgba(255,255,255,0.08)'),
                        xaxis=dict(showgrid=False),
                        paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)',
                        legend=dict(orientation='h', yanchor='bottom', y=1.02, xanchor='right', x=1, font=dict(color='#e2e8f0')),
                        font=dict(color='#e2e8f0')
                    )
                    st.plotly_chart(fig_risk, use_container_width=True)

                    # Risk summary table
                    st.markdown("##### 📋 Risk Summary Table")
                    risk_table_data = []
                    for d in risk_depts:
                        total = high_vals[risk_depts.index(d)] + med_vals[risk_depts.index(d)] + low_vals[risk_depts.index(d)]
                        risk_table_data.append({
                            "Department": d,
                            "🔴 High": risk_by_dept[d].get("High", 0),
                            "🟡 Medium": risk_by_dept[d].get("Medium", 0),
                            "🟢 Low": risk_by_dept[d].get("Low", 0),
                            "Total Responses": total
                        })
                    st.dataframe(pd.DataFrame(risk_table_data), use_container_width=True, hide_index=True)
                else:
                    st.info("No retention risk data available yet.")
                st.markdown('</div>', unsafe_allow_html=True)

            # ────────────────────────────────────────────
            # TAB 4: Strategic Priorities
            # ────────────────────────────────────────────
            with strategy_tab:
                strat_col, policy_col = st.columns([1, 1])

                with strat_col:
                    st.markdown('<div class="glass-card" style="padding:20px;">', unsafe_allow_html=True)
                    st.markdown("#### 🎯 AI-Generated Strategic Priorities")
                    priorities = hr_dash_data.get("strategic_priorities", [])
                    if priorities:
                        for i, p in enumerate(priorities):
                            priority_icon = "🔴" if i == 0 else ("🟡" if i == 1 else "🟢")
                            st.markdown(f"""
                            <div style="background:rgba(99,102,241,0.08); border-radius:10px; padding:14px; margin-bottom:10px; border-left:4px solid {'#ef4444' if i==0 else ('#f59e0b' if i==1 else '#10b981')};">
                                <strong style="color:#e2e8f0;">{priority_icon} Priority {i+1}</strong>
                                <p style="margin:6px 0 0; color:#cbd5e1; font-size:0.9rem;">{p}</p>
                            </div>
                            """, unsafe_allow_html=True)
                    else:
                        st.info("Submit more survey responses to generate strategic priorities.")
                    st.markdown('</div>', unsafe_allow_html=True)

                with policy_col:
                    st.markdown('<div class="glass-card" style="padding:20px;">', unsafe_allow_html=True)
                    st.markdown("#### 📚 RAG-Matched Policy Recommendations")
                    policy_recs = hr_dash_data.get("policy_recommendations", [])
                    if policy_recs:
                        for pr in policy_recs:
                            cat_label = (pr.get("category", "policy") or "policy").upper().replace("_", " ")
                            score_display = f" — Match: {pr['score']*100:.0f}%" if 'score' in pr else ""
                            st.markdown(f"""
                            <div style="background:rgba(16,185,129,0.08); border:1px solid rgba(16,185,129,0.2); border-radius:10px; padding:14px; margin-bottom:10px;">
                                <span style="display:inline-block; background:rgba(16,185,129,0.2); color:#6ee7b7; font-size:0.7rem; font-weight:600; padding:2px 8px; border-radius:4px;">{cat_label}{score_display}</span>
                                <h4 style="margin:8px 0 4px; color:#e2e8f0 !important; font-size:0.95rem;">{pr.get('title', 'Policy')}</h4>
                                <p style="margin:0; font-size:0.82rem; color:#94a3b8; line-height:1.4;">{(pr.get('content', '') or '')[:200]}...</p>
                            </div>
                            """, unsafe_allow_html=True)
                    else:
                        st.info("No policy recommendations available yet.")
                    st.markdown('</div>', unsafe_allow_html=True)

            # ────────────────────────────────────────────
            # TAB 5: Manage Surveys
            # ────────────────────────────────────────────
            with manage_tab:
                st.markdown('<div class="glass-card" style="padding:20px; border-radius: 12px; margin-bottom: 20px;">', unsafe_allow_html=True)
                st.markdown("### 📋 Create & Publish Pulse Survey")
                st.markdown("Design a new custom survey to gather employee feedback. Once published, the survey will be immediately active and available for employees in their portal.")
                
                survey_title = st.text_input(
                    "Survey Title:",
                    placeholder="e.g. Q3 Remote Work & Wellbeing Survey",
                    key="new_survey_title_input"
                )
                
                is_anon = st.checkbox(
                    "Anonymous Survey",
                    value=True,
                    help="Anonymous surveys do not record employee names or IDs in response records, though cooldown periods are still tracked.",
                    key="new_survey_anon_checkbox"
                )
                
                st.markdown("#### ❓ Survey Questions")
                
                questions_to_remove = []
                for idx, q in enumerate(st.session_state["new_survey_questions"]):
                    st.markdown(f"""
                    <div style="background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.08); border-radius:10px; padding:16px; margin-bottom:12px;">
                        <strong style="color:#e2e8f0;">Question #{idx+1}</strong>
                    </div>
                    """, unsafe_allow_html=True)
                    
                    q_col1, q_col2, q_col3 = st.columns([3, 1.5, 0.5])
                    with q_col1:
                        q_text = st.text_input(
                            "Question Text:",
                            value=q["question_text"],
                            key=f"q_text_input_{idx}",
                            placeholder="e.g. How satisfied are you with our current remote work tools?"
                        )
                        st.session_state["new_survey_questions"][idx]["question_text"] = q_text
                    with q_col2:
                        q_type = st.selectbox(
                            "Question Type:",
                            options=["rating", "text", "mcq"],
                            index=["rating", "text", "mcq"].index(q["type"]),
                            key=f"q_type_select_{idx}"
                        )
                        st.session_state["new_survey_questions"][idx]["type"] = q_type
                    with q_col3:
                        st.write("<div style='height: 28px;'></div>", unsafe_allow_html=True)
                        if st.button("🗑️", key=f"q_remove_btn_{idx}", help="Remove this question"):
                            questions_to_remove.append(idx)
                    
                    if q_type == "mcq":
                        q_opts = st.text_input(
                            "MCQ Options (comma-separated):",
                            value=q.get("options", "Yes, No"),
                            key=f"q_options_input_{idx}",
                            help="Enter options separated by commas. Example: Yes, No, Maybe"
                        )
                        st.session_state["new_survey_questions"][idx]["options"] = q_opts

                # Apply question removals
                if questions_to_remove:
                    for idx in sorted(questions_to_remove, reverse=True):
                        st.session_state["new_survey_questions"].pop(idx)
                    st.rerun()
                
                # Action buttons
                col_add, col_pub = st.columns([1, 1])
                with col_add:
                    if st.button("➕ Add Question", use_container_width=True, key="add_question_btn"):
                        st.session_state["new_survey_questions"].append({"question_text": "", "type": "rating", "options": "Yes, No"})
                        st.rerun()
                
                with col_pub:
                    if st.button("🚀 Publish Survey", use_container_width=True, key="publish_survey_btn"):
                        if not survey_title.strip():
                            st.error("⚠️ Survey Title is required.")
                        elif not st.session_state["new_survey_questions"]:
                            st.error("⚠️ Please add at least one question to the survey.")
                        else:
                            questions_payload = []
                            valid = True
                            for idx, q in enumerate(st.session_state["new_survey_questions"]):
                                if not q["question_text"].strip():
                                    st.error(f"⚠️ Question #{idx+1} Text cannot be empty.")
                                    valid = False
                                    break
                                
                                opts = None
                                if q["type"] == "mcq":
                                    opts = [opt.strip() for opt in q.get("options", "").split(",") if opt.strip()]
                                    if len(opts) < 2:
                                        st.error(f"⚠️ Question #{idx+1} must have at least 2 options for Multiple Choice.")
                                        valid = False
                                        break
                                
                                questions_payload.append({
                                    "question_text": q["question_text"].strip(),
                                    "type": q["type"],
                                    "options": opts,
                                    "sequence": idx + 1
                                })
                            
                            if valid:
                                payload = {
                                    "title": survey_title.strip(),
                                    "is_anonymous": is_anon,
                                    "questions": questions_payload
                                }
                                with st.spinner("Publishing new custom survey..."):
                                    try:
                                        resp = requests.post(f"{BASE_URL}/pulse-survey/create", json=payload)
                                        if resp.status_code == 200:
                                            st.success("🎉 Survey published successfully!")
                                            st.session_state["new_survey_questions"] = [{"question_text": "", "type": "rating", "options": "Yes, No"}]
                                            st.balloons()
                                            st.rerun()
                                        else:
                                            st.error(f"Failed to publish survey: {resp.text}")
                                    except Exception as e:
                                        st.error(f"Error calling backend API to create survey: {e}")
                st.markdown('</div>', unsafe_allow_html=True)



    # ══════════════════════════════════════════════════════════════════════
    # PAGE: EXIT MANAGEMENT
    # ══════════════════════════════════════════════════════════════════════
    elif selected_page == "ExitMgmt":
        st.markdown("""
        <div class="page-header">
            <div class="page-header-icon">🚪</div>
            <div><h1 style="margin:0; font-size:1.8rem !important;">Exit Management</h1></div>
        </div>
        <p class="page-subtitle">AI-powered exit interview analysis — Whisper transcription · Bedrock guardrail · Nova HR insights · S3 report storage</p>
        """, unsafe_allow_html=True)

        # ── Pipeline description cards ──
        st.markdown("""
        <div class="glass-card" style="padding:24px; margin-bottom:24px;">
            <h3 style="margin-top:0;">🤖 AI Exit Interview Pipeline</h3>
            <div style="display:grid; grid-template-columns:repeat(4,1fr); gap:14px; margin-top:16px;">
                <div style="background:rgba(239,68,68,0.08); border-radius:10px; padding:14px; border-left:4px solid #ef4444;">
                    <strong style="color:#fca5a5;">🎙️ 1. Whisper Transcription</strong>
                    <p style="font-size:0.82rem; color:#94a3b8; margin:6px 0 0;">Local Whisper AI converts audio to clean text transcript.</p>
                </div>
                <div style="background:rgba(239,68,68,0.08); border-radius:10px; padding:14px; border-left:4px solid #ef4444;">
                    <strong style="color:#fca5a5;">🛡️ 2. Bedrock Guardrail</strong>
                    <p style="font-size:0.82rem; color:#94a3b8; margin:6px 0 0;">Nova validates this is a genuine exit interview (not random audio).</p>
                </div>
                <div style="background:rgba(239,68,68,0.08); border-radius:10px; padding:14px; border-left:4px solid #ef4444;">
                    <strong style="color:#fca5a5;">📊 3. HR Analysis</strong>
                    <p style="font-size:0.82rem; color:#94a3b8; margin:6px 0 0;">Bedrock Nova generates sentiment, concerns, attrition risk & recommendations.</p>
                </div>
                <div style="background:rgba(239,68,68,0.08); border-radius:10px; padding:14px; border-left:4px solid #ef4444;">
                    <strong style="color:#fca5a5;">☁️ 4. S3 Report</strong>
                    <p style="font-size:0.82rem; color:#94a3b8; margin:6px 0 0;">Full report saved to <code>reports/</code> in your S3 bucket.</p>
                </div>
            </div>
        </div>
        """, unsafe_allow_html=True)

        # ── Session state for selected employee profile ──
        if "exit_selected_resignation_id" not in st.session_state:
            st.session_state["exit_selected_resignation_id"] = None
        if "exit_analysis_result" not in st.session_state:
            st.session_state["exit_analysis_result"] = None

        # ── Fetch resigned employees pending analysis ──
        try:
            resignations_res = requests.get(
                f"{BASE_URL}/hr/resignations",
                headers=headers
            )
            if resignations_res.status_code == 200:
                resignations_list = resignations_res.json()
            else:
                resignations_list = []
                st.error(f"Could not fetch resignations: {resignations_res.text}")
        except Exception as ex:
            resignations_list = []
            st.error(f"Backend connection error: {ex}")

        # ── DETAIL VIEW: HR clicked an employee profile ──
        selected_res_id = st.session_state.get("exit_selected_resignation_id")
        if selected_res_id:
            # Fetch full resignation details
            try:
                detail_res = requests.get(
                    f"{BASE_URL}/hr/resignations/{selected_res_id}",
                    headers=headers
                )
                if detail_res.status_code == 200:
                    r_detail = detail_res.json()
                else:
                    st.error("Could not load resignation details.")
                    st.session_state["exit_selected_resignation_id"] = None
                    st.rerun()
                    r_detail = {}
            except Exception as ex:
                st.error(f"Connection error: {ex}")
                r_detail = {}

            if r_detail:
                # Back button
                if st.button("← Back to Employee List", key="exit_back_btn"):
                    st.session_state["exit_selected_resignation_id"] = None
                    st.session_state["exit_analysis_result"] = None
                    st.rerun()

                # Employee profile header
                resigned_date = r_detail.get("resigned_at", "")[:10] if r_detail.get("resigned_at") else "—"
                st.markdown(f"""
                <div class="glass-card" style="padding:24px; border-left:4px solid #ef4444; margin-bottom:20px;">
                    <div style="display:flex; justify-content:space-between; align-items:flex-start; flex-wrap:wrap; gap:12px;">
                        <div>
                            <h2 style="margin:0 0 6px; color:#f8fafc !important;">{r_detail.get('name', '—')}</h2>
                            <p style="margin:0; color:#94a3b8 !important; font-size:0.9rem;">
                                🏷️ {r_detail.get('employee_code', '—')} &nbsp;·&nbsp;
                                🏢 {r_detail.get('department', '—')} &nbsp;·&nbsp;
                                💼 {r_detail.get('designation', '—')} &nbsp;·&nbsp;
                                📅 Resigned: {resigned_date}
                            </p>
                        </div>
                        <div>
                            <span style="background:rgba(239,68,68,0.15); color:#fca5a5; border:1px solid rgba(239,68,68,0.3);
                                   border-radius:20px; padding:6px 16px; font-size:0.82rem; font-weight:600;">
                                🚪 RESIGNED
                            </span>
                        </div>
                    </div>
                </div>
                """, unsafe_allow_html=True)

                # ── If analysis is already done, show results ──
                cached_result = st.session_state.get("exit_analysis_result")

                if r_detail.get("analysis_done") or cached_result:
                    report_data = cached_result if cached_result else r_detail
                    sentiment_score = report_data.get("sentiment_score") or 0.0
                    hr_report_text = report_data.get("hr_report") or ""
                    transcript_text = report_data.get("transcript") or ""
                    s3_path = report_data.get("s3_report_path") or "—"

                    # Sentiment color
                    if sentiment_score > 0.2:
                        sent_label = "Positive"
                        sent_color = "#22c55e"
                        sent_bg = "rgba(34,197,94,0.12)"
                    elif sentiment_score < -0.2:
                        sent_label = "Negative"
                        sent_color = "#ef4444"
                        sent_bg = "rgba(239,68,68,0.12)"
                    else:
                        sent_label = "Neutral"
                        sent_color = "#f59e0b"
                        sent_bg = "rgba(245,158,11,0.12)"

                    sent_pct = int((sentiment_score + 1) * 50)  # Map -1..1 to 0..100

                    st.success("✅ Exit interview analysis completed successfully!")
                    st.markdown("---")
                    st.markdown("### 📊 Analysis Dashboard")

                    # Sentiment gauge row
                    col_sent, col_s3 = st.columns([1, 1])
                    with col_sent:
                        st.markdown(f"""
                        <div class="glass-card" style="padding:20px; text-align:center;">
                            <p style="color:#94a3b8 !important; font-size:0.8rem; text-transform:uppercase; letter-spacing:0.08em; margin:0 0 10px;">Overall Sentiment</p>
                            <div style="font-size:2.2rem; font-weight:800; color:{sent_color} !important; margin-bottom:8px;">{sent_label}</div>
                            <div style="font-size:1.1rem; color:{sent_color} !important; margin-bottom:12px;">Score: {sentiment_score:+.2f}</div>
                            <div style="background:rgba(71,85,105,0.3); border-radius:8px; height:10px; overflow:hidden;">
                                <div style="width:{sent_pct}%; height:100%; background:{sent_color}; border-radius:8px; transition:width 1s ease;"></div>
                            </div>
                            <div style="display:flex; justify-content:space-between; margin-top:4px;">
                                <span style="color:#94a3b8 !important; font-size:0.72rem;">Very Negative</span>
                                <span style="color:#94a3b8 !important; font-size:0.72rem;">Very Positive</span>
                            </div>
                        </div>
                        """, unsafe_allow_html=True)
                    with col_s3:
                        st.markdown(f"""
                        <div class="glass-card" style="padding:20px;">
                            <p style="color:#94a3b8 !important; font-size:0.8rem; text-transform:uppercase; letter-spacing:0.08em; margin:0 0 10px;">📄 S3 Report</p>
                            <p style="color:#a5b4fc !important; font-size:0.82rem; word-break:break-all; margin-bottom:12px;">{s3_path}</p>
                            <p style="color:#64748b !important; font-size:0.78rem; margin:0;">Report saved in your <code>reports/</code> folder on S3 bucket <code>recruitment-resumes-bucket1</code></p>
                        </div>
                        """, unsafe_allow_html=True)

                    st.markdown("<br>", unsafe_allow_html=True)

                    # HR Report sections
                    st.markdown("""
                    <div class="glass-card" style="padding:24px;">
                        <h3 style="margin-top:0; color:#f8fafc !important;">🤖 AI-Generated HR Report</h3>
                    """, unsafe_allow_html=True)
                    st.markdown(f"""<div style="color:#cbd5e1; white-space:pre-wrap; font-size:0.9rem; line-height:1.8;">{hr_report_text}</div>""", unsafe_allow_html=True)
                    st.markdown("</div>", unsafe_allow_html=True)

                    st.markdown("<br>", unsafe_allow_html=True)

                    # Transcript expander
                    with st.expander("📝 Full Interview Transcript"):
                        st.markdown(f"""<div style="color:#94a3b8; font-size:0.88rem; line-height:1.8; white-space:pre-wrap;">{transcript_text}</div>""", unsafe_allow_html=True)

                # ── Upload Audio Section (only if not yet analyzed) ──
                else:
                    st.markdown("""
                    <div class="glass-card" style="padding:24px; border-left:4px solid #6366f1; margin-bottom:20px;">
                        <h3 style="margin-top:0; color:#f8fafc !important;">🎙️ Upload Exit Interview Audio</h3>
                        <p style="color:#94a3b8 !important; margin-bottom:0;">
                            Upload the exit interview recording for this employee. The AI pipeline will:
                            transcribe it with Whisper, validate it's a genuine exit interview, then generate
                            a structured HR analysis report and store it in S3.
                        </p>
                    </div>
                    """, unsafe_allow_html=True)

                    audio_file = st.file_uploader(
                        "📁 Upload Exit Interview Audio",
                        type=["mp3", "wav", "m4a", "ogg", "webm"],
                        key=f"exit_audio_{selected_res_id}",
                        help="Supported formats: MP3, WAV, M4A, OGG, WEBM"
                    )

                    if audio_file:
                        st.markdown(f"""
                        <div style="background:rgba(99,102,241,0.08); border:1px solid rgba(99,102,241,0.2);
                                    border-radius:10px; padding:12px 16px; margin:8px 0;">
                            <span style="color:#a5b4fc !important;">✅ File ready: <strong>{audio_file.name}</strong>
                            ({audio_file.size // 1024:,} KB)</span>
                        </div>
                        """, unsafe_allow_html=True)

                    analyze_disabled = audio_file is None
                    if st.button(
                        "🤖 Analyze Exit Interview" if not analyze_disabled else "📁 Upload Audio First",
                        type="primary",
                        use_container_width=True,
                        disabled=analyze_disabled,
                        key=f"exit_analyze_btn_{selected_res_id}"
                    ):
                        with st.spinner(f"🔄 Analyzing exit interview for {r_detail.get('name', 'employee')}... This may take 1-2 minutes."):
                            try:
                                files_payload = {
                                    "file": (audio_file.name, audio_file.getvalue(), "audio/mpeg")
                                }
                                analyze_res = requests.post(
                                    f"{BASE_URL}/hr/resignations/{selected_res_id}/upload-interview",
                                    files=files_payload,
                                    headers=headers,
                                    timeout=300  # 5-min timeout for Whisper
                                )
                                if analyze_res.status_code == 200:
                                    result_data = analyze_res.json()
                                    st.session_state["exit_analysis_result"] = result_data
                                    st.success("✅ Analysis complete! Report saved to GCS.")
                                    st.rerun()
                                else:
                                    try:
                                        err_detail = analyze_res.json().get("detail", analyze_res.text)
                                    except Exception:
                                        err_detail = analyze_res.text
                                    st.error(f"❌ Analysis failed: {err_detail}")
                            except requests.exceptions.Timeout:
                                st.error("⏱️ Request timed out. Whisper transcription may still be running. Please refresh the page in a few moments.")
                            except Exception as ex:
                                st.error(f"Connection error: {ex}")

        # ── LIST VIEW: Show resigned employees awaiting audio upload ──
        # ── LIST VIEW: Show resigned employees awaiting audio upload and completed dashboard ──
        else:
            # Fetch completed resignations for dashboard
            completed_list = []
            try:
                completed_res = requests.get(
                    f"{BASE_URL}/hr/resignations/completed",
                    headers=headers
                )
                if completed_res.status_code == 200:
                    completed_list = completed_res.json()
            except Exception as ex:
                logger.error(f"Error fetching completed resignations: {ex}")

            tab_pending, tab_dashboard = st.tabs(["🕒 Pending Analysis", "📊 Overall Dashboard"])

            with tab_pending:
                st.markdown("### 👥 Resigned Employees — Pending Exit Interview Analysis")
                st.markdown("""
                <p style="color:#94a3b8 !important; font-size:0.88rem; margin-bottom:20px;">
                    The following employees have resigned and are awaiting exit interview analysis.
                    Click on a profile to upload their audio and generate the AI report.
                    Employees whose analysis is complete will move to the "Overall Dashboard" tab.
                </p>
                """, unsafe_allow_html=True)

                if not resignations_list:
                    st.markdown("""
                    <div class="glass-card" style="padding:32px; text-align:center;">
                        <div style="font-size:2.5rem; margin-bottom:12px;">✅</div>
                        <h3 style="margin:0 0 8px; color:#f8fafc !important;">All Exit Interviews Completed</h3>
                        <p style="color:#94a3b8 !important; margin:0;">
                            No resigned employees are currently awaiting exit interview analysis.
                            All offboarding records have been processed.
                        </p>
                    </div>
                    """, unsafe_allow_html=True)
                else:
                    st.markdown(f"""
                    <div style="background:rgba(239,68,68,0.08); border:1px solid rgba(239,68,68,0.2);
                                border-radius:12px; padding:12px 18px; margin-bottom:20px;">
                        <span style="color:#fca5a5 !important; font-weight:600;">
                            📋 {len(resignations_list)} employee{'s' if len(resignations_list) != 1 else ''} pending exit interview
                        </span>
                    </div>
                    """, unsafe_allow_html=True)

                    for r in resignations_list:
                        resigned_date = r.get("resigned_at", "")[:10] if r.get("resigned_at") else "—"
                        audio_status = "🟡 Audio Pending" if not r.get("audio_uploaded") else "🟠 Analyzing..."

                        col_card, col_btn = st.columns([5, 1])
                        with col_card:
                            st.markdown(f"""
                            <div class="glass-card" style="padding:18px; border-left:4px solid #ef4444; margin-bottom:0;">
                                <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px;">
                                    <div>
                                        <h3 style="margin:0 0 4px; color:#f8fafc !important; font-size:1.1rem;">{r.get('name', '—')}</h3>
                                        <p style="margin:0; color:#94a3b8 !important; font-size:0.83rem;">
                                            🏷️ {r.get('employee_code', '—')} &nbsp;·&nbsp;
                                            🏢 {r.get('department', '—')} &nbsp;·&nbsp;
                                            💼 {r.get('designation', '—')} &nbsp;·&nbsp;
                                            📅 Resigned: {resigned_date}
                                        </p>
                                    </div>
                                    <span style="background:rgba(239,68,68,0.12); color:#fca5a5 !important;
                                           border:1px solid rgba(239,68,68,0.25); border-radius:16px;
                                           padding:4px 12px; font-size:0.78rem; font-weight:600;">{audio_status}</span>
                                </div>
                            </div>
                            """, unsafe_allow_html=True)
                        with col_btn:
                            if st.button(
                                "📂 Open Profile",
                                key=f"open_profile_{r['id']}",
                                use_container_width=True,
                                help=f"Open exit interview portal for {r.get('name')}"
                            ):
                                st.session_state["exit_selected_resignation_id"] = r["id"]
                                st.session_state["exit_analysis_result"] = None
                                st.rerun()
                        st.markdown("<div style='margin-bottom:12px'></div>", unsafe_allow_html=True)

            with tab_dashboard:
                st.markdown("### 📊 Overall Exit Analysis Dashboard")
                st.markdown("""
                <p style="color:#94a3b8 !important; font-size:0.88rem; margin-bottom:20px;">
                    Aggregated sentiment and retention metrics for all processed offboarding exit interviews.
                </p>
                """, unsafe_allow_html=True)

                if not completed_list:
                    st.markdown("""
                    <div class="glass-card" style="padding:32px; text-align:center;">
                        <div style="font-size:2.5rem; margin-bottom:12px;">📊</div>
                        <h3 style="margin:0 0 8px; color:#f8fafc !important;">No Data Available Yet</h3>
                        <p style="color:#94a3b8 !important; margin:0;">
                            Complete at least one exit interview analysis to generate overall dashboard metrics.
                        </p>
                    </div>
                    """, unsafe_allow_html=True)
                else:
                    # Calculate aggregated stats
                    total_completed = len(completed_list)
                    avg_sentiment = sum(c.get("sentiment_score") or 0.0 for c in completed_list) / total_completed
                    
                    pos_count = sum(1 for c in completed_list if (c.get("sentiment_score") or 0.0) > 0.2)
                    neg_count = sum(1 for c in completed_list if (c.get("sentiment_score") or 0.0) < -0.2)
                    neu_count = total_completed - pos_count - neg_count
                    
                    pos_pct = int((pos_count / total_completed) * 100)
                    neg_pct = int((neg_count / total_completed) * 100)
                    neu_pct = 100 - pos_pct - neg_pct

                    # Metric row
                    col1, col2, col3, col4 = st.columns(4)
                    with col1:
                        st.metric("Total Analyzed", f"{total_completed}")
                    with col2:
                        st.metric("Average Sentiment", f"{avg_sentiment:+.2f}")
                    with col3:
                        st.metric("Positive Sentiment", f"{pos_count} ({pos_pct}%)")
                    with col4:
                        st.metric("Negative Sentiment", f"{neg_count} ({neg_pct}%)")

                    st.markdown("---")

                    col_chart, col_dept = st.columns([1, 1])
                    with col_chart:
                        st.markdown("##### Sentiment Distribution")
                        import plotly.graph_objects as go
                        fig = go.Figure(data=[go.Pie(
                            labels=['Positive', 'Neutral', 'Negative'],
                            values=[pos_count, neu_count, neg_count],
                            hole=.4,
                            marker_colors=['#22c55e', '#f59e0b', '#ef4444']
                        )])
                        fig.update_layout(
                            paper_bgcolor='rgba(0,0,0,0)',
                            plot_bgcolor='rgba(0,0,0,0)',
                            font_color='#cbd5e1',
                            margin=dict(t=10, b=10, l=10, r=10),
                            height=220,
                            showlegend=True
                        )
                        st.plotly_chart(fig, use_container_width=True)

                    with col_dept:
                        st.markdown("##### Resignations by Department")
                        dept_counts = {}
                        for c in completed_list:
                            d = c.get("department") or "Other"
                            dept_counts[d] = dept_counts.get(d, 0) + 1
                        
                        import plotly.express as px
                        dept_fig = px.bar(
                            x=list(dept_counts.values()),
                            y=list(dept_counts.keys()),
                            orientation='h',
                            labels={'x': 'Count', 'y': 'Department'},
                            color_discrete_sequence=['#6366f1']
                        )
                        dept_fig.update_layout(
                            paper_bgcolor='rgba(0,0,0,0)',
                            plot_bgcolor='rgba(0,0,0,0)',
                            font_color='#cbd5e1',
                            margin=dict(t=10, b=10, l=10, r=10),
                            height=220,
                            xaxis_title=None,
                            yaxis_title=None
                        )
                        st.plotly_chart(dept_fig, use_container_width=True)

                    st.markdown("---")
                    st.markdown("### 📋 Completed Exit Reports")
                    
                    for c in completed_list:
                        resigned_date = c.get("resigned_at", "")[:10] if c.get("resigned_at") else "—"
                        sentiment_score = c.get("sentiment_score") or 0.0
                        if sentiment_score > 0.2:
                            label = "Positive"
                            color = "#22c55e"
                        elif sentiment_score < -0.2:
                            label = "Negative"
                            color = "#ef4444"
                        else:
                            label = "Neutral"
                            color = "#f59e0b"

                        col_card, col_btn = st.columns([5, 1])
                        with col_card:
                            st.markdown(f"""
                            <div class="glass-card" style="padding:16px; border-left:4px solid {color}; margin-bottom:0;">
                                <div style="display:flex; justify-content:space-between; align-items:center;">
                                    <div>
                                        <strong style="font-size:1.05rem; color:#f8fafc;">{c.get('name')}</strong> ({c.get('employee_code')})
                                        <p style="margin:4px 0 0; color:#94a3b8; font-size:0.82rem;">
                                            🏢 {c.get('department')} &nbsp;·&nbsp; 💼 {c.get('designation')} &nbsp;·&nbsp; 📅 Resigned: {resigned_date}
                                        </p>
                                    </div>
                                    <span style="background:{color}20; color:{color}; border:1px solid {color}40; border-radius:12px; padding:3px 10px; font-size:0.75rem; font-weight:600;">
                                        {label} ({sentiment_score:+.2f})
                                    </span>
                                </div>
                            </div>
                            """, unsafe_allow_html=True)
                        with col_btn:
                            if st.button("🔍 View Report", key=f"view_rep_{c['id']}", use_container_width=True):
                                st.session_state["exit_selected_resignation_id"] = c["id"]
                                st.session_state["exit_analysis_result"] = None
                                st.rerun()
                        st.markdown("<div style='margin-bottom:8px'></div>", unsafe_allow_html=True)

