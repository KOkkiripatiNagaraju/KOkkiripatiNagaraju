# AI HR Hub: Team Onboarding & Module Integration Guide

This guide is designed for developers onboarding to the **AI HR Hub & Recruitment Orchestration System**. It covers setting up the local environment, module-by-module assignments, code integration guidelines, and team collaboration protocols.

---

## 1. System Architecture Overview

The system consists of three main containerized services running on a Docker bridge network, backed by a local PostgreSQL database:

*   **FastAPI Backend (:8000):** Orchestrates database queries, runs AI evaluations, and connects to external APIs (AWS Bedrock, AWS S3, and Brevo SMTP).
*   **Recruiter Portal (:8501):** Streamlit admin app used by HR to track positions, review resume rankings, schedule interviews, and manage communications.
*   **Careers Portal (:8502):** Streamlit self-apply portal for candidates to fill out applications and upload resumes.

```
                  ┌────────────────────────┐
                  │      User Browser      │
                  └───────────┬────────────┘
                              │ (Accesses Port 8501 / 8502)
                              ▼
  ┌────────────────────────────────────────────────────────┐
  │                 Docker Compose Stack                   │
  │                                                        │
  │   ┌──────────────────┐          ┌──────────────────┐   │
  │   │   Recruiter UI   │          │   Candidate UI   │   │
  │   │   (Port 8501)    │          │   (Port 8502)    │   │
  │   └────────┬─────────┘          └────────┬─────────┘   │
  │            │                             │             │
  │            └──────────────┬──────────────┘             │
  │                           │ (HTTP REST API /api)       │
  │                           ▼                            │
  │                 ┌──────────────────┐                   │
  │                 │  FastAPI Backend │                   │
  │                 │   (Port 8000)    │                   │
  │                 └─────────┬────────┘                   │
  │                           │                            │
  │                           ▼ (SQL / ORM)                │
  │                 ┌──────────────────┐                   │
  │                 │ PostgreSQL Host  │                   │
  │                 │   (Port 5432)    │                   │
  │                 └──────────────────┘                   │
  └────────────────────────────────────────────────────────┘
```

---

## 2. Local Environment Setup

Follow these steps to spin up the platform locally:

### Step 1: Install Dependencies
*   Download and install [Docker Desktop](https://www.docker.com/products/docker-desktop/).
*   (Optional) Install Python 3.10+ if you wish to run unit tests or scripts outside of Docker.

### Step 2: Configure Environment Variables
Copy the `.env` template to the root folder of the project. Ensure the following environment variables are properly defined:
```env
DATABASE_URL=postgresql://postgres:root@localhost:5432/recruitment_db
AWS_ACCESS_KEY_ID=YOUR_AWS_ACCESS_KEY_ID
AWS_SECRET_ACCESS_KEY=YOUR_AWS_SECRET_ACCESS_KEY
AWS_REGION=us-east-1
S3_BUCKET_NAME=your-resume-s3-bucket
BREVO_API_KEY=YOUR_BREVO_API_KEY
BREVO_SENDER_EMAIL=your-sender@domain.com
JWT_SECRET=your-randomly-generated-long-string
```

### Step 3: Run the Stack
Run Docker Compose from the root directory to build and start the backend and both Streamlit UI portals:
```bash
docker compose up -d --build
```

### Step 4: Seed the Database
Populate your database with default Admin/Recruiter logins and a sample job posting:
```bash
docker compose exec web python seed.py
```

### Step 5: Verification URLs
*   **Recruiter Portal:** [http://localhost:8501](http://localhost:8501)
    *   *Login:* `recruiter@company.com` / *Password:* `password123`
*   **Careers Portal:** [http://localhost:8502](http://localhost:8502)
    *   *Use this to submit dummy candidate applications.*
*   **API Documentation:** [http://localhost:8000/docs](http://localhost:8000/docs)
    *   *View endpoints, request schemas, and test responses.*

---

## 3. Module Assignments

The core recruitment pipeline (Parsing, ATS scoring, Voice interview setup, and Email center) is already fully implemented. Your team is tasked with implementing the remaining modules.

All database models have been pre-defined in `models/schemas.py`.

```
                    ┌──────────────────────────┐
                    │      models/schemas.py   │
                    │  (Defines all 15 tables) │
                    └─────────────┬────────────┘
                                  │
      ┌───────────────────────────┼───────────────────────────┐
      ▼                           ▼                           ▼
[Onboarding]                  [Training]                 [Offboarding]
- onboarding_processes       - role_templates            - offboarding_processes
- onboarding_documents       - skill_gap_analyses        - exit_interviews
                             - courses
                             - course_assignments
```

### Developer 1: Employee Onboarding
*   **Database Tables:** `onboarding_processes`, `onboarding_documents`
*   **Backend:** Create `routers/onboarding.py`
    *   Add GET endpoints to fetch active onboarding lists.
    *   Add PATCH endpoints to verify or reject uploaded documents.
*   **Frontend:** Create `views/onboarding.py`
    *   Provide a recruiter dashboard listing candidates in onboarding.
    *   Let HR view uploaded document links and approve/reject them.

### Developer 2: Training & Development (T&D)
*   **Database Tables:** `role_templates`, `skill_gap_analyses`, `courses`, `course_assignments`
*   **Backend:** Create `routers/training.py`
    *   Add POST endpoints to trigger skill gap analyses comparing an employee profile to a target role template.
    *   Add endpoints to assign learning courses based on gaps.
*   **Frontend:** Create `views/training.py`
    *   Build employee development dashboards mapping skill gap graphs.
    *   Allow managers to assign courses and track completion status.

### Developer 3: Policies & Chatbot Hub
*   **Database Tables:** `policies`, `chatbot_tickets`
*   **Backend:** Create `routers/policies.py`
    *   Implement RAG semantic search endpoints using AWS Bedrock Titan Embeddings to query policy documents.
    *   Add POST endpoints to escalate unhandled chatbot queries to human-managed support tickets.
*   **Frontend:** Create `views/chatbot.py`
    *   Build a chatbot interface where employees can ask HR questions.

### Developer 4: Employee Surveys & Offboarding
*   **Database Tables:** `survey_definitions`, `survey_questions`, `survey_responses`, `offboarding_processes`, `exit_interviews`
*   **Backend:** Create `routers/surveys.py` and `routers/offboarding.py`
    *   Create endpoints to submit surveys, evaluate sentiment metrics, and initiate offboarding.
    *   Process transcript data from voice exit notes and compute exit sentiment.
*   **Frontend:** Create `views/surveys_offboarding.py`
    *   Provide surveys submission view for employees, and analytics dashboard for HR.
    *   Provide exit interview portal for departing staff.

---

## 4. Integration & Registration Protocol (Lead Dev/Gatekeeper)

As modules are completed, they must be registered in the central API router and Streamlit navigation menu.

### Step 1: Register Backend Routers
In `routers/api.py`, import and include the developer's router:
```python
# routers/api.py
from routers import onboarding, training, policies, surveys, offboarding

router.include_router(onboarding.router, tags=["Onboarding"])
router.include_router(training.router, tags=["Training"])
router.include_router(policies.router, tags=["Policies"])
router.include_router(surveys.router, tags=["Surveys"])
router.include_router(offboarding.router, tags=["Offboarding"])
```

### Step 2: Register Streamlit Navigation Sidebar
In `app.py`, update `nav_options` in the sidebar to include the new screens:
```python
# app.py (around Line 836)
nav_options = {
    "📊  Dashboard":          "Dashboard",
    "💼  Jobs Management":    "Jobs",
    "📄  Resume Screening":   "Resume",
    "🏆  Candidate Rankings": "Rankings",
    "🎙️  AI Interview Panel": "Interview",
    "✉️  Email Center":       "Email",
    "📋  Employee Onboarding":"Onboarding",
    "📚  Training & Dev":     "Training",
    "🤖  Policy Chatbot":     "Chatbot",
    "🚪  Exit & Surveys":      "ExitSurveys",
}
```

Implement the corresponding view calls inside the page-routing block:
```python
# app.py (Page rendering logic)
if selected_page == "Dashboard":
    render_dashboard(headers)
elif selected_page == "Onboarding":
    from views.onboarding import render_onboarding_view
    render_onboarding_view(headers)
elif selected_page == "Training":
    from views.training import render_training_view
    render_training_view(headers)
elif selected_page == "Chatbot":
    from views.chatbot import render_chatbot_view
    render_chatbot_view(headers)
elif selected_page == "ExitSurveys":
    from views.surveys_offboarding import render_surveys_offboarding_view
    render_surveys_offboarding_view(headers)
```

---

## 5. Team Collaboration & Git Safety Guidelines

To keep development clean and prevent conflicts:

*   **Never Push Directly to `main`:** Work on descriptive feature branches:
    ```bash
    git checkout -b feature/onboarding-module
    ```
*   **Keep Pull Requests Small:** Commit only your specific routers, views, and helpers. Do not edit core framework files (`main.py`, `app.py`, or database configurations) without coordinating with the Lead Developer.
*   **Avoid Committing Virtual Envs or Caches:** Make sure python caches, virtual directories (`.venv`, `myenv`), and configuration caches are excluded.
*   **Database Schema Updates:** The schemas are declared in `models/schemas.py`. If you need to make model alterations, align with the team first so database schemas stay unified.
