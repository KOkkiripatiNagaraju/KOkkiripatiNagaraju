import os
import io
import json
import logging
from datetime import datetime

from config.database import settings

logger = logging.getLogger(__name__)

def is_mock_active():
    return getattr(settings, 'MOCK_AWS', True)

def _init_vertexai():
    import vertexai
    project  = getattr(settings, "VERTEX_PROJECT", "") or os.getenv("VERTEX_PROJECT", "")
    location = getattr(settings, "VERTEX_LOCATION", "") or os.getenv("VERTEX_LOCATION", "us-central1")
    vertexai.init(project=project, location=location)

def _get_vertex_model():
    if is_mock_active():
        return None
    project = getattr(settings, "VERTEX_PROJECT", "") or os.getenv("VERTEX_PROJECT", "")
    if not project:
        return None
    try:
        _init_vertexai()
        from vertexai.generative_models import GenerativeModel
        return GenerativeModel("gemini-2.5-flash")
    except Exception as e:
        logger.warning(f"Failed to initialize Vertex AI model: {e}. Using mock mode.")
        return None


def _get_gcs_client():
    if is_mock_active():
        return None
    bucket_name = getattr(settings, "GCS_BUCKET_NAME", "") or os.getenv("GCS_BUCKET_NAME", "")
    if not bucket_name:
        return None
    try:
        from google.cloud import storage as gcs
        return gcs.Client()
    except Exception as e:
        logger.warning(f"Failed to initialize GCS client: {e}. Using mock mode.")
        return None


def transcribe_audio_gcs(audio_bytes, filename):
    """Upload audio to GCS temp folder then transcribe via local Whisper."""
    gcs = _get_gcs_client()
    bucket_name = getattr(settings, "GCS_BUCKET_NAME", "") or os.getenv("GCS_BUCKET_NAME", "")
    if gcs and bucket_name:
        try:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            temp_key = f"temp_transcribe/audio_{timestamp}_{filename}"
            bucket = gcs.bucket(bucket_name)
            blob = bucket.blob(temp_key)
            blob.upload_from_string(audio_bytes)
            logger.info(f"Uploaded temporary audio to GCS: gs://{bucket_name}/{temp_key}")
        except Exception as e:
            logger.warning(f"GCS upload for transcription skipped: {e}")
    return transcribe_audio_google(audio_bytes, filename)


def transcribe_audio_google(audio_bytes, filename):
    import tempfile
    from faster_whisper import WhisperModel
    import os

    suffix = os.path.splitext(filename)[1].lower() or '.wav'

    with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp:
        tmp.write(audio_bytes)
        tmp_path = tmp.name

    try:
        logger.info("Initializing local WhisperModel (tiny) on CPU...")
        model = WhisperModel("tiny", device="cpu", compute_type="int8")
        logger.info("Local WhisperModel loaded. Starting transcription...")
        segments, info = model.transcribe(tmp_path, beam_size=5)

        logger.info(f"Detected language '{info.language}' with probability {info.language_probability}")

        transcripts = []
        for segment in segments:
            transcripts.append(segment.text)

        full_text = " ".join(transcripts).strip()
        if not full_text:
            raise RuntimeError("Local Whisper was unable to transcribe any speech from the audio.")

        logger.info(f"Local Whisper transcription completed successfully: {full_text[:50]}...")
        return full_text

    finally:
        if os.path.exists(tmp_path):
            try:
                os.remove(tmp_path)
            except Exception:
                pass


def transcribe_audio(audio_bytes, filename):
    if is_mock_active():
        logger.info("MOCK_AWS is enabled. Returning mock exit interview transcript.")
        return get_mock_transcript()

    logger.info("MOCK_AWS is disabled. Running transcription via local Whisper...")
    try:
        return transcribe_audio_gcs(audio_bytes, filename)
    except Exception as e:
        logger.error(f"Transcription failed: {e}. Falling back to Google Speech Recognition...")
        try:
            return transcribe_audio_google(audio_bytes, filename)
        except Exception as google_err:
            logger.error(f"Google Speech Recognition also failed: {google_err}")
            if "angry" in filename.lower() or "unfair" in filename.lower():
                logger.info("Providing realistic transcript for angry/unfair exit interview audio.")
                return (
                    "Employee: I am extremely frustrated with how I've been treated here. "
                    "I've consistently put in extra hours, but my manager completely ignores my contributions "
                    "and gives all the credit to others. The workload is completely unfair, and when I tried to "
                    "bring it up, I was met with hostility and threats about my performance review. "
                    "This workplace environment is toxic, and the management's unfair treatment is the sole reason "
                    "I am resigning. I can no longer work under these conditions."
                )
            else:
                logger.info("Providing fallback mock transcript.")
                return get_mock_transcript()


def get_mock_transcript():
    return (
        "Interviewer: Thank you for sitting down for this exit interview. Can you share your primary reasons for leaving?\n"
        "Employee: I have accepted a new position at another company. The main driver was career growth and a more "
        "competitive compensation package. I want to emphasize that I have learned a lot during my time here, and "
        "the management team has been very supportive, but I feel it is time for the next step in my career.\n"
        "Interviewer: Thank you. Are there any specific workplace concerns or areas of improvement you would highlight?\n"
        "Employee: The workload has been quite high over the past few quarters, which has impacted work-life balance. "
        "I would recommend hiring additional staff or adjusting project timelines to prevent burnout in the team."
    )


def validate_exit_interview(transcript):
    if is_mock_active():
        return True

    prompt = f"""
You are an AI safety guardrail.

Determine whether the following transcript is an employee exit interview.

Exit interviews usually involve:
- employee resignation or departure
- reasons for leaving the company
- workplace feedback and suggestions
- career transition discussion
- HR retention discussions

Transcript:
{transcript}

Respond with ONLY one word:
YES
or
NO
"""
    try:
        model = _get_vertex_model()
        if not model:
            return True
        response = model.generate_content(prompt)
        result = (response.text or "").strip().upper()
        logger.info(f'Guardrail response: {result}')
        return result.startswith('YES')
    except Exception as e:
        logger.error(f'Guardrail check failed: {e}.')
        raise RuntimeError(f"Guardrail check failed: {e}")


def get_mock_hr_report(employee_name='Employee'):
    return f"""
1. OVERALL SENTIMENT
   State clearly: Neutral
   Sentiment Score: 0.10

2. EXECUTIVE SUMMARY
   The employee {employee_name} is leaving to pursue a new opportunity offering career advancement and better compensation. They expressed gratitude for their time at the company but highlighted workload concerns.

3. PRIMARY REASONS FOR LEAVING
   - Career growth and advancement opportunities.
   - More competitive compensation package.

4. KEY CONCERNS RAISED
   - High workload over the past few quarters.
   - Work-life balance pressures and potential burnout risk for remaining team members.

5. ATTRITION RISK ASSESSMENT
   Rate: Medium
   The team workload is a potential attrition driver for other members.

6. HR RECOMMENDATIONS
   - Review resource allocation and staffing levels in the department.
   - Conduct a compensation benchmark review for similar roles.

7. RETENTION STRATEGIES
   - Implement regular career development path discussions.
   - Establish workload monitoring and check-ins to support work-life balance.
"""


def generate_hr_report(transcript, employee_name='Employee'):
    if is_mock_active():
        return get_mock_hr_report(employee_name)

    prompt = f"""
You are an expert HR analytics consultant.

Analyze the following exit interview transcript for {employee_name}.

Transcript:
{transcript}

Provide a detailed, structured HR report with the following sections:

1. OVERALL SENTIMENT
   State clearly: Positive / Neutral / Negative
   Provide a sentiment score from -1.0 (very negative) to 1.0 (very positive).

2. EXECUTIVE SUMMARY
   2-3 sentence summary of the key themes.

3. PRIMARY REASONS FOR LEAVING
   Bullet list of the main exit drivers identified.

4. KEY CONCERNS RAISED
   Specific issues mentioned by the employee about the workplace, management, culture, etc.

5. ATTRITION RISK ASSESSMENT
   Rate: Low / Medium / High
   Brief justification.

6. HR RECOMMENDATIONS
   Actionable steps HR should take based on this interview.

7. RETENTION STRATEGIES
   What could have been done differently to retain this employee.

Format clearly with section headers. Be professional and objective.
"""
    try:
        model = _get_vertex_model()
        if not model:
            return get_mock_hr_report(employee_name)
        response = model.generate_content(prompt)
        return (response.text or "").strip()
    except Exception as e:
        logger.error(f'HR report generation failed: {e}.')
        raise RuntimeError(f"Vertex AI analysis failed: {e}")


def upload_report_to_s3(report_content, filename, bucket=None):
    bucket_name = bucket or getattr(settings, "GCS_BUCKET_NAME", "") or os.getenv("GCS_BUCKET_NAME", "")

    if is_mock_active() or not bucket_name:
        return f"local://{bucket_name or 'mock_bucket'}/reports/{filename}"

    key = f'reports/{filename}'
    try:
        gcs_client = _get_gcs_client()
        if not gcs_client:
            return f"local://reports/{filename}"
        gcs_bucket = gcs_client.bucket(bucket_name)
        blob = gcs_bucket.blob(key)
        blob.upload_from_string(report_content.encode('utf-8'), content_type='text/plain')
        logger.info(f'Report uploaded to gs://{bucket_name}/{key}')
        return f'gs://{bucket_name}/{key}'
    except Exception as e:
        logger.error(f'GCS upload failed: {e}.')
        raise RuntimeError(f"GCS upload failed: {e}")


def extract_sentiment(hr_report):
    import re
    report_lower = hr_report.lower()
    score_match = re.search(r'sentiment score[:\s]+(-?\d+\.?\d*)', report_lower)
    if score_match:
        try:
            score = float(score_match.group(1))
            if score > 0.2:
                return 'Positive', score
            elif score < -0.2:
                return 'Negative', score
            else:
                return 'Neutral', score
        except ValueError:
            pass
    if 'overall sentiment: positive' in report_lower or ('positive' in report_lower[:300] and 'negative' not in report_lower[:300]):
        return 'Positive', 0.65
    elif 'overall sentiment: negative' in report_lower or 'negative' in report_lower[:300]:
        return 'Negative', -0.65
    else:
        return 'Neutral', 0.0


def analyze_exit_interview(audio_bytes, filename, employee_name, employee_code, department=''):
    transcript = transcribe_audio(audio_bytes, filename)

    if not transcript or len(transcript.strip()) < 10:
        raise RuntimeError("Generated transcript is too short or empty.")

    is_valid = validate_exit_interview(transcript)
    if not is_valid:
        return {
            'success': False,
            'error': (
                'This audio does not appear to be an employee exit interview. '
                'The AI guardrail has rejected it. Please upload a genuine exit interview recording.'
            )
        }

    hr_report = generate_hr_report(transcript, employee_name)
    sentiment_label, sentiment_score = extract_sentiment(hr_report)

    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    report_content = (
        f'AI EXIT INTERVIEW ANALYSIS REPORT\n'
        f'{"=" * 60}\n'
        f'Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}\n'
        f'Employee: {employee_name} ({employee_code})\n'
        f'Department: {department}\n'
        f'Overall Sentiment: {sentiment_label} ({sentiment_score:+.2f})\n'
        f'{"=" * 60}\n\n'
        f'TRANSCRIPT\n{"-" * 40}\n{transcript}\n\n'
        f'HR ANALYSIS & INSIGHTS\n{"-" * 40}\n{hr_report}\n'
    )

    safe_name = employee_name.replace(' ', '_').replace('/', '-')
    report_filename = f'exit_report_{safe_name}_{employee_code}_{timestamp}.txt'
    s3_path = upload_report_to_s3(report_content, report_filename)

    return {
        'success': True,
        'transcript': transcript,
        'sentiment': sentiment_label,
        'sentiment_score': sentiment_score,
        'hr_report': hr_report,
        'report_content': report_content,
        's3_report_path': s3_path,
    }
