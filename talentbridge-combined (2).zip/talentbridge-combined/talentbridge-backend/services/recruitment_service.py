import logging
from sqlalchemy.orm import Session
from fastapi import HTTPException

from models import schemas
from agents.orchestrator import RecruitmentOrchestrator
from repositories import crud

logger = logging.getLogger(__name__)

# Singleton orchestrator — agents are stateless so this is safe
orchestrator = RecruitmentOrchestrator()


def process_job_creation_service(db: Session, job_id: int) -> None:
    """Analyse job description and store structured profile."""
    job = crud.get_job(db, job_id)
    if not job:
        logger.error("process_job_creation_service: job_id=%d not found.", job_id)
        return
    profile_json = orchestrator.job_analysis_agent.analyze(job.full_description)
    job.structured_profile = profile_json
    db.commit()
    logger.info("Job profile stored for job_id=%d", job_id)


def process_resume_ingestion_service(db: Session, candidate_id: int, text_content: str) -> None:
    """Trigger the full resume pipeline."""
    orchestrator.pipeline_on_resume_upload(db, candidate_id, text_content)


def setup_interview_workflow_service(db: Session, candidate_id: int) -> schemas.Interview:
    """Create interview record and generate questions for a candidate."""
    candidate = crud.get_candidate(db, candidate_id)
    if not candidate:
        raise HTTPException(status_code=404, detail=f"Candidate {candidate_id} not found.")

    # Prevent duplicate interviews
    existing = crud.get_interview_by_candidate(db, candidate_id)
    if existing:
        logger.info("Interview already exists for candidate_id=%d (interview_id=%d)", candidate_id, existing.id)
        return existing

    job = crud.get_job(db, candidate.job_id)
    if not job:
        raise HTTPException(status_code=404, detail=f"Job {candidate.job_id} not found.")

    interview = schemas.Interview(
        candidate_id=candidate.id,
        current_question_index=0,
        is_completed=False,
    )
    db.add(interview)
    db.commit()
    db.refresh(interview)

    required_skills = job.skills_required or []
    candidate_skills = candidate.skills or []
    candidate_projects = candidate.parsed_data.get("projects") if candidate.parsed_data else []

    questions = orchestrator.interview_agent.generate_questions(
        job_title=job.title,
        job_description=job.full_description,
        required_skills=required_skills,
        candidate_skills=candidate_skills,
        candidate_projects=candidate_projects
    )
    for q in questions:
        db_q = schemas.InterviewQuestion(
            interview_id=interview.id,
            category=q.get("category"),
            difficulty=q.get("difficulty"),
            question_text=q.get("question_text"),
            expected_answer=q.get("expected_answer"),
            rubric=q.get("rubric"),
        )
        db.add(db_q)

    db.commit()
    crud.update_candidate_status(db, candidate_id, "Interviewing")
    logger.info("Interview setup complete: interview_id=%d, candidate_id=%d", interview.id, candidate_id)
    return interview


def submit_interview_answer_service(
    db: Session,
    interview_id: int,
    question_id: int,
    candidate_answer: str,
    audio_file_path: str | None = None,
    audio_mime_type: str | None = None,
) -> dict:
    """Submit and evaluate one interview answer."""
    interview = crud.get_interview(db, interview_id)
    if not interview:
        raise HTTPException(status_code=404, detail=f"Interview {interview_id} not found.")
    if interview.is_completed:
        raise HTTPException(status_code=400, detail="This interview has already been completed.")

    return orchestrator.process_interview_answer(
        db,
        interview_id,
        question_id,
        candidate_answer,
        audio_file_path=audio_file_path,
        audio_mime_type=audio_mime_type,
    )


def get_interview_state_service(db: Session, interview_id: int) -> dict:
    """Return current interview state: answered questions and next question."""
    interview = crud.get_interview(db, interview_id)
    if not interview:
        raise HTTPException(status_code=404, detail=f"Interview {interview_id} not found.")

    questions = crud.get_interview_questions(db, interview_id)
    answers = (
        db.query(schemas.InterviewAnswer)
        .filter(schemas.InterviewAnswer.interview_id == interview_id)
        .all()
    )
    answered_ids = {a.interview_question_id for a in answers}

    next_question = next(
        (q for q in questions if q.id not in answered_ids), None
    )

    return {
        "interview_id":   interview.id,
        "is_completed":   interview.is_completed,
        "overall_score":  interview.overall_score,
        "total_questions": len(questions),
        "answered_count": len(answers),
        "next_question":  {
            "id":            next_question.id,
            "category":      next_question.category,
            "difficulty":    next_question.difficulty,
            "question_text": next_question.question_text,
        } if next_question else None,
    }
