"""
HR Vertex AI Service — replaces hr_bedrock_service.py.
Uses Vertex AI (Gemini) via GOOGLE_APPLICATION_CREDENTIALS + VERTEX_PROJECT.
Offline fallbacks are preserved unchanged.
"""
import json
import os

from config.database import settings


def _init_vertexai():
    import vertexai
    project  = getattr(settings, "VERTEX_PROJECT", "") or os.getenv("VERTEX_PROJECT", "")
    location = getattr(settings, "VERTEX_LOCATION", "") or os.getenv("VERTEX_LOCATION", "us-central1")
    vertexai.init(project=project, location=location)


class HRBedrockService:
    def __init__(self):
        self.model_id = "gemini-2.5-flash"
        project = getattr(settings, "VERTEX_PROJECT", "") or os.getenv("VERTEX_PROJECT", "")
        self.enabled = bool(project)
        self._model = None

    def _get_model(self):
        if self._model is None:
            _init_vertexai()
            from vertexai.generative_models import GenerativeModel
            self._model = GenerativeModel(self.model_id)
        return self._model

    def generate_text(self, system_prompt: str, user_prompt: str, max_tokens: int = 1800) -> str:
        if not self.enabled:
            return self._offline_response(system_prompt, user_prompt)

        try:
            model = self._get_model()
            full_prompt = f"{system_prompt}\n\n{user_prompt}"
            from vertexai.generative_models import GenerationConfig
            response = model.generate_content(
                full_prompt,
                generation_config=GenerationConfig(max_output_tokens=max_tokens),
            )
            return (response.text or "").strip()
        except Exception as exc:
            return (
                f"[VERTEX_AI_FALLBACK] Vertex AI call failed: {exc}\n\n"
                + self._offline_response(system_prompt, user_prompt)
            )

    # ------------------------------------------------------------------
    # Offline fallbacks (unchanged from original)
    # ------------------------------------------------------------------
    def _offline_response(self, system_prompt: str, user_prompt: str) -> str:
        lowered = user_prompt.lower()

        if "compliance" in lowered or "review" in lowered:
            return json.dumps(
                {
                    "compliance_score": 82,
                    "status": "Revisions Needed",
                    "risks": [
                        "Approval workflow should be defined more clearly.",
                        "Effective date and review cycle should be included.",
                        "Exception handling should be reviewed by HR/Legal.",
                    ],
                    "suggestions": [
                        "Add owner and approver fields.",
                        "Add escalation process.",
                        "Add employee communication note.",
                    ],
                },
                indent=2,
            )

        if "update" in lowered and "policy" in lowered:
            return """
# Updated HR Policy Draft

## Change Summary
- Updated the existing policy based on the requested change.
- Added clearer approval and exception handling language.
- Included HR review and compliance checkpoints.

## Purpose
This policy defines the updated rules, responsibilities, and approval process for employees and HR stakeholders.

## Scope
This policy applies to eligible employees, managers, HR users, and relevant business units.

## Policy Details
Employees must follow the updated rules described by HR. Any exception must be reviewed and approved by HR and Legal if required.

## Approval Workflow
1. Employee or manager submits request.
2. Manager reviews eligibility.
3. HR validates policy compliance.
4. Legal/Compliance reviews exceptions where required.

## Responsibilities
- Employees must follow the policy.
- Managers must review requests fairly.
- HR must maintain policy governance.
- Legal/Compliance must review sensitive clauses.

## Effective Date
To be confirmed by HR.

## Review Cycle
This policy should be reviewed annually or when business/legal requirements change.
"""

        if "chat" in lowered or "answer" in lowered:
            return """
Based on the available approved policy context, here is the answer:

The policy information indicates that employees must follow the defined approval process and eligibility rules.
If your request needs a personal exception or the policy does not clearly cover your situation,
please raise an HR support ticket for manual review.

Source: Approved HR policy context
"""

        return """
# HR Policy Draft

## 1. Purpose
This policy establishes clear and consistent guidelines for employees, managers, and HR teams.

## 2. Scope
This policy applies to all eligible employees across applicable departments and locations.

## 3. Eligibility
Eligibility will be based on role requirements, manager approval, business needs, and HR policy rules.

## 4. Policy Details
Employees must comply with the guidelines defined in this policy. Any exceptions must be reviewed by HR
and approved through the official workflow.

## 5. Approval Workflow
1. Employee submits a request.
2. Manager reviews the request.
3. HR validates eligibility and compliance.
4. Legal/Compliance reviews the policy when needed.
5. Final approval is recorded before publishing.

## 6. Roles and Responsibilities
- Employee: Follow policy rules and submit accurate information.
- Manager: Review employee requests fairly and on time.
- HR: Maintain policy, approvals, and employee communication.
- Legal/Compliance: Review risky or sensitive clauses.

## 7. Compliance and Risk Notes
This policy should be reviewed for fairness, non-discrimination, data privacy, and legal compliance before publishing.

## 8. Effective Date
To be confirmed by HR.

## 9. Review Cycle
This policy should be reviewed once every year or whenever company/legal requirements change.
"""


hr_bedrock_service = HRBedrockService()
