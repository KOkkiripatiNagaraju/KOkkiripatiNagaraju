"""
Adapter functions that convert ORM model objects into the dict formats
expected by the skill-gap engine, course recommender, and Bedrock prompt.
"""
from typing import Any, Dict, List


def employee_skills_to_list(employee_orm) -> List[Dict[str, Any]]:
    """Convert Employee.skills_profile JSON {"python": 5} -> [{"name": "Python", "level": 5}]."""
    profile = employee_orm.skills_profile
    if not profile or not isinstance(profile, dict):
        return []
    return [
        {"name": skill_name.title(), "level": int(level)}
        for skill_name, level in profile.items()
    ]


def role_skills_to_list(role_orm) -> List[Dict[str, Any]]:
    """Convert RoleTemplate.required_skills JSON -> [{"name": "Python", "level": 8}].

    Handles both dict format {"python": 8} and list format [{"name": "python", "level": 8}].
    """
    raw = role_orm.required_skills
    if not raw:
        return []

    # Dict format: {"python": 8, "sql": 7}
    if isinstance(raw, dict):
        return [
            {"name": skill_name.title(), "level": int(level)}
            for skill_name, level in raw.items()
        ]

    # List format: [{"name": "python", "level": 8}, ...]
    if isinstance(raw, list):
        result = []
        for item in raw:
            if isinstance(item, dict) and "name" in item and "level" in item:
                result.append({
                    "name": item["name"].title(),
                    "level": int(item["level"]),
                })
        return result

    return []


def course_orm_to_dict(course_orm) -> Dict[str, Any]:
    """Convert Course ORM -> {"id": int, "title": str, "skills_covered": list, "url": str}."""
    skills = course_orm.skills_covered or []
    if isinstance(skills, str):
        skills = [s.strip() for s in skills.split(",")]
    return {
        "id": course_orm.id,
        "title": course_orm.course_title,
        "skills_covered": skills,
        "description": course_orm.description or "",
        "url": getattr(course_orm, "url", "") or "",
    }


def build_employee_context(employee_orm) -> Dict[str, Any]:
    """Build dict for Bedrock prompt with graceful defaults for missing runtime columns."""
    skills_list = employee_skills_to_list(employee_orm)
    skills_str = ", ".join(f"{s['name']} ({s['level']}/10)" for s in skills_list) if skills_list else "None listed"

    return {
        "name": employee_orm.name,
        "email": employee_orm.email,
        "current_role": getattr(employee_orm, "current_role", None) or "Not specified",
        "department": getattr(employee_orm, "department", None) or "Not specified",
        "experience_years": getattr(employee_orm, "experience_years", None) or 0,
        "skills_summary": skills_str,
        "skills_list": skills_list,
    }


def build_role_context(role_orm) -> Dict[str, Any]:
    """Build dict for Bedrock prompt with graceful defaults for missing runtime columns."""
    skills_list = role_skills_to_list(role_orm)
    skills_str = ", ".join(f"{s['name']} ({s['level']}/10)" for s in skills_list) if skills_list else "None listed"

    return {
        "title": role_orm.role_title,
        "department": getattr(role_orm, "department", None) or "Not specified",
        "description": getattr(role_orm, "description", None) or "No description available",
        "required_skills_summary": skills_str,
        "required_skills_list": skills_list,
    }
