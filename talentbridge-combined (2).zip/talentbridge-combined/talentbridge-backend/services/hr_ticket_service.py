"""
HR Ticket service — operates on hr_tickets table only.
"""
import uuid
import datetime
from typing import List, Optional

from sqlalchemy.orm import Session

from models.hr_chatbot_models import HRTicket


def create_hr_ticket(
    db: Session,
    employee_id: Optional[str],
    employee_email: Optional[str],
    question: str,
    category: str = "Policy Clarification",
    priority: str = "Medium",
    ai_summary: Optional[str] = None,
    suggested_response: Optional[str] = None,
) -> HRTicket:
    ticket = HRTicket(
        employee_id=employee_id,
        employee_email=employee_email,
        question=question,
        category=category,
        priority=priority,
        status="Open",
        ai_summary=ai_summary,
        suggested_response=suggested_response,
        assigned_to="HR_SUPPORT",
    )
    db.add(ticket)
    db.commit()
    db.refresh(ticket)
    return ticket


def list_hr_tickets(db: Session) -> List[HRTicket]:
    return db.query(HRTicket).order_by(HRTicket.created_at.desc()).all()


def get_hr_ticket(db: Session, ticket_id: str) -> Optional[HRTicket]:
    try:
        uid = uuid.UUID(ticket_id)
    except (ValueError, AttributeError):
        return None
    return db.query(HRTicket).filter(HRTicket.id == uid).first()


def update_hr_ticket(
    db: Session,
    ticket_id: str,
    status: str,
    resolution_response: Optional[str] = None,
    resolved_by: Optional[str] = None,
    assigned_to: Optional[str] = None,
) -> HRTicket:
    ticket = get_hr_ticket(db, ticket_id)
    if not ticket:
        raise ValueError("Ticket not found")

    ticket.status = status
    if resolution_response:
        ticket.resolution_response = resolution_response
    if resolved_by:
        ticket.resolved_by = resolved_by
    if assigned_to:
        ticket.assigned_to = assigned_to
    if status in ("Closed", "Resolved"):
        ticket.resolved_at = datetime.datetime.utcnow()

    db.commit()
    db.refresh(ticket)
    return ticket


def get_tickets_by_employee(db: Session, employee_email: str) -> List[HRTicket]:
    return (
        db.query(HRTicket)
        .filter(HRTicket.employee_email == employee_email)
        .order_by(HRTicket.created_at.desc())
        .all()
    )
