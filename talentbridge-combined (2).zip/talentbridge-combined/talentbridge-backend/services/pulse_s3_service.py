"""
Pulse Survey GCS Backup Service — replaces pulse_s3_service.py.
Backs up survey responses to GCS or local filesystem (unchanged fallback logic).
"""
import json
import os
from config.database import settings


class PulseS3Service:
    def __init__(self):
        self._mock_mode = None
        self.local_backup_dir = os.path.join(
            os.path.dirname(os.path.dirname(__file__)),
            "data_backup"
        )
        self._gcs_client = None

    @property
    def mock_mode(self):
        if self._mock_mode is None:
            self._mock_mode = getattr(settings, 'MOCK_AWS', True)
            if self._mock_mode:
                os.makedirs(self.local_backup_dir, exist_ok=True)
        return self._mock_mode

    @mock_mode.setter
    def mock_mode(self, value):
        self._mock_mode = value

    @property
    def gcs_client(self):
        if not self.mock_mode and self._gcs_client is None:
            bucket_name = getattr(settings, "GCS_BUCKET_NAME", "") or os.getenv("GCS_BUCKET_NAME", "")
            if not bucket_name:
                self.mock_mode = True
                os.makedirs(self.local_backup_dir, exist_ok=True)
                return None
            try:
                from google.cloud import storage as gcs
                self._gcs_client = gcs.Client()
            except Exception as e:
                print(f"Failed to initialize GCS client, falling back to local storage. Error: {e}")
                self.mock_mode = True
                os.makedirs(self.local_backup_dir, exist_ok=True)
        return self._gcs_client

    def upload_response_backup(self, response_id: int, response_data: dict) -> str:
        filename = f"pulse_response_{response_id}.json"
        json_content = json.dumps(response_data, indent=2, default=str)

        if self.mock_mode:
            os.makedirs(self.local_backup_dir, exist_ok=True)
            file_path = os.path.join(self.local_backup_dir, filename)
            try:
                with open(file_path, "w") as f:
                    f.write(json_content)
                return file_path
            except Exception as e:
                print(f"Failed to write local backup: {e}")
                return f"local://error-saving-{filename}"

        try:
            bucket_name = getattr(settings, "GCS_BUCKET_NAME", "") or os.getenv("GCS_BUCKET_NAME", "")
            bucket = self.gcs_client.bucket(bucket_name)
            blob = bucket.blob(f"pulse-responses/{filename}")
            blob.upload_from_string(json_content, content_type="application/json")
            return f"gs://{bucket_name}/pulse-responses/{filename}"
        except Exception as e:
            print(f"Failed GCS upload for {filename}: {e}. Falling back to local backup.")
            os.makedirs(self.local_backup_dir, exist_ok=True)
            file_path = os.path.join(self.local_backup_dir, filename)
            with open(file_path, "w") as f:
                f.write(json_content)
            return file_path


pulse_s3_service = PulseS3Service()
