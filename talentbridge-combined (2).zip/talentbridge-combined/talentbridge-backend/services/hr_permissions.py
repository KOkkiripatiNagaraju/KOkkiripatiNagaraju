"""HR permission definitions and helpers."""

PERMISSIONS: dict[str, set[str]] = {
    "EMPLOYEE": {
        "ask_chatbot",
        "create_ticket",
        "view_own_tickets",
        "view_published_policies",
    },
    "HR_SUPPORT": {
        "view_tickets",
        "reply_ticket",
        "close_ticket",
        "update_ticket",
        "view_analytics",
        "ask_chatbot",
    },
    "HR_ADMIN": {
        "generate_policy",
        "edit_policy",
        "review_policy",
        "save_policy",
        "view_policies",
        "upload_document",
        "view_tickets",
        "update_ticket",
        "view_analytics",
        "approve_policy",
        "publish_policy",
        "request_changes",
        "delete_policy",
        "ask_chatbot",
    },
}


def get_role(is_manager: bool) -> str:
    return "HR_ADMIN" if is_manager else "EMPLOYEE"


def check_permission(role: str, action: str) -> bool:
    return action in PERMISSIONS.get(role.upper(), set())


def require_permission(role: str, action: str):
    if not check_permission(role, action):
        raise PermissionError(
            f"Access denied. Role '{role}' cannot perform '{action}'."
        )
    return True
