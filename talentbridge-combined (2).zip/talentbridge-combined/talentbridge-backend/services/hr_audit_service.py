"""HR audit trail service — writes to hr_audit_trail only."""
from typing import Optional
from sqlalchemy.orm import Session

from models.hr_chatbot_models import HRAuditTrail


def add_hr_audit_log(
    db: Session,
    actor: str,
    action: str,
    entity_type: str,
    entity_id: Optional[str] = None,
    details: Optional[dict] = None,
) -> HRAuditTrail:
    log = HRAuditTrail(
        actor=actor,
        action=action,
        entity_type=entity_type,
        entity_id=entity_id,
        details=details or {},
    )
    db.add(log)
    db.commit()
    return log
