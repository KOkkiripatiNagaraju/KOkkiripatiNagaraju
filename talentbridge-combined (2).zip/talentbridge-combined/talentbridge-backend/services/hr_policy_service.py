"""
HR Policy CRUD service.  Operates exclusively on hr_policies / hr_policy_versions.
"""
import uuid
from typing import List, Optional

from sqlalchemy.orm import Session

from models.hr_chatbot_models import HRPolicy, HRPolicyVersion
from models.hr_chatbot_schemas import HRPolicySaveRequest
from services.hr_storage_service import hr_storage_service


def list_hr_policies(db: Session) -> List[HRPolicy]:
    return db.query(HRPolicy).order_by(HRPolicy.created_at.desc()).all()


def get_hr_policy(db: Session, policy_id: str) -> Optional[HRPolicy]:
    try:
        uid = uuid.UUID(policy_id)
    except (ValueError, AttributeError):
        return None
    return db.query(HRPolicy).filter(HRPolicy.id == uid).first()


def save_hr_policy(
    db: Session,
    req: HRPolicySaveRequest,
    created_by: Optional[str] = None,
) -> HRPolicy:
    # S3 storage key for policy text
    s3_key = f"policies/{req.title.replace(' ', '_')}_{uuid.uuid4().hex[:8]}.md"
    storage_path = hr_storage_service.save_text(s3_key, req.content)

    if req.policy_id:
        # Update existing policy → add a new version
        try:
            existing_uid = uuid.UUID(req.policy_id)
        except (ValueError, AttributeError):
            existing_uid = None

        policy = (
            db.query(HRPolicy).filter(HRPolicy.id == existing_uid).first()
            if existing_uid
            else None
        )
        if policy:
            version = HRPolicyVersion(
                policy_id=policy.id,
                version_number=req.version_number,
                content=req.content,
                s3_key=storage_path,
                status=req.status,
                compliance_score=req.compliance_score,
                risks=req.risks,
                change_summary=req.change_summary,
                effective_date=req.effective_date,
                created_by=created_by,
            )
            db.add(version)
            db.flush()
            policy.current_version_id = version.id
            policy.status = req.status
            if req.review_date:
                policy.review_date = req.review_date
            db.commit()
            db.refresh(policy)
            return policy

    # Create brand-new policy
    policy = HRPolicy(
        title=req.title,
        policy_type=req.policy_type,
        status=req.status,
        review_date=req.review_date or "Annual Review",
        created_by=created_by,
    )
    db.add(policy)
    db.flush()

    version = HRPolicyVersion(
        policy_id=policy.id,
        version_number=req.version_number,
        content=req.content,
        s3_key=storage_path,
        status=req.status,
        compliance_score=req.compliance_score,
        risks=req.risks,
        change_summary=req.change_summary,
        effective_date=req.effective_date,
        created_by=created_by,
    )
    db.add(version)
    db.flush()

    policy.current_version_id = version.id
    db.commit()
    db.refresh(policy)
    return policy


def publish_hr_policy(db: Session, policy_id: str) -> HRPolicy:
    policy = get_hr_policy(db, policy_id)
    if not policy:
        raise ValueError("Policy not found")
    policy.status = "published"
    for version in policy.versions:
        version.status = "published"
    db.commit()
    db.refresh(policy)
    return policy


def delete_hr_policy(db: Session, policy_id: str) -> None:
    policy = get_hr_policy(db, policy_id)
    if not policy:
        raise ValueError("Policy not found")
    db.delete(policy)
    db.commit()
