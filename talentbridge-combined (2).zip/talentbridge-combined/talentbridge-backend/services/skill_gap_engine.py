"""
Skill Gap Analysis Engine.

Pure function that compares an employee's current skills against a target
role's required skills and identifies gaps with priority levels.
"""
import logging
from typing import Any, Dict, List

logger = logging.getLogger(__name__)

# Priority order for sorting
_PRIORITY_ORDER = {"Critical": 0, "High": 1, "Medium": 2}


def analyze_skill_gaps(
    employee_skills: List[Dict[str, Any]],
    required_skills: List[Dict[str, Any]],
) -> Dict[str, Any]:
    """Analyze skill gaps between employee skills and role requirements.

    Args:
        employee_skills: [{"name": "Python", "level": 6}, ...]
        required_skills: [{"name": "Python", "level": 8}, ...]

    Returns:
        {
            "readiness_score": float (0-100),
            "skill_gaps": [
                {
                    "skill_name": str,
                    "current_level": int,
                    "required_level": int,
                    "gap": int,
                    "priority": "Critical" | "High" | "Medium"
                }, ...
            ]
        }
    """
    # Build a lookup of employee's current skills (lowercased for matching)
    emp_lookup: Dict[str, int] = {
        s["name"].lower(): s["level"] for s in employee_skills
    }

    skill_gaps: List[Dict[str, Any]] = []
    total_required = 0
    total_achieved = 0

    for req in required_skills:
        req_name = req["name"]
        req_level = req["level"]
        total_required += req_level

        current_level = emp_lookup.get(req_name.lower(), 0)
        achieved = min(current_level, req_level)
        total_achieved += achieved

        gap = max(0, req_level - current_level)

        if gap == 0:
            # Employee meets or exceeds the requirement
            continue

        # Determine priority based on gap magnitude
        if gap >= 5:
            priority = "Critical"
        elif gap >= 3:
            priority = "High"
        else:
            priority = "Medium"

        skill_gaps.append({
            "skill_name": req_name,
            "current_level": current_level,
            "required_level": req_level,
            "gap": gap,
            "priority": priority,
        })

    # Calculate readiness score
    readiness_score = (total_achieved / total_required * 100) if total_required > 0 else 0.0
    readiness_score = round(readiness_score, 1)

    # Sort by severity: Critical > High > Medium, then by gap descending
    skill_gaps.sort(key=lambda g: (_PRIORITY_ORDER.get(g["priority"], 99), -g["gap"]))

    logger.info(
        "Skill gap analysis: readiness=%.1f%%, gaps=%d",
        readiness_score,
        len(skill_gaps),
    )

    return {
        "readiness_score": readiness_score,
        "skill_gaps": skill_gaps,
    }
