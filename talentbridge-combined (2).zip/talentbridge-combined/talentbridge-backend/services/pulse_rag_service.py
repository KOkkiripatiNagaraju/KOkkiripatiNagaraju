"""
Pulse Survey RAG Service
Retrieves relevant HR policies using cosine similarity on embeddings.
"""
import math
from sqlalchemy.orm import Session
from sqlalchemy import text
from typing import List, Dict, Any
from services.pulse_ai_service import pulse_ai_service


class PulseRAGService:
    def cosine_similarity(self, vec1: List[float], vec2: List[float]) -> float:
        """Computes cosine similarity between two vectors."""
        if not vec1 or not vec2:
            return 0.0
        dot = sum(a * b for a, b in zip(vec1, vec2))
        norm1 = math.sqrt(sum(a * a for a in vec1))
        norm2 = math.sqrt(sum(b * b for b in vec2))
        if norm1 == 0.0 or norm2 == 0.0:
            return 0.0
        return dot / (norm1 * norm2)

    def retrieve_policies(self, query: str, db: Session, limit: int = 2) -> List[Dict[str, Any]]:
        """
        Calculates search similarity against stored HR policies.
        Returns the top matching policies.
        """
        from models.schemas import Policy

        query_embedding = pulse_ai_service.get_embeddings(query)

        policies = db.query(Policy).all()
        if not policies:
            return []

        scored_policies = []
        for policy in policies:
            embedding = getattr(policy, 'embedding', None)
            if embedding:
                similarity = self.cosine_similarity(query_embedding, embedding)
            else:
                similarity = 0.0
            scored_policies.append((similarity, policy))

        scored_policies.sort(key=lambda x: x[0], reverse=True)

        results = []
        for score, policy in scored_policies[:limit]:
            category = getattr(policy, 'category', 'general')
            content = getattr(policy, 'content_markdown', '') or ''
            results.append({
                "id": policy.id,
                "title": policy.title,
                "content": content,
                "category": category or "general",
                "score": round(score, 4)
            })

        return results

    def seed_policies_if_empty(self, db: Session):
        """Pre-populates sample policies with computed embeddings if none have embeddings."""
        from models.schemas import Policy

        # Check if any policy has an embedding already
        policies_with_embeddings = db.query(Policy).filter(Policy.embedding.isnot(None)).count()
        if policies_with_embeddings > 0:
            return

        sample_policies = [
            {
                "title": "Employee Mental Health & Wellbeing Program",
                "content": "Our Mental Health & Wellbeing program offers all employees up to 6 free counseling sessions per year. We also provide a monthly wellness stipend of $100 that can be used for gym memberships, therapy, meditation apps, or physical wellness. If you are experiencing high levels of stress or burnout, please speak with your HR business partner or contact our external EAP provider at 1-800-WELLNESS. You can also request a Wellness Day off directly in the HR portal, which does not count against standard PTO.",
                "category": "wellbeing"
            },
            {
                "title": "Flexible Work Arrangements & Ergonomic Stipends",
                "content": "Employees are eligible to work remotely up to 3 days per week (hybrid model) or request full-time remote status with manager approval. We offer a one-time remote setup stipend of $500 to purchase ergonomic office chairs, desks, monitors, and accessories. Core collaboration hours are 10:00 AM to 3:00 PM EST, during which all team members are expected to be reachable. Outside of these hours, meeting requests should be minimized to avoid digital exhaustion and maintain healthy work-life integration.",
                "category": "workspace"
            },
            {
                "title": "Professional Development & Educational Stipends",
                "content": "To foster career growth, we support continuous education. Employees receive an annual professional development budget of $2,000 for courses, industry certifications, books, and conference attendance. Additionally, every employee has access to our corporate Udemy Business and Coursera portals. We recommend creating an Individual Development Plan (IDP) with your manager every 6 months to align your personal learning goals with project opportunities inside the organization.",
                "category": "career_growth"
            },
            {
                "title": "Manager Coaching, Feedback & Leadership Guidelines",
                "content": "Effective managers are expected to run weekly or bi-weekly 1-on-1 career check-ins. Managers should separate status updates from career conversations. At least once a month, 1-on-1s should be focused on professional growth, burnout checks, and resource adequacy. Micromanagement is discouraged; managers should document clear objectives and key results (OKRs) and empower teams to solve problems. Peer feedback loops are encouraged and integrated into our bi-annual review cycles.",
                "category": "management"
            },
            {
                "title": "Compensation, Performance Reviews & Raise Schedules",
                "content": "Compensation scales are reviewed annually to align with industry benchmarks. Performance evaluations occur twice a year (June and December). Merit raises, promotions, and bonuses are awarded based on these review cycles. Any employee who feels they are compensated below market rate can request an out-of-cycle compensation review. To initiate this, please document your key metrics, achievements, and market comparisons in the Compensation Review Request Form, and submit it to HR.",
                "category": "compensation"
            }
        ]

        print("Seeding default HR Policies with vector embeddings for RAG...")

        # Check if policies exist, if so update them with embeddings; if not, create new
        existing_policies = db.query(Policy).all()
        existing_titles = {p.title for p in existing_policies}

        for p_data in sample_policies:
            embedding = pulse_ai_service.get_embeddings(p_data["title"] + " " + p_data["content"])

            if p_data["title"] in existing_titles:
                # Update existing policy with embedding and category
                policy = db.query(Policy).filter(Policy.title == p_data["title"]).first()
                if policy:
                    policy.embedding = embedding
                    policy.category = p_data["category"]
            else:
                # Create new policy
                policy = Policy(
                    title=p_data["title"],
                    content_markdown=p_data["content"],
                    category=p_data["category"],
                    embedding=embedding
                )
                db.add(policy)

        db.commit()
        print("HR Policies RAG embeddings seeded successfully.")


pulse_rag_service = PulseRAGService()
