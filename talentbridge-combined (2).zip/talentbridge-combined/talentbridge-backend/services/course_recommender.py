"""
Course Recommender.

Simplified recommender that matches courses to skill gaps based on
skills_covered overlap. Scoring uses only gap-skill matching (3 pts each).
"""
import logging
from typing import Any, Dict, List

logger = logging.getLogger(__name__)


def recommend_courses(
    skill_gaps: List[Dict[str, Any]],
    courses: List[Dict[str, Any]],
    max_recommendations: int = 10,
) -> List[Dict[str, Any]]:
    """Recommend courses from the catalog that address the given skill gaps.

    Scoring (simplified — no difficulty/rating fields required):
        +3 points per matching gap skill the course covers

    Args:
        skill_gaps: [{"skill_name": str, "priority": str, ...}]
        courses: [{"id": int, "title": str, "skills_covered": [str, ...]}]
        max_recommendations: Maximum courses to return.

    Returns:
        [{"course_id": int, "course_title": str, "skills_covered": list,
          "addresses_gaps": [str, ...], "relevance_score": float}, ...]
    """
    if not skill_gaps or not courses:
        return []

    # Build a set of gap skill names (lowered) for fast lookup
    gap_skill_names = {g["skill_name"].lower() for g in skill_gaps}

    scored: List[Dict[str, Any]] = []
    seen_ids: set = set()

    for course in courses:
        cid = course.get("id")
        if cid in seen_ids:
            continue

        # Determine which gap skills this course addresses
        covered = course.get("skills_covered") or []
        matching_gaps = [
            skill for skill in covered
            if skill.lower() in gap_skill_names
        ]

        if not matching_gaps:
            continue

        # Score: 3 points per matching gap skill
        score = round(len(matching_gaps) * 3.0, 2)

        scored.append({
            "course_id": cid,
            "course_title": course.get("title", "Untitled"),
            "skills_covered": covered,
            "addresses_gaps": matching_gaps,
            "relevance_score": score,
            "url": course.get("url", ""),
            "description": course.get("description", ""),
        })
        seen_ids.add(cid)

    # Sort by relevance score descending
    scored.sort(key=lambda rc: rc["relevance_score"], reverse=True)

    result = scored[:max_recommendations]

    logger.info(
        "Course recommendation: %d gaps -> %d matching courses (returning top %d)",
        len(skill_gaps),
        len(scored),
        len(result),
    )

    return result
