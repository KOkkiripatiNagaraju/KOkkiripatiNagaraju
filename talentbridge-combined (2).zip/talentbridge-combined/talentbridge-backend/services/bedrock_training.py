"""
Vertex AI Learning Path Generator — replaces bedrock_training.py.
Function signatures are unchanged; all callers work without modification.
Falls back to the same rule-based generator when Vertex AI is unavailable.
"""
import json
import logging
import os
from typing import Any, Dict, List

logger = logging.getLogger(__name__)


def _get_vertex_model():
    try:
        import vertexai
        from vertexai.generative_models import GenerativeModel
        project  = os.getenv("VERTEX_PROJECT", "")
        if not project:
            from config.database import settings
            project = getattr(settings, "VERTEX_PROJECT", "")
        if not project:
            return None
        location = os.getenv("VERTEX_LOCATION", "us-central1")
        vertexai.init(project=project, location=location)
        return GenerativeModel("gemini-2.5-flash")
    except Exception as exc:
        logger.warning("Could not create Vertex AI model: %s", exc)
        return None


def _build_prompt(employee_ctx, role_ctx, skill_gaps, recommended_courses) -> str:
    gap_lines = "\n".join(
        f"  - {g['skill_name']}: Current {g['current_level']}/10 → Required {g['required_level']}/10 "
        f"(Gap: {g['gap']}, Priority: {g['priority']})"
        for g in skill_gaps
    )
    course_lines = "\n".join(
        f"  - {c['course_title']} → Covers: {', '.join(c.get('addresses_gaps', []))}"
        for c in recommended_courses
    )
    return f"""You are an expert HR Training & Development consultant. Create a structured learning path for the following employee.

## Employee Profile
- Name: {employee_ctx.get('name', 'Employee')}
- Current Role: {employee_ctx.get('current_role', 'Not specified')}
- Department: {employee_ctx.get('department', 'Not specified')}
- Experience: {employee_ctx.get('experience_years', 0)} years
- Current Skills: {employee_ctx.get('skills_summary', 'None listed')}

## Target Role
- Title: {role_ctx.get('title', 'Target Role')}
- Department: {role_ctx.get('department', 'Not specified')}
- Description: {role_ctx.get('description', 'No description')}

## Skill Gaps (sorted by priority)
{gap_lines}

## Recommended Courses
{course_lines}

## Instructions
Create a phased learning plan that:
1. Addresses Critical gaps first, then High, then Medium
2. Groups related skills into logical phases
3. Assigns appropriate courses to each phase
4. Provides realistic time estimates

Return your response as a JSON object with this exact structure:
{{
  "phases": [
    {{
      "phase_number": 1,
      "title": "Phase title",
      "description": "Brief description of this phase's focus",
      "skills": ["skill1", "skill2"],
      "courses": ["Course Title 1", "Course Title 2"],
      "duration_weeks": 4
    }}
  ],
  "weekly_schedule": "Recommended weekly study schedule (e.g., '10-12 hours per week')",
  "total_hours": 120,
  "estimated_weeks": 16,
  "recommendations": [
    "Additional recommendation 1",
    "Additional recommendation 2"
  ]
}}

Return ONLY the JSON object, no additional text.
"""


def generate_learning_path(
    employee_context: Dict[str, Any],
    role_context: Dict[str, Any],
    skill_gaps: List[Dict[str, Any]],
    recommended_courses: List[Dict[str, Any]],
) -> Dict[str, Any]:
    try:
        model = _get_vertex_model()
        if model is None:
            raise RuntimeError("Vertex AI model unavailable")

        prompt = _build_prompt(employee_context, role_context, skill_gaps, recommended_courses)
        response = model.generate_content(prompt)
        output_text = (response.text or "").strip()

        # Strip markdown fences if present
        if output_text.startswith("```"):
            lines = output_text.split("\n")
            json_lines, inside = [], False
            for line in lines:
                if line.strip().startswith("```") and not inside:
                    inside = True
                    continue
                elif line.strip().startswith("```") and inside:
                    break
                elif inside:
                    json_lines.append(line)
            output_text = "\n".join(json_lines)

        parsed = json.loads(output_text)
        phases = []
        for i, p in enumerate(parsed.get("phases", [])):
            phases.append({
                "phase_number": p.get("phase_number", i + 1),
                "title": p.get("title", f"Phase {i + 1}"),
                "description": p.get("description", ""),
                "skills": p.get("skills", []),
                "courses": p.get("courses", []),
                "duration_weeks": p.get("duration_weeks", 4),
            })

        logger.info("Successfully generated AI learning path via Vertex AI.")
        return {
            "phases": phases,
            "weekly_schedule": parsed.get("weekly_schedule", "10-12 hours per week"),
            "total_hours": parsed.get("total_hours", 0),
            "estimated_weeks": parsed.get("estimated_weeks", 0),
            "recommendations": parsed.get("recommendations", []),
        }

    except Exception as exc:
        logger.warning("Vertex AI unavailable (%s). Falling back to rule-based path.", exc)

    return _generate_fallback_path(skill_gaps, recommended_courses, role_context)


def _generate_fallback_path(skill_gaps, recommended_courses, role_context) -> Dict[str, Any]:
    """Unchanged rule-based fallback."""
    priority_groups: Dict[str, List] = {"Critical": [], "High": [], "Medium": []}
    for gap in skill_gaps:
        priority = gap.get("priority", "Medium")
        if priority in priority_groups:
            priority_groups[priority].append(gap)

    course_by_gap: Dict[str, List[str]] = {}
    for rc in recommended_courses:
        for gap_name in rc.get("addresses_gaps", []):
            course_by_gap.setdefault(gap_name.lower(), []).append(rc["course_title"])

    phases, total_hours, phase_num = [], 0, 0
    for priority_label, gaps in priority_groups.items():
        if not gaps:
            continue
        phase_num += 1
        skill_names = [g["skill_name"] for g in gaps]
        phase_courses, seen = [], set()
        for g in gaps:
            for ct in course_by_gap.get(g["skill_name"].lower(), []):
                if ct not in seen:
                    phase_courses.append(ct)
                    seen.add(ct)
        if priority_label == "Critical":
            duration_weeks = max(4, len(gaps) * 3)
        elif priority_label == "High":
            duration_weeks = max(3, len(gaps) * 2)
        else:
            duration_weeks = max(2, len(gaps))
        total_hours += duration_weeks * 10
        phases.append({
            "phase_number": phase_num,
            "title": f"Phase {phase_num}: {priority_label} Priority Skills",
            "description": f"Focus on {priority_label.lower()} priority skill gaps: {', '.join(skill_names)}",
            "skills": skill_names,
            "courses": phase_courses,
            "duration_weeks": duration_weeks,
        })

    estimated_weeks = sum(p["duration_weeks"] for p in phases) if phases else 4
    if total_hours == 0:
        total_hours = estimated_weeks * 10
    role_title = role_context.get("title", "target role")
    return {
        "phases": phases,
        "weekly_schedule": "10-12 hours per week",
        "total_hours": total_hours,
        "estimated_weeks": estimated_weeks,
        "recommendations": [
            "Focus on building foundational skills before advancing to complex topics.",
            "Dedicate consistent study time each week for best results.",
            f"Seek mentorship from senior {role_title} professionals.",
            "Apply learned skills through hands-on projects and real-world scenarios.",
            "Track progress regularly and adjust the plan as needed.",
        ],
    }
