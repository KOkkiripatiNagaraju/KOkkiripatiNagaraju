"""
HR Storage Service — stores policy content in GCS (policies/ prefix)
or local storage as a fallback.  Uses the project's GCS_BUCKET_NAME env.
"""
from pathlib import Path
import os
from config.database import settings


class HRStorageService:
    def __init__(self):
        self.bucket = getattr(settings, "GCS_BUCKET_NAME", "") or os.getenv("GCS_BUCKET_NAME", "")
        self.use_gcs = bool(self.bucket)
        self.local_root = Path("storage/hr_policies")
        self.local_root.mkdir(parents=True, exist_ok=True)
        self._client = None

    def _get_client(self):
        if self._client is None:
            from google.cloud import storage as gcs
            self._client = gcs.Client()
        return self._client

    def save_text(self, key: str, content: str) -> str:
        if self.use_gcs:
            try:
                client = self._get_client()
                bucket = client.bucket(self.bucket)
                blob = bucket.blob(key)
                blob.upload_from_string(content.encode("utf-8"), content_type="text/markdown")
                return f"gs://{self.bucket}/{key}"
            except Exception:
                pass  # fall through to local

        path = self.local_root / key
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
        return str(path)

    def read_text(self, key_or_path: str) -> str:
        if key_or_path.startswith("gs://"):
            try:
                _, _, rest = key_or_path.partition("gs://")
                bucket_name, _, key = rest.partition("/")
                client = self._get_client()
                blob = client.bucket(bucket_name).blob(key)
                return blob.download_as_text(encoding="utf-8")
            except Exception:
                pass

        path = Path(key_or_path)
        if path.exists():
            return path.read_text(encoding="utf-8")
        return ""


hr_storage_service = HRStorageService()
