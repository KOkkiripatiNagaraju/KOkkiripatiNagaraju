"""
Pulse Survey CRUD Operations
Handles survey response creation, AI analysis triggering, and dashboard metric aggregation.
"""
import datetime
from sqlalchemy.orm import Session
from typing import List, Dict, Any, Optional
from models.schemas import (
    Employee, SurveyDefinition, SurveyQuestion, Policy,
    PulseSurveyResponse, AIInsight, DashboardMetric
)
from services.pulse_ai_service import pulse_ai_service


def get_survey(db: Session, survey_id: int) -> Optional[SurveyDefinition]:
    return db.query(SurveyDefinition).filter(SurveyDefinition.id == survey_id).first()


def get_surveys(db: Session) -> List[SurveyDefinition]:
    return db.query(SurveyDefinition).all()


def get_employee_by_id(db: Session, employee_id: int) -> Optional[Employee]:
    return db.query(Employee).filter(Employee.id == employee_id).first()


def create_pulse_survey_response(db: Session, employee_id: Optional[int], survey_id: int,
                                  response_data: Dict[str, Any]) -> PulseSurveyResponse:
    """Stores response, triggers AI analysis, saves insight, recalculates dashboard metrics."""
    # 1. Store response
    response = PulseSurveyResponse(
        employee_id=employee_id,
        survey_id=survey_id,
        response_data=response_data,
        timestamp=datetime.datetime.utcnow()
    )
    db.add(response)
    db.commit()
    db.refresh(response)

    # 2. Get survey questions for AI context
    survey = get_survey(db, survey_id)
    questions_dict = {}
    if survey:
        questions = db.query(SurveyQuestion).filter(SurveyQuestion.survey_id == survey_id).all()
        questions_dict = {q.id: q.question_text for q in questions}

    # 3. Run AI sentiment analysis
    analysis = pulse_ai_service.analyze_feedback(response_data, questions_dict)

    # 4. Save AI insight
    insight = AIInsight(
        response_id=response.id,
        sentiment_score=analysis["sentiment_score"],
        emotion_scores=analysis["emotion_scores"],
        topics=analysis["topics"],
        retention_risk=analysis["retention_risk"],
        recommendations=analysis["recommendations"],
        timestamp=datetime.datetime.utcnow()
    )
    db.add(insight)
    db.commit()
    db.refresh(insight)

    # 5. Recalculate dashboard metrics
    update_dashboard_metrics(db, survey_id)

    return response


def get_employee_insights(db: Session, employee_id: int) -> List[AIInsight]:
    """Fetch AI insights for a specific employee, ordered by most recent first."""
    return db.query(AIInsight)\
        .join(PulseSurveyResponse, AIInsight.response_id == PulseSurveyResponse.id)\
        .filter(PulseSurveyResponse.employee_id == employee_id)\
        .order_by(PulseSurveyResponse.timestamp.desc())\
        .all()


def update_dashboard_metrics(db: Session, survey_id: int):
    """Recalculates aggregated metrics for a survey — org-wide and by department."""
    # Clear existing metrics for this survey
    db.query(DashboardMetric).filter(DashboardMetric.survey_id == survey_id).delete()

    # Get all responses for this survey
    responses = db.query(PulseSurveyResponse).filter(PulseSurveyResponse.survey_id == survey_id).all()
    if not responses:
        db.commit()
        return

    # Load insights for these responses
    response_ids = [r.id for r in responses]
    insights_map = {}
    insights = db.query(AIInsight).filter(AIInsight.response_id.in_(response_ids)).all()
    for ins in insights:
        insights_map[ins.response_id] = ins

    def calculate_aggregates(resp_list):
        count = len(resp_list)
        if count == 0:
            return {"sentiment": 0.0, "topics": {}, "risk": {"High": 0, "Medium": 0, "Low": 0}}

        sum_sentiment = 0.0
        topics_count = {}
        risk_count = {"High": 0, "Medium": 0, "Low": 0}

        for r in resp_list:
            ins = insights_map.get(r.id)
            if ins:
                sum_sentiment += ins.sentiment_score
                risk_count[ins.retention_risk] = risk_count.get(ins.retention_risk, 0) + 1
                for t in ins.topics:
                    topics_count[t] = topics_count.get(t, 0) + 1

        return {
            "sentiment": round(sum_sentiment / count, 2) if count > 0 else 0.0,
            "topics": topics_count,
            "risk": risk_count
        }

    # Org-wide aggregates
    org_agg = calculate_aggregates(responses)
    org_metric = DashboardMetric(
        department="All",
        survey_id=survey_id,
        aggregated_sentiment=org_agg["sentiment"],
        aggregated_topics=org_agg["topics"],
        risk_summary=org_agg["risk"]
    )
    db.add(org_metric)

    # Group by department
    departments = set()
    for r in responses:
        if r.employee_id:
            emp = db.query(Employee).filter(Employee.id == r.employee_id).first()
            if emp and emp.department:
                departments.add(emp.department)

    for dept in departments:
        dept_emp_ids = [e.id for e in db.query(Employee).filter(Employee.department == dept).all()]
        dept_responses = [r for r in responses if r.employee_id in dept_emp_ids]
        dept_agg = calculate_aggregates(dept_responses)
        dept_metric = DashboardMetric(
            department=dept,
            survey_id=survey_id,
            aggregated_sentiment=dept_agg["sentiment"],
            aggregated_topics=dept_agg["topics"],
            risk_summary=dept_agg["risk"]
        )
        db.add(dept_metric)

    db.commit()


def seed_pulse_survey(db: Session):
    """
    Seeds initial pulse survey with questions and pre-canned responses
    so dashboards are populated on first launch.
    """
    # Check if pulse survey data already exists
    existing_pulse_responses = db.query(PulseSurveyResponse).count()
    if existing_pulse_responses > 0:
        return

    # Check if the survey definition exists
    survey = db.query(SurveyDefinition).filter(SurveyDefinition.title == "Q2 Workplace Pulse & Engagement Survey").first()
    if not survey:
        survey = SurveyDefinition(
            title="Q2 Workplace Pulse & Engagement Survey",
            is_anonymous=True
        )
        db.add(survey)
        db.commit()
        db.refresh(survey)

    # Check if questions exist for this survey
    existing_questions = db.query(SurveyQuestion).filter(SurveyQuestion.survey_id == survey.id).count()
    if existing_questions == 0:
        questions_data = [
            {"question_text": "On a scale of 1 to 5, how satisfied are you with your workload balance?", "type": "rating", "sequence": 1, "options": None},
            {"question_text": "What are the main bottlenecks or challenges you are currently facing in your role?", "type": "text", "sequence": 2, "options": None},
            {"question_text": "Which aspect of our work environment do you feel needs the most immediate improvement?", "type": "mcq", "sequence": 3, "options": ["Workload & Stress", "Management Communication", "Compensation & Benefits", "Remote Work Flexibility", "Career Growth & Development"]},
            {"question_text": "Please provide any additional feedback or comments you'd like to share.", "type": "text", "sequence": 4, "options": None},
        ]
        for q_data in questions_data:
            q = SurveyQuestion(
                survey_id=survey.id,
                question_text=q_data["question_text"],
                type=q_data["type"],
                sequence=q_data["sequence"],
                options=q_data["options"]
            )
            db.add(q)
        db.commit()

    # Get all questions for this survey
    questions = db.query(SurveyQuestion).filter(SurveyQuestion.survey_id == survey.id).all()
    questions_dict = {q.id: q.question_text for q in questions}
    q_ids = sorted([q.id for q in questions])

    if len(q_ids) < 4:
        print("Warning: Not enough survey questions to seed responses")
        return

    # Get employees to link responses to
    employees = db.query(Employee).all()
    if not employees:
        print("Warning: No employees found to seed pulse survey responses. Skipping seeding.")
        return

    # Pre-canned responses with varying sentiments
    seeded_feedback = [
        {
            "employee_id": None,  # will pick first employee
            "answers": {
                str(q_ids[0]): 1,
                str(q_ids[1]): "I am working 60+ hour weeks and weekends to hit unrealistic product launch deadlines. The workload is completely unmanageable right now.",
                str(q_ids[2]): "Workload & Stress",
                str(q_ids[3]): "My manager doesn't listen to our estimates. I feel incredibly exhausted and close to burnout."
            }
        },
        {
            "employee_id": None,
            "answers": {
                str(q_ids[0]): 4,
                str(q_ids[1]): "Waiting on cross-functional sign-offs, but engineering tasks are going well.",
                str(q_ids[2]): "Remote Work Flexibility",
                str(q_ids[3]): "The hybrid arrangement is amazing. I love working from home on Monday/Friday. Great team."
            }
        },
        {
            "employee_id": None,
            "answers": {
                str(q_ids[0]): 3,
                str(q_ids[1]): "Our QA test suite is slow, which stalls my work.",
                str(q_ids[2]): "Compensation & Benefits",
                str(q_ids[3]): "I feel underpaid compared to local market salaries. Benefits are good but base compensation should be reviewed."
            }
        },
        {
            "employee_id": None,
            "answers": {
                str(q_ids[0]): 2,
                str(q_ids[1]): "The sales CRM is sluggish. Also, we are micromanaged on call counts every day.",
                str(q_ids[2]): "Management Communication",
                str(q_ids[3]): "I would appreciate more autonomy to handle my sales targets instead of daily log reporting."
            }
        },
        {
            "employee_id": None,
            "answers": {
                str(q_ids[0]): 5,
                str(q_ids[1]): "None, sales pipelines are very strong.",
                str(q_ids[2]): "Career Growth & Development",
                str(q_ids[3]): "Sarah is a great director. Commission plans are highly motivating!"
            }
        },
        {
            "employee_id": None,
            "answers": {
                str(q_ids[0]): 4,
                str(q_ids[1]): "Lacking designer assets for campaigns.",
                str(q_ids[2]): "Career Growth & Development",
                str(q_ids[3]): "I want more options for training and career advancement. I feel a bit stuck in my current track."
            }
        },
        {
            "employee_id": None,  # Anonymous
            "answers": {
                str(q_ids[0]): 2,
                str(q_ids[1]): "Unclear directions on strategic alignment. Constant fire-drills.",
                str(q_ids[2]): "Workload & Stress",
                str(q_ids[3]): "Very anxious about upcoming organization changes and layoffs."
            },
            "anonymous": True
        },
        {
            "employee_id": None,  # Anonymous
            "answers": {
                str(q_ids[0]): 4,
                str(q_ids[1]): "None, good communication flows.",
                str(q_ids[2]): "Compensation & Benefits",
                str(q_ids[3]): "Very happy with the medical package changes."
            },
            "anonymous": True
        }
    ]

    # Assign employees to non-anonymous responses
    emp_index = 0
    for feed in seeded_feedback:
        if not feed.get("anonymous", False) and employees:
            feed["employee_id"] = employees[emp_index % len(employees)].id
            emp_index += 1

    print("Seeding pulse survey responses with AI analysis...")
    for i, feed in enumerate(seeded_feedback):
        timestamp = datetime.datetime.utcnow() - datetime.timedelta(days=(len(seeded_feedback) - i) * 3)

        response = PulseSurveyResponse(
            employee_id=feed["employee_id"] if not feed.get("anonymous") else None,
            survey_id=survey.id,
            response_data=feed["answers"],
            timestamp=timestamp
        )
        db.add(response)
        db.commit()
        db.refresh(response)

        # Run AI analysis
        analysis = pulse_ai_service.analyze_feedback(feed["answers"], questions_dict)

        insight = AIInsight(
            response_id=response.id,
            sentiment_score=analysis["sentiment_score"],
            emotion_scores=analysis["emotion_scores"],
            topics=analysis["topics"],
            retention_risk=analysis["retention_risk"],
            recommendations=analysis["recommendations"],
            timestamp=timestamp
        )
        db.add(insight)
        db.commit()

    # Refresh dashboard stats
    update_dashboard_metrics(db, survey.id)
    print("Pulse survey seeding completed.")
