"""
Pulse Survey AI Sentiment Analysis Service
Uses Vertex AI (Gemini) or falls back to a smart mock engine for offline use.
"""
import json
import re
import os
from typing import Dict, Any, List
from config.database import settings


def _init_vertexai():
    import vertexai
    project  = getattr(settings, "VERTEX_PROJECT", "") or os.getenv("VERTEX_PROJECT", "")
    location = getattr(settings, "VERTEX_LOCATION", "") or os.getenv("VERTEX_LOCATION", "us-central1")
    vertexai.init(project=project, location=location)


class PulseAIService:
    def __init__(self):
        self._mock_mode = None
        self._vertex_model = None
        self._embed_model = None

    @property
    def mock_mode(self):
        if self._mock_mode is None:
            self._mock_mode = getattr(settings, 'MOCK_AWS', True)
        return self._mock_mode

    @mock_mode.setter
    def mock_mode(self, value):
        self._mock_mode = value

    def _get_vertex_model(self):
        if self._vertex_model is None:
            project = getattr(settings, "VERTEX_PROJECT", "") or os.getenv("VERTEX_PROJECT", "")
            if not project:
                self.mock_mode = True
                return None
            try:
                _init_vertexai()
                from vertexai.generative_models import GenerativeModel
                self._vertex_model = GenerativeModel("gemini-2.5-flash")
            except Exception as e:
                print(f"Failed to initialize Vertex AI model, falling back to mock mode. Error: {e}")
                self.mock_mode = True
        return self._vertex_model

    def _get_embed_model(self):
        if self._embed_model is None:
            project = getattr(settings, "VERTEX_PROJECT", "") or os.getenv("VERTEX_PROJECT", "")
            if not project:
                return None
            try:
                _init_vertexai()
                from vertexai.language_models import TextEmbeddingModel
                self._embed_model = TextEmbeddingModel.from_pretrained("text-embedding-005")
            except Exception as e:
                print(f"Failed to initialize Vertex AI embedding model. Error: {e}")
        return self._embed_model

    def get_embeddings(self, text: str) -> List[float]:
        """
        Generates dense vector embeddings via Vertex AI text-embedding-005,
        or a deterministic local pseudo-embedding (hash-based) if in mock mode.
        """
        if self.mock_mode:
            embedding = [0.0] * 384
            cleaned_text = text.lower()
            for i in range(384):
                val = sum(ord(char) * (i + 1) for char in cleaned_text) % 100
                embedding[i] = (val / 50.0) - 1.0
            return embedding

        try:
            model = self._get_embed_model()
            if model is None:
                raise RuntimeError("Embedding model unavailable")
            embeddings = model.get_embeddings([text[:8000]])
            return embeddings[0].values
        except Exception as e:
            print(f"Error generating Vertex AI embeddings: {e}. Falling back to mock embeddings.")
            self.mock_mode = True
            return self.get_embeddings(text)

    def analyze_feedback(self, response_data: Dict[str, Any], questions_dict: Dict[int, str]) -> Dict[str, Any]:
        """
        Processes feedback text. Analyzes via Vertex AI LLM
        or uses the local smart mock engine if offline.
        """
        full_feedback_parts = []
        for q_id_str, answer in response_data.items():
            try:
                q_id = int(q_id_str)
                q_text = questions_dict.get(q_id, "Feedback")
            except ValueError:
                q_text = "Feedback"

            if isinstance(answer, str):
                full_feedback_parts.append(f"{q_text}: {answer}")
            elif isinstance(answer, (int, float)):
                full_feedback_parts.append(f"{q_text}: Rated {answer}/5")
            elif isinstance(answer, list):
                full_feedback_parts.append(f"{q_text}: Selected {', '.join(map(str, answer))}")

        full_feedback_text = " | ".join(full_feedback_parts)

        if self.mock_mode:
            return self._smart_mock_analysis(full_feedback_text)

        try:
            return self._call_vertex_feedback_analyzer(full_feedback_text)
        except Exception as e:
            print(f"Vertex AI Feedback Analyzer failed: {e}. Falling back to smart mock.")
            return self._smart_mock_analysis(full_feedback_text)

    def _call_vertex_feedback_analyzer(self, text: str) -> Dict[str, Any]:
        """Calls Vertex AI for AI sentiment analysis."""
        prompt = f"""
You are an expert HR Feedback Analyzer Agent. Analyze the following employee survey feedback:
"{text}"

Your goal is to extract sentiment, emotions, topics, attrition risk, and role-specific action recommendations.

You MUST respond with a single, valid JSON block. Do not include introductory or concluding text outside the JSON.

JSON Schema:
{{
  "sentiment_score": float,  // A score between -1.0 (highly negative) and 1.0 (highly positive)
  "emotion_scores": {{
    "Stress": float,        // 0.0 to 1.0
    "Burnout": float,       // 0.0 to 1.0
    "Satisfaction": float,  // 0.0 to 1.0
    "Anxiety": float,       // 0.0 to 1.0
    "Excitement": float     // 0.0 to 1.0
  }},
  "topics": [string],       // Array of 1 to 3 primary topics
  "retention_risk": string, // "High", "Medium", or "Low"
  "recommendations": {{
    "employee": [string],   // 2-3 action items for the employee
    "manager": [string],    // 2-3 coaching tips for the manager
    "hr": [string]          // 2-3 strategic priorities for HR
  }}
}}

JSON:"""

        try:
            model = self._get_vertex_model()
            if model is None:
                raise RuntimeError("Vertex AI model unavailable")
            response = model.generate_content(prompt)
            output_text = response.text or ""
            json_match = re.search(r"\{.*\}", output_text, re.DOTALL)
            if json_match:
                return json.loads(json_match.group(0))
            else:
                raise ValueError("Failed to parse agent JSON response block")
        except Exception as e:
            print(f"Error in Vertex AI API: {e}")
            raise e

    def _smart_mock_analysis(self, text: str) -> Dict[str, Any]:
        """Rule-based NLP mock for sentiment, emotion, topics, and recommendations."""
        normalized_text = text.lower()

        sentiment_score = 0.2
        emotions = {
            "Stress": 0.1, "Burnout": 0.1, "Satisfaction": 0.6,
            "Anxiety": 0.1, "Excitement": 0.3
        }
        topics = []

        stress_words = ["stress", "burnout", "tired", "exhaust", "overtime", "workload", "hours", "busy", "pressure", "overwork", "deadlines"]
        stress_count = sum(1 for word in stress_words if word in normalized_text)
        if stress_count > 0:
            emotions["Stress"] = min(0.95, 0.2 + (stress_count * 0.25))
            emotions["Burnout"] = min(0.9, 0.15 + (stress_count * 0.2))
            emotions["Satisfaction"] = max(0.05, emotions["Satisfaction"] - (stress_count * 0.15))
            emotions["Anxiety"] = min(0.9, 0.2 + (stress_count * 0.2))
            emotions["Excitement"] = max(0.0, emotions["Excitement"] - 0.2)
            sentiment_score -= (stress_count * 0.2)
            topics.append("workload")
            if "burnout" in normalized_text:
                topics.append("burnout")

        manager_words = ["manager", "boss", "supervisor", "lead", "micromanage", "support", "direction", "feedback"]
        manager_count = sum(1 for word in manager_words if word in normalized_text)
        if manager_count > 0:
            topics.append("management")
            if any(neg in normalized_text for neg in ["bad", "poor", "micromanage", "never", "hard", "no support"]):
                emotions["Stress"] = min(0.95, emotions["Stress"] + 0.2)
                emotions["Satisfaction"] = max(0.05, emotions["Satisfaction"] - 0.25)
                sentiment_score -= 0.3
            else:
                emotions["Satisfaction"] = min(1.0, emotions["Satisfaction"] + 0.15)
                sentiment_score += 0.1

        comp_words = ["salary", "pay", "comp", "raise", "bonus", "benefits", "money", "promotion"]
        comp_count = sum(1 for word in comp_words if word in normalized_text)
        if comp_count > 0:
            topics.append("compensation")
            if any(neg in normalized_text for neg in ["low", "underpaid", "fair", "market", "hike", "raise", "increase"]):
                if "low" in normalized_text or "underpaid" in normalized_text:
                    emotions["Satisfaction"] = max(0.05, emotions["Satisfaction"] - 0.2)
                    sentiment_score -= 0.25
                else:
                    sentiment_score += 0.15

        remote_words = ["remote", "office", "wfh", "commute", "flexible", "hybrid", "workspace"]
        remote_count = sum(1 for word in remote_words if word in normalized_text)
        if remote_count > 0:
            topics.append("workspace")
            if "flexible" in normalized_text or "remote" in normalized_text:
                emotions["Satisfaction"] = min(1.0, emotions["Satisfaction"] + 0.1)
                emotions["Excitement"] = min(1.0, emotions["Excitement"] + 0.1)

        career_words = ["career", "growth", "learn", "skill", "training", "mentor", "promotion", "develop"]
        career_count = sum(1 for word in career_words if word in normalized_text)
        if career_count > 0:
            topics.append("career_growth")
            if "no growth" in normalized_text or "stuck" in normalized_text:
                emotions["Satisfaction"] = max(0.05, emotions["Satisfaction"] - 0.2)
                sentiment_score -= 0.2
            else:
                emotions["Excitement"] = min(1.0, emotions["Excitement"] + 0.15)

        pos_words = ["happy", "great", "love", "satisfied", "enjoy", "awesome", "good", "nice", "perfect", "well", "appreciate"]
        pos_count = sum(1 for word in pos_words if word in normalized_text)
        if pos_count > 0:
            sentiment_score = min(1.0, sentiment_score + (pos_count * 0.25))
            emotions["Satisfaction"] = min(1.0, emotions["Satisfaction"] + (pos_count * 0.15))
            emotions["Excitement"] = min(1.0, emotions["Excitement"] + (pos_count * 0.15))
            emotions["Stress"] = max(0.0, emotions["Stress"] - (pos_count * 0.1))
            emotions["Burnout"] = max(0.0, emotions["Burnout"] - (pos_count * 0.1))

        neg_words = ["bad", "sad", "hate", "unhappy", "angry", "poor", "frustrated", "disappointed", "annoyed"]
        neg_count = sum(1 for word in neg_words if word in normalized_text)
        if neg_count > 0:
            sentiment_score = max(-1.0, sentiment_score - (neg_count * 0.3))
            emotions["Satisfaction"] = max(0.05, emotions["Satisfaction"] - (neg_count * 0.2))
            emotions["Anxiety"] = min(0.95, emotions["Anxiety"] + (neg_count * 0.2))
            emotions["Stress"] = min(0.95, emotions["Stress"] + (neg_count * 0.15))

        if not topics:
            topics = ["general_engagement"]

        sentiment_score = max(-1.0, min(1.0, sentiment_score))

        if emotions["Burnout"] > 0.6 or emotions["Stress"] > 0.7 or sentiment_score < -0.3:
            retention_risk = "High"
        elif emotions["Burnout"] > 0.4 or emotions["Stress"] > 0.5 or sentiment_score < 0.1:
            retention_risk = "Medium"
        else:
            retention_risk = "Low"

        employee_recs, manager_recs, hr_recs = [], [], []

        if "workload" in topics or "burnout" in topics:
            employee_recs.extend([
                "Block out focused 'no-meetings' times in your calendar to tackle priorities.",
                "Schedule a 1-on-1 review with your manager to re-align on workload expectations and deadlines.",
                "Leverage the employee wellness program for burnout prevention workshops."
            ])
            manager_recs.extend([
                "Review team task allocation and identify high-friction or low-value activities that can be postponed.",
                "Have explicit 1-on-1 check-ins focused purely on workload balance, not status updates.",
                "Actively encourage team members to take vacation days and log off on time."
            ])
            hr_recs.extend([
                "Audit department headcount and open requisitions in high-stress teams.",
                "Review current workload policies and launch mental health days support.",
                "Conduct a structural workflow assessment to eliminate operational bottlenecks."
            ])

        if "management" in topics:
            employee_recs.extend([
                "Share clear, constructive upward feedback on what communication style works best for you.",
                "Establish structured updates (like weekly summaries) to streamline manager review requests."
            ])
            manager_recs.extend([
                "Increase delegate-level trust; avoid checking status multiple times a day.",
                "Ensure goals and KPIs are clearly documented to reduce micro-management perceptions."
            ])
            hr_recs.extend([
                "Introduce manager feedback channels and run 360 leadership assessments.",
                "Enroll new supervisors in coaching-oriented management training tracks."
            ])

        if "compensation" in topics:
            employee_recs.extend([
                "Research market value ranges and document your key achievements and impact for the next cycle.",
                "Request a compensation review roadmap to understand promotion milestones."
            ])
            manager_recs.extend([
                "Advocate for underpaid high-performers with HR during quarterly budget allocations.",
                "Clearly explain the current cycle's compensation review schedules and equity models."
            ])
            hr_recs.extend([
                "Conduct a comprehensive pay equity and market alignment audit for the department.",
                "Publish transparent career progression frameworks mapping skills to compensation bands."
            ])

        if "workspace" in topics:
            employee_recs.extend([
                "Optimize your remote workstation setup utilizing the company workspace stipend.",
                "Establish clear boundaries between home-office and personal time."
            ])
            manager_recs.extend([
                "Standardize core working hours to accommodate hybrid and remote team structures.",
                "Host regional social meets or team offsites to improve remote engagement."
            ])
            hr_recs.extend([
                "Review flexible workspace policies to ensure equitable hybrid capabilities.",
                "Increase office-bound stipends for technology and ergonomic support."
            ])

        if "career_growth" in topics:
            employee_recs.extend([
                "Draft an Individual Development Plan (IDP) and outline three skills you want to learn this year.",
                "Access the company learning library or request educational reimbursement for certs."
            ])
            manager_recs.extend([
                "Dedicate one meeting per month to talk specifically about professional development, not project tasks.",
                "Involve the employee in cross-functional projects that build desired skills."
            ])
            hr_recs.extend([
                "Launch structured internal mentorship programs pairing leaders with junior staff.",
                "Integrate digital learning platforms (e.g. Coursera/Udemy) with employee profiles."
            ])

        if len(employee_recs) < 2:
            employee_recs.extend([
                "Continue detailing constructive ideas in future pulse surveys.",
                "Attend team-building events and department town halls to share feedback."
            ])
        if len(manager_recs) < 2:
            manager_recs.extend([
                "Keep a consistent frequency of feedback check-ins.",
                "Celebrate individual and team milestones in group forums."
            ])
        if len(hr_recs) < 2:
            hr_recs.extend([
                "Track the aggregated results of this survey and share a summary report with leadership.",
                "Verify standard HR policy accessibility on the employee intranet."
            ])

        return {
            "sentiment_score": round(sentiment_score, 2),
            "emotion_scores": {k: round(v, 2) for k, v in emotions.items()},
            "topics": list(set(topics))[:3],
            "retention_risk": retention_risk,
            "recommendations": {
                "employee": employee_recs[:3],
                "manager": manager_recs[:3],
                "hr": hr_recs[:3]
            }
        }


pulse_ai_service = PulseAIService()
