"""
Onboarding Service — orchestrates AI salary recommendation, offer letter
generation, BGV verification, and access assignment for the base project.

This service bridges the base project's Candidate/Job models with the new
onboarding agents and integrations.
"""
import datetime
import logging

from fastapi import HTTPException
from sqlalchemy.orm import Session

from config.onboarding_settings import get_onboarding_settings
from agents.onboarding.salary_agent import SalaryRecommendationAgent
from agents.onboarding.offer_letter_agent import OfferLetterAgent
from agents.onboarding.bgv_agent import BGVVerificationAgent
from agents.onboarding.access_agent import AccessRecommendationAgent
from integrations.onboarding_storage import OnboardingStorageClient
from integrations.onboarding_email import OnboardingEmailClient
from models import schemas
from models.onboarding_models import (
    OnboardingOffer,
    OnboardingBGVDocument,
    OnboardingAccessAssignment,
)

logger = logging.getLogger(__name__)


def _get_services():
    """Lazily construct all service objects using the onboarding settings."""
    s = get_onboarding_settings()
    return (
        SalaryRecommendationAgent(s),
        OfferLetterAgent(s),
        BGVVerificationAgent(s),
        AccessRecommendationAgent(),
        OnboardingStorageClient(s),
        OnboardingEmailClient(s),
    )


# ─────────────────────────────────────────────────────────────────────────────
# Helper
# ─────────────────────────────────────────────────────────────────────────────

def _get_candidate_and_job(db: Session, candidate_id: int):
    cand = db.query(schemas.Candidate).filter(schemas.Candidate.id == candidate_id).first()
    if not cand:
        raise HTTPException(status_code=404, detail="Candidate not found.")
    job = db.query(schemas.Job).filter(schemas.Job.id == cand.job_id).first()
    if not job:
        raise HTTPException(status_code=404, detail="Job associated with candidate not found.")
    return cand, job


def _extract_salary_from_parsed(parsed_data: dict | None) -> tuple[float, float]:
    """Try to extract current/expected salary from parsed resume data."""
    if not parsed_data:
        return 0.0, 0.0
    cs = parsed_data.get("current_salary") or parsed_data.get("current salary") or 0.0
    es = parsed_data.get("expected_salary") or parsed_data.get("expected salary") or 0.0
    try:
        return float(cs), float(es)
    except (TypeError, ValueError):
        return 0.0, 0.0


# ─────────────────────────────────────────────────────────────────────────────
# Public API Functions (called by routers/api.py)
# ─────────────────────────────────────────────────────────────────────────────

def get_salary_recommendation(
    db: Session,
    candidate_id: int,
    current_salary: float | None = None,
    expected_salary: float | None = None,
) -> dict:
    """
    Run AI salary recommendation for a candidate.
    If current_salary / expected_salary are not provided, attempts to extract
    from parsed_data; falls back to 0 (Bedrock will use midpoint of job range).
    """
    cand, job = _get_candidate_and_job(db, candidate_id)
    salary_agent, *_ = _get_services()

    # Resolve salary inputs
    if current_salary is None or expected_salary is None:
        cs_parsed, es_parsed = _extract_salary_from_parsed(cand.parsed_data)
        current_salary = current_salary if current_salary is not None else cs_parsed
        expected_salary = expected_salary if expected_salary is not None else es_parsed

    exp_years = cand.experience_years or 0.0

    salary, notes = salary_agent.recommend(
        candidate_name=cand.name,
        role=job.title,
        department=job.department,
        location=job.location,
        experience_years=float(exp_years),
        current_salary=float(current_salary),
        expected_salary=float(expected_salary),
        salary_range=job.salary_range,
    )

    return {
        "candidate_id": candidate_id,
        "candidate_name": cand.name,
        "role": job.title,
        "department": job.department,
        "location": job.location,
        "salary_range": job.salary_range,
        "recommended_salary": salary,
        "notes": notes,
    }


def generate_offer_letter(
    db: Session,
    candidate_id: int,
    salary: float,
    salary_notes: dict | None = None,
) -> dict:
    """
    Generate AI offer letter PDF and store it. Creates/updates OnboardingOffer record.
    Returns the offer record dict.
    """
    cand, job = _get_candidate_and_job(db, candidate_id)
    _, offer_agent, _, _, storage, _ = _get_services()

    if salary_notes is None:
        salary_notes = {}

    # Generate offer letter text via Bedrock (or local template fallback)
    letter_text = offer_agent.generate(
        candidate_name=cand.name,
        role=job.title,
        department=job.department,
        location=job.location,
        salary=salary,
        salary_notes=salary_notes,
    )

    # Render PDF
    pdf_bytes = offer_agent.render_pdf(letter_text)

    # Store PDF
    uri = storage.put_bytes(
        key_prefix=f"offers/candidate_{candidate_id}",
        file_name=f"offer-letter-{candidate_id}.pdf",
        content=pdf_bytes,
        content_type="application/pdf",
    )

    # Upsert OnboardingOffer record
    offer = db.query(OnboardingOffer).filter(
        OnboardingOffer.candidate_id == candidate_id
    ).first()

    if offer:
        offer.recommended_salary = salary
        offer.salary_notes = salary_notes
        offer.offer_letter_text = letter_text
        offer.offer_letter_uri = uri
        offer.status = "generated"
    else:
        offer = OnboardingOffer(
            candidate_id=candidate_id,
            job_id=cand.job_id,
            recommended_salary=salary,
            salary_notes=salary_notes,
            offer_letter_text=letter_text,
            offer_letter_uri=uri,
            status="generated",
        )
        db.add(offer)

    db.commit()
    db.refresh(offer)

    return {
        "offer_id": offer.id,
        "candidate_id": candidate_id,
        "candidate_name": cand.name,
        "job_title": job.title,
        "salary": salary,
        "offer_letter_uri": uri,
        "status": offer.status,
    }


async def send_offer_email(db: Session, candidate_id: int) -> dict:
    """
    Send the generated offer letter PDF to the candidate's email.
    """
    cand, job = _get_candidate_and_job(db, candidate_id)
    _, _, _, _, storage, email_client = _get_services()

    offer = db.query(OnboardingOffer).filter(
        OnboardingOffer.candidate_id == candidate_id
    ).first()
    if not offer or offer.status not in ("generated", "sent"):
        raise HTTPException(
            status_code=400,
            detail="Offer letter must be generated first before sending email.",
        )

    # Fetch PDF bytes
    try:
        pdf_bytes = storage.get_bytes(offer.offer_letter_uri)
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Could not retrieve offer PDF: {exc}") from exc

    result = await email_client.send_offer_email(
        db=db,
        candidate_id=candidate_id,
        recipient=cand.email,
        subject=f"Offer Letter — {job.title} at AI CareerHub",
        body=(
            f"Dear {cand.name},\n\n"
            "Congratulations! Your offer letter is attached to this email.\n"
            "Please review and accept it in the Candidate Portal.\n\n"
            "Best Regards,\nHR Onboarding Team\nAI CareerHub"
        ),
        attachment_content=pdf_bytes,
        attachment_name=f"Offer_Letter_{cand.name.replace(' ', '_')}.pdf",
    )

    if result["status"] == "failed":
        raise HTTPException(
            status_code=502,
            detail="Failed to send offer letter email via Gmail. Please check your Gmail API configuration."
        )

    offer.status = "sent"
    offer.sent_at = datetime.datetime.utcnow()
    db.commit()

    return {
        "candidate_id": candidate_id,
        "email": cand.email,
        "email_status": "sent",
        "offer_status": "sent",
    }


def get_offer(db: Session, candidate_id: int) -> dict | None:
    """Return the current offer record for a candidate (for candidate portal)."""
    offer = db.query(OnboardingOffer).filter(
        OnboardingOffer.candidate_id == candidate_id
    ).first()
    if not offer:
        return None
    return {
        "offer_id": offer.id,
        "candidate_id": candidate_id,
        "recommended_salary": offer.recommended_salary,
        "offer_letter_uri": offer.offer_letter_uri,
        "offer_letter_text": offer.offer_letter_text,
        "status": offer.status,
        "created_at": offer.created_at.isoformat() if offer.created_at else None,
        "sent_at": offer.sent_at.isoformat() if offer.sent_at else None,
    }


def get_offer_pdf(db: Session, candidate_id: int) -> bytes:
    """Return PDF bytes for an offer letter (for download in candidate portal)."""
    offer = db.query(OnboardingOffer).filter(
        OnboardingOffer.candidate_id == candidate_id
    ).first()
    if not offer or not offer.offer_letter_uri:
        raise HTTPException(status_code=404, detail="No offer letter found for this candidate.")

    _, _, _, _, storage, _ = _get_services()
    try:
        return storage.get_bytes(offer.offer_letter_uri)
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Could not retrieve offer PDF: {exc}") from exc


def store_bgv_document(
    db: Session,
    candidate_id: int,
    doc_type: str,
    file_name: str,
    file_bytes: bytes,
    content_type: str = "application/octet-stream",
    identity_no: str | None = None,
) -> dict:
    """
    Store a BGV document and run AI verification if enabled.
    Returns BGV document record dict.
    """
    cand, _ = _get_candidate_and_job(db, candidate_id)
    _, _, bgv_agent, _, storage, _ = _get_services()

    # Store file
    uri = storage.put_bytes(
        key_prefix=f"bgv/candidate_{candidate_id}",
        file_name=file_name,
        content=file_bytes,
        content_type=content_type,
    )

    # Run verification
    result = bgv_agent.verify(
        file_name=file_name,
        file_bytes=file_bytes,
        candidate_name=cand.name,
        candidate_email=cand.email,
        doc_type=doc_type,
        identity_no=identity_no,
    )
    verification_status = result.get("decision", "review")  # accepted | rejected | review

    doc = OnboardingBGVDocument(
        candidate_id=candidate_id,
        doc_type=doc_type,
        file_name=file_name,
        storage_uri=uri,
        verification_status=verification_status,
        agent_result=result,
        verified_at=datetime.datetime.utcnow(),
    )
    db.add(doc)
    db.commit()
    db.refresh(doc)

    return {
        "doc_id": doc.id,
        "candidate_id": candidate_id,
        "doc_type": doc_type,
        "file_name": file_name,
        "verification_status": verification_status,
        "reason": result.get("reason", ""),
        "confidence": result.get("confidence", 0.0),
    }


def assign_access(db: Session, candidate_id: int, employee_id: int | None = None) -> list[dict]:
    """Assign birthright access to a newly onboarded candidate/employee."""
    cand, job = _get_candidate_and_job(db, candidate_id)
    _, _, _, access_agent, _, _ = _get_services()

    # Check existing assignments
    existing = db.query(OnboardingAccessAssignment).filter(
        OnboardingAccessAssignment.candidate_id == candidate_id
    ).all()
    if existing:
        return [
            {"access_name": a.access_name, "access_type": a.access_type, "justification": a.justification}
            for a in existing
        ]

    recommendations = access_agent.recommend(role=job.title, department=job.department)
    assignments = []
    for item in recommendations:
        a = OnboardingAccessAssignment(
            candidate_id=candidate_id,
            employee_id=employee_id,
            access_name=item["access_name"],
            access_type=item["access_type"],
            justification=item["justification"],
        )
        db.add(a)
        assignments.append(item)

    db.commit()
    return assignments
