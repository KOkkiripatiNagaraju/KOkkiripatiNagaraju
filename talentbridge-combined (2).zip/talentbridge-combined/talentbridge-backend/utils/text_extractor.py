import io
import logging
import re
from pypdf import PdfReader
import docx2txt

logger = logging.getLogger(__name__)


def extract_text(file_bytes: bytes, filename: str) -> str:
    """
    Extract text from a file based on its extension/type.
    Supports PDF (digital + OCR fallback), DOCX, and plain text.
    """
    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""

    if ext == "pdf":
        text = _extract_pdf_digital(file_bytes)
        if _is_sufficient(text):
            return text
        # Digital extraction yielded little/nothing — try OCR
        logger.info("text_extractor: digital PDF extraction insufficient (%d chars), attempting OCR.", len(text))
        ocr_text = _extract_pdf_ocr(file_bytes)
        return ocr_text if _is_sufficient(ocr_text) else text

    if ext in ("docx", "doc"):
        try:
            text = docx2txt.process(io.BytesIO(file_bytes))
            if text and text.strip():
                return text.strip()
        except Exception as e:
            logger.error("Failed to extract text from DOCX: %s", e)

    # Plain-text fallback (txt, md, or unknown)
    for enc in ("utf-8", "latin-1"):
        try:
            return file_bytes.decode(enc).strip()
        except Exception:
            continue
    return ""


# ── helpers ──────────────────────────────────────────────────────────────────

def _is_sufficient(text: str, min_chars: int = 80) -> bool:
    """True if the extracted text looks like real content, not just noise."""
    if not text:
        return False
    # Count only printable non-whitespace characters
    printable = re.sub(r"\s+", "", text)
    return len(printable) >= min_chars


def _extract_pdf_digital(file_bytes: bytes) -> str:
    """Standard pypdf text layer extraction."""
    try:
        reader = PdfReader(io.BytesIO(file_bytes))
        pages = []
        for page in reader.pages:
            page_text = page.extract_text()
            if page_text:
                pages.append(page_text)
        return "\n".join(pages).strip()
    except Exception as e:
        logger.error("PDF digital extraction failed: %s", e)
        return ""


def _extract_pdf_ocr(file_bytes: bytes) -> str:
    """
    OCR fallback for scanned / image-based PDFs.
    Tries pdf2image → PIL → pytesseract.
    Gracefully no-ops if any dependency is missing.
    """
    try:
        from pdf2image import convert_from_bytes
        import pytesseract

        images = convert_from_bytes(file_bytes, dpi=200, fmt="jpeg")
        texts = []
        for img in images:
            page_text = pytesseract.image_to_string(img, lang="eng")
            if page_text and page_text.strip():
                texts.append(page_text.strip())
        result = "\n".join(texts).strip()
        if result:
            logger.info("text_extractor: OCR succeeded (%d chars extracted).", len(result))
        return result

    except ImportError as e:
        logger.warning("text_extractor: OCR dependencies not available (%s). Skipping OCR.", e)
        return ""
    except Exception as e:
        logger.error("text_extractor: OCR failed: %s", e)
        return ""
