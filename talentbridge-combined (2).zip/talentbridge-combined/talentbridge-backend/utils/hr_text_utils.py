"""Text utility helpers for the HR chatbot retrieval pipeline."""
import re
from collections import Counter

STOPWORDS = {
    "the", "is", "are", "a", "an", "to", "of", "and", "or", "for", "in", "on",
    "with", "what", "how", "can", "i", "we", "you", "my", "our", "policy",
    "please", "will", "be", "do", "has", "have", "this", "that", "it",
}


def clean_text(text: str) -> str:
    return re.sub(r"\s+", " ", text or "").strip()


def tokenize(text: str) -> list[str]:
    words = re.findall(r"[a-zA-Z0-9]+", (text or "").lower())
    return [w for w in words if w not in STOPWORDS and len(w) > 2]


def simple_similarity(query: str, document: str) -> float:
    q_tokens = tokenize(query)
    d_tokens = tokenize(document)
    if not q_tokens or not d_tokens:
        return 0.0
    q_count = Counter(q_tokens)
    d_set = set(d_tokens)
    matched = sum(count for token, count in q_count.items() if token in d_set)
    return matched / max(len(q_tokens), 1)


def split_into_chunks(text: str, max_chars: int = 1500) -> list[str]:
    text = clean_text(text)
    if len(text) <= max_chars:
        return [text]
    sentences = re.split(r"(?<=[.!?])\s+", text)
    chunks: list[str] = []
    current = ""
    for sentence in sentences:
        if len(current) + len(sentence) + 1 <= max_chars:
            current += " " + sentence
        else:
            if current.strip():
                chunks.append(current.strip())
            current = sentence
    if current.strip():
        chunks.append(current.strip())
    return chunks
