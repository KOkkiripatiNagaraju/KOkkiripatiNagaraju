"""
Thin compatibility wrapper — re-exports everything from gcs_storage.
All existing imports (from utils.aws_s3 import ...) continue to work unchanged.
"""
from utils.gcs_storage import (  # noqa: F401
    upload_to_s3,
    generate_presigned_download_url,
)
