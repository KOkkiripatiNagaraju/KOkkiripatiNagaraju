"""
Vertex AI LLM client — Google Gemini models via Vertex AI.

Primary   : gemini-2.5-flash
Fallback  : gemini-2.5-flash-lite
Embeddings: text-embedding-005
"""
import math
import time
import logging
import os

logger = logging.getLogger(__name__)

PRIMARY_LLM  = "gemini-2.5-flash"
FALLBACK_LLM = "gemini-2.5-flash-lite"
EMBEDDING_MODEL = "text-embedding-005"

# Sentinel returned when all LLM calls fail
LLM_UNAVAILABLE = "__LLM_UNAVAILABLE__"

# Sentinel returned when embedding generation fails
EMBEDDING_UNAVAILABLE = None

# Retry config for 429 Too Many Requests
_MAX_RETRIES    = 4
_BASE_DELAY     = 5.0
_BACKOFF_FACTOR = 2.0


def _is_rate_limit(exc: Exception) -> bool:
    msg = str(exc).lower()
    return "429" in msg or "resource_exhausted" in msg or "rate" in msg or "quota" in msg


def _get_vertex_config() -> tuple[str, str]:
    """Return (project_id, location) from env / settings."""
    from config.database import settings as db_settings
    project  = getattr(db_settings, "VERTEX_PROJECT", "") or os.getenv("VERTEX_PROJECT", "")
    location = getattr(db_settings, "VERTEX_LOCATION", "") or os.getenv("VERTEX_LOCATION", "us-central1")
    return project, location


def _init_vertexai():
    import vertexai
    project, location = _get_vertex_config()
    vertexai.init(project=project, location=location)


def invoke_llm(prompt: str, max_tokens: int = 2048, json_mode: bool = False) -> str:
    """
    Invoke Gemini via Vertex AI with automatic fallback to the -001 model.
    Retries up to _MAX_RETRIES times with exponential backoff on 429 errors.
    Returns LLM_UNAVAILABLE if all models and retries are exhausted.
    """
    if json_mode:
        prompt = (
            prompt.rstrip()
            + "\n\nIMPORTANT: Respond with ONLY valid JSON. No markdown, no code fences, no explanation."
        )

    try:
        _init_vertexai()
        from vertexai.generative_models import GenerativeModel, GenerationConfig
    except Exception as exc:
        logger.error("Failed to initialise Vertex AI: %s", exc)
        return LLM_UNAVAILABLE

    gen_config = GenerationConfig(max_output_tokens=max_tokens)

    for model_id in (PRIMARY_LLM, FALLBACK_LLM):
        delay = _BASE_DELAY
        for attempt in range(1, _MAX_RETRIES + 1):
            try:
                model = GenerativeModel(model_id)
                response = model.generate_content(prompt, generation_config=gen_config)

                # Safely extract text — response.text raises ValueError when
                # finish_reason is MAX_TOKENS and no content parts were emitted.
                try:
                    text = response.text or ""
                except (ValueError, AttributeError):
                    try:
                        parts = response.candidates[0].content.parts or []
                        text = "".join(getattr(p, "text", "") for p in parts).strip()
                    except Exception:
                        text = ""
                    if not text:
                        try:
                            finish = response.candidates[0].finish_reason.name
                        except Exception:
                            finish = "UNKNOWN"
                        logger.warning(
                            "Model %s returned no text (finish_reason=%s, attempt %d). "
                            "Increase max_tokens for this call.",
                            model_id, finish, attempt,
                        )
                        break  # try next model

                if json_mode:
                    text = text.strip()
                    if text.startswith("```"):
                        text = text.split("\n", 1)[-1]
                    if text.endswith("```"):
                        text = text.rsplit("```", 1)[0]
                    text = text.strip()

                logger.info("LLM response via model=%s (attempt %d)", model_id, attempt)
                return text

            except Exception as exc:
                if _is_rate_limit(exc) and attempt < _MAX_RETRIES:
                    logger.warning(
                        "Model %s rate-limited (attempt %d/%d) — retrying in %.0fs.",
                        model_id, attempt, _MAX_RETRIES, delay,
                    )
                    time.sleep(delay)
                    delay *= _BACKOFF_FACTOR
                else:
                    logger.warning("Model %s failed (attempt %d): %s — moving on.", model_id, attempt, exc)
                    break

    logger.error("All Vertex AI models exhausted. Returning unavailability sentinel.")
    return LLM_UNAVAILABLE


def get_embedding(text: str) -> list:
    """
    Get a vector embedding via Vertex AI text-embedding-005.
    Retries on 429 with exponential backoff.
    Returns EMBEDDING_UNAVAILABLE sentinel on failure.
    """
    try:
        _init_vertexai()
        from vertexai.language_models import TextEmbeddingModel
    except Exception as exc:
        logger.error("Failed to initialise Vertex AI for embeddings: %s", exc)
        return EMBEDDING_UNAVAILABLE

    delay = _BASE_DELAY
    for attempt in range(1, _MAX_RETRIES + 1):
        try:
            model = TextEmbeddingModel.from_pretrained(EMBEDDING_MODEL)
            embeddings = model.get_embeddings([text[:8000]])
            return embeddings[0].values

        except Exception as exc:
            if _is_rate_limit(exc) and attempt < _MAX_RETRIES:
                logger.warning(
                    "Embedding rate-limited (attempt %d/%d) — retrying in %.0fs.",
                    attempt, _MAX_RETRIES, delay,
                )
                time.sleep(delay)
                delay *= _BACKOFF_FACTOR
            else:
                logger.warning("Vertex AI embedding failed (attempt %d): %s. Returning EMBEDDING_UNAVAILABLE.", attempt, exc)
                return EMBEDDING_UNAVAILABLE

    return EMBEDDING_UNAVAILABLE


def cosine_similarity(v1: list, v2: list) -> float:
    if not v1 or not v2:
        return 0.0
    if len(v1) != len(v2):
        n = max(len(v1), len(v2))
        v1 = v1 + [0.0] * (n - len(v1))
        v2 = v2 + [0.0] * (n - len(v2))
    dot_prod = sum(p * q for p, q in zip(v1, v2))
    mag1 = math.sqrt(sum(p ** 2 for p in v1))
    mag2 = math.sqrt(sum(q ** 2 for q in v2))
    if mag1 == 0 or mag2 == 0:
        return 0.0
    return dot_prod / (mag1 * mag2)