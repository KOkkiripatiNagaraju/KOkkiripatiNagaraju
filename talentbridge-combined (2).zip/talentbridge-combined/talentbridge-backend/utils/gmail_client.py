"""
Gmail API client — replaces the Brevo transactional email integration.

Uses Google OAuth2 with automatic token refresh.
Credentials are read exclusively from environment variables / .env:

    GMAIL_CLIENT_ID
    GMAIL_CLIENT_SECRET
    GMAIL_REFRESH_TOKEN
    GMAIL_REDIRECT_URI        (default: https://developers.google.com/oauthplayground)
    GMAIL_SENDER_EMAIL        (the "From" address, must match the authorised account)
"""

import base64
import datetime
import logging
import os
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from typing import List, Optional

logger = logging.getLogger(__name__)

MAX_RETRIES = 2


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _get_credentials():
    """Build and return a refreshed google.oauth2.credentials.Credentials object."""
    from google.oauth2.credentials import Credentials
    from google.auth.transport.requests import Request

    client_id     = os.getenv("GMAIL_CLIENT_ID", "")
    client_secret = os.getenv("GMAIL_CLIENT_SECRET", "")
    refresh_token = os.getenv("GMAIL_REFRESH_TOKEN", "")
    redirect_uri  = os.getenv("GMAIL_REDIRECT_URI", "https://developers.google.com/oauthplayground")

    if not all([client_id, client_secret, refresh_token]):
        raise EnvironmentError(
            "Gmail OAuth2 credentials are incomplete. "
            "Set GMAIL_CLIENT_ID, GMAIL_CLIENT_SECRET, and GMAIL_REFRESH_TOKEN in your .env file."
        )

    creds = Credentials(
        token=None,
        refresh_token=refresh_token,
        token_uri="https://oauth2.googleapis.com/token",
        client_id=client_id,
        client_secret=client_secret,
        scopes=["https://www.googleapis.com/auth/gmail.send"],
    )
    creds.refresh(Request())
    return creds


def _build_service():
    """Return an authorised Gmail API service resource."""
    from googleapiclient.discovery import build
    creds = _get_credentials()
    return build("gmail", "v1", credentials=creds, cache_discovery=False)


def _build_message(
    sender: str,
    to_email: str,
    to_name: str,
    subject: str,
    html_content: str,
    plain_text: Optional[str] = None,
    cc: Optional[List[str]] = None,
    bcc: Optional[List[str]] = None,
    reply_to: Optional[str] = None,
    attachments: Optional[List[dict]] = None,
) -> dict:
    """
    Construct a base64url-encoded RFC 2822 message dict ready for the Gmail API.

    attachments: list of {"filename": str, "content": bytes, "mime_type": str}
    """
    msg = MIMEMultipart("alternative") if not attachments else MIMEMultipart("mixed")

    msg["From"]    = f"{to_name} Recruitment <{sender}>" if not attachments else sender
    msg["To"]      = f"{to_name} <{to_email}>"
    msg["Subject"] = subject

    if cc:
        msg["Cc"] = ", ".join(cc)
    if bcc:
        msg["Bcc"] = ", ".join(bcc)
    if reply_to:
        msg["Reply-To"] = reply_to

    # Body parts
    alt_part = MIMEMultipart("alternative") if attachments else msg
    if plain_text:
        alt_part.attach(MIMEText(plain_text, "plain", "utf-8"))
    alt_part.attach(MIMEText(html_content, "html", "utf-8"))

    if attachments:
        msg.attach(alt_part)
        for att in (attachments or []):
            part = MIMEBase(*att.get("mime_type", "application/octet-stream").split("/", 1))
            part.set_payload(att["content"])
            encoders.encode_base64(part)
            part.add_header("Content-Disposition", "attachment", filename=att["filename"])
            msg.attach(part)

    raw = base64.urlsafe_b64encode(msg.as_bytes()).decode("utf-8")
    return {"raw": raw}


# ---------------------------------------------------------------------------
# Public API — drop-in replacement for brevo_client functions
# ---------------------------------------------------------------------------

def log_to_mock_emails(
    to_email: str,
    to_name: str,
    subject: str,
    body: str,
    source: str = "Recruitment flow",
) -> None:
    """Append an email record to mock_emails.txt (development / offline use)."""
    try:
        with open("mock_emails.txt", "a", encoding="utf-8") as f:
            f.write("=" * 50 + "\n")
            f.write(f"Timestamp : {datetime.datetime.utcnow().isoformat()} UTC\n")
            f.write(f"Source    : {source}\n")
            f.write(f"To        : {to_name} <{to_email}>\n")
            f.write(f"Subject   : {subject}\n")
            f.write(f"Body      :\n{body}\n")
            f.write("=" * 50 + "\n\n")
    except Exception as exc:
        logger.error("Failed to write to mock_emails.txt: %s", exc)


def send_gmail_email(
    to_email: str,
    to_name: str,
    subject: str,
    html_content: str,
    plain_text: Optional[str] = None,
    reply_to: Optional[str] = None,
    cc: Optional[List[str]] = None,
    bcc: Optional[List[str]] = None,
    attachments: Optional[List[dict]] = None,
) -> bool:
    """
    Send an email via the Gmail API.

    Returns True on success, False on failure.

    Parameters
    ----------
    to_email      : Recipient address.
    to_name       : Recipient display name.
    subject       : Email subject line.
    html_content  : Full HTML body.
    plain_text    : Optional plain-text fallback (auto-generated if omitted).
    reply_to      : Optional Reply-To address.
    cc            : Optional list of CC addresses.
    bcc           : Optional list of BCC addresses.
    attachments   : Optional list of dicts:
                    {"filename": str, "content": bytes, "mime_type": str}
    """
    sender_email = os.getenv("GMAIL_SENDER_EMAIL", "")
    if not sender_email:
        logger.error("Gmail: GMAIL_SENDER_EMAIL is not set.")
        return False

    # Graceful fallback: if OAuth creds are missing, log locally instead of crashing.
    client_id = os.getenv("GMAIL_CLIENT_ID", "")
    if not client_id:
        logger.warning("Gmail credentials not configured — logging email locally.")
        log_to_mock_emails(to_email, to_name, subject, html_content, source="Gmail fallback")
        return False

    for attempt in range(1, MAX_RETRIES + 1):
        try:
            service = _build_service()
            message  = _build_message(
                sender=sender_email,
                to_email=to_email,
                to_name=to_name,
                subject=subject,
                html_content=html_content,
                plain_text=plain_text,
                cc=cc,
                bcc=bcc,
                reply_to=reply_to,
                attachments=attachments,
            )
            result = service.users().messages().send(userId="me", body=message).execute()
            logger.info(
                "Gmail: email sent to %s — message_id=%s (attempt %d)",
                to_email, result.get("id"), attempt,
            )
            return True

        except Exception as exc:
            logger.warning(
                "Gmail: send attempt %d/%d failed for %s: %s",
                attempt, MAX_RETRIES, to_email, exc,
            )
            if attempt == MAX_RETRIES:
                logger.error("Gmail: all %d attempts exhausted for %s.", MAX_RETRIES, to_email)
                return False

    return False


# ---------------------------------------------------------------------------
# Interview invitation — dedicated helper used by the scheduling endpoint
# ---------------------------------------------------------------------------

def send_interview_invitation(
    to_email: str,
    candidate_name: str,
    job_title: str,
    company_name: str,
    interview_date: str,
    interview_time: str,
    timezone_label: str,
    interview_mode: str,
    meeting_platform: str,
    join_link: str,
) -> bool:
    """
    Send a styled interview invitation email to a candidate.

    All parameters are strings — the caller is responsible for formatting
    dates/times before passing them in.
    """
    subject = f"Interview Invitation — {job_title} at {company_name}"

    html_body = _build_interview_invitation_html(
        candidate_name=candidate_name,
        job_title=job_title,
        company_name=company_name,
        interview_date=interview_date,
        interview_time=interview_time,
        timezone_label=timezone_label,
        interview_mode=interview_mode,
        meeting_platform=meeting_platform,
        join_link=join_link,
    )

    plain_body = (
        f"Dear {candidate_name},\n\n"
        f"Congratulations! You have been shortlisted for the position of {job_title} at {company_name}.\n\n"
        f"Interview Details\n"
        f"-----------------\n"
        f"Position   : {job_title}\n"
        f"Company    : {company_name}\n"
        f"Date       : {interview_date}\n"
        f"Time       : {interview_time} {timezone_label}\n"
        f"Mode       : {interview_mode}\n"
        f"Platform   : {meeting_platform}\n"
        f"Join Link  : {join_link}\n\n"
        f"Please join 5–10 minutes before the scheduled time.\n\n"
        f"We wish you all the best!\n\n"
        f"Best regards,\n"
        f"HR Team — {company_name}\n\n"
        f"---\n"
        f"This is an automated email generated by the TalentBridge AI Hiring Platform. "
        f"Please do not reply to this email."
    )

    return send_gmail_email(
        to_email=to_email,
        to_name=candidate_name,
        subject=subject,
        html_content=html_body,
        plain_text=plain_body,
    )


def _build_interview_invitation_html(
    candidate_name: str,
    job_title: str,
    company_name: str,
    interview_date: str,
    interview_time: str,
    timezone_label: str,
    interview_mode: str,
    meeting_platform: str,
    join_link: str,
) -> str:
    """Return a clean, modern, responsive HTML interview invitation."""
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>Interview Invitation</title>
<!--[if mso]>
<noscript><xml><o:OfficeDocumentSettings><o:PixelsPerInch>96</o:PixelsPerInch></o:OfficeDocumentSettings></xml></noscript>
<![endif]-->
<style>
  /* Reset */
  * {{ margin: 0; padding: 0; box-sizing: border-box; }}
  body {{ background-color: #f4f6fb; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; color: #1a202c; }}
  a {{ color: inherit; text-decoration: none; }}

  /* Wrapper */
  .email-wrapper {{ max-width: 620px; margin: 40px auto; background: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 24px rgba(0,0,0,0.08); }}

  /* Header */
  .email-header {{ background: linear-gradient(135deg, #1a56db 0%, #0e3fa8 100%); padding: 40px 48px; text-align: center; }}
  .email-header .brand {{ color: #ffffff; font-size: 22px; font-weight: 700; letter-spacing: 0.5px; }}
  .email-header .brand span {{ color: #93c5fd; }}
  .email-header .tagline {{ color: rgba(255,255,255,0.75); font-size: 13px; margin-top: 4px; }}

  /* Body */
  .email-body {{ padding: 40px 48px; }}
  .greeting {{ font-size: 20px; font-weight: 600; color: #1a202c; margin-bottom: 12px; }}
  .intro-text {{ font-size: 15px; line-height: 1.7; color: #4a5568; margin-bottom: 28px; }}
  .intro-text strong {{ color: #1a56db; }}

  /* Schedule card */
  .schedule-card {{ background: #f0f5ff; border: 1px solid #c3d8fc; border-left: 4px solid #1a56db; border-radius: 10px; padding: 28px 32px; margin-bottom: 32px; }}
  .schedule-card h3 {{ font-size: 14px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.8px; color: #1a56db; margin-bottom: 20px; }}
  .detail-row {{ display: flex; align-items: flex-start; gap: 12px; margin-bottom: 14px; }}
  .detail-row:last-child {{ margin-bottom: 0; }}
  .detail-icon {{ width: 20px; text-align: center; flex-shrink: 0; margin-top: 1px; }}
  .detail-label {{ font-size: 12px; color: #718096; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; display: block; }}
  .detail-value {{ font-size: 15px; color: #1a202c; font-weight: 500; display: block; margin-top: 1px; }}

  /* CTA button */
  .cta-wrapper {{ text-align: center; margin: 32px 0 20px; }}
  .cta-button {{ display: inline-block; background: linear-gradient(135deg, #1a56db 0%, #0e3fa8 100%); color: #ffffff !important; font-size: 16px; font-weight: 700; padding: 16px 48px; border-radius: 8px; text-decoration: none; letter-spacing: 0.3px; box-shadow: 0 4px 14px rgba(26,86,219,0.35); }}
  .cta-fallback {{ text-align: center; font-size: 13px; color: #718096; margin-top: 12px; word-break: break-all; }}
  .cta-fallback a {{ color: #1a56db; text-decoration: underline; }}

  /* Note */
  .reminder-note {{ background: #fffbeb; border: 1px solid #fcd34d; border-radius: 8px; padding: 14px 18px; font-size: 14px; color: #92400e; margin-bottom: 28px; line-height: 1.6; }}
  .reminder-note strong {{ color: #78350f; }}

  /* Closing */
  .closing {{ font-size: 15px; line-height: 1.7; color: #4a5568; margin-bottom: 32px; }}

  /* Footer */
  .email-footer {{ background: #f7fafc; border-top: 1px solid #e2e8f0; padding: 28px 48px; text-align: center; }}
  .footer-company {{ font-size: 15px; font-weight: 700; color: #2d3748; margin-bottom: 4px; }}
  .footer-team {{ font-size: 13px; color: #718096; margin-bottom: 12px; }}
  .footer-divider {{ border: none; border-top: 1px solid #e2e8f0; margin: 12px 0; }}
  .footer-copyright {{ font-size: 12px; color: #a0aec0; margin-bottom: 8px; }}
  .footer-disclaimer {{ font-size: 11px; color: #b0bec5; line-height: 1.6; font-style: italic; }}

  @media only screen and (max-width: 640px) {{
    .email-body, .email-header, .email-footer {{ padding: 28px 24px; }}
    .cta-button {{ padding: 14px 32px; font-size: 15px; }}
    .detail-row {{ flex-direction: column; gap: 4px; }}
  }}
</style>
</head>
<body>
<div class="email-wrapper">

  <!-- Header -->
  <div class="email-header">
    <div class="brand">Talent<span>Bridge</span></div>
    <div class="tagline">AI-Powered Hiring Platform</div>
  </div>

  <!-- Body -->
  <div class="email-body">
    <p class="greeting">Dear {candidate_name},</p>
    <p class="intro-text">
      Congratulations! We are pleased to inform you that you have been
      <strong>shortlisted for an interview</strong> for the position of
      <strong>{job_title}</strong> at <strong>{company_name}</strong>.
      We were impressed with your profile and look forward to speaking with you.
    </p>

    <!-- Schedule card -->
    <div class="schedule-card">
      <h3>&#128197; Interview Schedule</h3>

      <div class="detail-row">
        <div class="detail-icon">&#128188;</div>
        <div>
          <span class="detail-label">Position</span>
          <span class="detail-value">{job_title}</span>
        </div>
      </div>

      <div class="detail-row">
        <div class="detail-icon">&#127970;</div>
        <div>
          <span class="detail-label">Company</span>
          <span class="detail-value">{company_name}</span>
        </div>
      </div>

      <div class="detail-row">
        <div class="detail-icon">&#128197;</div>
        <div>
          <span class="detail-label">Date</span>
          <span class="detail-value">{interview_date}</span>
        </div>
      </div>

      <div class="detail-row">
        <div class="detail-icon">&#128336;</div>
        <div>
          <span class="detail-label">Time</span>
          <span class="detail-value">{interview_time} {timezone_label}</span>
        </div>
      </div>

      <div class="detail-row">
        <div class="detail-icon">&#128187;</div>
        <div>
          <span class="detail-label">Mode</span>
          <span class="detail-value">{interview_mode}</span>
        </div>
      </div>

      <div class="detail-row">
        <div class="detail-icon">&#128222;</div>
        <div>
          <span class="detail-label">Platform</span>
          <span class="detail-value">{meeting_platform}</span>
        </div>
      </div>
    </div>

    <!-- CTA -->
    <div class="cta-wrapper">
      <a href="{join_link}" class="cta-button" target="_blank">
        &#128249; &nbsp; Join Interview
      </a>
    </div>
    <p class="cta-fallback">
      Button not working? Copy and paste this link into your browser:<br/>
      <a href="{join_link}">{join_link}</a>
    </p>

    <!-- Reminder -->
    <div class="reminder-note">
      &#9200; <strong>Please join 5–10 minutes before</strong> the scheduled time to ensure
      a smooth start. Make sure your camera and microphone are working beforehand.
    </div>

    <!-- Closing -->
    <p class="closing">
      We wish you all the best for your interview. If you have any questions regarding
      the schedule, please contact your HR representative directly.<br/><br/>
      Warm regards,<br/>
      <strong>HR Team — {company_name}</strong>
    </p>
  </div>

  <!-- Footer -->
  <div class="email-footer">
    <p class="footer-company">{company_name}</p>
    <p class="footer-team">Human Resources Team</p>
    <hr class="footer-divider"/>
    <p class="footer-copyright">&copy; {datetime.datetime.utcnow().year} {company_name}. All rights reserved.</p>
    <p class="footer-disclaimer">
      This is an automated email generated by the TalentBridge AI Hiring Platform.
      Please do not reply to this email.
    </p>
  </div>

</div>
</body>
</html>"""
