"""
GCS storage — mirrors aws_s3.py function signatures exactly.
All callers that import from aws_s3 get this via the thin wrapper.
Falls back to local filesystem when GCS_BUCKET_NAME is not set.
"""
import uuid
import logging
import os
from pathlib import Path
from datetime import timedelta

from config.database import settings

logger = logging.getLogger(__name__)

LOCAL_FALLBACK_DIR = Path("storage/uploads")


def _get_gcs_client():
    from google.cloud import storage as gcs
    return gcs.Client()


def _bucket_name() -> str:
    return getattr(settings, "GCS_BUCKET_NAME", "") or os.getenv("GCS_BUCKET_NAME", "")


def upload_to_s3(file_bytes: bytes, filename: str) -> str:
    """
    Upload bytes to GCS (or local fallback). Returns the storage key on success.
    Signature is identical to the old upload_to_s3() so no callers change.
    """
    unique_id = uuid.uuid4().hex
    safe_filename = "".join(c for c in filename if c.isalnum() or c in (".", "_", "-"))
    key = f"resumes/{unique_id}_{safe_filename}"

    bucket_name = _bucket_name()
    if bucket_name:
        try:
            client = _get_gcs_client()
            bucket = client.bucket(bucket_name)
            blob = bucket.blob(key)
            blob.upload_from_string(file_bytes, content_type=_guess_content_type(safe_filename))
            logger.info("Uploaded resume to gs://%s/%s", bucket_name, key)
            return key
        except Exception as exc:
            logger.warning("GCS upload failed: %s — falling back to local storage.", exc)

    # Local fallback
    LOCAL_FALLBACK_DIR.mkdir(parents=True, exist_ok=True)
    local_path = LOCAL_FALLBACK_DIR / key.replace("/", "_")
    local_path.write_bytes(file_bytes)
    logger.info("Stored resume locally at %s", local_path)
    return key


def generate_presigned_download_url(key: str, expires_in_seconds: int = 3600) -> str:
    """
    Generate a signed download URL for a stored file.
    Signature identical to the old generate_presigned_download_url().
    """
    bucket_name = _bucket_name()
    if bucket_name:
        try:
            client = _get_gcs_client()
            bucket = client.bucket(bucket_name)
            blob = bucket.blob(key)
            url = blob.generate_signed_url(
                expiration=timedelta(seconds=expires_in_seconds),
                method="GET",
                version="v4",
            )
            return url
        except Exception as exc:
            logger.warning("GCS signed URL failed: %s — returning local path.", exc)

    # Local fallback: return a path indicator (caller handles display)
    local_path = LOCAL_FALLBACK_DIR / key.replace("/", "_")
    return f"local://{local_path}"


def _guess_content_type(filename: str) -> str:
    ext = filename.rsplit(".", 1)[-1].lower()
    return {
        "pdf":  "application/pdf",
        "docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "doc":  "application/msword",
        "txt":  "text/plain",
    }.get(ext, "application/octet-stream")
