"""
Removed — all AWS/Bedrock code has been replaced with Google Gemini (GCP).
This file is kept only so any lingering import doesn't cause an ImportError;
it immediately re-exports from utils.llm_client.

DO NOT add any new imports from this file. Use utils.llm_client directly.
"""
from utils.llm_client import (  # noqa: F401
    invoke_llm,
    get_embedding,
    cosine_similarity,
    LLM_UNAVAILABLE,
    PRIMARY_LLM,
    FALLBACK_LLM,
    EMBEDDING_MODEL,
)

# Legacy aliases kept only for safety — no code should use these names any more
invoke_llama3      = invoke_llm        # noqa: F401
get_titan_embedding = get_embedding    # noqa: F401
BEDROCK_UNAVAILABLE = LLM_UNAVAILABLE  # noqa: F401
