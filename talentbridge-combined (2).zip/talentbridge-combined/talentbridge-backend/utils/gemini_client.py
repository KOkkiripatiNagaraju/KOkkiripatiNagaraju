"""
Compatibility re-export — all symbols now live in utils.llm_client.
Import from utils.llm_client directly in new code.
"""
from utils.llm_client import (  # noqa: F401
    invoke_llm,
    get_embedding,
    cosine_similarity,
    LLM_UNAVAILABLE,
    PRIMARY_LLM,
    FALLBACK_LLM,
    EMBEDDING_MODEL,
)
