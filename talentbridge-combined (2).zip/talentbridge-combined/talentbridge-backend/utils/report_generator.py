import logging
from io import BytesIO
from datetime import datetime

from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

logger = logging.getLogger(__name__)


def generate_pdf_report(candidate_name: str, data: dict) -> bytes:
    """
    Generate a well-formatted PDF hiring assessment report.

    Args:
        candidate_name: Candidate's full name.
        data:           Key-value dict of evaluation metrics.

    Returns:
        PDF bytes.
    """
    buffer = BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=letter,
        rightMargin=0.75 * inch,
        leftMargin=0.75 * inch,
        topMargin=1 * inch,
        bottomMargin=0.75 * inch,
    )
    styles = getSampleStyleSheet()

    title_style = ParagraphStyle(
        "CustomTitle",
        parent=styles["Title"],
        fontSize=20,
        spaceAfter=6,
        textColor=colors.HexColor("#1a1a2e"),
    )
    subtitle_style = ParagraphStyle(
        "Subtitle",
        parent=styles["Normal"],
        fontSize=11,
        textColor=colors.HexColor("#555555"),
        spaceAfter=18,
    )
    section_style = ParagraphStyle(
        "SectionHeader",
        parent=styles["Heading2"],
        fontSize=13,
        textColor=colors.HexColor("#16213e"),
        spaceBefore=12,
        spaceAfter=6,
    )

    story = []

    # Header
    story.append(Paragraph("AI Recruitment Hub", styles["Heading3"]))
    story.append(Paragraph(f"Hiring Assessment Report", title_style))
    story.append(Paragraph(f"Candidate: {candidate_name}", subtitle_style))
    story.append(Paragraph(f"Generated: {datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}", subtitle_style))
    story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#cccccc")))
    story.append(Spacer(1, 12))

    # Scores table
    story.append(Paragraph("Evaluation Scores", section_style))

    score_keys = [
        "skills_match", "experience_match", "project_relevance",
        "education_score", "certification_score", "semantic_similarity", "total_score"
    ]
    table_data = [["Metric", "Score (%)"]]
    for key in score_keys:
        if key in data:
            label = key.replace("_", " ").title()
            val = data[key]
            table_data.append([label, f"{val:.2f}" if isinstance(val, float) else str(val)])

    if len(table_data) > 1:
        tbl = Table(table_data, colWidths=[3.5 * inch, 1.5 * inch])
        tbl.setStyle(TableStyle([
            ("BACKGROUND",  (0, 0), (-1, 0), colors.HexColor("#16213e")),
            ("TEXTCOLOR",   (0, 0), (-1, 0), colors.white),
            ("FONTNAME",    (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTSIZE",    (0, 0), (-1, 0), 11),
            ("ALIGN",       (1, 0), (1, -1), "CENTER"),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.HexColor("#f5f5f5"), colors.white]),
            ("GRID",        (0, 0), (-1, -1), 0.5, colors.HexColor("#cccccc")),
            ("TOPPADDING",  (0, 0), (-1, -1), 6),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
            ("LEFTPADDING", (0, 0), (-1, -1), 8),
        ]))
        story.append(tbl)
        story.append(Spacer(1, 14))

    # Verdict
    if "ai_verdict" in data or "verdict" in data:
        story.append(Paragraph("AI Recommendation", section_style))
        verdict = data.get("ai_verdict") or data.get("verdict", "—")
        rating = data.get("ai_rating") or data.get("total_score", "—")
        justification = data.get("ai_justification") or data.get("justification", "")

        story.append(Paragraph(f"<b>Verdict:</b> {verdict}  |  <b>AI Rating:</b> {rating}%", styles["Normal"]))
        story.append(Spacer(1, 6))
        if justification:
            story.append(Paragraph(justification, styles["Normal"]))
        story.append(Spacer(1, 12))

    # Strengths and gaps
    for section_key, section_label in [("strengths", "Strengths"), ("skill_gaps", "Skill Gaps")]:
        items = data.get(section_key)
        if items and isinstance(items, list):
            story.append(Paragraph(section_label, section_style))
            for item in items:
                story.append(Paragraph(f"• {item}", styles["Normal"]))
            story.append(Spacer(1, 8))

    # Recommendation text
    if "recommendation" in data and data["recommendation"]:
        story.append(Paragraph("Summary Recommendation", section_style))
        story.append(Paragraph(str(data["recommendation"]), styles["Normal"]))

    doc.build(story)
    return buffer.getvalue()


def generate_excel_report(candidate_name: str, data: dict) -> bytes:
    """
    Generate a styled Excel evaluation report.
    """
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Evaluation Report"

    header_font = Font(name="Calibri", bold=True, color="FFFFFF", size=12)
    header_fill = PatternFill(start_color="16213E", end_color="16213E", fill_type="solid")
    header_border = Border(bottom=Side(style="medium", color="CCCCCC"))
    center_align = Alignment(horizontal="center", vertical="center")
    thin_border = Border(
        left=Side(style="thin", color="CCCCCC"),
        right=Side(style="thin", color="CCCCCC"),
        top=Side(style="thin", color="CCCCCC"),
        bottom=Side(style="thin", color="CCCCCC"),
    )

    # Title row
    ws.merge_cells("A1:C1")
    title_cell = ws["A1"]
    title_cell.value = f"Hiring Assessment — {candidate_name}"
    title_cell.font = Font(name="Calibri", bold=True, size=14, color="1A1A2E")
    title_cell.alignment = center_align

    ws.append([])  # spacer

    # Header row
    headers = ["Evaluation Metric", "Value", "Notes"]
    ws.append(headers)
    for col_num, header in enumerate(headers, start=1):
        cell = ws.cell(row=3, column=col_num)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = center_align
        cell.border = header_border

    # Data rows
    alt_fill = PatternFill(start_color="F5F5F5", end_color="F5F5F5", fill_type="solid")
    row_idx = 4
    for key, val in data.items():
        if isinstance(val, list):
            val = ", ".join(str(v) for v in val)
        label = key.replace("_", " ").title()
        ws.cell(row=row_idx, column=1, value=label).border = thin_border
        ws.cell(row=row_idx, column=2, value=str(val)).border = thin_border
        ws.cell(row=row_idx, column=3, value="").border = thin_border

        if row_idx % 2 == 0:
            for col in range(1, 4):
                ws.cell(row=row_idx, column=col).fill = alt_fill

        row_idx += 1

    # Column widths
    ws.column_dimensions["A"].width = 32
    ws.column_dimensions["B"].width = 28
    ws.column_dimensions["C"].width = 20

    buffer = BytesIO()
    wb.save(buffer)
    return buffer.getvalue()