# AI Recruitment System — GCP Edition

Migrated from AWS Bedrock + S3 to **Google Gemini API + Google Cloud Storage**.  
Docker setup and all application logic are unchanged from the original.

---

## API Keys Required

### 1. Gemini API Key (required — LLM + embeddings)

**What it does:** Powers resume parsing, ATS scoring, semantic job matching, interview question generation, email drafting, HR policy generation, sentiment analysis, and exit interview reports.

**How to get it (free, no credit card):**
1. Go to **https://aistudio.google.com/apikey**
2. Sign in with your Google account
3. Click **Create API key**
4. Copy the key

**Where to put it in `.env`:**
```
GEMINI_API_KEY=AIzaSy...your_key_here
```

**Free tier limits:** ~1,500 requests/day, 10 RPM (Gemini 2.0 Flash)

---

### 2. Google Application Credentials (optional — only needed for GCS)

**What it does:** Allows the app to read/write files to Google Cloud Storage (resume uploads, offer letter PDFs, pulse survey backups). If you leave `GCS_BUCKET_NAME` blank, the app uses local filesystem storage instead — no credentials needed.

**How to get it:**
1. Go to **https://console.cloud.google.com/iam-admin/serviceaccounts**
2. Create a service account with the **Storage Object Admin** role on your bucket
3. Click the service account → **Keys** → **Add Key** → **JSON**
4. Download the JSON file and place it somewhere on your machine (e.g. `./gcp-key.json`)

**Where to put it in `.env`:**
```
GCS_BUCKET_NAME=your-bucket-name
GOOGLE_APPLICATION_CREDENTIALS=/run/secrets/gcp_sa_key.json
```

Also mount the key file into the Docker container by adding this to `docker-compose.yml` under the `web` service:
```yaml
volumes:
  - ./gcp-key.json:/run/secrets/gcp_sa_key.json:ro
environment:
  - GOOGLE_APPLICATION_CREDENTIALS=/run/secrets/gcp_sa_key.json
```

**If you skip GCS:** Leave `GCS_BUCKET_NAME=` blank. All files (resumes, PDFs, backups) are stored in the `storage/` folder inside the container. This is fine for local development and testing.

---

### 3. Brevo API Key (optional — email notifications)

**What it does:** Sends offer letter emails, interview invitations, and candidate notifications.

**How to get it (free tier: 300 emails/day):**
1. Sign up at **https://app.brevo.com**
2. Go to **Profile → SMTP & API → API Keys**
3. Click **Generate a new API key**

**Where to put it in `.env`:**
```
BREVO_API_KEY=xkeysib-...your_key_here
BREVO_SENDER_EMAIL=noreply@yourdomain.com
```

To disable email (log-only mode), set:
```
EMAIL_PROVIDER=local
```

---

## Quick Start

```bash
# 1. Add your Gemini API key to .env
# 2. Create the external Docker volume (first time only)
docker volume create ai-recruitment-system-copy2_postgres_data

# 3. Build and start
docker compose up -d --build

# 4. Seed the database
docker compose exec web python seed.py
```

Open:
- Recruiter portal: http://localhost:8501 — `recruiter@company.com` / `password123`
- Candidate portal: http://localhost:8502
- API docs: http://localhost:8000/docs

---

## Environment Variables Reference

| Variable | Required | Description |
|---|---|---|
| `GEMINI_API_KEY` | **Yes** | Gemini API key from aistudio.google.com |
| `GCS_BUCKET_NAME` | No | GCS bucket for file storage (blank = local) |
| `GOOGLE_APPLICATION_CREDENTIALS` | No | Path to GCP service account JSON (only if using GCS) |
| `BREVO_API_KEY` | No | Brevo key for email sending |
| `BREVO_SENDER_EMAIL` | No | Verified sender email in Brevo |
| `MOCK_AWS` | No | `false` = use real Gemini; `true` = local mocks |
| `DATABASE_URL` | Yes | Postgres connection string |
| `JWT_SECRET` | Yes | Random string for JWT signing |
| `STORAGE_PROVIDER` | No | `local` (default) or `gcs` |

