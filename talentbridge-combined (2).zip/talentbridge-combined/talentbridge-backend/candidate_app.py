import os
import requests
import streamlit as st
from datetime import datetime

# Set page config
st.set_page_config(
    page_title="Jobs | AI CareerHub",
    page_icon="💼",
    layout="wide",
    initial_sidebar_state="collapsed",
)

# API configuration
BASE_URL = os.environ.get("BASE_URL", "http://localhost:8000/api")
COMPANY_EMAIL_DOMAIN = os.environ.get("COMPANY_EMAIL_DOMAIN", "company.com").strip().lower()
# Public URLs — override these with your deployed domain in production
EMPLOYEE_PORTAL_URL = os.environ.get("EMPLOYEE_PORTAL_URL", "http://localhost:8501")

# Custom CSS for exact visual parity and high-contrast light mode styling
st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Segoe+UI:wght@300;400;600;700&display=swap');
    
    html, body {
        font-family: 'Segoe UI', system-ui, -apple-system, sans-serif !important;
    }
    
    /* Background - LinkedIn light grey */
    .stApp, .main, [data-testid="stMainViewContainer"], [data-testid="stAppViewContainer"] {
        background-color: #f3f2ef !important;
        color: #191919 !important;
    }
    
    /* LinkedIn Header Bar */
    .linkedin-hdr {
        background-color: #ffffff;
        border-bottom: 1px solid #e0e0e0;
        padding: 10px 40px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 24px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }
    
    /* Custom Styling for Streamlit Containers to look like LinkedIn cards */
    div[data-testid="stVerticalBlockBorderWrapper"] {
        background-color: #ffffff !important;
        border: 1px solid #e0e0e0 !important; /* Default light border for sidebar/news */
        border-radius: 8px !important;
        padding: 24px !important;
        box-shadow: 0 1px 3px rgba(0,0,0,0.03) !important;
        margin-bottom: 20px !important;
    }
    
    /* Specific styling for Job Posting containers with thin black border */
    div[data-testid="stVerticalBlockBorderWrapper"]:has(.job-card-marker) {
        border: 1px solid #000000 !important; /* Thin black border */
        box-shadow: none !important;
    }
    
    /* Force inputs to be white with grey borders and dark text */
    div[data-baseweb="input"] {
        background-color: #ffffff !important;
        border: 1px solid #b3b3b3 !important;
        border-radius: 4px !important;
        color: #191919 !important;
        box-shadow: none !important;
    }
    
    div[data-baseweb="input"] input {
        color: #191919 !important;
        background-color: #ffffff !important;
        font-size: 0.95rem !important;
    }
    
    /* Override browser autofill color styling */
    input:-webkit-autofill,
    input:-webkit-autofill:hover, 
    input:-webkit-autofill:focus, 
    input:-webkit-autofill:active {
        -webkit-box-shadow: 0 0 0 30px #ffffff inset !important;
        -webkit-text-fill-color: #191919 !important;
    }
    
    /* Placeholder text visibility */
    div[data-baseweb="input"] input::placeholder {
        color: #666666 !important;
        opacity: 0.85 !important;
    }
    
    /* Force visibility toggle eye button to match input background */
    div[data-baseweb="input"] button {
        background-color: transparent !important;
        border: none !important;
        color: #5e5e5e !important;
        box-shadow: none !important;
    }
    div[data-baseweb="input"] button:hover {
        background-color: transparent !important;
    }
    div[data-baseweb="input"] button svg {
        fill: #5e5e5e !important;
    }
    
    /* File uploader custom style and dropzone overrides */
    div[data-testid="stFileUploader"] {
        background-color: #ffffff !important;
        color: #191919 !important;
        margin-bottom: 20px !important;
    }
    div[data-testid="stFileUploader"] [data-testid="stFileUploaderDropzone"] {
        background-color: #ffffff !important;
        border: 1px dashed #b3b3b3 !important;
        border-radius: 8px !important;
        padding: 16px !important;
        display: flex !important;
        flex-direction: column !important;
        align-items: center !important;
        justify-content: center !important;
        gap: 10px !important;
    }
    div[data-testid="stFileUploader"] [data-testid="stFileUploaderDropzoneInstructions"] {
        color: #191919 !important;
    }
    div[data-testid="stFileUploader"] [data-testid="stFileUploaderDropzoneInstructions"] * {
        color: #191919 !important;
        -webkit-text-fill-color: #191919 !important;
    }
    div[data-testid="stFileUploader"] [data-testid="stFileUploaderDropzone"] button {
        background-color: #ffffff !important;
        color: #0a66c2 !important;
        border: 1px solid #0a66c2 !important;
        border-radius: 24px !important;
        padding: 6px 18px !important;
        font-weight: 600 !important;
        font-size: 0.88rem !important;
        display: inline-block !important;
    }
    div[data-testid="stFileUploader"] [data-testid="stFileUploaderDropzone"] button span {
        display: none !important;
    }
    div[data-testid="stFileUploader"] [data-testid="stFileUploaderDropzone"] button::after {
        content: "Upload" !important;
        color: #0a66c2 !important;
        font-weight: 600 !important;
        font-size: 0.88rem !important;
        display: inline-block !important;
    }
    div[data-testid="stFileUploader"] [data-testid="stFileUploaderDropzone"] button:hover {
        background-color: #e8f4fd !important;
        color: #004182 !important;
        border-color: #0a66c2 !important;
    }
    div[data-testid="stFileUploader"] [data-testid="stFileUploaderDropzone"] button:hover::after {
        color: #004182 !important;
    }
    
    /* Checkbox overrides for high-contrast light mode */
    div[data-testid="stCheckbox"] label {
        color: #191919 !important;
    }
    div[data-testid="stCheckbox"] label * {
        color: #191919 !important;
        -webkit-text-fill-color: #191919 !important;
    }
    div[data-testid="stCheckbox"] span {
        color: #191919 !important;
        -webkit-text-fill-color: #191919 !important;
    }
    div[data-testid="stCheckbox"] p {
        color: #191919 !important;
        -webkit-text-fill-color: #191919 !important;
    }
    
    /* Widget labels */
    label[data-testid="stWidgetLabel"] p {
        color: #404040 !important;
        font-size: 0.9rem !important;
        font-weight: 600 !important;
        margin-bottom: 6px !important;
    }
    
    /* Radio options high contrast text */
    div[data-testid="stRadio"] label p {
        color: #191919 !important;
        font-weight: 600 !important;
        font-size: 0.95rem !important;
    }
    
    /* Native buttons styling - default to secondary LinkedIn style */
    div.stButton > button {
        border-radius: 24px !important;
        font-weight: 600 !important;
        font-size: 0.9rem !important;
        padding: 6px 18px !important;
        transition: all 0.15s ease-in-out !important;
        background-color: #ffffff !important;
        color: #0a66c2 !important;
        border: 1px solid #0a66c2 !important;
    }
    div.stButton > button:hover {
        background-color: #e8f4fd !important;
        color: #004182 !important;
        border-color: #0a66c2 !important;
    }
    
    /* Primary buttons (LinkedIn Blue style) */
    div.stButton > button[data-testid="baseButton-primary"],
    div.stButton > button[kind="primary"] {
        background-color: #0a66c2 !important;
        color: #ffffff !important;
        border: 1px solid #0a66c2 !important;
    }
    div.stButton > button[data-testid="baseButton-primary"]:hover,
    div.stButton > button[kind="primary"]:hover {
        background-color: #004182 !important;
        border-color: #004182 !important;
        color: #ffffff !important;
    }
    
    /* Secondary buttons explicit override */
    div.stButton > button[data-testid="baseButton-secondary"],
    div.stButton > button[kind="secondary"] {
        background-color: #ffffff !important;
        color: #0a66c2 !important;
        border: 1px solid #0a66c2 !important;
    }
    div.stButton > button[data-testid="baseButton-secondary"]:hover,
    div.stButton > button[kind="secondary"]:hover {
        background-color: #e8f4fd !important;
        color: #004182 !important;
        border-color: #0a66c2 !important;
    }
    
    /* Custom Profile Card Header */
    .profile-banner {
        background: linear-gradient(to right, #a0b4cd, #708fa8);
        height: 60px;
        border-top-left-radius: 8px;
        border-top-right-radius: 8px;
        margin: -24px -24px 12px -24px;
    }
    
    .profile-avatar {
        width: 64px;
        height: 64px;
        background-color: #0a66c2;
        color: white;
        border: 2px solid white;
        border-radius: 50%;
        margin: -40px auto 8px auto;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.8rem;
        font-weight: bold;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    
    /* Job Card Details styling */
    .li-job-title {
        color: #0a66c2 !important;
        font-size: 1.25rem !important;
        font-weight: 600 !important;
        text-decoration: none !important;
    }
    
    .li-job-meta {
        color: #5e5e5e !important;
        font-size: 0.88rem !important;
        margin: 2px 0 12px 0;
    }
    
    .li-tags {
        display: flex;
        flex-wrap: wrap;
        gap: 6px;
        margin-bottom: 12px;
    }
    
    .li-tag {
        background-color: #f3f2ef;
        color: #5e5e5e;
        padding: 3px 10px;
        border-radius: 12px;
        font-size: 0.78rem;
        font-weight: 500;
        border: 1px solid #e0e0e0;
    }
    
    /* Custom Applied Button */
    .applied-btn {
        background-color: #ffffff !important;
        color: #01754f !important;
        border: 1px solid #01754f !important;
        border-radius: 24px !important;
        font-weight: 600 !important;
        padding: 8px 20px !important;
        font-size: 0.88rem !important;
        cursor: not-allowed;
        display: inline-block;
        text-align: center;
    }
    
    /* News Section */
    .news-title {
        font-size: 0.88rem !important;
        font-weight: 600 !important;
        color: #191919 !important;
        margin-bottom: 2px !important;
    }
    
    .news-meta {
        font-size: 0.75rem !important;
        color: #5e5e5e !important;
        margin-bottom: 8px;
    }
    
    /* Status Badges */
    .badge {
        padding: 4px 10px;
        border-radius: 12px;
        font-weight: 600;
        font-size: 0.78rem;
    }
    .badge-applied { background-color: #e8f4fd; color: #0a66c2; }
    .badge-screening { background-color: #fffbeb; color: #b45309; }
    .badge-shortlisted { background-color: #f0fdf4; color: #16a34a; }
    .badge-interviewing { background-color: #faf5ff; color: #7e22ce; }
    .badge-offered { background-color: #ecfdf5; color: #047857; }
    .badge-rejected { background-color: #fef2f2; color: #b91c1c; }
    
    /* High contrast text for Streamlit alerts in light mode */
    div[data-testid="stAlert"] * {
        color: #191919 !important;
        -webkit-text-fill-color: #191919 !important;
    }

    /* Enforce dark text color for all text elements globally in candidate app */
    .stApp p, .stApp span, .stApp label, .stApp div, .stApp li,
    .stMarkdown, .stMarkdown p, .stMarkdown span,
    [data-testid="stMarkdownContainer"],
    [data-testid="stMarkdownContainer"] p,
    [data-testid="stMarkdownContainer"] span,
    [data-testid="stMarkdownContainer"] li,
    h1, h2, h3, h4, h5, h6 {
        color: #191919 !important;
        -webkit-text-fill-color: #191919 !important;
    }

    /* Dropdown / Popover / Select contrast visibility fixes */
    div[data-baseweb="select"] * {
        color: #191919 !important;
        -webkit-text-fill-color: #191919 !important;
    }
    div[data-baseweb="popover"] {
        background-color: #ffffff !important;
    }
    div[data-baseweb="popover"] * {
        color: #191919 !important;
        -webkit-text-fill-color: #191919 !important;
        background-color: #ffffff !important;
    }
    li[role="option"] {
        background-color: #ffffff !important;
        color: #191919 !important;
    }
    li[role="option"]:hover {
        background-color: #f3f2ef !important;
    }
</style>
""", unsafe_allow_html=True)

# Helper for authorization headers
def get_auth_headers():
    if "auth_token" in st.session_state:
        return {"Authorization": f"Bearer {st.session_state['auth_token']}"}
    return {}

# ── Verhoeff checksum tables ──────────────────────────────────────────────────
_VMULT = [
    [0,1,2,3,4,5,6,7,8,9],[1,2,3,4,0,6,7,8,9,5],[2,3,4,0,1,7,8,9,5,6],
    [3,4,0,1,2,8,9,5,6,7],[4,0,1,2,3,9,5,6,7,8],[5,9,8,7,6,0,4,3,2,1],
    [6,5,9,8,7,1,0,4,3,2],[7,6,5,9,8,2,1,0,4,3],[8,7,6,5,9,3,2,1,0,4],
    [9,8,7,6,5,4,3,2,1,0]
]
_VPERM = [
    [0,1,2,3,4,5,6,7,8,9],[1,5,7,6,2,8,3,0,9,4],[5,8,0,3,7,9,6,1,4,2],
    [8,9,1,6,0,4,3,5,2,7],[9,4,5,3,1,2,6,8,7,0],[4,2,8,6,5,7,3,9,0,1],
    [2,7,9,3,8,0,6,4,1,5],[7,0,4,6,9,1,3,2,5,8]
]

def _validate_aadhaar(num: str) -> bool:
    """Returns True if num is a valid 12-digit Aadhaar number (Verhoeff checksum == 0)."""
    if not num or not num.isdigit() or len(num) != 12:
        return False
    if num[0] in ('0', '1'):   # first digit cannot be 0 or 1 per UIDAI
        return False
    digits = [int(x) for x in reversed(num)]
    c = 0
    for i, d in enumerate(digits):
        c = _VMULT[c][_VPERM[i % 8][d]]
    return c == 0


def generate_offer_letter_pdf(candidate_name, job_title, salary_info="As per approved corporate scale"):
    from reportlab.lib.pagesizes import letter
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib import colors
    import io
    
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter, rightMargin=54, leftMargin=54, topMargin=54, bottomMargin=54)
    styles = getSampleStyleSheet()
    
    title_style = ParagraphStyle(
        'DocTitle',
        parent=styles['Heading1'],
        fontName='Helvetica-Bold',
        fontSize=22,
        leading=26,
        textColor=colors.HexColor('#002a54'),
        alignment=1, # Centered
        spaceAfter=15
    )
    
    body_style = ParagraphStyle(
        'DocBody',
        parent=styles['BodyText'],
        fontName='Helvetica',
        fontSize=10,
        leading=14,
        textColor=colors.HexColor('#333333'),
        spaceAfter=10
    )

    story = []
    story.append(Paragraph("OFFER OF EMPLOYMENT", title_style))
    story.append(Spacer(1, 10))
    
    import datetime
    today_str = datetime.date.today().strftime("%B %d, %Y")
    story.append(Paragraph(f"<b>Date:</b> {today_str}", body_style))
    story.append(Paragraph(f"<b>To:</b> {candidate_name}", body_style))
    story.append(Spacer(1, 10))
    
    story.append(Paragraph(
        f"Dear {candidate_name},<br/><br/>"
        f"We are pleased to extend you an offer of employment for the position of <b>{job_title}</b>. "
        f"Based on your qualifications, experience, and interviews, we believe you will be a valuable addition to our team.",
        body_style
    ))
    
    data = [
        [Paragraph("<b>Position</b>", body_style), Paragraph(job_title, body_style)],
        [Paragraph("<b>Location</b>", body_style), Paragraph("Corporate Office / Remote Hub", body_style)],
        [Paragraph("<b>Employment Type</b>", body_style), Paragraph("Full-Time Permanent", body_style)],
        [Paragraph("<b>Compensation</b>", body_style), Paragraph(salary_info, body_style)],
    ]
    t = Table(data, colWidths=[150, 350])
    t.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), colors.HexColor('#f9fafb')),
        ('BOX', (0,0), (-1,-1), 0.5, colors.HexColor('#d1d5db')),
        ('INNERGRID', (0,0), (-1,-1), 0.5, colors.HexColor('#e5e7eb')),
        ('PADDING', (0,0), (-1,-1), 8),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
    ]))
    story.append(t)
    story.append(Spacer(1, 10))
    
    story.append(Paragraph(
        "<b>Terms & Conditions:</b><br/>"
        "1. <b>Hours of Work:</b> Your hours of work will be defined by corporate guidelines.<br/>"
        "2. <b>Background Verification:</b> This offer is contingent upon successful completion of background verification checks (BGV).<br/>"
        "3. <b>Onboarding Documents:</b> You are required to submit valid copies of Aadhaar, PAN, and a signed copy of this offer letter.<br/>"
        "4. <b>Confidentiality:</b> You agree to protect and keep confidential all corporate and client data.",
        body_style
    ))
    story.append(Spacer(1, 20))
    
    sig_data = [
        [Paragraph("____________________________<br/><b>HR Representative</b><br/>Enterprise Solutions", body_style),
         Paragraph("____________________________<br/><b>Candidate Signature</b><br/>(Accepted & Approved)", body_style)]
    ]
    sig_table = Table(sig_data, colWidths=[250, 250])
    sig_table.setStyle(TableStyle([
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
        ('PADDING', (0,0), (-1,-1), 10),
    ]))
    story.append(sig_table)
    
    doc.build(story)
    pdf_bytes = buffer.getvalue()
    buffer.close()
    return pdf_bytes
def render_offer_letter_view(my_apps, headers):
    offer_app = next((app for app in my_apps if app.get("status") in ["Offered", "Offer Accepted", "Joined", "Offer Rejected"]), None)
    if not offer_app:
        st.info("No active offer found.")
        return

    status = offer_app.get("status")

    if status == "Offer Rejected":
        st.markdown("""
        <div style="background:#fef2f2;border:1px solid #fca5a5;border-radius:10px;
                    padding:24px;text-align:center;margin-top:20px;">
            <div style="font-size:2.5rem;margin-bottom:8px;">❌</div>
            <h4 style="color:#b91c1c;margin:0 0 8px 0;">Offer Rejected</h4>
            <p style="margin:0;font-size:0.95rem;color:#7f1d1d;font-weight:600;">
                You have rejected the offer letter for this job.
            </p>
        </div>""", unsafe_allow_html=True)
        return

    offer_accepted = status in ("Offer Accepted", "Joined")

    # Fetch AI Offer Letter generated by HR
    ai_offer = None
    try:
        res = requests.get(f"{BASE_URL}/candidates/me/offer", headers=headers)
        if res.status_code == 200:
            ai_offer = res.json()
    except Exception:
        pass

    # Gate: HR must generate the offer letter before candidate can see it
    hr_offer_ready = (
        ai_offer is not None
        and ai_offer.get("status") in ("generated", "sent", "accepted", "revoked")
    )

    accepted_badge = (
        '<span style="background:#dcfce7;color:#16a34a;padding:3px 10px;'
        'border-radius:12px;font-size:0.78rem;font-weight:600;">\u2705 Accepted</span>'
        if offer_accepted else ""
    )
    st.markdown(f"""
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:14px;">
        <div style="width:4px;height:28px;background:#0a66c2;border-radius:4px;"></div>
        <h3 style="margin:0;font-size:1.15rem;font-weight:700;color:#191919;">
            Offer Letter
        </h3>
        {accepted_badge}
    </div>""", unsafe_allow_html=True)

    with st.container(border=True):

        # ── HR has NOT yet generated the offer letter ─────────────────────────
        if not hr_offer_ready:
            st.markdown("""
            <div style="background:#f0f9ff;border:1px solid #7dd3fc;border-radius:10px;
                        padding:28px;text-align:center;margin:12px 0;">
                <div style="font-size:2.5rem;margin-bottom:10px;">⏳</div>
                <h4 style="color:#0369a1;margin:0 0 8px 0;">Offer Letter Pending</h4>
                <p style="margin:0;font-size:0.92rem;color:#0c4a6e;">
                    HR has not yet generated your official offer letter.<br>
                    You will be notified once it is ready for your review.
                </p>
            </div>""", unsafe_allow_html=True)
            return

        # ── HR has generated the offer — show it ──────────────────────────────
        salary_str = "As per approved corporate scale"
        if ai_offer and ai_offer.get("recommended_salary"):
            salary_str = f"${ai_offer.get('recommended_salary'):,}"

        if not offer_accepted:
            # Show the AI-generated offer letter content
            if ai_offer and ai_offer.get("offer_letter_text"):
                st.markdown(f"""
                <div style="background:#ffffff; border:1px solid #d1d5db; border-radius:8px;
                            padding:24px; font-family:'Segoe UI', system-ui, sans-serif;
                            color:#333; line-height:1.6; margin-bottom:16px; white-space:pre-wrap;">
                    {ai_offer['offer_letter_text']}
                </div>
                """, unsafe_allow_html=True)
            else:
                # Offer record exists but no letter text yet
                st.info("\U0001f4cb Offer letter is being prepared. Please check back shortly.")
                return

            st.info("\U0001f4cb Review your official offer above and select **Approve** or **Reject** to respond.")
            st.warning("\u26a0\ufe0f By accepting this offer you authorize Background Verification (BGV) checks.")

            btn_col1, btn_col2 = st.columns(2)
            with btn_col1:
                if st.button("\u270d\ufe0f Approve Offer & Proceed", use_container_width=True, type="primary", key="approve_offer_btn"):
                    try:
                        res = requests.post(f"{BASE_URL}/candidates/me/accept-offer", headers=headers)
                        if res.status_code == 200:
                            st.success("Offer accepted! Please navigate to the BGV Portal tab in the sidebar to complete verification.")
                            st.rerun()
                        else:
                            st.error(res.json().get("detail", "Error accepting offer."))
                    except Exception:
                        st.error("Connection error. Please try again.")
            with btn_col2:
                if st.button("\u274c Reject Offer", use_container_width=True, type="secondary", key="reject_offer_btn"):
                    try:
                        res = requests.post(f"{BASE_URL}/candidates/me/reject-offer", headers=headers)
                        if res.status_code == 200:
                            st.warning("You have rejected the offer.")
                            st.rerun()
                        else:
                            st.error(res.json().get("detail", "Error rejecting offer."))
                    except Exception:
                        st.error("Connection error. Please try again.")
        else:
            # Offer accepted — show the AI letter
            candidate_name = offer_app.get("name", "Candidate")
            job_title = offer_app.get("job_title", "Software Engineer")

            if ai_offer and ai_offer.get("offer_letter_text"):
                st.markdown(f"""
                <div style="background:#ffffff; border:1px solid #d1d5db; border-radius:8px;
                            padding:24px; font-family:'Segoe UI', system-ui, sans-serif;
                            color:#333; line-height:1.6; margin-bottom:16px; white-space:pre-wrap;">
                    {ai_offer['offer_letter_text']}
                </div>
                """, unsafe_allow_html=True)

            # Offer PDF download — only from backend (HR generated)
            try:
                pdf_res = requests.get(f"{BASE_URL}/candidates/me/offer-pdf", headers=headers)
                if pdf_res.status_code == 200:
                    st.download_button(
                        label="\U0001f4e5 Download Official Offer Letter (PDF)",
                        data=pdf_res.content,
                        file_name=f"Offer_Letter_{candidate_name.replace(' ', '_')}.pdf",
                        mime="application/pdf",
                        use_container_width=True,
                        key="download_offer_pdf_btn"
                    )
                else:
                    st.info("PDF will be available once generated by HR.")
            except Exception as e:
                st.warning(f"Could not load PDF: {e}")


def render_bgv_view(my_apps, headers):
    offer_app = next((app for app in my_apps if app.get("status") in ["Offered", "Offer Accepted", "Joined", "Offer Rejected", "Offer Revoked"]), None)
    if not offer_app:
        st.info("No active offer found.")
        return

    status = offer_app.get("status")

    if status == "Offer Rejected":
        st.markdown("""
        <div style="background:#fef2f2;border:1px solid #fca5a5;border-radius:10px;
                    padding:24px;text-align:center;margin-top:20px;">
            <div style="font-size:2.5rem;margin-bottom:8px;">❌</div>
            <h4 style="color:#b91c1c;margin:0 0 8px 0;">BGV Disabled</h4>
            <p style="margin:0;font-size:0.95rem;color:#7f1d1d;font-weight:600;">
                You have rejected the offer letter for this job. Background Verification is disabled.
            </p>
        </div>""", unsafe_allow_html=True)
        return

    if status == "Offer Revoked":
        revocation_details = offer_app.get("parsed_data", {}).get("bgv_revocation_details", "Background Verification failed on all three attempts.")
        st.markdown(f"""
        <div style="background:#fef2f2;border:1px solid #fca5a5;border-radius:10px;
                    padding:24px;text-align:center;margin-top:20px;">
            <div style="font-size:2.5rem;margin-bottom:8px;">🚫</div>
            <h4 style="color:#b91c1c;margin:0 0 8px 0;">Offer Revoked</h4>
            <p style="margin:0 0 12px 0;font-size:0.95rem;color:#7f1d1d;font-weight:600;">
                Your employment offer has been revoked due to background verification (BGV) failures.
            </p>
            <div style="background:#ffffff; border:1px solid #fca5a5; border-radius:6px; padding:12px; font-size:0.88rem; color:#7f1d1d; text-align:left;">
                <strong>Revocation Details:</strong><br/>
                {revocation_details}
            </div>
        </div>""", unsafe_allow_html=True)
        return

    offer_accepted = status in ("Offer Accepted", "Joined")

    if status == "Joined":
        lock_label = ('<span style="background:#dcfce7;color:#16a34a;padding:3px 10px;'
                      'border-radius:12px;font-size:0.78rem;font-weight:600;">\u2705 Submitted</span>')
    elif offer_accepted:
        lock_label = ('<span style="background:#eff6ff;color:#1d4ed8;padding:3px 10px;'
                      'border-radius:12px;font-size:0.78rem;font-weight:600;">\U0001f513 Enabled</span>')
    else:
        lock_label = ('<span style="background:#fef3c7;color:#b45309;padding:3px 10px;'
                      'border-radius:12px;font-size:0.78rem;font-weight:600;">'
                      '\U0001f512 Locked &mdash; Accept Offer First</span>')

    sec2_color = "#0a66c2" if offer_accepted else "#d1d5db"
    sec2_text  = "#191919" if offer_accepted else "#9ca3af"
    st.markdown(f"""
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:14px;">
        <div style="width:4px;height:28px;background:{sec2_color};border-radius:4px;"></div>
        <h3 style="margin:0;font-size:1.15rem;font-weight:700;color:{sec2_text};">
            Background Verification (BGV)
        </h3>
        {lock_label}
    </div>""", unsafe_allow_html=True)

    if status == "Joined":
        # Check if corporate credentials exist in the candidate application
        corp_creds = offer_app.get("parsed_data", {}).get("corporate_credentials") if offer_app.get("parsed_data") else None
        
        creds_html = ""
        if corp_creds:
            creds_html = (
                f'<div style="background:#ffffff; border:1px solid #e2e8f0; border-radius:8px; padding:16px; margin:16px auto; max-width:400px; text-align:left; box-shadow:0 1px 3px rgba(0,0,0,0.05);">'
                f'<h5 style="margin:0 0 12px 0; font-size:0.95rem; color:#1e293b; font-weight:600; text-align:center; border-bottom:1px solid #e2e8f0; padding-bottom:8px;">\U0001f512 Corporate Portal Credentials</h5>'
                f'<div style="margin-bottom:8px; font-size:0.88rem; color:#475569;">'
                f'<strong>Corporate Email:</strong> <span style="font-family:monospace; background:#f1f5f9; padding:2px 6px; border-radius:4px; color:#0f172a;">{corp_creds.get("email")}</span>'
                f'</div>'
                f'<div style="font-size:0.88rem; color:#475569;">'
                f'<strong>Temporary Password:</strong> <span style="font-family:monospace; background:#f1f5f9; padding:2px 6px; border-radius:4px; color:#0f172a;">{corp_creds.get("password")}</span>'
                f'</div>'
                f'<p style="margin:12px 0 0 0; font-size:0.78rem; color:#64748b; text-align:center; font-style:italic;">Use these credentials to sign in to the Employee Portal below.</p>'
                f'</div>'
            )
            
        st.markdown(f"""
        <div style="background:#f0fdf4;border:1px solid #86efac;border-radius:10px;
                    padding:24px;text-align:center;">
            <div style="font-size:2.5rem;margin-bottom:8px;">🎉</div>
            <h4 style="color:#15803d;margin:0 0 8px 0;">BGV Completed & Verified!</h4>
            <p style="margin:0;font-size:0.9rem;color:#166534;margin-bottom:12px;">
                You are now an active employee. Access the Employee Portal at
                <a href="{EMPLOYEE_PORTAL_URL}/" target="_blank"
                   style="color:#0a66c2;font-weight:600;">{EMPLOYEE_PORTAL_URL}</a>.
            </p>
            {creds_html}
        </div>""", unsafe_allow_html=True)
        return

    if not offer_accepted:
        st.markdown("""
        <div style="background:#f9fafb;border:2px dashed #d1d5db;border-radius:10px;
                    padding:32px;text-align:center;">
            <div style="font-size:2.5rem;margin-bottom:10px;">\U0001f512</div>
            <p style="color:#6b7280;font-size:0.92rem;margin:0;">
                Please accept your offer letter in the <strong>Offer Letter</strong> section first to
                unlock Background Verification.
            </p>
        </div>""", unsafe_allow_html=True)
        return

    st.markdown("""
    <div style="background:#fffbeb;border-left:4px solid #f59e0b;border-radius:0 8px 8px 0;
                padding:14px 18px;margin-bottom:20px;">
        <strong style="color:#92400e;">What you need to submit:</strong>
        <ul style="margin:6px 0 0 0;padding-left:18px;color:#78350f;font-size:0.88rem;">
            <li>Your <strong>Aadhaar Number</strong> (validated using UIDAI checksum)</li>
            <li>Upload <strong>Aadhaar Card</strong> (PDF / PNG / JPG)</li>
            <li>Upload <strong>PAN Card</strong> (PDF / PNG / JPG)</li>
        </ul>
    </div>""", unsafe_allow_html=True)

    # ── Fetch document status and decide whether form is accessible ─────────────────
    try:
        candidate_id = offer_app["candidate_id"]
        bgv_docs_res = requests.get(f"{BASE_URL}/onboarding/{candidate_id}/bgv", headers=headers)
        if bgv_docs_res.status_code == 200:
            bgv_docs = bgv_docs_res.json()
            # Group by doc_type — keep newest per type
            newest_docs = {}
            for d in bgv_docs:
                dt = d.get("doc_type")
                if dt not in newest_docs:
                    newest_docs[dt] = d

            review_docs   = [d for d in newest_docs.values() if d.get("verification_status") == "review"]
            rejected_docs = [d for d in newest_docs.values() if d.get("verification_status") == "rejected"]

            # ── HR Review lock: hide the form entirely ONLY if nothing is rejected ────────
            if review_docs and not rejected_docs:
                st.markdown("""
                <div style="background:#fffbeb;border:1px solid #fde68a;border-radius:10px;
                            padding:20px;margin-bottom:20px;">
                    <h5 style="color:#92400e;margin:0 0 8px 0;font-weight:700;">
                        ⏳ Documents Under HR Manual Review
                    </h5>
                    <p style="margin:0 0 12px 0;font-size:0.9rem;color:#78350f;">
                        One or more of your documents could not be automatically verified
                        (possibly due to blur or low image quality) and have been sent to HR
                        for manual review.
                        <strong>You cannot re-upload documents until HR has completed the review.</strong>
                        You will be notified of the outcome.
                    </p>
                    <ul style="margin:0;padding-left:20px;color:#78350f;font-size:0.85rem;">
                """, unsafe_allow_html=True)
                for rd in review_docs:
                    agent_result = rd.get("agent_result") or {}
                    reason_str = (agent_result.get("reason", "Under HR review.")
                                  if isinstance(agent_result, dict) else "Under HR review.")
                    st.markdown(
                        f"<li><strong>{rd.get('doc_type','').upper()}</strong> "
                        f"({rd.get('file_name', '')}): {reason_str}</li>",
                        unsafe_allow_html=True
                    )
                st.markdown("</ul></div>", unsafe_allow_html=True)
                return   # ← Form completely hidden while in HR review

            # ── Rejected docs: show reasons so candidate knows what to fix ──────
            if rejected_docs:
                st.markdown("""
                <div style="background:#fef2f2;border:1px solid #fca5a5;border-radius:8px;
                            padding:16px;margin-bottom:20px;">
                    <h5 style="color:#b91c1c;margin:0 0 8px 0;font-weight:600;">
                        ❌ Background Verification Rejected
                    </h5>
                    <p style="margin:0 0 10px 0;font-size:0.88rem;color:#7f1d1d;">
                        Your documents were rejected. Review the reasons below,
                        upload correct documents, and re-submit.
                    </p>
                    <ul style="margin:0;padding-left:20px;color:#7f1d1d;font-size:0.85rem;">
                """, unsafe_allow_html=True)
                for rd in rejected_docs:
                    agent_result = rd.get("agent_result") or {}
                    reason_str = (agent_result.get("reason", "Verification rejected.")
                                  if isinstance(agent_result, dict) else "Verification rejected.")
                    st.markdown(
                        f"<li><strong>{rd.get('doc_type','').upper()}</strong> "
                        f"({rd.get('file_name', '')}): {reason_str}</li>",
                        unsafe_allow_html=True
                    )
                st.markdown("</ul></div>", unsafe_allow_html=True)
    except Exception:
        pass


    aadhaar_raw = st.text_input(
        "Aadhaar Number *",
        placeholder="Enter 12-digit Aadhaar number",
        max_chars=12,
        key="bgv_aadhaar_input",
        help="Must be a valid 12-digit UIDAI Aadhaar (Verhoeff checksum validated)."
    )
    aadhaar_digits = aadhaar_raw.strip().replace(" ", "").replace("-", "")
    aadhaar_valid  = False

    if aadhaar_digits:
        if not aadhaar_digits.isdigit():
            st.error("\u274c Aadhaar must contain digits only.")
        elif len(aadhaar_digits) != 12:
            st.warning(f"\u26a0\ufe0f Aadhaar must be exactly 12 digits (you entered {len(aadhaar_digits)}).")
        elif aadhaar_digits[0] in ('0', '1'):
            st.error("\u274c Invalid Aadhaar — first digit cannot be 0 or 1.")
        elif not _validate_aadhaar(aadhaar_digits):
            st.error("\u274c Invalid Aadhaar — checksum validation failed. Please re-enter.")
        else:
            aadhaar_valid = True
            st.success("\u2705 Valid Aadhaar number.")

    st.markdown("<div style='height:8px'></div>", unsafe_allow_html=True)
    st.markdown("##### \U0001f4ce Upload Documents")

    if not aadhaar_valid:
        st.markdown("""
        <div style="background:#fef2f2;border:1px solid #fca5a5;border-radius:8px;
                    padding:12px 16px;margin-bottom:12px;">
            <span style="color:#b91c1c;font-weight:600;font-size:0.88rem;">
                🔒 Document uploads locked — enter a valid Aadhaar to unlock.
            </span>
        </div>""", unsafe_allow_html=True)

    upload_disabled = not aadhaar_valid

    doc_aadhaar = st.file_uploader(
        "Upload Aadhaar Card *", type=["pdf", "png", "jpg", "jpeg"],
        key="bgv_aadhaar_file", disabled=upload_disabled
    )
    doc_pan = st.file_uploader(
        "Upload PAN Card *", type=["pdf", "png", "jpg", "jpeg"],
        key="bgv_pan_file", disabled=upload_disabled
    )

    st.markdown("<div style='height:8px'></div>", unsafe_allow_html=True)
    declare = st.checkbox(
        "I hereby declare that all information and documents provided are true and accurate.",
        key="bgv_declare"
    )

    all_ready = aadhaar_valid and doc_aadhaar and doc_pan and declare

    st.markdown("<div style='height:12px'></div>", unsafe_allow_html=True)

    if st.button("\U0001f680  Submit BGV & Join Company", use_container_width=True,
                 type="primary", key="submit_bgv_btn", disabled=not all_ready):
        try:
            with st.spinner("Uploading verification documents and running AI BGV checks..."):
                candidate_id = offer_app["candidate_id"]
                
                # 1. Upload Aadhaar
                files_aadhaar = {"file": (doc_aadhaar.name, doc_aadhaar.getvalue(), doc_aadhaar.type)}
                data_aadhaar = {"doc_type": "aadhaar", "identity_no": aadhaar_digits}
                res_aadhaar = requests.post(f"{BASE_URL}/onboarding/{candidate_id}/bgv", data=data_aadhaar, files=files_aadhaar, headers=headers)

                # 2. Upload PAN
                files_pan = {"file": (doc_pan.name, doc_pan.getvalue(), doc_pan.type)}
                data_pan = {"doc_type": "pan"}
                res_pan = requests.post(f"{BASE_URL}/onboarding/{candidate_id}/bgv", data=data_pan, files=files_pan, headers=headers)

            # ── Classify each document outcome ───────────────────────────
            hard_failures = []   # decision == "rejected"  → block submission
            hr_reviews    = []   # decision == "review"    → pass to HR review

            if res_aadhaar.status_code == 200:
                aad_res  = res_aadhaar.json()
                aad_status = aad_res.get("verification_status", "rejected")
                aad_reason = aad_res.get("reason", "Verification failed.")
                if aad_status == "rejected":
                    hard_failures.append(f"Aadhaar Card: {aad_reason}")
                elif aad_status == "review":
                    hr_reviews.append(f"Aadhaar Card: {aad_reason}")
                # "accepted" → no action needed
            else:
                hard_failures.append(
                    f"Failed to upload Aadhaar (status {res_aadhaar.status_code}): {res_aadhaar.text}"
                )

            if res_pan.status_code == 200:
                pan_res  = res_pan.json()
                pan_status = pan_res.get("verification_status", "rejected")
                pan_reason = pan_res.get("reason", "Verification failed.")
                if pan_status == "rejected":
                    hard_failures.append(f"PAN Card: {pan_reason}")
                elif pan_status == "review":
                    hr_reviews.append(f"PAN Card: {pan_reason}")
                # "accepted" → no action needed
            else:
                hard_failures.append(
                    f"Failed to upload PAN (status {res_pan.status_code}): {res_pan.text}"
                )

            # ── Hard failures: block and count as a BGV attempt ──────────
            if hard_failures:
                st.error("❌ Background Verification Failed. Please correct the document issues.")
                for r in hard_failures:
                    st.error(r)
                # Register the BGV failure attempt on the backend
                try:
                    requests.post(
                        f"{BASE_URL}/candidates/me/register-bgv-failure",
                        json={"reasons": hard_failures},
                        headers=headers
                    )
                except Exception:
                    pass

            # ── HR review items: inform candidate, still complete submission ─
            elif hr_reviews:
                # Documents submitted but flagged for manual HR review — proceed
                payload = {
                    "father_name": "N/A",
                    "permanent_address": "Submitted via portal",
                    "identity_proof_no": aadhaar_digits,
                    "declaration_accepted": True
                }
                res = requests.post(f"{BASE_URL}/candidates/me/submit-bgv", json=payload, headers=headers)
                if res.status_code == 200:
                    st.info(
                        "⚠️ **Documents Submitted for HR Manual Review.** "
                        "One or more of your documents could not be fully verified automatically "
                        "(e.g. the image may be partially blurry or low-resolution). "
                        "Your submission has been forwarded to the HR team for manual verification. "
                        "You will be notified of the outcome."
                    )
                    for r in hr_reviews:
                        st.caption(f"🔍 Flagged for review: {r}")
                    st.rerun()
                else:
                    st.error(res.json().get("detail", "Error submitting BGV."))

            # ── All accepted: full success ────────────────────────────────
            else:
                payload = {
                    "father_name": "N/A",
                    "permanent_address": "Submitted via portal",
                    "identity_proof_no": aadhaar_digits,
                    "declaration_accepted": True
                }
                res = requests.post(f"{BASE_URL}/candidates/me/submit-bgv", json=payload, headers=headers)
                if res.status_code == 200:
                    st.success("🎉 Background Verification Successful! You are now an active Employee.")
                    st.balloons()
                    st.rerun()
                else:
                    st.error(res.json().get("detail", "Error submitting BGV."))

        except Exception as e:
            st.error(f"Connection error: {e}")

    if not all_ready:
        missing = []
        if not aadhaar_valid:  missing.append("valid Aadhaar")
        if not doc_aadhaar:    missing.append("Aadhaar upload")
        if not doc_pan:        missing.append("PAN upload")
        if not declare:        missing.append("declaration")
        if missing:
            st.caption(f"\u26a0\ufe0f Still needed: {', '.join(missing)}")

# CUSTOM HEADER WITH BRAND LOGO
# ─────────────────────────────────────────────────────────────────────────────
st.markdown("""
<div class="linkedin-hdr">
    <div style="display: flex; align-items: center; gap: 10px;">
        Careers Portal
    </div>
</div>
""", unsafe_allow_html=True)

# ─────────────────────────────────────────────────────────────────────────────
# AUTHENTICATION LAYER
# ─────────────────────────────────────────────────────────────────────────────
if "auth_token" not in st.session_state:
    col_l, col_auth, col_r = st.columns([1.2, 1.6, 1.2])
    
    with col_auth:
        with st.container(border=True, key="auth_container"):
            # Selector inside box
            auth_mode = st.radio(
                "Auth Mode Selector",
                ["Sign In", "Register"],
                horizontal=True,
                label_visibility="collapsed"
            )
            
            if auth_mode == "Sign In":
                st.markdown("""
                <div style="text-align: center; margin-bottom: 20px; margin-top: 10px;">
                    <h2 style="font-size: 1.6rem; font-weight: 600; color: #191919; margin: 0;">Sign in</h2>
                    <p style="color: #5e5e5e; font-size: 0.88rem; margin: 5px 0 0 0;">Stay updated on your job applications</p>
                </div>
                """, unsafe_allow_html=True)
                
                login_email = st.text_input("Email", placeholder="email@domain.com", key="login_email")
                login_pass = st.text_input("Password", type="password", placeholder="••••••••", key="login_pass")
                
                st.markdown("<br>", unsafe_allow_html=True)
                if st.button("Sign In", use_container_width=True, type="primary"):
                    if not login_email or not login_pass:
                        st.error("Please fill in all fields.")
                    elif login_email.strip().lower() in [f"recruiter@{COMPANY_EMAIL_DOMAIN}", f"manager@{COMPANY_EMAIL_DOMAIN}"] or login_email.strip().lower().endswith(f"@{COMPANY_EMAIL_DOMAIN}"):
                        st.error(f"Access denied: HR staff/corporate accounts (@{COMPANY_EMAIL_DOMAIN}) cannot sign in to the Candidate Portal.")
                    else:
                        try:
                            res = requests.post(f"{BASE_URL}/login", data={"username": login_email, "password": login_pass})
                            if res.status_code == 200:
                                st.session_state["auth_token"] = res.json()["access_token"]
                                st.session_state["cand_email"] = login_email
                                st.session_state["candidate_view"] = "Jobs Board"
                                st.rerun()
                            else:
                                st.error("Invalid email or password.")
                        except Exception as e:
                            st.error(f"Connection failure: {e}")
                            
            else:
                st.markdown("""
                <div style="text-align: center; margin-bottom: 20px; margin-top: 10px;">
                    <h2 style="font-size: 1.6rem; font-weight: 600; color: #191919; margin: 0;">Register</h2>
                    <p style="color: #5e5e5e; font-size: 0.88rem; margin: 5px 0 0 0;">Join now to apply and track status</p>
                </div>
                """, unsafe_allow_html=True)
                
                reg_name = st.text_input("Full Name", placeholder="Enter name as per AADHAR", key="reg_name")
                reg_email = st.text_input("Email Address", placeholder="email@domain.com", key="reg_email")
                reg_phone = st.text_input("Phone Number", placeholder="+1 (555) 123-4567", key="reg_phone")
                reg_pass = st.text_input("Password (min 8 chars)", type="password", placeholder="••••••••", key="reg_pass")
                reg_confirm = st.text_input("Confirm Password", type="password", placeholder="••••••••", key="reg_confirm")
                
                st.markdown("<br>", unsafe_allow_html=True)
                if st.button("Agree & Join", use_container_width=True, type="primary"):
                    if not (reg_name and reg_email and reg_phone and reg_pass and reg_confirm):
                        st.error("Please fill in all fields.")
                    elif reg_email.strip().lower() in [f"recruiter@{COMPANY_EMAIL_DOMAIN}", f"manager@{COMPANY_EMAIL_DOMAIN}"] or reg_email.strip().lower().endswith(f"@{COMPANY_EMAIL_DOMAIN}"):
                        st.error(f"Registration denied: Corporate emails (@{COMPANY_EMAIL_DOMAIN}) cannot be registered as candidates.")
                    elif reg_pass != reg_confirm:
                        st.error("Passwords do not match.")
                    elif len(reg_pass) < 8:
                        st.error("Password must be at least 8 characters.")
                    else:
                        try:
                            res = requests.post(f"{BASE_URL}/register", json={
                                "email": reg_email,
                                "password": reg_pass,
                                "full_name": reg_name,
                                "is_manager": False
                            })
                            if res.status_code == 200:
                                st.success("Successfully registered!")
                                # Auto login
                                login_res = requests.post(f"{BASE_URL}/login", data={"username": reg_email, "password": reg_pass})
                                if login_res.status_code == 200:
                                    st.session_state["auth_token"] = login_res.json()["access_token"]
                                    st.session_state["cand_email"] = reg_email
                                    st.session_state["candidate_view"] = "Jobs Board"
                                    st.rerun()
                            else:
                                st.error(res.json().get('detail', 'Could not register user.'))
                        except Exception as e:
                            st.error(f"Connection failure: {e}")

# ─────────────────────────────────────────────────────────────────────────────
# AUTHENTICATED CANDIDATE DASHBOARD
# ─────────────────────────────────────────────────────────────────────────────
else:
    # Set default view
    if "candidate_view" not in st.session_state:
        st.session_state["candidate_view"] = "Jobs Board"
    # Safety guard: HR Helpdesk has been moved to the Employee portal — redirect stale sessions
    if st.session_state["candidate_view"] == "HR Helpdesk":
        st.session_state["candidate_view"] = "Jobs Board"


    headers = get_auth_headers()
    
    # Fetch Candidate User details
    user_details = None
    try:
        user_res = requests.get(f"{BASE_URL}/users/me", headers=headers)
        if user_res.status_code == 200:
            user_details = user_res.json()
            # Security Check: Reject HR users if they somehow bypass form validation
            email_clean = user_details.get("email", "").strip().lower()
            if user_details.get("is_manager") or email_clean in [f"recruiter@{COMPANY_EMAIL_DOMAIN}", f"manager@{COMPANY_EMAIL_DOMAIN}"] or email_clean.endswith(f"@{COMPANY_EMAIL_DOMAIN}"):
                st.session_state.clear()
                st.error(f"Access denied: HR/Corporate credentials (@{COMPANY_EMAIL_DOMAIN}) are not allowed on the Candidate Careers Portal.")
                st.stop()
        else:
            st.session_state.clear()
            st.rerun()
    except Exception:
        st.error("Unable to contact backend API server.")
        
    # Fetch existing applications to find already applied job_ids
    my_apps = []
    applied_job_ids = set()
    try:
        apps_res = requests.get(f"{BASE_URL}/candidates/me", headers=headers)
        if apps_res.status_code == 200:
            my_apps = apps_res.json()
            applied_job_ids = {app["job_id"] for app in my_apps}
    except Exception:
        pass

    # ── GATE: Block candidate portal if user is now an employee (Joined) ──────
    joined_app = next((app for app in my_apps if app.get("status") == "Joined"), None)
    if joined_app:
        parsed = joined_app.get("parsed_data") or {}
        corp_creds = parsed.get("corporate_credentials")
        
        # ── Congratulations card (white + blue theme) ────────────────────
        st.markdown("""
        <div style="max-width:600px; margin:80px auto 0 auto; text-align:center;">
            <div style="background:#ffffff; border:1px solid #bfdbfe; border-radius:16px; padding:40px 32px; box-shadow:0 4px 16px rgba(0,0,0,0.08);">
                <div style="font-size:3rem; margin-bottom:12px;">\U0001f389</div>
                <h2 style="color:#1d4ed8; margin:0 0 8px 0; font-size:1.5rem;">Congratulations, you are now an Employee!</h2>
                <p style="margin:0 0 6px 0; font-size:0.95rem; color:#1e40af;">
                    Your Background Verification is complete and your employee account has been created.
                </p>
                <p style="margin:0 0 16px 0; font-size:0.88rem; color:#3b82f6;">
                    This Candidate Portal is no longer available to you. Please use the <strong>Employee Portal</strong> to access all employee services.
                </p>
        """, unsafe_allow_html=True)

        if corp_creds:
            corp_email = corp_creds.get('email', '')
            corp_password = corp_creds.get('password', '')
            st.markdown(f"""
            <div style="background:#eff6ff; border:1px solid #bfdbfe; border-radius:8px; padding:16px; margin:4px auto 16px auto; max-width:420px; text-align:left;">
                <h5 style="margin:0 0 12px 0; font-size:0.95rem; color:#1e40af; font-weight:600; text-align:center; border-bottom:1px solid #bfdbfe; padding-bottom:8px;">\U0001f512 Your Corporate Portal Credentials</h5>
                <div style="margin-bottom:8px; font-size:0.88rem; color:#1e3a8a;">
                    <strong>Corporate Email:</strong>&nbsp;<span style="font-family:monospace; background:#ffffff; padding:2px 6px; border-radius:4px; color:#0f172a; border:1px solid #e2e8f0;">{corp_email}</span>
                </div>
                <div style="font-size:0.88rem; color:#1e3a8a;">
                    <strong>Temporary Password:</strong>&nbsp;<span style="font-family:monospace; background:#ffffff; padding:2px 6px; border-radius:4px; color:#0f172a; border:1px solid #e2e8f0;">{corp_password}</span>
                </div>
            </div>
            """, unsafe_allow_html=True)

        st.markdown(f"""
                <div style="margin-top:8px; padding-bottom:8px;">
                    <a href="{EMPLOYEE_PORTAL_URL}/" target="_blank"
                       style="display:inline-block; background:#1d4ed8; color:#ffffff; padding:10px 28px; border-radius:8px; font-weight:600; text-decoration:none; font-size:0.95rem;">
                        \U0001f680 Go to Employee Portal
                    </a>
                </div>
            </div>
        </div>
        """, unsafe_allow_html=True)
        
        # Provide logout button
        if st.button("🔓 Log out", key="joined_logout"):
            st.session_state.clear()
            st.rerun()
        st.stop()

    # 3-Column LinkedIn Grid Layout
    col_profile, col_feed, col_news = st.columns([1.5, 4.2, 1.8])
    
    # ─────────────────────────────────────────────────────────────────────────
    # COLUMN 1: LEFT SIDEBAR (Profile Card & Navigation)
    # ─────────────────────────────────────────────────────────────────────────
    with col_profile:
        with st.container(border=True, key="profile_sidebar"):
            st.markdown('<div class="profile-banner"></div>', unsafe_allow_html=True)
            
            # User initials avatar
            initials = ""
            if user_details and user_details.get("full_name"):
                names = user_details["full_name"].split()
                initials = "".join([n[0] for n in names[:2]]).upper()
            
            st.markdown(f'<div class="profile-avatar">{initials}</div>', unsafe_allow_html=True)
            
            # User details
            full_name = user_details["full_name"] if user_details else "Candidate"
            email = user_details["email"] if user_details else ""
            st.markdown(f"""
            <div style="text-align: center; margin-bottom: 15px;">
                <h4 style="margin: 0; font-size: 1.05rem; font-weight: 600; color:#191919;">{full_name}</h4>
                <p style="margin: 3px 0 0 0; font-size: 0.8rem; color:#5e5e5e;">Job Seeker at AI CareerHub</p>
            </div>
            <hr style="border: 0; border-top: 1px solid #e0e0e0; margin: 10px 0;">
            """, unsafe_allow_html=True)
            
            # Custom navigation buttons
            if st.button("💼  Jobs Board", key="menu_jobs", use_container_width=True, type="secondary" if st.session_state["candidate_view"] != "Jobs Board" else "primary"):
                st.session_state["candidate_view"] = "Jobs Board"
                st.rerun()
                
            if st.button("📋  My Applications", key="menu_apps", use_container_width=True, type="secondary" if st.session_state["candidate_view"] != "My Applications" else "primary"):
                st.session_state["candidate_view"] = "My Applications"
                st.rerun()
                
            if st.button("👤  My Profile", key="menu_profile", use_container_width=True, type="secondary" if st.session_state["candidate_view"] != "My Profile" else "primary"):
                st.session_state["candidate_view"] = "My Profile"
                st.rerun()
                
            has_offer = any(app.get("status") in ["Offered", "Offer Accepted", "Joined", "Offer Rejected", "Offer Revoked"] for app in my_apps)
            if has_offer:
                if st.button("📜  Offer Letter", key="menu_offer", use_container_width=True, type="secondary" if st.session_state["candidate_view"] != "Offer Letter" else "primary"):
                    st.session_state["candidate_view"] = "Offer Letter"
                    st.rerun()
                bgv_disabled = not any(app.get("status") in ["Offer Accepted", "Joined", "Offer Revoked"] for app in my_apps)
                if st.button("🔐  BGV Portal", key="menu_bgv", use_container_width=True, type="secondary" if st.session_state["candidate_view"] != "Background Verification" else "primary", disabled=bgv_disabled):
                    st.session_state["candidate_view"] = "Background Verification"
                    st.rerun()

            st.markdown('<hr style="border: 0; border-top: 1px solid #e0e0e0; margin: 10px 0;">', unsafe_allow_html=True)
            if st.button("🔄  Refresh Portal", key="menu_refresh", use_container_width=True):
                st.rerun()
            if st.button("🚪  Sign Out", key="menu_signout", use_container_width=True):
                st.session_state.clear()
                st.rerun()

    # ─────────────────────────────────────────────────────────────────────────
    # COLUMN 2: MIDDLE MAIN FEED (Dynamic Content Panel)
    # ─────────────────────────────────────────────────────────────────────────
    with col_feed:
        # Display success banner popups at the top of the feed if set
        if "success_message" in st.session_state and st.session_state["success_message"]:
            st.success(st.session_state["success_message"])
            st.session_state["success_message"] = None  # Clear it
            
        # ── VIEW A: JOBS BOARD ────────────────────────────────────────────────
        if st.session_state["candidate_view"] == "Jobs Board":
            if "apply_job_id" not in st.session_state:
                st.session_state["apply_job_id"] = None
            if "apply_job_title" not in st.session_state:
                st.session_state["apply_job_title"] = None
                
            # If not in active application form
            if st.session_state["apply_job_id"] is None:
                st.markdown("<h3 style='margin: 0 0 16px 0; font-size:1.3rem; font-weight:600; color:#191919;'>Recommended Job Openings</h3>", unsafe_allow_html=True)
                
                # Fetch positions
                jobs = []
                try:
                    res = requests.get(f"{BASE_URL}/public/jobs")
                    if res.status_code == 200:
                        jobs = res.json()
                except Exception:
                    st.error("Failed to load jobs list.")
                    
                if not jobs:
                    with st.container(border=True, key="no_jobs_card"):
                        st.info("No active jobs found matching your profile.")
                else:
                    for job in jobs:
                        skills_str = ", ".join(job['skills_required']) if job['skills_required'] else "General"
                        has_applied = job["id"] in applied_job_ids
                        
                        with st.container(border=True):
                            st.markdown(f"""
                            <div class="job-card-marker">
                                <div style="display:flex; justify-content:space-between; align-items:start;">
                                    <div>
                                        <span class="li-job-title">{job['title']}</span>
                                        <div class="li-job-meta">🏢 {job['department']} · 📍 {job['location']} · ⏱️ {job['employment_type']}</div>
                                    </div>
                                    <div style="font-weight:600; color:#5e5e5e; font-size:0.9rem;">💰 {job['salary_range']}</div>
                                </div>
                                <div class="li-tags">
                                    <span class="li-tag">🛠️ {skills_str}</span>
                                    <span class="li-tag">💼 {job['experience_required']}+ years exp</span>
                                </div>
                                <div style="font-size:0.88rem; color:#191919; line-height:1.5; margin-bottom:14px;">{job['full_description'][:280]}...</div>
                            </div>
                            """, unsafe_allow_html=True)
                            
                            # Apply button
                            if has_applied:
                                st.markdown('<button class="applied-btn" disabled>✔️ Applied</button>', unsafe_allow_html=True)
                            else:
                                if st.button("⚡ Easy Apply", key=f"btn_apply_{job['id']}", use_container_width=True, type="primary"):
                                    st.session_state["apply_job_id"] = job["id"]
                                    st.session_state["apply_job_title"] = job["title"]
                                    st.rerun()
                        
                        # Visual spacer to prevent cards from collapsing together
                        st.markdown("<div style='height: 12px;'></div>", unsafe_allow_html=True)
                                    
            else:
                # Easy Apply Application Form
                job_id = st.session_state["apply_job_id"]
                job_title = st.session_state["apply_job_title"]
                
                with st.container(border=True, key=f"easy_apply_form_{job_id}"):
                    st.markdown(f'<h3 style="font-size: 1.3rem; font-weight: 600; color: #191919; margin: 0 0 16px 0;">⚡ Easy Apply: {job_title}</h3>', unsafe_allow_html=True)
                    
                    if st.button("⬅️ Back to Openings", key="back_to_listings"):
                        st.session_state["apply_job_id"] = None
                        st.session_state["apply_job_title"] = None
                        st.rerun()
                        
                    st.markdown("<br>", unsafe_allow_html=True)
                    st.text_input("Name (Linked from Profile)", value=full_name, disabled=True)
                    st.text_input("Email (Linked from Profile)", value=email, disabled=True)
                    phone_num = st.text_input("Phone Number *", placeholder="+1 (555) 123-4567", key="cand_phone")
                    uploaded_resume = st.file_uploader("Upload Resume (PDF or TXT) *", type=["pdf", "txt"], key="cand_resume")
                    
                    st.markdown("<br>", unsafe_allow_html=True)
                    submit_disabled = not (phone_num and uploaded_resume)
                    
                    if st.button("Submit Application", use_container_width=True, type="primary", disabled=submit_disabled):
                        with st.spinner("Submitting application..."):
                            try:
                                file_ext = "application/pdf" if uploaded_resume.name.endswith(".pdf") else "text/plain"
                                files_payload = {"file": (uploaded_resume.name, uploaded_resume.getvalue(), file_ext)}
                                data_payload = {"phone": phone_num}
                                
                                apply_res = requests.post(
                                    f"{BASE_URL}/public/jobs/{job_id}/apply-secure",
                                    headers=headers,
                                    data=data_payload,
                                    files=files_payload
                                )
                                if apply_res.status_code == 200:
                                    st.session_state["success_message"] = f"🎉 Application for '{job_title}' submitted successfully! You can track its status under 'My Applications'."
                                    st.session_state["apply_job_id"] = None
                                    st.session_state["apply_job_title"] = None
                                    st.rerun()
                                else:
                                    st.error(apply_res.json().get('detail', 'Could not submit application.'))
                            except Exception as e:
                                st.error(f"Error submitting application: {e}")

        # ── VIEW B: MY APPLICATIONS ──────────────────────────────────────────
        elif st.session_state["candidate_view"] == "My Applications":
            st.markdown("<h3 style='margin: 0 0 16px 0; font-size:1.3rem; font-weight:600; color:#191919;'>Your Job Applications</h3>", unsafe_allow_html=True)
            
            if not my_apps:
                with st.container(border=True, key="no_apps_card"):
                    st.info("You haven't submitted any job applications yet.")
            else:
                for app in my_apps:
                    status = app["status"]
                    badge_style = "badge-applied"
                    display_status = "Applied"
                    
                    if status == "Screening":
                        badge_style = "badge-screening"
                        display_status = "In Review"
                    elif status == "Shortlisted":
                        badge_style = "badge-shortlisted"
                        display_status = "Shortlisted"
                    elif status == "Interviewing":
                        badge_style = "badge-interviewing"
                        display_status = "Interview Active"
                    elif status == "Offered":
                        badge_style = "badge-offered"
                        display_status = "Offer Extended"
                    elif status == "Offer Accepted":
                        badge_style = "badge-interviewing"
                        display_status = "Offer Accepted"
                    elif status == "Joined":
                        badge_style = "badge-shortlisted"
                        display_status = "BGV Cleared / Joined"
                    elif status == "Rejected":
                        badge_style = "badge-rejected"
                        display_status = "Process Completed"
                    elif status == "Offer Rejected":
                        badge_style = "badge-rejected"
                        display_status = "Offer Rejected"
                        
                    with st.container(border=True):
                        st.markdown(f"""
                        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
                            <div>
                                <span style="font-size:1.05rem; font-weight:600; color:#0a66c2;">{app['job_title']}</span>
                                <div style="font-size:0.8rem; color:#5e5e5e; margin-top:2px;">📍 {app['location']} · Applied on: {app['applied_at'][:10] if app['applied_at'] else "Recently"}</div>
                            </div>
                            <span class="badge {badge_style}">{display_status}</span>
                        </div>
                        """, unsafe_allow_html=True)
                        
                        # AI Interview Panel — link is sent via email, no button here
                        if status == "Interviewing" and app["interview_join_token"]:
                            st.markdown("<hr style='border:0; border-top:1px solid #e0e0e0; margin:10px 0;'>", unsafe_allow_html=True)

                            # Check scheduled time to show the right message
                            scheduled_at_raw = app.get("interview_scheduled_at")
                            now_utc = datetime.utcnow()
                            interview_open = True
                            sched_display = ""
                            time_remaining_str = ""

                            if scheduled_at_raw:
                                try:
                                    sched_str = scheduled_at_raw.replace("Z", "+00:00") if isinstance(scheduled_at_raw, str) else ""
                                    if sched_str:
                                        sched_dt = datetime.fromisoformat(sched_str).replace(tzinfo=None)
                                    else:
                                        sched_dt = scheduled_at_raw if hasattr(scheduled_at_raw, "year") else None

                                    if sched_dt:
                                        from zoneinfo import ZoneInfo
                                        from datetime import timezone
                                        utc_dt = sched_dt.replace(tzinfo=timezone.utc)
                                        ist_dt = utc_dt.astimezone(ZoneInfo("Asia/Kolkata"))
                                        sched_display = f"{ist_dt.strftime('%d %b %Y at %I:%M %p IST')} ({utc_dt.strftime('%H:%M UTC')})" 
                                        if now_utc < sched_dt:
                                            interview_open = False
                                            delta = sched_dt - now_utc
                                            total_secs = int(delta.total_seconds())
                                            hours, rem = divmod(total_secs, 3600)
                                            mins, secs = divmod(rem, 60)
                                            if hours > 0:
                                                time_remaining_str = f"{hours}h {mins}m"
                                            elif mins > 0:
                                                time_remaining_str = f"{mins}m {secs}s"
                                            else:
                                                time_remaining_str = f"{secs}s"
                                except Exception:
                                    interview_open = True

                            if interview_open:
                                msg = "🎙️ Your AI Voice Interview is ready. **Check your email** for the unique interview link sent by our team."
                                if sched_display:
                                    msg += f" Scheduled for **{sched_display}**."
                                msg += " ⚠️ Once you open the link, do **not** refresh or close the tab — the interview will be marked complete."
                                st.info(msg)
                            else:
                                st.warning(
                                    f"🔒 Interview not yet open. Scheduled for **{sched_display}** "
                                    f"(opens in ~{time_remaining_str}). Your unique link has been sent to your registered email — "
                                    f"please use it at the scheduled time."
                                )


                        
                        # Visual spacer to prevent cards from collapsing together
                        st.markdown("<div style='height: 12px;'></div>", unsafe_allow_html=True)

        # ── VIEW C: MY PROFILE ────────────────────────────────────────────────
        elif st.session_state["candidate_view"] == "My Profile":
            st.markdown("<h3 style='margin: 0 0 16px 0; font-size:1.3rem; font-weight:600; color:#191919;'>My Profile Page</h3>", unsafe_allow_html=True)
            if user_details:
                with st.container(border=True, key="profile_details_card"):
                    st.markdown(f"""
                    <h4 style="margin:0 0 12px 0; font-size:1.15rem; font-weight:600; color:#0a66c2;">Contact Information</h4>
                    <p style="margin:4px 0; font-size:0.9rem;">📧 <strong>Email Address:</strong> {user_details['email']}</p>
                    <p style="margin:4px 0; font-size:0.9rem;">👤 <strong>Full Name:</strong> {user_details['full_name']}</p>
                    <p style="margin:4px 0; font-size:0.9rem;">💼 <strong>Account Role:</strong> System Candidate</p>
                    <p style="margin:4px 0; font-size:0.8rem; color:#5e5e5e; margin-top:12px;">Candidate Profile created on: {user_details['created_at'][:10] if user_details['created_at'] else "Recently"}</p>
                    """, unsafe_allow_html=True)

        # ── VIEW D: OFFER LETTER ──────────────────────────────────────────────
        elif st.session_state["candidate_view"] == "Offer Letter":
            render_offer_letter_view(my_apps, headers)
            
        # ── VIEW E: BGV PORTAL ──────────────────────────────────────────────
        elif st.session_state["candidate_view"] == "Background Verification":
            render_bgv_view(my_apps, headers)


    # ─────────────────────────────────────────────────────────────────────────
    # COLUMN 3: RIGHT SIDEBAR (LinkedIn News & Tips)
    # ─────────────────────────────────────────────────────────────────────────
    with col_news:
        with st.container(border=True, key="recent_apps_card"):
            st.markdown('<h4 style="margin: 0 0 12px 0; font-size:0.95rem; font-weight:600; color:#191919;">Recent Applications</h4>', unsafe_allow_html=True)
            if not my_apps:
                st.markdown("<p style='font-size:0.8rem; color:#5e5e5e;'>No applications submitted yet.</p>", unsafe_allow_html=True)
            else:
                for app in my_apps[:3]:  # Display top 3
                    st.markdown(f"""
                    <div style="margin-bottom: 8px; border-bottom: 1px solid #f3f2ef; padding-bottom: 6px;">
                        <div style="font-size:0.85rem; font-weight:600; color:#0a66c2;">{app['job_title']}</div>
                        <div style="font-size:0.75rem; color:#5e5e5e; margin-top:2px;">Status: <strong>{app['status']}</strong></div>
                    </div>
                    """, unsafe_allow_html=True)
                    
        with st.container(border=True, key="newly_posted_card"):
            st.markdown('<h4 style="margin: 0 0 12px 0; font-size:0.95rem; font-weight:600; color:#191919;">Newly Posted Jobs</h4>', unsafe_allow_html=True)
            # Find other jobs (excluding current application selections if needed, or simply list the jobs)
            active_jobs = []
            try:
                jobs_res = requests.get(f"{BASE_URL}/public/jobs")
                if jobs_res.status_code == 200:
                    active_jobs = jobs_res.json()
            except Exception:
                pass

            if not active_jobs:
                st.markdown("<p style='font-size:0.8rem; color:#5e5e5e;'>No other positions posted yet.</p>", unsafe_allow_html=True)
            else:
                # Show up to 3 jobs
                for j in active_jobs[:3]:
                    st.markdown(f"""
                    <div style="margin-bottom: 8px; border-bottom: 1px solid #f3f2ef; padding-bottom: 6px;">
                        <div style="font-size:0.85rem; font-weight:600; color:#191919;">{j['title']}</div>
                        <div style="font-size:0.75rem; color:#5e5e5e; margin-top:2px;">🏢 {j['department']} · 📍 {j['location']}</div>
                    </div>
                    """, unsafe_allow_html=True)

# ─────────────────────────────────────────────────────────────────────────────
# FOOTER
# ─────────────────────────────────────────────────────────────────────────────
st.markdown("""
<div style="text-align: center; padding: 2rem; color: #5e5e5e; font-size: 0.78rem; margin-top: 3rem; border-top: 1px solid #e0e0e0;">
    © 2026 AI CareerHub Services · Powered by AWS Bedrock HR Swarm Orchestrator
</div>
""", unsafe_allow_html=True)
