from config.database import SessionLocal, Base, engine
from models import schemas
from middleware.auth import hash_password
from sqlalchemy import text

def seed_database():
    print("Creating tables if they do not exist...")
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    
    # 1. Create Default Users (HR and HR Manager roles) if not exists
    if db.query(schemas.User).filter(schemas.User.email == "manager@company.com").first() is None:
        print("Seeding default users...")
        hr_recruiter = schemas.User(email="recruiter@company.com", hashed_password=hash_password("password123"), full_name="Alice Recruiter", is_manager=False)
        hr_manager = schemas.User(email="manager@company.com", hashed_password=hash_password("password123"), full_name="Bob Hiring Manager", is_manager=True)
        db.add(hr_recruiter)
        db.add(hr_manager)
        db.commit()
    
    # 2. Create Seed Job Meta-Profiles if not exists
    if db.query(schemas.Job).filter(schemas.Job.title == "Senior Python Backend Engineer").first() is None:
        print("Seeding default jobs...")
        job = schemas.Job(
            title="Senior Python Backend Engineer",
            department="Engineering",
            location="Remote (US / India)",
            employment_type="Full-Time",
            salary_range="$120,000 - $150,000",
            experience_required=5,
            skills_required=["Python", "FastAPI", "PostgreSQL", "AWS Bedrock", "Docker"],
            responsibilities="Design resilient APIs, build AI multi-agent orchestration frameworks, and maximize query latency efficiency parameters.",
            full_description="We are seeking a senior systems builder to integrate machine learning workflows into distributed high-throughput enterprise systems.",
            status="Active"
        )
        db.add(job)
        db.commit()

    # 3. Create Seed Employees if not exists
    if db.query(schemas.Employee).filter(schemas.Employee.employee_code == "EMP001").first() is None:
        print("Seeding default employees...")
        employees = [
            schemas.Employee(employee_code="EMP001", name="Priya Sharma", email="priya.sharma@company.com", status="Active",
                             skills_profile={"python": 6, "sql": 5, "excel": 7, "statistics": 4, "machine learning": 2, "communication": 6}),
            schemas.Employee(employee_code="EMP002", name="Rahul Verma", email="rahul.verma@company.com", status="Active",
                             skills_profile={"python": 7, "javascript": 5, "react": 3, "sql": 6, "docker": 4, "git": 7, "api design": 5}),
            schemas.Employee(employee_code="EMP003", name="Ananya Patel", email="ananya.patel@company.com", status="Active",
                             skills_profile={"seo": 5, "content writing": 6, "social media": 7, "google analytics": 4, "communication": 8}),
            schemas.Employee(employee_code="EMP004", name="Vikram Singh", email="vikram.singh@company.com", status="Active",
                             skills_profile={"sql": 7, "excel": 8, "data analysis": 6, "python": 3, "communication": 7, "stakeholder management": 5}),
            schemas.Employee(employee_code="EMP005", name="Sneha Reddy", email="sneha.reddy@company.com", status="Active",
                             skills_profile={"recruitment": 7, "communication": 8, "conflict resolution": 5, "excel": 6, "compliance": 4}),
            schemas.Employee(employee_code="EMP006", name="Arjun Kumar", email="arjun.kumar@company.com", status="Active",
                             skills_profile={"aws": 6, "linux": 7, "docker": 5, "kubernetes": 3, "python": 5, "terraform": 2, "networking": 6}),
        ]
        for emp in employees:
            db.add(emp)
        db.commit()

        # Update runtime columns (current_role, department, experience_years) via raw SQL
        employee_extras = [
            ("EMP001", "Junior Data Analyst", "Analytics", 2),
            ("EMP002", "Software Developer", "Engineering", 4),
            ("EMP003", "Marketing Coordinator", "Marketing", 3),
            ("EMP004", "Business Analyst", "Operations", 5),
            ("EMP005", "HR Executive", "Human Resources", 3),
            ("EMP006", "Cloud Engineer", "Infrastructure", 4),
        ]
        for code, role, dept, exp in employee_extras:
            db.execute(text(
                'UPDATE employees SET "current_role" = :role, department = :dept, experience_years = :exp WHERE employee_code = :code'
            ), {"role": role, "dept": dept, "exp": exp, "code": code})
        db.commit()

    # 4. Create Role Templates if not exists
    if db.query(schemas.RoleTemplate).filter(schemas.RoleTemplate.role_title == "Senior Data Scientist").first() is None:
        print("Seeding default role templates...")
        role_templates = [
            schemas.RoleTemplate(role_title="Senior Data Scientist",
                                 required_skills={"python": 8, "machine learning": 8, "statistics": 7, "sql": 7, "deep learning": 6, "data visualization": 6, "communication": 5}),
            schemas.RoleTemplate(role_title="Full Stack Tech Lead",
                                 required_skills={"python": 8, "javascript": 8, "react": 7, "sql": 7, "docker": 6, "system design": 7, "api design": 7, "git": 8}),
            schemas.RoleTemplate(role_title="Digital Marketing Manager",
                                 required_skills={"seo": 8, "content writing": 7, "social media": 8, "google analytics": 7, "paid advertising": 6, "communication": 8, "data analysis": 5}),
            schemas.RoleTemplate(role_title="Product Manager",
                                 required_skills={"stakeholder management": 8, "data analysis": 7, "communication": 8, "sql": 5, "agile": 7, "product strategy": 7, "user research": 6}),
            schemas.RoleTemplate(role_title="HR Manager",
                                 required_skills={"recruitment": 8, "communication": 9, "conflict resolution": 7, "compliance": 7, "leadership": 7, "hr analytics": 6, "training design": 6}),
            schemas.RoleTemplate(role_title="Solutions Architect",
                                 required_skills={"aws": 8, "system design": 8, "docker": 7, "kubernetes": 7, "terraform": 6, "networking": 7, "python": 6, "security": 6}),
        ]
        for rt in role_templates:
            db.add(rt)
        db.commit()

        # Update runtime columns for role templates
        role_extras = [
            ("Senior Data Scientist", "Analytics", "Lead data science initiatives, build ML pipelines, and mentor junior analysts."),
            ("Full Stack Tech Lead", "Engineering", "Architect and lead full-stack development across frontend and backend systems."),
            ("Digital Marketing Manager", "Marketing", "Strategize and execute digital marketing campaigns across all channels."),
            ("Product Manager", "Operations", "Define product vision, manage roadmap, and drive cross-functional alignment."),
            ("HR Manager", "Human Resources", "Lead HR operations including recruitment, compliance, and employee development."),
            ("Solutions Architect", "Infrastructure", "Design scalable cloud architectures and lead infrastructure modernization."),
        ]
        for title, dept, desc in role_extras:
            db.execute(text(
                "UPDATE role_templates SET department = :dept, description = :desc WHERE role_title = :title"
            ), {"dept": dept, "desc": desc, "title": title})
        db.commit()

    # 5. Create Courses if not exists
    if db.query(schemas.Course).filter(schemas.Course.course_title == "Machine Learning Specialization").first() is None:
        print("Seeding default courses...")
        courses = [
            schemas.Course(course_title="Machine Learning Specialization", skills_covered=["machine learning", "python", "statistics"],
                           description="Comprehensive ML course covering supervised/unsupervised learning, neural networks, and model evaluation.",
                           url="https://www.coursera.org/specializations/machine-learning"),
            schemas.Course(course_title="Deep Learning with TensorFlow", skills_covered=["deep learning", "python", "machine learning"],
                           description="Hands-on deep learning course using TensorFlow and Keras frameworks.",
                           url="https://www.udemy.com/course/deep-learning-tensorflow"),
            schemas.Course(course_title="Python for Data Science", skills_covered=["python", "data analysis", "statistics", "data visualization"],
                           description="Master Python for data manipulation, visualization, and statistical analysis.",
                           url="https://www.udemy.com/course/python-data-science-bootcamp"),
            schemas.Course(course_title="Advanced SQL Mastery", skills_covered=["sql", "data analysis"],
                           description="Advanced SQL techniques including window functions, CTEs, optimization, and analytics.",
                           url="https://www.linkedin.com/learning/advanced-sql-for-analytics"),
            schemas.Course(course_title="React & Node.js Full Stack", skills_covered=["react", "javascript", "api design"],
                           description="Build modern full-stack applications with React frontend and Node.js backend.",
                           url="https://www.udemy.com/course/react-node-fullstack"),
            schemas.Course(course_title="System Design Fundamentals", skills_covered=["system design", "api design"],
                           description="Learn to design scalable, resilient distributed systems and microservices architectures.",
                           url="https://www.pluralsight.com/courses/system-design-tech-leads"),
            schemas.Course(course_title="Docker & Kubernetes Mastery", skills_covered=["docker", "kubernetes"],
                           description="Container orchestration from basics to production-grade deployments.",
                           url="https://www.udemy.com/course/docker-kubernetes-masterclass"),
            schemas.Course(course_title="AWS Solutions Architect Prep", skills_covered=["aws", "networking", "security"],
                           description="Prepare for AWS Solutions Architect certification with hands-on labs.",
                           url="https://www.coursera.org/learn/aws-solutions-architect"),
            schemas.Course(course_title="SEO & Digital Marketing", skills_covered=["seo", "google analytics", "content writing"],
                           description="Master search engine optimization and digital marketing analytics.",
                           url="https://www.udemy.com/course/seo-digital-marketing"),
            schemas.Course(course_title="Content Strategy & Social Media", skills_covered=["content writing", "social media", "communication"],
                           description="Develop comprehensive content strategies for social media platforms.",
                           url="https://www.coursera.org/learn/content-strategy-marketing-automation"),
            schemas.Course(course_title="Data Visualization with Tableau", skills_covered=["data visualization", "data analysis"],
                           description="Create impactful dashboards and visual analytics with Tableau.",
                           url="https://www.linkedin.com/learning/data-visualization-tableau-powerbi"),
            schemas.Course(course_title="Agile & Scrum Masterclass", skills_covered=["agile", "stakeholder management", "communication"],
                           description="Become proficient in Agile methodologies and Scrum framework for project management.",
                           url="https://www.coursera.org/learn/agile-scrum-certification"),
            schemas.Course(course_title="Product Management Essentials", skills_covered=["product strategy", "user research", "stakeholder management"],
                           description="Learn the fundamentals of product management from idetion to launch.",
                           url="https://www.edx.org/course/product-management-fundamentals"),
            schemas.Course(course_title="HR Analytics & Compliance", skills_covered=["hr analytics", "compliance", "training design"],
                           description="Data-driven HR decision making and regulatory compliance frameworks.",
                           url="https://www.udemy.com/course/hris-hr-analytics"),
            schemas.Course(course_title="Terraform Infrastructure as Code", skills_covered=["terraform", "aws", "docker"],
                           description="Automate cloud infrastructure provisioning with Terraform.",
                           url="https://www.pluralsight.com/courses/terraform-iac"),
        ]
        for course in courses:
            db.add(course)
        db.commit()

    print("Database seeding completed.")

if __name__ == "__main__":
    seed_database()