# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, '.')
from config.database import SessionLocal
from models import schemas

db = SessionLocal()
try:
    # Check current jobs count
    existing = db.query(schemas.Job).all()
    print(f"Existing jobs count: {len(existing)}")
    
    # Add Job 2
    job2 = schemas.Job(
        title="Frontend React Developer",
        department="Engineering",
        location="Remote (India / Europe)",
        employment_type="Full-Time",
        salary_range="$80,000 - $110,000",
        experience_required=3,
        skills_required=["React", "TypeScript", "HTML5/CSS3", "Streamlit", "Redux"],
        responsibilities="Build highly interactive UI panels, optimize rendering cycles, and maintain responsive workflows.",
        full_description="We are seeking an UI engineer to lead the layout transformations of our core HR portal, converting raw pages into high-fidelity mockups.",
        status="Active"
    )
    
    # Add Job 3
    job3 = schemas.Job(
        title="Technical Product Manager",
        department="Product Management",
        location="Bengaluru, India (Hybrid)",
        employment_type="Full-Time",
        salary_range="$140,000 - $180,000",
        experience_required=6,
        skills_required=["Product Strategy", "Agile/Scrum", "FastAPI/REST APIs", "Jira", "AI System Design"],
        responsibilities="Define feature roadmaps, orchestrate cross-functional teams, and integrate user research feedback loops.",
        full_description="We are looking for a technical product manager who has experience building enterprise SaaS platforms and integrating AI orchestration features.",
        status="Active"
    )
    
    db.add(job2)
    db.add(job3)
    db.commit()
    print("Successfully added 2 additional active jobs to the database.")
except Exception as e:
    db.rollback()
    print(f"Error: {e}")
finally:
    db.close()
