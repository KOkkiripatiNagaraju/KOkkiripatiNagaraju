import datetime
import logging
from sqlalchemy.orm import Session
from models import schemas

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────
# User operations
# ─────────────────────────────────────────────

def get_user_by_email(db: Session, email: str) -> schemas.User | None:
    return db.query(schemas.User).filter(schemas.User.email == email).first()


def create_user(db: Session, user_in: schemas.UserCreate, hashed_pass: str) -> schemas.User:
    db_user = schemas.User(
        email=user_in.email,
        hashed_password=hashed_pass,
        full_name=user_in.full_name,
        is_manager=user_in.is_manager,
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user


# ─────────────────────────────────────────────
# Job operations
# ─────────────────────────────────────────────

def create_job(db: Session, job: schemas.JobCreate) -> schemas.Job:
    db_job = schemas.Job(**job.model_dump())
    db.add(db_job)
    db.commit()
    db.refresh(db_job)
    return db_job


def get_jobs(db: Session) -> list[schemas.Job]:
    return db.query(schemas.Job).order_by(schemas.Job.created_at.desc()).all()


def get_job(db: Session, job_id: int) -> schemas.Job | None:
    return db.query(schemas.Job).filter(schemas.Job.id == job_id).first()


def archive_job(db: Session, job_id: int) -> schemas.Job | None:
    job = get_job(db, job_id)
    if job:
        job.status = "Archived"
        db.commit()
        db.refresh(job)
    return job


# ─────────────────────────────────────────────
# Candidate operations
# ─────────────────────────────────────────────

def create_candidate(
    db: Session, job_id: int, name: str, email: str, phone: str, s3_key: str
) -> schemas.Candidate:
    cand = schemas.Candidate(
        job_id=job_id,
        name=name,
        email=email,
        phone=phone,
        s3_key=s3_key,
        status="Applied",
    )
    db.add(cand)
    db.commit()
    db.refresh(cand)
    return cand


def get_candidates_by_job(db: Session, job_id: int) -> list[schemas.Candidate]:
    return (
        db.query(schemas.Candidate)
        .filter(schemas.Candidate.job_id == job_id)
        .order_by(schemas.Candidate.applied_at.desc())
        .all()
    )


def get_candidate(db: Session, candidate_id: int) -> schemas.Candidate | None:
    return db.query(schemas.Candidate).filter(schemas.Candidate.id == candidate_id).first()


def update_candidate_status(db: Session, candidate_id: int, status: str) -> schemas.Candidate | None:
    cand = get_candidate(db, candidate_id)
    if cand:
        cand.status = status
        db.commit()
        db.refresh(cand)
    return cand


# ─────────────────────────────────────────────
# ATS Score operations
# ─────────────────────────────────────────────

def save_ats_score(db: Session, score_data: dict) -> schemas.ATSScore:
    existing = (
        db.query(schemas.ATSScore)
        .filter(schemas.ATSScore.candidate_id == score_data["candidate_id"])
        .first()
    )
    if existing:
        for k, v in score_data.items():
            setattr(existing, k, v)
        db.commit()
        db.refresh(existing)
        return existing

    db_score = schemas.ATSScore(**score_data)
    db.add(db_score)
    db.commit()
    db.refresh(db_score)
    return db_score


def get_ats_score(db: Session, candidate_id: int) -> schemas.ATSScore | None:
    return (
        db.query(schemas.ATSScore)
        .filter(schemas.ATSScore.candidate_id == candidate_id)
        .first()
    )


# ─────────────────────────────────────────────
# Ranking operations
# BUG FIX: original code created CandidateRanking objects but never called db.add(rk),
#          so rankings were silently discarded and never persisted.
# ─────────────────────────────────────────────

def update_rankings(db: Session, job_id: int, rankings: list) -> None:
    # Clear existing rankings for this job
    db.query(schemas.CandidateRanking).filter(schemas.CandidateRanking.job_id == job_id).delete()
    db.flush()  # Ensure deletes are applied before inserts

    for item in rankings:
        rk = schemas.CandidateRanking(
            job_id=job_id,
            candidate_id=item.get("candidate_id"),
            rank=item.get("rank"),
            final_score=item.get("final_score") or item.get("ats_score") or 0.0,
        )
        db.add(rk)  # FIX: was missing — objects were created but never added to the session

    db.commit()
    logger.info("Rankings persisted for job_id=%d, count=%d", job_id, len(rankings))


def get_rankings_by_job(db: Session, job_id: int) -> list[schemas.CandidateRanking]:
    return (
        db.query(schemas.CandidateRanking)
        .filter(schemas.CandidateRanking.job_id == job_id)
        .order_by(schemas.CandidateRanking.rank)
        .all()
    )


# ─────────────────────────────────────────────
# Interview operations
# ─────────────────────────────────────────────

def get_interview(db: Session, interview_id: int) -> schemas.Interview | None:
    return db.query(schemas.Interview).filter(schemas.Interview.id == interview_id).first()


def get_interview_by_candidate(db: Session, candidate_id: int) -> schemas.Interview | None:
    return (
        db.query(schemas.Interview)
        .filter(schemas.Interview.candidate_id == candidate_id)
        .first()
    )


def get_interview_by_join_token(db: Session, join_token: str) -> schemas.Interview | None:
    return (
        db.query(schemas.Interview)
        .filter(schemas.Interview.join_token == join_token)
        .first()
    )


def schedule_interview(
    db: Session,
    interview_id: int,
    scheduled_at: datetime.datetime,
    join_token: str,
    token_expires_at: datetime.datetime,
) -> schemas.Interview:
    interview = get_interview(db, interview_id)
    interview.scheduled_at = scheduled_at
    interview.join_token = join_token
    interview.join_token_created_at = datetime.datetime.utcnow()
    interview.join_token_expires_at = token_expires_at
    db.commit()
    db.refresh(interview)
    return interview


def get_interview_questions(db: Session, interview_id: int) -> list[schemas.InterviewQuestion]:
    return (
        db.query(schemas.InterviewQuestion)
        .filter(schemas.InterviewQuestion.interview_id == interview_id)
        .order_by(schemas.InterviewQuestion.id)
        .all()
    )


def save_interview_answer(
    db: Session,
    interview_id: int,
    question_id: int,
    candidate_answer: str,
    score: float,
    feedback: str,
    audio_file_path: str | None = None,
    audio_mime_type: str | None = None,
) -> schemas.InterviewAnswer:
    # Upsert: update if answer already exists for this question
    existing = (
        db.query(schemas.InterviewAnswer)
        .filter(schemas.InterviewAnswer.interview_question_id == question_id)
        .first()
    )
    if existing:
        existing.candidate_answer = candidate_answer
        existing.transcript = candidate_answer
        if audio_file_path is not None:
            existing.audio_file_path = audio_file_path
        if audio_mime_type is not None:
            existing.audio_mime_type = audio_mime_type
        existing.score = score
        existing.feedback = feedback
        existing.answered_at = datetime.datetime.utcnow()
        db.commit()
        db.refresh(existing)
        return existing

    ans = schemas.InterviewAnswer(
        interview_id=interview_id,
        interview_question_id=question_id,
        candidate_answer=candidate_answer,
        transcript=candidate_answer,
        audio_file_path=audio_file_path,
        audio_mime_type=audio_mime_type,
        score=score,
        feedback=feedback,
    )
    db.add(ans)
    db.commit()
    db.refresh(ans)
    return ans


def complete_interview(db: Session, interview_id: int, overall_score: float, summary: str) -> schemas.Interview:
    interview = get_interview(db, interview_id)
    interview.is_completed = True
    interview.overall_score = overall_score
    interview.evaluation_summary = summary
    interview.completed_at = datetime.datetime.utcnow()
    db.commit()
    db.refresh(interview)
    return interview


# ─────────────────────────────────────────────
# Recommendation operations
# ─────────────────────────────────────────────

def get_recommendation(db: Session, candidate_id: int) -> schemas.Recommendation | None:
    return (
        db.query(schemas.Recommendation)
        .filter(schemas.Recommendation.candidate_id == candidate_id)
        .first()
    )


def upsert_recommendation(db: Session, candidate_id: int, rec_data: dict) -> schemas.Recommendation:
    existing = get_recommendation(db, candidate_id)
    if existing:
        for k, v in rec_data.items():
            setattr(existing, k, v)
        existing.updated_at = datetime.datetime.utcnow()
        db.commit()
        db.refresh(existing)
        return existing

    rec = schemas.Recommendation(candidate_id=candidate_id, **rec_data)
    db.add(rec)
    db.commit()
    db.refresh(rec)
    return rec


def apply_hr_override(
    db: Session, candidate_id: int, verdict: str, notes: str
) -> schemas.Recommendation | None:
    rec = get_recommendation(db, candidate_id)
    if rec:
        rec.hr_override_verdict = verdict
        rec.hr_notes = notes
        rec.updated_at = datetime.datetime.utcnow()
        db.commit()
        db.refresh(rec)
    return rec


# ─────────────────────────────────────────────
# Email log operations
# ─────────────────────────────────────────────

def get_pending_emails(db: Session) -> list[schemas.EmailLog]:
    return db.query(schemas.EmailLog).filter(schemas.EmailLog.status == "Draft").all()


# ─────────────────────────────────────────────
# Audit log
# ─────────────────────────────────────────────

def log_audit(db: Session, user_id: int | None, action: str, details: str) -> None:
    log = schemas.AuditLog(
        user_id=user_id,
        action=action,
        details=details,
        timestamp=datetime.datetime.utcnow(),
    )
    db.add(log)
    db.commit()


# ─────────────────────────────────────────────
# Training & Development operations
# ─────────────────────────────────────────────

def get_employee_by_id(db: Session, employee_id: int):
    return db.query(schemas.Employee).filter(schemas.Employee.id == employee_id).first()


def get_all_employees(db: Session):
    return db.query(schemas.Employee).order_by(schemas.Employee.name).all()


def get_role_template_by_id(db: Session, role_template_id: int):
    return db.query(schemas.RoleTemplate).filter(schemas.RoleTemplate.id == role_template_id).first()


def get_all_role_templates(db: Session):
    return db.query(schemas.RoleTemplate).order_by(schemas.RoleTemplate.role_title).all()


def get_courses(db: Session):
    return db.query(schemas.Course).order_by(schemas.Course.course_title).all()


class SkillGapAnalysisWrapper:
    def __init__(self, plan_dict):
        self.id = plan_dict.get("id")
        self.employee_id = plan_dict.get("employee_id")
        self.target_role_template_id = plan_dict.get("target_role_template_id")
        self.readiness_score = plan_dict.get("readiness_score")
        import datetime
        analyzed_at_str = plan_dict.get("analyzed_at")
        if analyzed_at_str:
            try:
                self.analyzed_at = datetime.datetime.fromisoformat(analyzed_at_str)
            except Exception:
                self.analyzed_at = datetime.datetime.utcnow()
        else:
            self.analyzed_at = datetime.datetime.utcnow()
        self.skill_gaps = plan_dict.get("skill_gaps")
        self.ai_learning_path = plan_dict.get("ai_learning_path")
        self.recommended_courses = plan_dict.get("recommended_courses")


class CourseAssignmentWrapper:
    def __init__(self, emp_id, course_id, status="Assigned"):
        self.id = course_id
        self.employee_id = emp_id
        self.course_id = course_id
        self.gap_analysis_id = emp_id
        self.status = status
        import datetime
        self.assigned_at = datetime.datetime.utcnow()


def create_skill_gap_analysis(
    db,
    employee_id,
    target_role_template_id,
    readiness_score,
    skill_gaps=None,
    ai_learning_path=None,
    recommended_courses=None,
):
    import datetime
    emp = db.query(schemas.Employee).filter(schemas.Employee.id == employee_id).first()
    if not emp:
        return None

    # Enrich recommended_courses with status
    courses_list = []
    if recommended_courses:
        for rc in recommended_courses:
            if isinstance(rc, dict):
                rc_dict = dict(rc)
            else:
                rc_dict = {
                    "id": getattr(rc, "id", None),
                    "course_title": getattr(rc, "course_title", ""),
                    "skills_covered": getattr(rc, "skills_covered", []),
                    "description": getattr(rc, "description", ""),
                    "url": getattr(rc, "url", ""),
                }
            if "assigned" not in rc_dict:
                rc_dict["assigned"] = False
            if "status" not in rc_dict:
                rc_dict["status"] = "Recommended"
            courses_list.append(rc_dict)

    plan = {
        "id": employee_id,  # Analysis ID mapped to employee_id
        "employee_id": employee_id,
        "target_role_template_id": target_role_template_id,
        "readiness_score": readiness_score,
        "analyzed_at": datetime.datetime.utcnow().isoformat(),
        "skill_gaps": skill_gaps or [],
        "ai_learning_path": ai_learning_path,
        "recommended_courses": courses_list,
    }

    emp.training_plan = plan
    from sqlalchemy.orm.attributes import flag_modified
    flag_modified(emp, "training_plan")
    db.commit()
    db.refresh(emp)
    return SkillGapAnalysisWrapper(emp.training_plan)


def get_skill_gap_analysis(db: Session, analysis_id: int):
    # analysis_id maps to employee_id
    emp = db.query(schemas.Employee).filter(schemas.Employee.id == analysis_id).first()
    if not emp or not emp.training_plan:
        return None
    return SkillGapAnalysisWrapper(emp.training_plan)


def get_skill_gap_analyses_by_employee(db: Session, employee_id: int):
    emp = db.query(schemas.Employee).filter(schemas.Employee.id == employee_id).first()
    if not emp or not emp.training_plan:
        return []
    return [SkillGapAnalysisWrapper(emp.training_plan)]


def create_course_assignment(db: Session, employee_id: int, course_id: int, gap_analysis_id: int):
    emp = db.query(schemas.Employee).filter(schemas.Employee.id == employee_id).first()
    if not emp or not emp.training_plan:
        return None

    plan = dict(emp.training_plan)
    courses = plan.get("recommended_courses", [])
    updated = False
    for rc in courses:
        cid = rc.get("course_id") or rc.get("id") or rc.get("course", {}).get("course_id") or rc.get("course", {}).get("id")
        if cid == course_id or str(cid) == str(course_id):
            rc["assigned"] = True
            rc["status"] = "Assigned"
            if "course" in rc:
                rc["course"]["assigned"] = True
                rc["course"]["status"] = "Assigned"
            updated = True

    if updated:
        from sqlalchemy.orm.attributes import flag_modified
        emp.training_plan = plan
        flag_modified(emp, "training_plan")
        db.commit()
        db.refresh(emp)

    return CourseAssignmentWrapper(employee_id, course_id, "Assigned")


def get_course_assignments_by_analysis(db: Session, gap_analysis_id: int):
    # gap_analysis_id is the employee_id
    emp = db.query(schemas.Employee).filter(schemas.Employee.id == gap_analysis_id).first()
    if not emp or not emp.training_plan:
        return []

    assignments = []
    courses = emp.training_plan.get("recommended_courses", [])
    for rc in courses:
        cid = rc.get("course_id") or rc.get("id") or rc.get("course", {}).get("course_id") or rc.get("course", {}).get("id")
        assigned = rc.get("assigned") or rc.get("course", {}).get("assigned")
        status = rc.get("status") or rc.get("course", {}).get("status") or "Assigned"
        if assigned or status in ("Assigned", "In_Progress", "Completed"):
            assignments.append(CourseAssignmentWrapper(gap_analysis_id, cid, status))
    return assignments
