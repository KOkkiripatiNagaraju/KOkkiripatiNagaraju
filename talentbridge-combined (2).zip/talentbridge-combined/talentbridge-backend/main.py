import logging
import uvicorn
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from sqlalchemy import text

from config.database import Base, engine
from models import schemas
from models import onboarding_models  # noqa: F401 — registers onboarding tables with Base
from models import hr_chatbot_models  # noqa: F401 — registers HR chatbot tables with Base
from routers import api, training
from routers import hr_policy as hr_policy_router
from routers import pulse_survey as pulse_survey_router

# ── Logging ────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)


def ensure_runtime_schema() -> None:
    """Add columns used by newer features when running without Alembic."""
    statements = [
        "ALTER TABLE interviews ADD COLUMN IF NOT EXISTS scheduled_at TIMESTAMP",
        "ALTER TABLE interviews ADD COLUMN IF NOT EXISTS join_token VARCHAR",
        "ALTER TABLE interviews ADD COLUMN IF NOT EXISTS join_token_created_at TIMESTAMP",
        "ALTER TABLE interviews ADD COLUMN IF NOT EXISTS join_token_expires_at TIMESTAMP",
        "ALTER TABLE interview_answers ADD COLUMN IF NOT EXISTS transcript TEXT",
        "ALTER TABLE interview_answers ADD COLUMN IF NOT EXISTS audio_file_path VARCHAR",
        "ALTER TABLE interview_answers ADD COLUMN IF NOT EXISTS audio_mime_type VARCHAR",
        "CREATE UNIQUE INDEX IF NOT EXISTS ix_interviews_join_token ON interviews (join_token)",
        # Pulse Survey: extend survey_questions with type/options/sequence
        "ALTER TABLE survey_questions ADD COLUMN IF NOT EXISTS type VARCHAR DEFAULT 'text'",
        "ALTER TABLE survey_questions ADD COLUMN IF NOT EXISTS options JSON",
        "ALTER TABLE survey_questions ADD COLUMN IF NOT EXISTS sequence INTEGER DEFAULT 1",
        # Pulse Survey: extend policies with category and embedding
        "ALTER TABLE policies ADD COLUMN IF NOT EXISTS category VARCHAR DEFAULT 'general'",
        "ALTER TABLE policies ADD COLUMN IF NOT EXISTS embedding JSON",
        # Pulse Survey: add last_survey_submission to employees for cooldown tracking
        "ALTER TABLE employees ADD COLUMN IF NOT EXISTS last_survey_submission TIMESTAMP",
        # Exit Management (Functionality 6): Create resignations table if not already present
        """
        CREATE TABLE IF NOT EXISTS resignations (
            id SERIAL PRIMARY KEY,
            employee_id INTEGER NOT NULL,
            employee_code VARCHAR NOT NULL,
            name VARCHAR NOT NULL,
            email VARCHAR NOT NULL,
            department VARCHAR,
            designation VARCHAR,
            resigned_at TIMESTAMP DEFAULT NOW(),
            audio_uploaded BOOLEAN DEFAULT FALSE,
            analysis_done BOOLEAN DEFAULT FALSE,
            transcript TEXT,
            sentiment_score FLOAT,
            hr_report TEXT,
            s3_report_path VARCHAR
        )
        """,
        "CREATE INDEX IF NOT EXISTS ix_resignations_email ON resignations (email)",
        "CREATE INDEX IF NOT EXISTS ix_resignations_id ON resignations (id)",
    ]
    with engine.begin() as conn:
        for statement in statements:
            conn.execute(text(statement))



# ── Lifespan ───────────────────────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Creating database tables if they don't exist...")
    Base.metadata.create_all(bind=engine)
    ensure_runtime_schema()
    # Seed pulse survey data if not already present
    from config.database import SessionLocal
    from services.pulse_survey_crud import seed_pulse_survey
    from services.pulse_rag_service import pulse_rag_service
    db = SessionLocal()
    try:
        seed_pulse_survey(db)
        pulse_rag_service.seed_policies_if_empty(db)
    except Exception as e:
        logger.warning(f"Pulse survey seeding skipped or failed: {e}")
    finally:
        db.close()
    logger.info("AI Recruitment System started successfully.")
    yield


# ── App ────────────────────────────────────────────────────────────────────
app = FastAPI(
    title="AI Recruitment Orchestration System",
    description=(
        "An AI-powered recruitment platform that automates resume parsing, "
        "ATS scoring, semantic matching, interview generation, and decision support."
    ),
    version="2.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan,
)

# ── CORS ───────────────────────────────────────────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],   # Restrict in production: e.g. ["https://yourdomain.com"]
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Routes ─────────────────────────────────────────────────────────────────
app.include_router(api.router)
app.include_router(training.router, prefix="/api")
app.include_router(hr_policy_router.router, prefix="/api")
app.include_router(pulse_survey_router.router, prefix="/api")


@app.get("/health", tags=["System"])
def health_check():
    """Simple health check endpoint."""
    return {"status": "healthy", "service": "AI Recruitment Orchestration System"}


# ── Entry Point ────────────────────────────────────────────────────────────
if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
