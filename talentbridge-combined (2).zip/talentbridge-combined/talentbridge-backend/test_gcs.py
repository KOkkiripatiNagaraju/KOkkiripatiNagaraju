from google import genai

client = genai.Client(
    vertexai=True,
    project="hr-portal-500307",
    location="us-central1"
)
print(client.models.generate_content(model="gemini-2.5-flash", contents="say hello").text)