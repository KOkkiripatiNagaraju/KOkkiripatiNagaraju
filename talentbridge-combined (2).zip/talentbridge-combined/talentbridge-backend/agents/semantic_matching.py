import logging
from utils.llm_client import get_embedding, cosine_similarity, invoke_llm, LLM_UNAVAILABLE, EMBEDDING_UNAVAILABLE

logger = logging.getLogger(__name__)

# Sentinel score returned when embeddings are unavailable.
# ATSScoringAgent checks for this and reweights accordingly.
SEMANTIC_UNAVAILABLE = -1.0


class SemanticMatchingAgent:
    def evaluate_match(self, job_desc: str, resume_text: str) -> tuple[float, str]:
        """
        Compute a semantic similarity score between a job description and a resume.

        Returns:
            (score_0_to_100, explanation_string)
            score is SEMANTIC_UNAVAILABLE (-1.0) when embeddings could not be generated.
        """
        job_emb = get_embedding(job_desc)
        res_emb = get_embedding(resume_text)

        if job_emb is EMBEDDING_UNAVAILABLE or res_emb is EMBEDDING_UNAVAILABLE:
            logger.warning("SemanticMatching: embeddings unavailable, returning sentinel score.")
            return SEMANTIC_UNAVAILABLE, "Semantic similarity could not be computed (embedding service unavailable)."

        similarity = cosine_similarity(job_emb, res_emb)
        score = round(similarity * 100, 2)

        explanation_prompt = f"""
In exactly 2 sentences, explain why this resume does or does not match the job description.
Be specific about key skills or experience gaps.

Job Description (excerpt):
{job_desc[:400]}

Resume (excerpt):
{resume_text[:400]}
"""
        explanation = invoke_llm(explanation_prompt, max_tokens=1024)

        if explanation == LLM_UNAVAILABLE:
            explanation = (
                f"Semantic similarity score is {score:.1f}%. "
                "Manual review is recommended to verify alignment with role requirements."
            )

        return score, explanation.strip()