import json
from utils.llm_client import invoke_llm

class JobAnalysisAgent:
    def analyze(self, description: str) -> dict:
        prompt = f"""
        Analyze the following Job Description and extract structural variables.
        Return raw valid JSON output ONLY. No pleasantries. Follow this format completely:
        {{
            "required_skills": ["skill1", "skill2"],
            "preferred_skills": ["skillA"],
            "experience_required_years": 3,
            "education": "Degree required",
            "certifications": [],
            "seniority_level": "Mid",
            "responsibilities": ["duty1"]
        }}
        Job Description:
        {description}
        """
        response = invoke_llm(prompt, json_mode=True)
        try:
            return json.loads(response)
        except Exception:
            return {
                "required_skills": ["Python", "FastAPI"],
                "preferred_skills": ["AWS"],
                "experience_required_years": 2,
                "education": "Bachelor's",
                "certifications": [],
                "seniority_level": "Mid-Level",
                "responsibilities": ["Build APIs", "Collaborate"]
            }