# import json
# import logging
# from utils.llm_client import invoke_llm, LLM_UNAVAILABLE
# from agents.semantic_matching import SEMANTIC_UNAVAILABLE

# logger = logging.getLogger(__name__)

# # Scoring weights (must sum to 1.0)
# WEIGHTS = {
#     "skills_match":    0.20,
#     "experience_match": 0.10,
#     "project_relevance": 0.10,
#     "education_score": 0.15,
#     "certification_score": 0.05,
#     "semantic_similarity": 0.40,
# }

# # Weights used when semantic similarity is unavailable (redistributed proportionally)
# WEIGHTS_NO_SEMANTIC = {
#     "skills_match":    0.34,
#     "experience_match": 0.17,
#     "project_relevance": 0.17,
#     "education_score": 0.24,
#     "certification_score": 0.08,
#     "semantic_similarity": 0.00,
# }


# class ATSScoringAgent:
#     def calculate_score(self, job_profile: dict, cand_profile: dict, semantic_score: float) -> dict:
#         """
#         Compute a weighted ATS score and generate LLM-powered insights.

#         Args:
#             job_profile:    Structured job requirements from JobAnalysisAgent.
#             cand_profile:   Parsed candidate profile from ResumeParsingAgent.
#             semantic_score: 0–100 similarity score from SemanticMatchingAgent.

#         Returns:
#             Full scoring dict ready to persist via crud.save_ats_score.
#         """
#         # ── Skills match ────────────────────────────────────────────────
#         req_skills = [s.lower() for s in job_profile.get("required_skills", [])]
#         cand_skills = [s.lower() for s in cand_profile.get("skills", [])]
#         matched_skills = [s for s in cand_skills if s in req_skills]

#         if not req_skills:
#             # No required skills defined — neutral score, not a perfect 80
#             skills_match_pct = 50.0
#         else:
#             skills_match_pct = (len(matched_skills) / len(req_skills) * 100)

#         # ── Experience match ─────────────────────────────────────────────
#         req_exp = float(job_profile.get("experience_required_years", 0))
#         cand_exp_val = cand_profile.get("experience_years")
        
#         # Safely parse candidate experience and check if they have any mentioned experience
#         if cand_exp_val is None:
#             cand_exp = 0.0
#             has_experience = False
#         else:
#             try:
#                 cand_exp = float(cand_exp_val)
#                 has_experience = cand_exp > 0.0
#             except (ValueError, TypeError):
#                 cand_exp = 0.0
#                 has_experience = False

#         if not has_experience:
#             # If no experience is found/mentioned in the resume, score it as 0%
#             exp_match_pct = 0.0
#         elif req_exp <= 0:
#             exp_match_pct = 100.0
#         elif cand_exp >= req_exp:
#             exp_match_pct = 100.0
#         else:
#             exp_match_pct = round(cand_exp / req_exp * 100, 2)

#         # ── Project relevance ────────────────────────────────────────────
#         proj_rel = 85.0 if cand_profile.get("projects") else 50.0

#         # ── Education match ──────────────────────────────────────────────
#         req_edu = job_profile.get("education", "").lower()
#         cand_edu_str = str(cand_profile.get("education", "")).lower()
#         edu_score = 90.0 if (req_edu and req_edu in cand_edu_str) else 70.0

#         # ── Certification match ──────────────────────────────────────────
#         req_certs = job_profile.get("certifications", [])
#         cand_certs = cand_profile.get("certifications", [])
#         cert_score = 100.0 if len(cand_certs) >= len(req_certs) else 50.0

#         # ── Weighted total ───────────────────────────────────────────────
#         semantic_available = semantic_score != SEMANTIC_UNAVAILABLE
#         w = WEIGHTS if semantic_available else WEIGHTS_NO_SEMANTIC
#         effective_semantic = semantic_score if semantic_available else 0.0

#         total_ats = (
#             skills_match_pct   * w["skills_match"]
#             + exp_match_pct      * w["experience_match"]
#             + proj_rel           * w["project_relevance"]
#             + edu_score          * w["education_score"]
#             + cert_score         * w["certification_score"]
#             + effective_semantic * w["semantic_similarity"]
#         )

#         # ── LLM insight generation ────────────────────────────────────────
#         missing_skills = [s for s in req_skills if s not in cand_skills]
#         insight = self._generate_insights(req_skills, cand_skills, missing_skills)

#         return {
#             "skills_match":        round(skills_match_pct, 2),
#             "experience_match":    round(exp_match_pct, 2),
#             "project_relevance":   round(proj_rel, 2),
#             "education_score":     round(edu_score, 2),
#             "certification_score": round(cert_score, 2),
#             "semantic_similarity": round(effective_semantic, 2),
#             "total_score":         round(total_ats, 2),
#             "strengths":           insight.get("strengths"),
#             "skill_gaps":          insight.get("skill_gaps"),
#             "recommendation":      insight.get("recommendation"),
#         }

#     def _generate_insights(self, req_skills: list, cand_skills: list, missing_skills: list) -> dict:
#         """Use LLM to summarise strengths, gaps and a hiring recommendation."""
#         matched = [s for s in cand_skills if s in req_skills]

#         prompt = f"""
# You are a technical recruiter reviewing a candidate profile.

# Required skills: {req_skills}
# Candidate skills: {cand_skills}
# Matched skills:  {matched}
# Missing skills:  {missing_skills}

# Return ONLY a valid JSON object with exactly these keys:
# {{
#     "strengths": ["2-3 specific strength points based on matched skills"],
#     "skill_gaps": ["list only the genuinely missing skills"],
#     "recommendation": "One concise sentence recommending the next hiring step."
# }}
# """
#         raw = invoke_llm(prompt, json_mode=True)

#         if raw == LLM_UNAVAILABLE:
#             return self._fallback_insights(matched, missing_skills)

#         try:
#             parsed = json.loads(raw)
#             return {
#                 "strengths":      list(parsed.get("strengths") or []),
#                 "skill_gaps":     list(parsed.get("skill_gaps") or missing_skills),
#                 "recommendation": str(parsed.get("recommendation") or "Proceed to the next evaluation stage."),
#             }
#         except json.JSONDecodeError:
#             logger.warning("ATSScoring: LLM insights JSON parse failed.")
#             return self._fallback_insights(matched, missing_skills)

#     @staticmethod
#     def _fallback_insights(matched: list, missing_skills: list) -> dict:
#         strengths = (
#             [f"Strong foundation in {', '.join(matched[:3])}."] if matched
#             else ["Candidate profile requires further review."]
#         )
#         return {
#             "strengths": strengths,
#             "skill_gaps": missing_skills,
#             "recommendation": (
#                 "Advance to technical screening." if not missing_skills
#                 else f"Review gaps in: {', '.join(missing_skills[:3])} before proceeding."
#             ),
#         }
import json
import logging
import re
from utils.llm_client import invoke_llm, LLM_UNAVAILABLE
from agents.semantic_matching import SEMANTIC_UNAVAILABLE

logger = logging.getLogger(__name__)

# Scoring weights (must sum to 1.0)
WEIGHTS = {
    "skills_match":         0.30,
    "experience_match":     0.15,
    "project_relevance":    0.10,
    "education_score":      0.05,
    "certification_score":  0.05,
    "semantic_similarity":  0.35,
}

# Weights used when semantic similarity is unavailable (redistributed proportionally)
WEIGHTS_NO_SEMANTIC = {
    "skills_match":        0.46,
    "experience_match":     0.23,
    "project_relevance":    0.15,
    "education_score":      0.08,
    "certification_score":  0.08,
    "semantic_similarity":  0.0,
}

# ---------------------------------------------------------
# Normalize skills
# ---------------------------------------------------------
SKILL_ALIASES = {
    "node": "nodejs",
    "node.js": "nodejs",
    "nodejs": "nodejs",

    "js": "javascript",
    "javascript": "javascript",

    "py": "python",
    "python3": "python",
    "python": "python",

    "ml": "machine learning",
    "machine learning": "machine learning",

    "ai": "artificial intelligence",

    "reactjs": "react",
    "react.js": "react",

    "postgres": "postgresql",
    "postgresql": "postgresql",

    "mongo": "mongodb",
    "mongo db": "mongodb",
    "mongodb": "mongodb",

    "aws cloud": "aws",
    "amazon web services": "aws"
}


def normalize_skill(skill):
    skill = skill.lower().strip()
    skill = re.sub(r"[^\w\s+#]", "", skill)
    return SKILL_ALIASES.get(skill, skill)


class ATSScoringAgent:
    def calculate_score(self, job_profile: dict, cand_profile: dict, semantic_score: float) -> dict:
        """
        Compute a weighted ATS score and generate LLM-powered insights.

        Args:
            job_profile:    Structured job requirements from JobAnalysisAgent.
            cand_profile:   Parsed candidate profile from ResumeParsingAgent.
            semantic_score: 0–100 similarity score from SemanticMatchingAgent.

        Returns:
            Full scoring dict ready to persist via crud.save_ats_score.
        """
        # ── Skills match ────────────────────────────────────────────────
        req_skills = {
            normalize_skill(s)
            for s in job_profile.get("required_skills", [])
        }

        preferred_skills = {
            normalize_skill(s)
            for s in job_profile.get("preferred_skills", [])
        }

        cand_skills = {
            normalize_skill(s)
            for s in cand_profile.get("skills", [])
        }

        required_matches = req_skills & cand_skills
        preferred_matches = preferred_skills & cand_skills

        required_score = (
            len(required_matches) / len(req_skills) * 100
            if req_skills else 100
        )

        preferred_score = (
            len(preferred_matches) / len(preferred_skills) * 100
            if preferred_skills else 100
        )

        skills_match_pct = (
            required_score * 0.8 +
            preferred_score * 0.2
        )

        matched_skills = list(required_matches | preferred_matches)

        # ── Experience match ─────────────────────────────────────────────
        req_exp = float(job_profile.get("experience_required_years", 0))

        try:
            cand_exp = float(cand_profile.get("experience_years", 0))
        except Exception:
            cand_exp = 0

        if req_exp == 0:
            exp_match_pct = 100

        elif cand_exp == 0:
            exp_match_pct = 0

        else:
            ratio = cand_exp / req_exp

            if ratio >= 1.5:
                exp_match_pct = 100

            elif ratio >= 1.0:
                exp_match_pct = 95

            elif ratio >= 0.8:
                exp_match_pct = 80

            elif ratio >= 0.6:
                exp_match_pct = 60

            elif ratio >= 0.4:
                exp_match_pct = 40

            else:
                exp_match_pct = round(ratio * 100, 2)

        # ── Project relevance ────────────────────────────────────────────
        proj_rel = 85.0 if cand_profile.get("projects") else 50.0

        # ── Education match ──────────────────────────────────────────────
        req_edu = job_profile.get("education", "").lower()
        cand_edu_str = str(cand_profile.get("education", "")).lower()
        edu_score = 90.0 if (req_edu and req_edu in cand_edu_str) else 70.0

        # ── Certification match ──────────────────────────────────────────
        req_certs = job_profile.get("certifications", [])
        cand_certs = cand_profile.get("certifications", [])
        cert_score = 100.0 if len(cand_certs) >= len(req_certs) else 50.0

        # ── Weighted total ───────────────────────────────────────────────
        semantic_available = semantic_score != SEMANTIC_UNAVAILABLE
        w = WEIGHTS if semantic_available else WEIGHTS_NO_SEMANTIC
        effective_semantic = semantic_score if semantic_available else 0.0

        total_ats = (
            skills_match_pct     * w["skills_match"]
            + exp_match_pct      * w["experience_match"]
            + proj_rel           * w["project_relevance"]
            + edu_score          * w["education_score"]
            + cert_score         * w["certification_score"]
            + effective_semantic * w["semantic_similarity"]
        )

        # ── LLM insight generation ────────────────────────────────────────
        missing_skills = list(req_skills - cand_skills)
        insight = self._generate_insights(list(req_skills), list(cand_skills), missing_skills)

        return {
            "skills_match":        round(skills_match_pct, 2),
            "experience_match":    round(exp_match_pct, 2),
            "project_relevance":   round(proj_rel, 2),
            "education_score":     round(edu_score, 2),
            "certification_score": round(cert_score, 2),
            "semantic_similarity": round(effective_semantic, 2),
            "total_score":         round(total_ats, 2),
            "strengths":           insight.get("strengths"),
            "skill_gaps":          insight.get("skill_gaps"),
            "recommendation":      insight.get("recommendation"),
        }

    def _generate_insights(self, req_skills: list, cand_skills: list, missing_skills: list) -> dict:
        """Use LLM to summarise strengths, gaps and a hiring recommendation."""
        matched = [s for s in cand_skills if s in req_skills]

        prompt = f"""
You are a technical recruiter reviewing a candidate profile.

Required skills: {req_skills}
Candidate skills: {cand_skills}
Matched skills:  {matched}
Missing skills:  {missing_skills}

Return ONLY a valid JSON object with exactly these keys:
{{
    "strengths": ["2-3 specific strength points based on matched skills"],
    "skill_gaps": ["list only the genuinely missing skills"],
    "recommendation": "One concise sentence recommending the next hiring step."
}}
"""
        raw = invoke_llm(prompt, json_mode=True)

        if raw == LLM_UNAVAILABLE:
            return self._fallback_insights(matched, missing_skills)

        try:
            parsed = json.loads(raw)
            return {
                "strengths":      list(parsed.get("strengths") or []),
                "skill_gaps":     list(parsed.get("skill_gaps") or missing_skills),
                "recommendation": str(parsed.get("recommendation") or "Proceed to the next evaluation stage."),
            }
        except json.JSONDecodeError:
            logger.warning("ATSScoring: LLM insights JSON parse failed.")
            return self._fallback_insights(matched, missing_skills)

    @staticmethod
    def _fallback_insights(matched: list, missing_skills: list) -> dict:
        strengths = (
            [f"Strong foundation in {', '.join(matched[:3])}."] if matched
            else ["Candidate profile requires further review."]
        )
        return {
            "strengths": strengths,
            "skill_gaps": missing_skills,
            "recommendation": (
                "Advance to technical screening." if not missing_skills
                else f"Review gaps in: {', '.join(missing_skills[:3])} before proceeding."
            ),
        }