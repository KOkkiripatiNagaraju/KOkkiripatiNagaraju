import json
import logging
from utils.llm_client import invoke_llm, LLM_UNAVAILABLE

logger = logging.getLogger(__name__)

_STATUS_LABELS = {
    "shortlist":  "application has been shortlisted for further review",
    "interview":  "have been selected for an interview",
    "offer":      "have been selected for a job offer",
    "reject":     "application will not be moving forward at this time",
    "screening":  "application is currently under review",
}


class EmailAgent:
    def generate_draft(self, candidate_name: str, status_type: str, position_title: str) -> dict:
        """
        Generate an HR outreach email draft.

        Args:
            candidate_name: Candidate's full name.
            status_type:    One of: shortlist, interview, offer, reject, screening
                            (or a free-form description for edge cases).
            position_title: The job title being applied for.

        Returns:
            {"subject": str, "body": str (HTML)}
        """
        human_status = _STATUS_LABELS.get(status_type.lower(), status_type)

        prompt = f"""
You are a professional HR coordinator writing a recruitment outreach email.

Candidate name: {candidate_name}
Position: {position_title}
Update: The candidate {human_status}.

Write a warm, professional email. Requirements:
- Polite and encouraging tone regardless of outcome
- Clearly state the update without jargon
- For rejections: brief, kind, and respectful — do not give detailed reasons
- For positive steps: include a clear next-step instruction
- HTML format for the body (use <p>, <br>, <strong> tags only)

Return ONLY a valid JSON object:
{{
    "subject": "Concise and relevant email subject line",
    "body": "<p>HTML email body here</p>"
}}
"""
        raw = invoke_llm(prompt, max_tokens=1024, json_mode=True)

        if raw == LLM_UNAVAILABLE:
            return self._fallback_email(candidate_name, position_title, human_status)

        try:
            result = json.loads(raw)
            subject = str(result.get("subject") or f"Update on your {position_title} application")
            body = str(result.get("body") or "")
            if not body.strip():
                raise ValueError("Empty body")
            return {"subject": subject, "body": body}
        except (json.JSONDecodeError, ValueError):
            logger.warning("EmailAgent: LLM response parse failed.")
            return self._fallback_email(candidate_name, position_title, human_status)

    @staticmethod
    def _fallback_email(candidate_name: str, position_title: str, status_description: str) -> dict:
        return {
            "subject": f"Update regarding your application — {position_title}",
            "body": (
                f"<p>Dear <strong>{candidate_name}</strong>,</p>"
                f"<p>Thank you for your interest in the <strong>{position_title}</strong> position.</p>"
                f"<p>We are writing to let you know that your {status_description}. "
                f"Our team will be in touch with further details shortly.</p>"
                f"<p>If you have any questions in the meantime, please don't hesitate to reach out.</p>"
                f"<p>Best regards,<br><strong>HR Team</strong></p>"
            ),
        }