"""Saves HR policy drafts and versions to the database."""
from typing import Optional
from sqlalchemy.orm import Session

from models.hr_chatbot_models import HRPolicy
from models.hr_chatbot_schemas import HRPolicySaveRequest
from services.hr_policy_service import save_hr_policy


class HRPolicyVersioningAgent:
    """Persists policy drafts and creates version history records."""

    name = "HRPolicyVersioningAgent"

    def save(
        self,
        db: Session,
        req: HRPolicySaveRequest,
        created_by: Optional[str] = None,
    ) -> HRPolicy:
        return save_hr_policy(db, req, created_by=created_by)
