"""Retrieves similar published policies to use as context during generation."""
from sqlalchemy.orm import Session

from models.hr_chatbot_models import HRPolicy, HRPolicyVersion
from utils.hr_text_utils import simple_similarity, split_into_chunks


class HRPolicyRetrieverAgent:
    """Finds similar published HR policies for context during draft generation."""

    name = "HRPolicyRetrieverAgent"

    def retrieve(self, db: Session, query: str, limit: int = 3) -> list[dict]:
        rows = (
            db.query(HRPolicyVersion, HRPolicy)
            .join(HRPolicy, HRPolicyVersion.policy_id == HRPolicy.id)
            .filter(HRPolicyVersion.status == "published")
            .order_by(HRPolicyVersion.created_at.desc())
            .all()
        )

        matches: list[dict] = []
        for version, policy in rows:
            for chunk in split_into_chunks(version.content or ""):
                score = simple_similarity(query, chunk)
                if score > 0:
                    matches.append({
                        "policy_id": str(policy.id),
                        "title": policy.title,
                        "version": version.version_number,
                        "score": round(score, 3),
                        "content": chunk,
                    })

        matches.sort(key=lambda item: item["score"], reverse=True)
        return matches[:limit]
