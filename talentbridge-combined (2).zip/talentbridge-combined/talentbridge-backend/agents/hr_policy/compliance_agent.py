"""Reviews HR policy drafts for compliance, completeness, clarity, and risk."""
import json
from services.hr_bedrock_service import hr_bedrock_service


class HRComplianceReviewAgent:
    """AI compliance reviewer for HR policy drafts."""

    name = "HRComplianceReviewAgent"

    SYSTEM_PROMPT = """\
You are an enterprise HR compliance review agent.
Review the HR policy draft for:
- completeness
- clarity
- fairness and non-discrimination
- privacy and data protection risk
- legal and regulatory compliance risk
- missing approval workflow
- missing effective date or review cycle

Return ONLY strict JSON in this format:
{
  "compliance_score": <number 0-100>,
  "status": "Approved" or "Revisions Needed",
  "risks": [<string>],
  "suggestions": [<string>]
}
"""

    def review(self, policy_text: str) -> dict:
        result = hr_bedrock_service.generate_text(
            self.SYSTEM_PROMPT,
            f"Review this HR policy draft:\n\n{policy_text}",
            max_tokens=1200,
        )

        try:
            start = result.find("{")
            end = result.rfind("}") + 1
            if start >= 0 and end > start:
                return json.loads(result[start:end])
        except Exception:
            pass

        return {
            "compliance_score": 78,
            "status": "Revisions Needed",
            "risks": [
                "AI compliance review returned an unexpected format.",
                "Manual HR / Legal review is strongly recommended before publishing.",
            ],
            "suggestions": [
                "Re-run the compliance review.",
                "Ensure all 9 required sections are present.",
            ],
            "raw_review": result,
        }
