"""Generates or updates HR policy drafts via Amazon Bedrock."""
from services.hr_bedrock_service import hr_bedrock_service


class HRPolicyDraftingAgent:
    """Generates enterprise-grade HR policy drafts using Bedrock."""

    name = "HRPolicyDraftingAgent"

    SYSTEM_PROMPT = """\
You are an enterprise HR policy drafting agent.
Create professional, fair, clear, and audit-ready HR policy content.
Do not generate discriminatory, confidential, illegal, unsafe, or final legal advice.
Always include these sections:
1. Purpose
2. Scope
3. Eligibility
4. Policy Details
5. Approval Workflow
6. Roles and Responsibilities
7. Compliance Notes
8. Effective Date
9. Review Cycle
Output clean Markdown only.
"""

    def generate(self, policy_type: str, title: str, requirements: str,
                 department: str = None, location: str = None,
                 effective_date: str = None,
                 retrieved_context: list[dict] | None = None) -> str:
        context = ""
        if retrieved_context:
            context = "\n\nReference policies/context:\n" + "\n---\n".join(
                f"{item['title']} v{item['version']}\n{item['content']}"
                for item in retrieved_context
            )

        prompt = f"""Create a complete HR policy draft.

Policy Type: {policy_type}
Title: {title}
Department: {department or 'All relevant departments'}
Location: {location or 'All applicable locations'}
Effective Date: {effective_date or 'To be confirmed'}

Requirements:
{requirements}
{context}
"""
        return hr_bedrock_service.generate_text(self.SYSTEM_PROMPT, prompt)

    def update(self, existing_policy: str, update_instructions: str,
               retrieved_context: list[dict] | None = None) -> str:
        context = ""
        if retrieved_context:
            context = "\n\nRelated approved policy context:\n" + "\n---\n".join(
                f"{item['title']} v{item['version']}\n{item['content']}"
                for item in retrieved_context
            )

        prompt = f"""Update the existing HR policy based on the instructions below.

Existing Policy:
{existing_policy}

Update Instructions:
{update_instructions}
{context}

Return:
1. Updated policy in Markdown
2. A brief change summary at the end
"""
        return hr_bedrock_service.generate_text(self.SYSTEM_PROMPT, prompt)
