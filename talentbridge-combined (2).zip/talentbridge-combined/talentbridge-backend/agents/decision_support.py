import logging

logger = logging.getLogger(__name__)

# Verdict thresholds
THRESHOLDS = [
    (90, "Strong Hire"),
    (80, "Hire"),
    (70, "Consider"),
    (60, "Borderline"),
    (0,  "Reject"),
]

JUSTIFICATION_TEMPLATES = {
    "Strong Hire": (
        "The candidate achieved a combined evaluation score of {score:.1f}%, placing them in the top tier. "
        "Their skills, experience, and interview performance all exceed requirements. "
        "Recommend proceeding to offer stage without delay."
    ),
    "Hire": (
        "The candidate scored {score:.1f}% overall, meeting role requirements with solid performance across "
        "technical and behavioral dimensions. Recommend making an offer."
    ),
    "Consider": (
        "The candidate scored {score:.1f}%, showing promise but with some gaps in key areas. "
        "A second-round interview or technical assessment is recommended before a final decision."
    ),
    "Borderline": (
        "The candidate's combined score of {score:.1f}% falls below the hiring threshold. "
        "They may be suitable for a junior variant of this role or re-evaluated after skill development."
    ),
    "Reject": (
        "The candidate scored {score:.1f}%, indicating significant gaps in required skills or experience. "
        "Recommend declining this application at the current time."
    ),
}


class DecisionSupportAgent:
    def formulate_recommendation(self, ats_score: float, interview_avg: float | None) -> dict:
        """
        Produce an AI hiring recommendation.

        Args:
            ats_score:     ATS total score (0–100).
            interview_avg: Average interview score (0–100), or None if not yet interviewed.

        Returns:
            {"ai_rating": float, "ai_verdict": str, "ai_justification": str}
        """
        if interview_avg is not None:
            combined = (ats_score + interview_avg) / 2
        else:
            # Pre-interview: weight ATS score fully, but flag the pending interview
            combined = ats_score

        combined = round(max(0.0, min(100.0, combined)), 2)

        verdict = "Reject"
        for threshold, label in THRESHOLDS:
            if combined >= threshold:
                verdict = label
                break

        justification = JUSTIFICATION_TEMPLATES[verdict].format(score=combined)

        if interview_avg is None:
            justification += " Note: interview has not yet been completed — this rating will update after the interview stage."

        logger.info("Decision: verdict=%s, combined_score=%.2f, interview_avg=%s", verdict, combined, interview_avg)

        return {
            "ai_rating":        combined,
            "ai_verdict":       verdict,
            "ai_justification": justification,
        }