import logging

logger = logging.getLogger(__name__)


class CandidateRankingAgent:
    """
    Ranks candidates for a job by a composite score.

    Ranking priority (descending):
      1. ATS total score  (primary — 35% skills, 25% exp, 15% project, etc.)
      2. Years of experience  (secondary tie-breaker)
      3. Semantic similarity  (tertiary tie-breaker)
    """

    def compute_rankings(self, candidates_with_scores: list) -> list:
        """
        Args:
            candidates_with_scores: List of dicts, each with keys:
                candidate_id (int), ats_score (float),
                experience (float), semantic_score (float)

        Returns:
            The same list sorted by rank, with 'rank' and 'final_score' added.
        """
        if not candidates_with_scores:
            return []

        # Validate required keys
        required_keys = {"candidate_id", "ats_score", "experience", "semantic_score"}
        for item in candidates_with_scores:
            missing = required_keys - item.keys()
            if missing:
                logger.warning("Ranking input missing keys %s for candidate_id=%s", missing, item.get("candidate_id"))
                for k in missing:
                    item[k] = 0.0

        sorted_list = sorted(
            candidates_with_scores,
            key=lambda x: (
                float(x.get("ats_score", 0)),
                float(x.get("experience", 0)),
                float(x.get("semantic_score", 0)),
            ),
            reverse=True,
        )

        for index, cand in enumerate(sorted_list):
            cand["rank"] = index + 1
            # Expose a clean final_score for persistence
            cand["final_score"] = round(float(cand.get("ats_score", 0)), 2)

        logger.info("Rankings computed for %d candidates.", len(sorted_list))
        return sorted_list