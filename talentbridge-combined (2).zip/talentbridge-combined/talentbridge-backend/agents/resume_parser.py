import json
import re
import logging
from utils.llm_client import invoke_llm, LLM_UNAVAILABLE

logger = logging.getLogger(__name__)

_FALLBACK_PROFILE = {
    "name": "",           # empty — callers should treat "" as "not extracted"
    "email": "",
    "phone": "",
    "skills": [],
    "experience_years": 0.0,
    "education": [],
    "certifications": [],
    "projects": [],
    "current_company": "",
}

# ── Regex-based name extractor (fast, no LLM needed) ─────────────────────────

# Common resume name-line patterns (first non-blank lines are usually the name)
_NAME_BLACKLIST = re.compile(
    r"\b(resume|curriculum|vitae|cv|profile|summary|objective|contact|address|"
    r"email|phone|mobile|linkedin|github|portfolio|www|http|@)\b",
    re.IGNORECASE,
)
_LOOKS_LIKE_NAME = re.compile(
    r"^[A-Z][a-zA-Z'\-\.]+(?:\s+[A-Z][a-zA-Z'\-\.]+){1,4}$"
)


def _regex_extract_name(raw_text: str) -> str:
    """
    Attempt to extract a candidate name from the first few lines of the resume
    using heuristics. Returns empty string if nothing plausible is found.
    """
    lines = [ln.strip() for ln in raw_text.splitlines() if ln.strip()]
    for line in lines[:15]:          # name is almost always in the first 15 lines
        # Skip lines that contain typical header/contact words
        if _NAME_BLACKLIST.search(line):
            continue
        # Skip very long lines (not a name)
        if len(line) > 60:
            continue
        # Must look like a proper-cased name (2–5 words, each capitalised)
        if _LOOKS_LIKE_NAME.match(line):
            return line
    return ""


class ResumeParsingAgent:
    def parse(self, raw_text: str) -> dict:
        """
        Parse raw resume text into a structured candidate profile.
        Returns a validated dict even if the LLM fails.
        Name field will be empty string if it cannot be determined
        (callers must treat "" as "unknown", not as a hard mismatch).
        """
        if not raw_text or not raw_text.strip():
            logger.warning("ResumeParser: received empty text.")
            return dict(_FALLBACK_PROFILE)

        prompt = f"""Parse the following resume and extract structured candidate information.
Return ONLY a valid JSON object with exactly these keys:

{{
    "name": "Full Name",
    "email": "email@example.com",
    "phone": "1234567890",
    "skills": ["Skill1", "Skill2"],
    "experience_years": 4.5,
    "education": ["BSc Computer Science - MIT 2020"],
    "certifications": ["AWS Certified Solutions Architect"],
    "projects": ["Project Name: brief description"],
    "current_company": "Company Name"
}}

Important: Extract the candidate's real name from the resume header/top section.
Do NOT use placeholder values like "Unknown Candidate" — if you cannot find the name, use an empty string "".

Resume:
{raw_text}
"""
        raw = invoke_llm(prompt, json_mode=True)

        if raw == LLM_UNAVAILABLE:
            logger.warning("ResumeParser: LLM unavailable, attempting regex name extraction.")
            result = dict(_FALLBACK_PROFILE)
            result["name"] = _regex_extract_name(raw_text)
            return result

        try:
            parsed = json.loads(raw)
            validated = self._validate(parsed)
            # If LLM returned a placeholder/garbage name, try regex as recovery
            name = validated.get("name", "")
            if not name or name.lower() in ("unknown candidate", "unknown", "n/a", "candidate"):
                logger.info("ResumeParser: LLM returned unusable name '%s', trying regex fallback.", name)
                validated["name"] = _regex_extract_name(raw_text)
            return validated
        except json.JSONDecodeError:
            logger.warning("ResumeParser: LLM returned invalid JSON. Raw=%s", raw[:200])
            result = dict(_FALLBACK_PROFILE)
            result["name"] = _regex_extract_name(raw_text)
            return result

    def _validate(self, data: dict) -> dict:
        """Coerce all fields to expected types and fill missing keys."""
        def safe_float(val):
            try:
                return float(val)
            except (TypeError, ValueError):
                return 0.0

        raw_name = str(data.get("name") or "").strip()
        # Reject obvious placeholder values
        if raw_name.lower() in ("unknown candidate", "unknown", "n/a", "none", "candidate", "full name"):
            raw_name = ""

        return {
            "name": raw_name,
            "email": str(data.get("email") or "").strip(),
            "phone": str(data.get("phone") or "").strip(),
            "skills": [str(s) for s in (data.get("skills") or [])],
            "experience_years": safe_float(data.get("experience_years")),
            "education": [str(e) for e in (data.get("education") or [])],
            "certifications": [str(c) for c in (data.get("certifications") or [])],
            "projects": [str(p) for p in (data.get("projects") or [])],
            "current_company": str(data.get("current_company") or "").strip(),
        }
