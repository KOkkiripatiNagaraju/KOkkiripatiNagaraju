"""
HR Chatbot Orchestrator — coordinates guardrail, retrieval, answer generation,
confidence evaluation, and ticket escalation into one workflow.
"""
from typing import Optional

from sqlalchemy.orm import Session

from agents.hr_chatbot.input_guardrail_agent import HRInputGuardrailAgent
from agents.hr_chatbot.policy_retrieval_agent import HRPolicyRetrievalAgent
from agents.hr_chatbot.answer_generation_agent import HRAnswerGenerationAgent
from agents.hr_chatbot.confidence_agent import HRConfidenceAgent
from agents.hr_chatbot.ticket_agent import HRTicketEscalationAgent
from models.hr_chatbot_models import HRChatMessage


class HRChatbotOrchestrator:
    """End-to-end HR chatbot pipeline: guardrail → retrieve → generate → escalate."""

    name = "HRChatbotOrchestrator"

    def __init__(self):
        self.guardrail   = HRInputGuardrailAgent()
        self.retriever   = HRPolicyRetrievalAgent()
        self.generator   = HRAnswerGenerationAgent()
        self.confidence  = HRConfidenceAgent()
        self.ticket_agent = HRTicketEscalationAgent()

    def ask(
        self,
        db: Session,
        question: str,
        employee_id: Optional[str] = None,
        employee_email: Optional[str] = None,
    ) -> dict:
        trace = []

        # ── Step 1: Input guardrail ─────────────────────────────────────────
        guard = self.guardrail.check(question)
        trace.append({"agent": self.guardrail.name, "result": guard})

        if not guard["allowed"]:
            reason_code = guard.get("reason_code", "blocked")

            # ── Greeting, non-HR, or confidential: reply only, NO ticket, NO DB write ──
            if reason_code in ("greeting", "non_hr", "confidential"):
                return {
                    "answer": guard["reason"],
                    "confidence": "n/a",
                    "sources": [],
                    "ticket_created": False,
                    "ticket_id": None,
                    "agent_trace": trace,
                }

            # ── Hard-blocked: create ticket ──────────────────────────────────
            ticket = self.ticket_agent.create(
                db,
                employee_id=employee_id,
                employee_email=employee_email,
                question=question,
                category="Blocked Query",
                priority="High",
                ai_summary=guard["reason"],
                suggested_response="This query was blocked by guardrails and escalated to HR.",
            )
            self._save_message(
                db, question,
                answer=guard["reason"],
                confidence="blocked",
                employee_id=employee_id,
                employee_email=employee_email,
                ticket_created=True,
                ticket_id=str(ticket.id),
            )
            return {
                "answer": guard["reason"],
                "confidence": "blocked",
                "sources": [],
                "ticket_created": True,
                "ticket_id": str(ticket.id),
                "agent_trace": trace,
            }


        # ── Step 2: Policy retrieval ────────────────────────────────────────
        contexts = self.retriever.retrieve(db, question)
        trace.append({
            "agent": self.retriever.name,
            "chunks_found": len(contexts),
            "top_score": contexts[0]["score"] if contexts else 0,
        })

        # ── Step 2.5: Non-HR safety net ─────────────────────────────────────
        # If no policy context found AND the question has no HR-related keyword,
        # it almost certainly slipped past the guardrail keyword list.
        # Return politely WITHOUT raising a ticket.
        if not contexts and not self.guardrail.has_hr_keywords(question):
            non_hr_reply = (
                "🚫 This question doesn't appear to be related to HR policies or workplace matters.\n\n"
                "I can only assist with HR topics such as:\n"
                "• Leave & attendance policies\n"
                "• Work-from-home guidelines\n"
                "• Salary, benefits & reimbursements\n"
                "• Code of conduct & company policies\n\n"
                "Please ask an HR-related question and I'll be happy to help! 😊"
            )
            self._save_message(
                db, question,
                answer=non_hr_reply,
                confidence="non_hr",
                employee_id=employee_id,
                employee_email=employee_email,
                ticket_created=False,
                ticket_id=None,
            )
            return {
                "answer": non_hr_reply,
                "confidence": "non_hr",
                "sources": [],
                "ticket_created": False,
                "ticket_id": None,
                "agent_trace": trace,
            }

        # ── Step 3: Confidence evaluation ───────────────────────────────────
        conf = self.confidence.evaluate(contexts)
        trace.append({"agent": self.confidence.name, "result": conf})

        # ── Step 4: Answer generation ────────────────────────────────────────
        answer = self.generator.generate(question, contexts)
        trace.append({"agent": self.generator.name, "action": "Answer generated"})

        # ── Step 5: Ticket creation (if required) ────────────────────────────
        ticket_created = False
        ticket_id = None

        should_create_ticket = guard.get("requires_ticket") or conf.get("should_escalate")
        if should_create_ticket:
            # Use a meaningful category: "No Policy Found" when no context at all
            no_context = len(contexts) == 0
            ticket_category = "No Policy Found" if no_context else "Policy Clarification"
            ticket_priority = "High" if no_context else ("Medium" if conf["confidence"] == "medium" else "High")
            ticket = self.ticket_agent.create(
                db,
                employee_id=employee_id,
                employee_email=employee_email,
                question=question,
                category=ticket_category,
                priority=ticket_priority,
                ai_summary=conf["reason"],
                suggested_response=answer,
            )
            ticket_created = True
            ticket_id = str(ticket.id)
            trace.append({"agent": self.ticket_agent.name, "ticket_id": ticket_id})

        # ── Step 6: Persist chat message ────────────────────────────────────
        self._save_message(
            db, question, answer,
            confidence=conf["confidence"],
            sources=[{"title": c["title"], "version": c["version"]} for c in contexts],
            employee_id=employee_id,
            employee_email=employee_email,
            ticket_created=ticket_created,
            ticket_id=ticket_id,
        )

        return {
            "answer": answer,
            "confidence": conf["confidence"],
            "sources": [
                {"title": c["title"], "version": c["version"], "score": c["score"]}
                for c in contexts
            ],
            "ticket_created": ticket_created,
            "ticket_id": ticket_id,
            "agent_trace": trace,
        }

    @staticmethod
    def _save_message(
        db: Session,
        question: str,
        answer: str,
        confidence: str,
        employee_id: Optional[str] = None,
        employee_email: Optional[str] = None,
        sources: Optional[list] = None,
        ticket_created: bool = False,
        ticket_id: Optional[str] = None,
    ):
        msg = HRChatMessage(
            employee_id=employee_id,
            employee_email=employee_email,
            question=question,
            answer=answer,
            confidence=confidence,
            sources=sources or [],
            ticket_created=ticket_created,
            ticket_id=ticket_id,
        )
        db.add(msg)
        db.commit()
