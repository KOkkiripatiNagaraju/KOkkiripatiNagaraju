import json
import logging
from utils.llm_client import invoke_llm, LLM_UNAVAILABLE

logger = logging.getLogger(__name__)

_DEFAULT_QUESTIONS = [
    {
        "category": "Technical",
        "difficulty": "Medium",
        "question_text": "Explain the difference between synchronous and asynchronous programming. Give a real-world use case for each.",
        "expected_answer": "Synchronous: blocking execution where each operation waits for the previous. Async: non-blocking using callbacks, promises, or async/await — ideal for I/O-heavy tasks like API calls.",
        "rubric": {"correctness": 60, "clarity": 40},
    },
    {
        "category": "Technical",
        "difficulty": "Medium",
        "question_text": "What is the difference between SQL and NoSQL databases? When would you choose one over the other?",
        "expected_answer": "SQL: relational, structured schemas, ACID compliant, good for complex queries. NoSQL: non-relational, flexible schema, horizontally scalable, good for unstructured/semi-structured data.",
        "rubric": {"correctness": 50, "depth": 30, "clarity": 20},
    },
    {
        "category": "Technical",
        "difficulty": "Hard",
        "question_text": "Explain the concept of microservices architecture. What are the key challenges and how do you address them?",
        "expected_answer": "Decoupled services, independent deployment. Challenges: data consistency (eventual consistency), service communication (API gateways, gRPC), monitoring (distributed tracing).",
        "rubric": {"correctness": 50, "depth": 30, "clarity": 20},
    },
    {
        "category": "Behavioral",
        "difficulty": "Medium",
        "question_text": "Describe a time you had to meet a tight deadline. How did you manage your workload?",
        "expected_answer": "Look for prioritisation, communication with stakeholders, and a concrete outcome.",
        "rubric": {"situation_clarity": 40, "action_taken": 40, "outcome": 20},
    },
    {
        "category": "Situational",
        "difficulty": "Hard",
        "question_text": "A critical bug reaches production just before a major release. Walk me through your response.",
        "expected_answer": "Ideal response covers: immediate mitigation, root-cause analysis, stakeholder communication, and a prevention plan.",
        "rubric": {"decisiveness": 40, "communication": 30, "technical_depth": 30},
    },
    {
        "category": "System Design",
        "difficulty": "Hard",
        "question_text": "Design a rate limiter for an API. What algorithm would you use and how would you scale it?",
        "expected_answer": "Algorithms: Token Bucket, Leaky Bucket, Sliding Window. Scaling: use Redis cluster to keep track of counts across multiple server instances.",
        "rubric": {"technical_depth": 40, "scalability": 30, "communication": 30},
    },
]


class InterviewAgent:
    def generate_questions(
        self,
        job_title: str,
        job_description: str,
        required_skills: list,
        candidate_skills: list,
        candidate_projects: list
    ) -> list:
        """
        Generate a tailored set of exactly 6 interview questions.

        Returns a list of question dicts (category, difficulty,
        question_text, expected_answer, rubric).
        """
        skills_str = ", ".join(str(s) for s in candidate_skills) if candidate_skills else "general software engineering"
        req_skills_str = ", ".join(str(s) for s in required_skills) if required_skills else "general skills"
        projects_str = "; ".join(str(p) for p in candidate_projects) if candidate_projects else "No specific projects listed"

        prompt = f"""
You are a senior technical interviewer. Generate exactly 6 interview questions for a {job_title} role, customized specifically to the candidate's background and projects while meeting the job description.

Job Description:
{job_description}

Required Skills:
{req_skills_str}

Candidate's Stated Skills:
{skills_str}

Candidate's Projects/Experience:
{projects_str}

IMPORTANT Guidelines:
1. Ensure the questions are uniquely tailored to this candidate's projects and skills so that different candidates for the same job get different questions. Do NOT use generic questions. Include references to their specific projects or technologies where appropriate.
2. You MUST generate exactly 6 questions:
   - 3 Technical questions (testing depth in their stated skills/projects as they relate to the job requirements)
   - 1 Behavioral question (STAR-method, tailored to their background)
   - 1 Situational / problem-solving question (tailored to challenges they might face in this role)
   - 1 System Design question (tailored to the role and candidate's experience level)
3. Return ONLY a valid JSON array with exactly this structure per item:
[
    {{
        "category": "Technical",
        "difficulty": "Medium",
        "question_text": "Tailored question text...",
        "expected_answer": "Key points an ideal answer should cover.",
        "rubric": {{"correctness": 50, "communication": 30, "depth": 20}}
    }}
]
"""
        raw = invoke_llm(prompt, max_tokens=2048, json_mode=True)

        if raw == LLM_UNAVAILABLE:
            logger.warning("InterviewAgent: Bedrock unavailable. Using default questions.")
            return _DEFAULT_QUESTIONS

        try:
            questions = json.loads(raw)
            if not isinstance(questions, list) or len(questions) == 0:
                raise ValueError("Expected a non-empty list of questions.")
            return [self._validate_question(q) for q in questions]
        except (json.JSONDecodeError, ValueError) as exc:
            logger.warning("InterviewAgent: Failed to parse LLM response (%s). Using defaults.", exc)
            return _DEFAULT_QUESTIONS

    @staticmethod
    def _validate_question(q: dict) -> dict:
        return {
            "category":        str(q.get("category", "General")),
            "difficulty":      str(q.get("difficulty", "Medium")),
            "question_text":   str(q.get("question_text", "")),
            "expected_answer": str(q.get("expected_answer", "")),
            "rubric":          q.get("rubric") if isinstance(q.get("rubric"), dict) else {"correctness": 50, "communication": 50},
        }