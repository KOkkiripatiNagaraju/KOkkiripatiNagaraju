import json
import logging
from utils.llm_client import invoke_llm, LLM_UNAVAILABLE

logger = logging.getLogger(__name__)


class InterviewEvaluationAgent:
    def evaluate_response(self, question: str, expected: str, actual_answer: str, rubric: dict = None) -> dict:
        """
        Evaluate a candidate's answer against the expected benchmark.

        Args:
            question:      The interview question asked.
            expected:      The expected ideal answer / key points.
            actual_answer: What the candidate actually said.
            rubric:        Optional rubric dict with criteria and their weights.

        Returns:
            {"score": float (0–100), "feedback": str}
        """
        if not actual_answer or not actual_answer.strip():
            return {
                "score": 0.0,
                "feedback": "No answer was provided. Score recorded as 0."
            }

        rubric_text = ""
        if rubric:
            rubric_text = f"\nEvaluation rubric (criteria: weight): {json.dumps(rubric)}"

        prompt = f"""
You are an expert interviewer evaluating a candidate's answer. Be highly objective, strict, and unbiased. Do not give default, generic, or overly generous scores.

Question: {question}

Expected key points/rubric guidelines: {expected}

Candidate's answer: {actual_answer}
{rubric_text}

Evaluation criteria (0-100 scale):
- Accuracy and correctness (does the candidate address the core concepts correctly?)
- Depth and detail (is the response complete or is it a brief/vague summary?)
- Clarity and communication
- Relevance to the question

Strict scoring guidelines:
- Penalize vague, short, generic, or dodging answers heavily. A candidate who only restates the question or gives buzzwords without explanation should receive a very low score (e.g. below 40).
- If the candidate answers with generic non-committal statements, penalize them.
- A score above 90 should represent an exceptional, highly detailed, and completely correct response that matches all expected key points.
- A score of 70-85 is a good answer that is mostly complete but has minor gaps.
- A score of 50-69 represents an answer that has major gaps or is very brief.
- A score below 50 represents a wrong, extremely incomplete, or generic placeholder answer.

Return ONLY a valid JSON object:
{{
    "score": 78.5,
    "feedback": "2-3 sentences of specific, constructive feedback explaining the score and any gaps."
}}
"""
        raw = invoke_llm(prompt, max_tokens=512, json_mode=True)

        if raw == LLM_UNAVAILABLE:
            return {
                "score": 70.0,
                "feedback": "Automated evaluation temporarily unavailable. Manual review recommended."
            }

        try:
            result = json.loads(raw)
            score = float(result.get("score", 70.0))
            # Clamp score to valid range
            score = max(0.0, min(100.0, score))
            feedback = str(result.get("feedback", "Review pending."))
            return {"score": round(score, 2), "feedback": feedback}
        except (json.JSONDecodeError, ValueError, TypeError):
            logger.warning("InterviewEvaluation: JSON parse failed. Raw=%s", raw[:200])
            return {
                "score": 70.0,
                "feedback": "Answer partially addresses the question. Further clarification recommended."
            }