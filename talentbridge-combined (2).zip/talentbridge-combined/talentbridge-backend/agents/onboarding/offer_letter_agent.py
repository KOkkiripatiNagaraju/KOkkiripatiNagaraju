"""
Offer Letter Agent — generates professional offer letter text via Vertex AI (Gemini).
Also provides a local PDF renderer using reportlab (already in requirements.txt).
"""
import logging
import os
from decimal import Decimal

from config.onboarding_settings import OnboardingSettings

logger = logging.getLogger(__name__)


SYSTEM_PROMPT = """You are an HR document specialist. Generate concise, professional offer letters.

Rules:
- Maximum 280 words
- No invented benefits, perks, or legal clauses beyond what is provided
- No placeholders like [Company Name] or [Date] — use only what is provided
- Plain text output only, no markdown
- Tone: warm but professional
- Structure exactly as:
  1. Date (top, format: June 16, 2026)
  2. Salutation (Dear <First Name>,)
  3. One sentence — congratulations + role + department + location
  4. One sentence — annual salary (e.g. "Annual CTC: INR 12,00,000")
  5. One sentence — contingency (BGV + documents)
  6. One sentence — next step (accept in the candidate portal)
  7. Sign-off: "HR Onboarding Team\nAI CareerHub"
"""


def _init_vertexai(settings: OnboardingSettings):
    import vertexai
    project  = settings.vertex_project  or os.getenv("VERTEX_PROJECT", "")
    location = settings.vertex_location or os.getenv("VERTEX_LOCATION", "us-central1")
    vertexai.init(project=project, location=location)


class OfferLetterAgent:
    """Generates offer letter text via Vertex AI (Gemini)."""

    def __init__(self, settings: OnboardingSettings):
        self.settings = settings

    def generate(
        self,
        candidate_name: str,
        role: str,
        department: str,
        location: str,
        salary: float,
        salary_notes: dict,
    ) -> str:
        """
        Returns offer letter as plain text.
        Falls back to a local template if Vertex AI fails.
        """
        rationale = salary_notes.get("why", "")
        full_prompt = (
            f"{SYSTEM_PROMPT}\n\n"
            f"Generate an offer letter for:\n"
            f"- Name: {candidate_name}\n"
            f"- Role: {role}\n"
            f"- Department: {department}\n"
            f"- Location: {location}\n"
            f"- Annual Salary: {salary:,.0f}\n"
            f"- Compensation rationale (internal only, do NOT include in letter): {rationale}\n\n"
            "Follow the structure and rules in the system prompt exactly."
        )

        try:
            _init_vertexai(self.settings)
            from vertexai.generative_models import GenerativeModel
            model_id = self.settings.vertex_model_id or "gemini-2.5-flash"
            model = GenerativeModel(model_id)
            response = model.generate_content(full_prompt)
            return (response.text or "").strip()
        except Exception as exc:
            logger.warning("Vertex AI offer letter generation failed, using local template: %s", exc)
            return self._local_template(candidate_name, role, department, location, salary)

    @staticmethod
    def _local_template(
        candidate_name: str,
        role: str,
        department: str,
        location: str,
        salary: float,
    ) -> str:
        import datetime
        today = datetime.date.today().strftime("%B %d, %Y")
        first_name = candidate_name.split()[0] if candidate_name else candidate_name
        return (
            f"{today}\n\n"
            f"Dear {first_name},\n\n"
            f"We are pleased to offer you the position of {role} in the {department} department "
            f"based at {location}.\n\n"
            f"Annual CTC: {salary:,.0f}\n\n"
            "This offer is contingent upon successful completion of Background Verification (BGV) "
            "and submission of required documents.\n\n"
            "Please accept or decline this offer in the Candidate Portal at your earliest convenience.\n\n"
            "Sincerely,\n"
            "HR Onboarding Team\n"
            "AI CareerHub"
        )

    @staticmethod
    def render_pdf(text: str) -> bytes:
        """
        Render offer letter text to PDF using reportlab.
        """
        try:
            from reportlab.lib.pagesizes import letter
            from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
            from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
            from reportlab.lib import colors
            import io

            buffer = io.BytesIO()
            doc = SimpleDocTemplate(
                buffer, pagesize=letter,
                rightMargin=54, leftMargin=54, topMargin=54, bottomMargin=54,
            )
            styles = getSampleStyleSheet()

            title_style = ParagraphStyle(
                "OfferTitle",
                parent=styles["Heading1"],
                fontName="Helvetica-Bold",
                fontSize=20,
                leading=24,
                textColor=colors.HexColor("#002a54"),
                alignment=1,
                spaceAfter=18,
            )
            body_style = ParagraphStyle(
                "OfferBody",
                parent=styles["BodyText"],
                fontName="Helvetica",
                fontSize=10.5,
                leading=16,
                textColor=colors.HexColor("#222222"),
                spaceAfter=10,
            )

            story = [Paragraph("OFFER OF EMPLOYMENT", title_style), Spacer(1, 8)]
            for line in text.splitlines():
                if line.strip():
                    story.append(Paragraph(line.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"), body_style))
                else:
                    story.append(Spacer(1, 6))

            doc.build(story)
            return buffer.getvalue()

        except Exception as exc:
            logger.error("reportlab PDF rendering failed: %s", exc)
            return OfferLetterAgent._minimal_pdf(text)

    @staticmethod
    def _minimal_pdf(text: str) -> bytes:
        """Pure-Python minimal PDF without dependencies."""
        lines = []
        for raw in text.splitlines():
            line = raw.strip()
            if not line:
                lines.append("")
                continue
            while len(line) > 88:
                lines.append(line[:88])
                line = line[88:]
            lines.append(line)

        escaped = [l.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)") for l in lines]
        cmds = ["BT", "/F1 11 Tf", "72 742 Td", "14 TL"]
        for i, l in enumerate(escaped):
            if i:
                cmds.append("T*")
            cmds.append(f"({l}) Tj")
        cmds.append("ET")
        stream = "\n".join(cmds).encode("latin-1", errors="replace")

        objs = [
            b"<< /Type /Catalog /Pages 2 0 R >>",
            b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
            b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>",
            b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
            b"<< /Length " + str(len(stream)).encode() + b" >>\nstream\n" + stream + b"\nendstream",
        ]
        pdf = bytearray(b"%PDF-1.4\n")
        offsets = [0]
        for n, obj in enumerate(objs, 1):
            offsets.append(len(pdf))
            pdf.extend(f"{n} 0 obj\n".encode())
            pdf.extend(obj)
            pdf.extend(b"\nendobj\n")
        xref = len(pdf)
        pdf.extend(f"xref\n0 {len(objs)+1}\n".encode())
        pdf.extend(b"0000000000 65535 f \n")
        for o in offsets[1:]:
            pdf.extend(f"{o:010d} 00000 n \n".encode())
        pdf.extend(f"trailer\n<< /Size {len(objs)+1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n".encode())
        return bytes(pdf)
