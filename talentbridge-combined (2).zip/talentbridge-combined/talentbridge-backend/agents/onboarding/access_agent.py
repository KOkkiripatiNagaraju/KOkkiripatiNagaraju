"""
Access Recommendation Agent — maps employee role/department to birthright access.
Pure Python, no external dependencies.
"""
import logging

logger = logging.getLogger(__name__)


class AccessRecommendationAgent:
    """Maps candidate department/role to standard birthright access items."""

    def recommend(self, role: str, department: str) -> list[dict]:
        dept = department.lower()
        base = [
            {
                "access_name": "HR Portal",
                "access_type": "application",
                "justification": "All employees need self-service HR and profile access.",
            },
            {
                "access_name": "Corporate Email",
                "access_type": "identity",
                "justification": "Required for official communication after identity creation.",
            },
            {
                "access_name": "Company Intranet",
                "access_type": "application",
                "justification": "Standard employee onboarding access.",
            },
        ]

        if any(kw in dept for kw in ("engineer", "dev", "tech", "software", "qa", "data")):
            base.extend([
                {
                    "access_name": "Developer Knowledge Base",
                    "access_type": "application",
                    "justification": "Engineering role requires technical documentation access.",
                },
                {
                    "access_name": "Source Control (Read)",
                    "access_type": "permission-set",
                    "justification": "Birthright read access for engineering onboarding.",
                },
                {
                    "access_name": "CI/CD Pipeline View",
                    "access_type": "application",
                    "justification": "Standard visibility for engineering roles.",
                },
            ])
        elif any(kw in dept for kw in ("hr", "human resource", "talent", "recrui")):
            base.extend([
                {
                    "access_name": "HR Policies & Compliance",
                    "access_type": "application",
                    "justification": "HR department birthright policy and process access.",
                },
                {
                    "access_name": "Recruitment System",
                    "access_type": "application",
                    "justification": "HR staff need access to ATS for daily operations.",
                },
            ])
        elif any(kw in dept for kw in ("finance", "account", "payroll")):
            base.extend([
                {
                    "access_name": "Finance ERP (Read)",
                    "access_type": "application",
                    "justification": "Finance role birthright read access to ERP system.",
                },
            ])
        else:
            base.append({
                "access_name": "Employee Knowledge Base",
                "access_type": "application",
                "justification": "Default department onboarding content.",
            })

        return base
