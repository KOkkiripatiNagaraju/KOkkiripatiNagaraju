"""
Salary Recommendation Agent — queries Vertex AI (Gemini) to recommend
an optimal salary for a candidate given a job's salary range.

Input: candidate profile dict + job salary_range string (e.g. "80000-120000")
Output: (recommended_salary: float, notes: dict)
"""
import json
import logging
import os
from decimal import Decimal

from config.onboarding_settings import OnboardingSettings

logger = logging.getLogger(__name__)


def _init_vertexai(settings: OnboardingSettings):
    import vertexai
    project  = settings.vertex_project  or os.getenv("VERTEX_PROJECT", "")
    location = settings.vertex_location or os.getenv("VERTEX_LOCATION", "us-central1")
    vertexai.init(project=project, location=location)


class SalaryRecommendationAgent:
    """Policy-backed salary recommender using Vertex AI (Gemini)."""

    def __init__(self, settings: OnboardingSettings):
        self.settings = settings

    def recommend(
        self,
        candidate_name: str,
        role: str,
        department: str,
        location: str,
        experience_years: float,
        current_salary: float,
        expected_salary: float,
        salary_range: str,
    ) -> tuple[float, dict]:
        """
        Returns (recommended_salary_float, notes_dict).
        Falls back to midpoint of salary_range if Vertex AI fails.
        """
        low, high = self._parse_range(salary_range, current_salary, expected_salary)

        prompt_text = (
            "You are an expert compensation analyst. Recommend an optimal salary for the candidate.\n\n"
            f"Candidate Profile:\n"
            f"- Name: {candidate_name}\n"
            f"- Role: {role}\n"
            f"- Department: {department}\n"
            f"- Location: {location}\n"
            f"- Years of Experience: {experience_years}\n"
            f"- Current Salary: {current_salary:,.0f}\n"
            f"- Expected Salary: {expected_salary:,.0f}\n\n"
            f"Job Salary Range (approved budget): {salary_range}\n"
            f"  → Parsed lower bound: {low:,.0f}\n"
            f"  → Parsed upper bound: {high:,.0f}\n\n"
            "Guidelines:\n"
            "1. The recommended salary MUST be within the approved budget range (lower bound to upper bound).\n"
            "2. Account for experience level: junior (<3 yrs) near floor, mid (3-6 yrs) mid-range, senior (6+ yrs) near ceiling.\n"
            "3. Consider location cost-of-living: metro cities (Bangalore, Mumbai, Delhi, Hyderabad, Pune, Chennai) get a 10% premium.\n"
            "4. Respect the candidate's expected salary as a guardrail — don't exceed it unless it's below the floor.\n"
            "5. Round to the nearest 1,000.\n\n"
            "Return ONLY a JSON object with keys:\n"
            "- recommended_salary: integer\n"
            "- reason: concise explanation (2-3 sentences)\n"
            "No markdown, no extra text."
        )

        try:
            _init_vertexai(self.settings)
            from vertexai.generative_models import GenerativeModel
            model_id = self.settings.vertex_model_id or "gemini-2.5-flash"
            model = GenerativeModel(model_id)
            response = model.generate_content(prompt_text)
            text = (response.text or "").strip()

            # Strip markdown fences if present
            if text.startswith("```"):
                lines = text.splitlines()
                text = "\n".join(lines[1:-1] if lines[-1].startswith("```") else lines[1:]).strip()

            start, end = text.find("{"), text.rfind("}")
            if start != -1 and end != -1:
                text = text[start : end + 1]

            result = json.loads(text)
            salary = float(result["recommended_salary"])
            salary = max(low, min(high, salary))
            reason = result.get("reason", "Salary computed by Vertex AI.")
            return salary, {
                "agent": "SalaryRecommendationAgent",
                "why": reason,
                "inputs": {
                    "role": role,
                    "experience_years": experience_years,
                    "current_salary": current_salary,
                    "expected_salary": expected_salary,
                    "location": location,
                    "salary_range": salary_range,
                },
                "range_parsed": {"low": low, "high": high},
            }

        except Exception as exc:
            logger.warning("Vertex AI salary recommendation failed, using midpoint: %s", exc)
            midpoint = round((low + high) / 2 / 1000) * 1000
            return midpoint, {
                "agent": "SalaryRecommendationAgent",
                "why": f"Vertex AI unavailable ({exc}). Midpoint of salary range used.",
                "inputs": {"salary_range": salary_range},
                "range_parsed": {"low": low, "high": high},
                "fallback": True,
            }

    @staticmethod
    def _parse_range(salary_range: str, current: float, expected: float) -> tuple[float, float]:
        import re
        nums = re.findall(r"[\d,]+", salary_range.replace(",", ""))
        nums = [float(n.replace(",", "")) for n in nums if n]
        if len(nums) >= 2:
            return min(nums), max(nums)
        if len(nums) == 1:
            return nums[0] * 0.85, nums[0] * 1.15
        low = min(current, expected) * 0.9
        high = max(current, expected) * 1.2
        return low, high
