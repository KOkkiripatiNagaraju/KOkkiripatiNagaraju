"""
BGV Verification Agent — verifies background check documents using Tesseract OCR.

Verification Logic:
  1. Aadhaar Upload:
     - Extract Aadhaar number via OCR.
     - If number unreadable (blur) → HR Review.
     - If number found but MISMATCHES entered number → Rejected.
     - If number matches → extract name from Aadhaar.
     - If name unreadable (blur/garbled) → HR Review.
     - If name is completely different from profile name → Rejected.
     - If name is close but not exact (OCR noise) → HR Review.
     - If both Aadhaar number and name match → Accepted.

  2. PAN Upload:
     - Extract name from PAN card via OCR.
     - If name unreadable → HR Review.
     - If name is completely different from profile name → Rejected.
     - If name matches (fuzzy) → Accepted.

  3. Cross-validation (done when both docs submitted, triggered from service layer).

HR Review means the candidate CANNOT re-upload until HR makes a decision.
"""
import json
import logging
import re
import os
from pathlib import Path
from difflib import SequenceMatcher

from config.onboarding_settings import OnboardingSettings

logger = logging.getLogger(__name__)

# ── Similarity threshold constants ────────────────────────────────────────────
# Ratio >= ACCEPT_THRESHOLD → name match is good (accept)
# Ratio >= REVIEW_THRESHOLD and < ACCEPT_THRESHOLD → OCR garbling likely (review)
# Ratio < REVIEW_THRESHOLD → completely different name (reject)
NAME_ACCEPT_THRESHOLD = 0.85   # e.g. "Maheshwar" vs "Maheshwer" → 0.89 → accept
                               #      "Maheshwar" vs "Mheswr"    → 0.80 → review
NAME_REVIEW_THRESHOLD = 0.50   # e.g. "Maheshwar" vs "Teja"      → 0.15 → reject


def _clean_name(name: str) -> str:
    """Normalize name: lowercase, keep only alphanumeric characters and single spaces."""
    cleaned = re.sub(r'[^a-zA-Z0-9\s]', '', name.lower())
    return " ".join(cleaned.split())


def _best_name_score(profile_name: str, doc_name: str) -> float:
    """Return the best similarity score between profile name and document name/line."""
    p_clean = _clean_name(profile_name)
    d_clean = _clean_name(doc_name)
    
    if not p_clean or not d_clean:
        return 0.0
        
    p_tokens = set(p_clean.split())
    
    # Remove single-letter noise words from document tokens if they are not in the profile tokens
    d_tokens_filtered = [t for t in d_clean.split() if len(t) > 1 or t in p_tokens]
    d_clean_filtered = " ".join(d_tokens_filtered)
    
    if not d_clean_filtered:
        return 0.0
        
    # Check exact match after stripping all spaces (for initials like V S S V vs VSSV)
    p_nospaces = p_clean.replace(" ", "")
    d_nospaces = d_clean_filtered.replace(" ", "")
    if p_nospaces == d_nospaces and len(p_nospaces) > 3:
        return 1.0
        
    # Sequence similarity
    seq = SequenceMatcher(None, p_clean, d_clean_filtered).ratio()
    
    # Token-based overlap
    d_tokens = set(d_tokens_filtered)
    overlap = p_tokens & d_tokens
    tok = len(overlap) / len(p_tokens) if p_tokens else 0.0
    
    return max(seq, tok)



class BGVVerificationAgent:
    """
    BGV verifier using Tesseract OCR.
    Always returns a dict with: decision, confidence, reason, checks.
    """

    def __init__(self, settings: OnboardingSettings):
        self.settings = settings

    def _setup_tesseract(self):
        """Configure pytesseract with the executable path and tessdata prefix from settings or env."""
        try:
            import pytesseract
            tess_cmd = self.settings.tesseract_cmd or os.getenv("TESSERACT_CMD", "")
            # If running inside a Linux environment (like Docker) but the path is a Windows path, ignore it
            if os.name == 'posix' and ('\\' in tess_cmd or ':' in tess_cmd):
                logger.info("POSIX environment detected; ignoring Windows Tesseract path to use system installation.")
                tess_cmd = ""
            if tess_cmd:
                pytesseract.pytesseract.tesseract_cmd = tess_cmd

            # Set TESSDATA_PREFIX so Tesseract can find language data files.
            # First check the env var, then derive from the tesseract exe path.
            tessdata_prefix = os.getenv("TESSDATA_PREFIX", "")
            if not tessdata_prefix and tess_cmd:
                # Derive tessdata dir from the tesseract executable location
                import pathlib
                tess_dir = pathlib.Path(tess_cmd).parent
                candidate_tessdata = tess_dir / "tessdata"
                if candidate_tessdata.exists():
                    tessdata_prefix = str(tess_dir)
            if tessdata_prefix:
                os.environ["TESSDATA_PREFIX"] = tessdata_prefix
                logger.info("TESSDATA_PREFIX set to: %s", tessdata_prefix)
        except ImportError:
            logger.warning("pytesseract not installed.")

    def _find_best_name_in_text(self, profile_name: str, extracted_text: str) -> tuple[str, float]:
        """Scan all lines in extracted text to find the best match for the profile name."""
        lines = [l.strip() for l in extracted_text.split("\n") if l.strip()]
        best_line = ""
        best_score = 0.0

        # Extended set of PAN/Aadhaar header keywords to skip
        header_keywords = [
            "government of india", "govt. of india", "govt of india",
            "भारत सरकार", "unique identification",
            "income tax department", "incometaxdepartment", "incometaxdepartiment",
            "permanent account number", "uidai", "aadhaar",
            "आयकर विभाग", "स्थायी लेखा संख्या",
        ]

        # We also look at combinations of adjacent lines (e.g. sometimes first and last name are on separate lines)
        combined_lines = list(lines)
        for i in range(len(lines) - 1):
            combined_lines.append(f"{lines[i]} {lines[i+1]}")

        for line in combined_lines:
            lower = line.lower()
            # Skip lines that are known header keywords or too short
            if any(kw in lower for kw in header_keywords):
                continue
            if len(line) < 3:
                continue
            # Skip lines that are mostly non-letter characters (OCR garbage)
            alpha_ratio = sum(c.isalpha() for c in line) / max(len(line), 1)
            if alpha_ratio < 0.50:
                continue
            # Skip very long lines (unlikely to be just a name)
            if len(line) > 60:
                continue

            score = _best_name_score(profile_name, line)
            if score > best_score:
                best_score = score
                best_line = line

        return best_line, best_score

    def verify(
        self,
        file_name: str,
        file_bytes: bytes,
        candidate_name: str,
        candidate_email: str,
        doc_type: str = "id_document",   # aadhaar | pan
        identity_no: str | None = None,
    ) -> dict:
        """Main entry point. Returns verification result dict."""
        # Step 1: Local sanity checks (always run)
        local = self._verify_local(file_name, file_bytes, doc_type)
        if local["decision"] == "rejected":
            return local

        # Step 2: OCR-based verification
        return self._verify_with_ocr(
            file_name, file_bytes, candidate_name, candidate_email,
            local, doc_type, identity_no
        )

    def _verify_local(self, file_name: str, file_bytes: bytes, doc_type: str) -> dict:
        """Basic sanity: file type, size."""
        suffix = Path(file_name).suffix.lower()
        allowed = {".pdf", ".png", ".jpg", ".jpeg", ".txt"}
        checks = ["file_received"]

        if suffix not in allowed:
            return {
                "agent": "BGVVerificationAgent",
                "decision": "rejected",
                "confidence": 0.9,
                "reason": f"File type '{suffix}' is not allowed. Accepted: PDF, PNG, JPG, TXT.",
                "checks": checks,
            }
        checks.append("file_type_ok")

        if len(file_bytes) < 50:
            return {
                "agent": "BGVVerificationAgent",
                "decision": "rejected",
                "confidence": 0.9,
                "reason": "Uploaded file is too small to be a valid BGV document.",
                "checks": checks,
            }
        checks.append("size_ok")

        return {"decision": "accepted", "checks": checks}

    def _extract_text(
        self,
        file_name: str,
        file_bytes: bytes,
        candidate_name: str | None = None,
        doc_type: str | None = None,
        identity_no: str | None = None,
    ) -> str:
        """
        Extract text using:
          - pypdf for digital PDFs (text layer).
          - pytesseract (Tesseract OCR) on temporary files to preserve image DPI/metadata.
          - Plain UTF-8 decode for .txt files.
        """
        suffix = Path(file_name).suffix.lower()
        if suffix == ".txt":
            return file_bytes.decode("utf-8", errors="ignore")

        # Try pypdf for digital PDFs first
        if suffix == ".pdf":
            try:
                import pypdf
                from io import BytesIO
                reader = pypdf.PdfReader(BytesIO(file_bytes))
                text = ""
                for page in reader.pages:
                    text += page.extract_text() or ""
                if text.strip():
                    return text
            except Exception as e:
                logger.warning("pypdf extraction failed: %s. Falling back to OCR.", e)

        # Tesseract OCR with robust multi-strategy preprocessing for real-world ID photos
        self._setup_tesseract()
        try:
            import pytesseract
            import tempfile
            from PIL import Image, ImageOps, ImageFilter, ImageEnhance
            from io import BytesIO

            def _evaluate_text_ok(text: str) -> bool:
                """Return True if the text contains a complete match (decision == accepted)."""
                if not text or not text.strip():
                    return False
                if not candidate_name or not doc_type:
                    return False
                
                text_lower = text.lower()
                if doc_type == "aadhaar":
                    is_aadhaar_doc = any(kw in text_lower for kw in [
                        "aadhaar", "uidai", "unique", "government", "india", "identity",
                        "dob", "birth", "male", "female"
                    ])
                    if not is_aadhaar_doc:
                        return False
                    
                    if identity_no:
                        clean_entered = "".join(filter(str.isdigit, identity_no))
                        found_numbers = self._extract_aadhaar_number(text)
                        if clean_entered not in found_numbers:
                            return False
                    
                    doc_name, name_score = self._find_best_name_in_text(candidate_name, text)
                    if name_score >= NAME_ACCEPT_THRESHOLD:
                        return True
                        
                elif doc_type == "pan":
                    is_pan_doc = any(kw in text_lower for kw in [
                        "income tax", "permanent account", "pan", "tax", "department", "govt", "india", "card"
                    ])
                    if not is_pan_doc:
                        return False
                    
                    structured_name = self._extract_name_from_pan(text)
                    structured_score = _best_name_score(candidate_name, structured_name) if structured_name else 0.0
                    broad_name, broad_score = self._find_best_name_in_text(candidate_name, text)
                    if max(structured_score, broad_score) >= NAME_ACCEPT_THRESHOLD:
                        return True
                
                return False

            def _ocr_file_path(path: str, config: str) -> str:
                """Run tesseract directly on a file path."""
                t = pytesseract.image_to_string(path, config=config)
                return t

            def _ocr_pil_image(pil_img, config: str) -> str:
                """Save PIL image to a temp file with 300 DPI and run tesseract."""
                with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as temp_file:
                    temp_path = temp_file.name
                try:
                    pil_img.save(temp_path, format="PNG", dpi=(300, 300))
                    return _ocr_file_path(temp_path, config)
                finally:
                    try:
                        os.unlink(temp_path)
                    except Exception:
                        pass

            def _ocr_variants_lazy(pil_img) -> str:
                """
                Extract text using sequential preprocessing strategies.
                Stops early if a strategy yields a successful match.
                """
                # Strategy 1: Raw image OCR (PSM 6)
                try:
                    t = _ocr_pil_image(pil_img, config="--oem 3 --psm 6")
                    if _evaluate_text_ok(t):
                        logger.info("Lazy OCR matching succeeded on Strategy 1 (Raw PSM 6). Stopping.")
                        return t
                except Exception as e:
                    logger.warning(f"Strategy 1 failed: {e}")
                    t = ""

                successful_texts = [t] if t.strip() else []
                best_score_text = t if t.strip() else ""
                best_score = 0.0
                if t.strip() and candidate_name:
                    _, best_score = self._find_best_name_in_text(candidate_name, t)

                # Preprocess image for further strategies: convert to grayscale
                gray = ImageOps.grayscale(pil_img)
                w, h = gray.size

                # Smart resize:
                # If image is very large, downscale it to max dimension 1800 for speed
                # If image is small, upscale it to max dimension 1200 for OCR accuracy
                max_dim = max(w, h)
                if max_dim > 2000:
                    scale = 1800.0 / max_dim
                    gray = gray.resize((int(w * scale), int(h * scale)), Image.Resampling.LANCZOS)
                elif max_dim < 1000:
                    scale = 1200.0 / max_dim
                    gray = gray.resize((int(w * scale), int(h * scale)), Image.Resampling.LANCZOS)

                # Base preprocessed image: autocontrast + single sharpen
                preproc = ImageOps.autocontrast(gray, cutoff=2)
                preproc = preproc.filter(ImageFilter.SHARPEN)

                # Strategy 2: Preprocessed image + PSM 6
                try:
                    t = _ocr_pil_image(preproc, config="--oem 3 --psm 6")
                    if _evaluate_text_ok(t):
                        logger.info("Lazy OCR matching succeeded on Strategy 2 (Preproc PSM 6). Stopping.")
                        return t
                    if t.strip():
                        successful_texts.append(t)
                        if candidate_name:
                            _, score = self._find_best_name_in_text(candidate_name, t)
                            if score > best_score:
                                best_score = score
                                best_score_text = t
                except Exception as e:
                    logger.warning(f"Strategy 2 failed: {e}")

                # Strategy 3: Preprocessed image + PSM 3 (auto layout)
                try:
                    t = _ocr_pil_image(preproc, config="--oem 3 --psm 3")
                    if _evaluate_text_ok(t):
                        logger.info("Lazy OCR matching succeeded on Strategy 3 (Preproc PSM 3). Stopping.")
                        return t
                    if t.strip():
                        successful_texts.append(t)
                        if candidate_name:
                            _, score = self._find_best_name_in_text(candidate_name, t)
                            if score > best_score:
                                best_score = score
                                best_score_text = t
                except Exception as e:
                    logger.warning(f"Strategy 3 failed: {e}")

                # Strategy 4: Simple threshold 120 + PSM 6
                try:
                    bw = preproc.point(lambda p: 255 if p > 120 else 0)
                    t = _ocr_pil_image(bw, config="--oem 3 --psm 6")
                    if _evaluate_text_ok(t):
                        logger.info("Lazy OCR matching succeeded on Strategy 4 (Threshold 120). Stopping.")
                        return t
                    if t.strip():
                        successful_texts.append(t)
                        if candidate_name:
                            _, score = self._find_best_name_in_text(candidate_name, t)
                            if score > best_score:
                                best_score = score
                                best_score_text = t
                except Exception as e:
                    logger.warning(f"Strategy 4 failed: {e}")

                # If we couldn't find a perfect match, return the best scoring text, or join them
                if best_score_text and best_score >= NAME_REVIEW_THRESHOLD:
                    return best_score_text
                return "\n".join(successful_texts)

            # --- Main OCR execution ---
            # If it's a PDF, we convert its pages to PIL images
            if suffix == ".pdf":
                try:
                    from pdf2image import convert_from_bytes
                    images = convert_from_bytes(file_bytes)
                    all_texts = []
                    for img in images:
                        all_texts.append(_ocr_variants_lazy(img))
                    return "\n".join(all_texts)
                except Exception as pdf_exc:
                    logger.warning("pdf2image/OCR failed for PDF: %s", pdf_exc)
                    return ""
            else:
                # If it's a raw image, we first attempt OCR on the raw file path directly
                # to preserve its original metadata, colors, and DPI.
                # Only if that doesn't yield a perfect match, we open it in PIL and run lazy strategies.
                with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as temp_file:
                    temp_file.write(file_bytes)
                    temp_path = temp_file.name
                
                try:
                    # Strategy 1 (Raw File Path PSM 6)
                    t = _ocr_file_path(temp_path, config="--oem 3 --psm 6")
                    if _evaluate_text_ok(t):
                        logger.info("Lazy OCR matching succeeded on Strategy 1 (Raw File Path PSM 6). Stopping.")
                        return t
                except Exception as e:
                    logger.warning(f"Raw file path Strategy 1 failed: {e}")
                    t = ""
                finally:
                    try:
                        os.unlink(temp_path)
                    except Exception:
                        pass

                # Fallback: Load image and try other strategies
                img = Image.open(BytesIO(file_bytes))
                return _ocr_variants_lazy(img)

        except ImportError:
            logger.warning("pytesseract or Pillow not installed — OCR skipped.")
            return ""
        except Exception as exc:
            logger.warning("OCR extraction error: %s", exc)
            return ""


    def _extract_aadhaar_number(self, text: str) -> list[str]:
        """Find all 12-digit Aadhaar-like numbers in extracted text."""
        # Aadhaar can appear as XXXX XXXX XXXX or XXXXXXXXXXXX
        patterns = re.findall(r'\b\d{4}[\s\-]?\d{4}[\s\-]?\d{4}\b', text)
        return ["".join(filter(str.isdigit, p)) for p in patterns]

    def _extract_name_from_aadhaar(self, text: str) -> str:
        """
        Attempt to extract the name from Aadhaar OCR text.
        Aadhaar cards typically have the name on the first few lines
        after 'Government of India' or before DOB/Year of Birth.
        """
        lines = [l.strip() for l in text.split("\n") if l.strip()]
        # Common Aadhaar header keywords to skip
        skip_keywords = {
            "government of india", "भारत सरकार", "unique identification",
            "uidai", "aadhaar", "आधार", "dob", "date of birth",
            "year of birth", "male", "female", "transgender",
            "download", "digitally signed"
        }
        name_candidates = []
        for line in lines:
            lower = line.lower()
            # Skip lines that are keywords, numbers-only, or very short
            if any(kw in lower for kw in skip_keywords):
                continue
            if re.fullmatch(r'[\d\s\-]+', line):
                continue
            if len(line) < 3:
                continue
            # Skip lines that look like DOB (DD/MM/YYYY)
            if re.search(r'\d{2}/\d{2}/\d{4}', line):
                continue
            # Skip lines that are only punctuation/symbols
            if re.fullmatch(r'[^a-zA-Z\u0900-\u097F]+', line):
                continue
            name_candidates.append(line)

        # The name is usually one of the first non-header lines
        return name_candidates[0] if name_candidates else ""

    def _extract_name_from_pan(self, text: str) -> str:
        """
        Attempt to extract the name from PAN card OCR text.
        PAN cards have the name on the line after 'Name' / 'नाम' label.

        Strategy (in order):
          1. Look for a line whose stripped text is exactly "Name" or "Name:" or
             starts with "नाम" (the Hindi label on Indian PAN cards) and take the
             next non-empty line as the name.
          2. Fall back to scanning all lines and returning the first plausible one
             (skipping headers, PAN numbers, dates, digits-only lines).
        """
        lines = [l.strip() for l in text.split("\n") if l.strip()]
        skip_keywords = {
            "income tax department", "income tax", "permanent account number",
            "permanent account", "govt. of india", "government of india",
            "भारत सरकार", "आयकर विभाग", "स्थायी लेखा",
            "pan", "father", "fathers name", "पिता का नाम", "father's name",
            "date of birth", "dob", "जन्म की तारीख", "signature", "हस्ताक्षर"
        }

        # ── Priority 1: anchored label look-up ───────────────────────────────
        # Indian PAN cards print either "नाम/ Name" or just "Name" before the
        # holder's name.  We detect any line that is primarily a label and grab
        # the very next non-empty line.
        for i, line in enumerate(lines):
            lower = line.lower()
            # Match lines that are purely the Name label (with or without Hindi)
            is_name_label = (
                lower.strip() in ("name", "name:", "naam", "naam:")
                or re.fullmatch(r'[\u0900-\u097F/\s]*name[:\s]*', lower.strip())
                or lower.strip().startswith("नाम")
            )
            if is_name_label:
                # Take the next non-empty line
                for j in range(i + 1, len(lines)):
                    candidate = lines[j].strip()
                    # Skip if the very next line is another label or a PAN number
                    if not candidate:
                        continue
                    cand_lower = candidate.lower()
                    if any(kw in cand_lower for kw in skip_keywords):
                        break  # next label encountered; name should have been here
                    if re.fullmatch(r'[A-Z]{5}\d{4}[A-Z]', candidate):  # PAN number
                        continue
                    if re.fullmatch(r'[\d\s\-/]+', candidate):  # digits only
                        continue
                    # Accept only lines that look like a real name (mostly letters)
                    alpha_ratio = sum(c.isalpha() for c in candidate) / max(len(candidate), 1)
                    if alpha_ratio >= 0.6 and len(candidate) >= 3:
                        return candidate

        # ── Priority 2: fallback scan ─────────────────────────────────────────
        name_candidates = []
        for line in lines:
            lower = line.lower()
            if any(kw in lower for kw in skip_keywords):
                continue
            if re.fullmatch(r'[\d\s\-/]+', line):
                continue
            if len(line) < 3:
                continue
            if re.search(r'\d{2}/\d{2}/\d{4}', line):
                continue
            # Skip PAN number pattern like ABCDE1234F
            if re.fullmatch(r'[A-Z]{5}\d{4}[A-Z]', line):
                continue
            if re.fullmatch(r'[^a-zA-Z\u0900-\u097F]+', line):
                continue
            # Require mostly-alphabetic content to weed out OCR junk
            alpha_ratio = sum(c.isalpha() for c in line) / max(len(line), 1)
            if alpha_ratio < 0.6:
                continue
            name_candidates.append(line)

        return name_candidates[0] if name_candidates else ""

    def _verify_with_ocr(
        self,
        file_name: str,
        file_bytes: bytes,
        candidate_name: str,
        candidate_email: str,
        local_result: dict,
        doc_type: str = "id_document",
        identity_no: str | None = None,
    ) -> dict:
        """Full OCR-based verification following strict BGV rules."""
        base_checks = local_result.get("checks", [])
        extracted_text = self._extract_text(
            file_name, file_bytes,
            candidate_name=candidate_name,
            doc_type=doc_type,
            identity_no=identity_no
        )

        # ── Blur / Unreadable check ───────────────────────────────────────────
        if not extracted_text.strip():
            return {
                "agent": "BGVVerificationAgent",
                "decision": "review",
                "confidence": 0.95,
                "reason": (
                    "The uploaded document appears to be completely blurred or unreadable. "
                    "OCR could not extract any text. Sent to HR for manual review."
                ),
                "checks": base_checks + ["ocr_empty", "hr_review_required"],
            }

        if len(extracted_text.strip()) < 50:
            return {
                "agent": "BGVVerificationAgent",
                "decision": "review",
                "confidence": 0.90,
                "reason": (
                    f"The {doc_type.upper()} document appears very blurry or low-quality — "
                    "only a few characters could be extracted. Sent to HR for manual review."
                ),
                "checks": base_checks + ["ocr_too_short", "hr_review_required"],
            }

        text_lower = extracted_text.lower()

        # ══════════════════════════════════════════════════════════════════════
        # AADHAAR VERIFICATION
        # ══════════════════════════════════════════════════════════════════════
        if doc_type == "aadhaar":

            # ── Doc type sanity: must look like an Aadhaar ───────────────────
            is_aadhaar_doc = any(kw in text_lower for kw in [
                "aadhaar", "uidai", "unique", "government", "india", "identity",
                "dob", "birth", "male", "female", "ఆధార్", "భారత", "ప్రభుత్వం"
            ])
            if not is_aadhaar_doc:
                return {
                    "agent": "BGVVerificationAgent",
                    "decision": "rejected",
                    "confidence": 0.95,
                    "reason": (
                        "Wrong document type: The uploaded file does not appear to be an Aadhaar card. "
                        "Keywords like 'Aadhaar', 'UIDAI', or 'Government of India' were not found."
                    ),
                    "checks": base_checks + ["wrong_doc_type"],
                }

            # Cross-document check: reject if it looks like a PAN card
            if any(kw in text_lower for kw in ["income tax", "permanent account", "permanent account number", "pan card"]):
                return {
                    "agent": "BGVVerificationAgent",
                    "decision": "rejected",
                    "confidence": 0.98,
                    "reason": (
                        "Wrong document type: The uploaded file appears to be a PAN card, "
                        "but you uploaded it in the Aadhaar Card slot. Please upload your Aadhaar card."
                    ),
                    "checks": base_checks + ["wrong_doc_type", "pan_cross_upload"],
                }

            # ── Step 1: Aadhaar Number Check ─────────────────────────────────
            if identity_no:
                clean_entered = "".join(filter(str.isdigit, identity_no))
                found_numbers = self._extract_aadhaar_number(extracted_text)

                if not found_numbers:
                    # OCR could not read the 12-digit number → blur → HR review
                    logger.info("Aadhaar number not found in OCR text for %s", file_name)
                    return {
                        "agent": "BGVVerificationAgent",
                        "decision": "review",
                        "confidence": 0.85,
                        "reason": (
                            "The Aadhaar number could not be read from the document. "
                            "The image may be blurry or the number area is cropped. "
                            "Sent to HR for manual review."
                        ),
                        "checks": base_checks + ["aadhaar_number_unreadable", "hr_review_required"],
                    }

                if clean_entered not in found_numbers:
                    # Number found but it does NOT match → hard reject
                    logger.warning(
                        "Aadhaar mismatch: entered=%s found=%s", clean_entered, found_numbers
                    )
                    return {
                        "agent": "BGVVerificationAgent",
                        "decision": "rejected",
                        "confidence": 1.0,
                        "reason": (
                            f"Aadhaar number mismatch: You entered '{identity_no}', but the uploaded "
                            f"Aadhaar card contains number(s): {', '.join(found_numbers)}. "
                            "Please upload the correct Aadhaar card."
                        ),
                        "checks": base_checks + ["aadhaar_number_mismatch"],
                    }

                # Aadhaar number matched ✓
                logger.info("Aadhaar number match: %s", clean_entered)

            # ── Step 2: Name Check from Aadhaar ──────────────────────────────
            doc_name, name_score = self._find_best_name_in_text(candidate_name, extracted_text)

            if not doc_name:
                return {
                    "agent": "BGVVerificationAgent",
                    "decision": "review",
                    "confidence": 0.80,
                    "reason": (
                        "The name could not be extracted from the Aadhaar card. "
                        "The document may be blurry or the name area is unreadable. "
                        "Sent to HR for manual review."
                    ),
                    "checks": base_checks + ["aadhaar_name_unreadable", "hr_review_required"],
                }

            logger.info(
                "Aadhaar name check: profile='%s' best_doc_line='%s' score=%.2f",
                candidate_name, doc_name, name_score
            )

            if name_score >= NAME_ACCEPT_THRESHOLD:
                return {
                    "agent": "BGVVerificationAgent",
                    "decision": "accepted",
                    "confidence": round(0.85 + name_score * 0.15, 2),
                    "reason": (
                        f"Aadhaar verification successful. "
                        f"Aadhaar number matches. Name on Aadhaar ('{doc_name}') matches "
                        f"candidate profile ('{candidate_name}')."
                    ),
                    "checks": base_checks + ["aadhaar_number_ok", "aadhaar_name_ok"],
                }
            elif name_score >= NAME_REVIEW_THRESHOLD:
                return {
                    "agent": "BGVVerificationAgent",
                    "decision": "review",
                    "confidence": 0.65,
                    "reason": (
                        f"Aadhaar number matched, but the name extracted from the Aadhaar card "
                        f"('{doc_name}') could not be confidently matched to the candidate profile "
                        f"('{candidate_name}'). This may be due to OCR noise or a blurry scan. "
                        "Sent to HR for manual review."
                    ),
                    "checks": base_checks + ["aadhaar_number_ok", "aadhaar_name_ocr_ambiguous", "hr_review_required"],
                }
            else:
                return {
                    "agent": "BGVVerificationAgent",
                    "decision": "rejected",
                    "confidence": 0.92,
                    "reason": (
                        f"Identity mismatch on Aadhaar: The name on the Aadhaar card is '{doc_name}', "
                        f"but the candidate profile name is '{candidate_name}'. "
                        "These names appear to belong to different individuals."
                    ),
                    "checks": base_checks + ["aadhaar_name_mismatch"],
                }

        # ══════════════════════════════════════════════════════════════════════
        # PAN VERIFICATION
        # ══════════════════════════════════════════════════════════════════════
        elif doc_type == "pan":

            # ── Doc type sanity: must look like a PAN ────────────────────────
            is_pan_doc = any(kw in text_lower for kw in [
                "income tax", "permanent account", "pan", "tax", "department", "govt", "india", "card"
            ])
            if not is_pan_doc:
                return {
                    "agent": "BGVVerificationAgent",
                    "decision": "rejected",
                    "confidence": 0.95,
                    "reason": (
                        "Wrong document type: The uploaded file does not appear to be a PAN card. "
                        "Keywords like 'Income Tax Department' or 'Permanent Account Number' were not found."
                    ),
                    "checks": base_checks + ["wrong_doc_type"],
                }

            # Cross-document check: reject if it looks like an Aadhaar card
            if any(kw in text_lower for kw in ["aadhaar", "uidai", "unique identification"]):
                return {
                    "agent": "BGVVerificationAgent",
                    "decision": "rejected",
                    "confidence": 0.98,
                    "reason": (
                        "Wrong document type: The uploaded file appears to be an Aadhaar card, "
                        "but you uploaded it in the PAN Card slot. Please upload your PAN card."
                    ),
                    "checks": base_checks + ["wrong_doc_type", "aadhaar_cross_upload"],
                }

            # ── Name Check from PAN ───────────────────────────────────────────
            # Priority 1: structured extraction anchored to the "Name" label.
            # This avoids OCR junk from holograms / Hindi watermarks.
            structured_name = self._extract_name_from_pan(extracted_text)
            structured_score = _best_name_score(candidate_name, structured_name) if structured_name else 0.0

            # Priority 2: broad best-line scan (fallback)
            broad_name, broad_score = self._find_best_name_in_text(candidate_name, extracted_text)

            # Use whichever gave a higher score; prefer structured when equal
            if structured_score >= broad_score:
                doc_name, name_score = structured_name, structured_score
            else:
                doc_name, name_score = broad_name, broad_score

            logger.info(
                "PAN name check: profile='%s' structured='%s'(%.2f) broad='%s'(%.2f) → using='%s'(%.2f)",
                candidate_name, structured_name, structured_score,
                broad_name, broad_score, doc_name, name_score
            )

            if not doc_name:
                return {
                    "agent": "BGVVerificationAgent",
                    "decision": "review",
                    "confidence": 0.80,
                    "reason": (
                        "The name could not be extracted from the PAN card. "
                        "The document may be blurry or the name area is unreadable. "
                        "Sent to HR for manual review."
                    ),
                    "checks": base_checks + ["pan_name_unreadable", "hr_review_required"],
                }

            if name_score >= NAME_ACCEPT_THRESHOLD:
                return {
                    "agent": "BGVVerificationAgent",
                    "decision": "accepted",
                    "confidence": round(0.85 + name_score * 0.15, 2),
                    "reason": (
                        f"PAN verification successful. "
                        f"Name on PAN ('{doc_name}') matches candidate profile ('{candidate_name}')."
                    ),
                    "checks": base_checks + ["pan_name_ok"],
                }
            elif name_score >= NAME_REVIEW_THRESHOLD:
                return {
                    "agent": "BGVVerificationAgent",
                    "decision": "review",
                    "confidence": 0.65,
                    "reason": (
                        f"The name extracted from the PAN card ('{doc_name}') could not be "
                        f"confidently matched to the candidate profile ('{candidate_name}'). "
                        "This may be due to OCR noise or a blurry scan. "
                        "Sent to HR for manual review."
                    ),
                    "checks": base_checks + ["pan_name_ocr_ambiguous", "hr_review_required"],
                }
            else:
                # ── OCR garbage guard ─────────────────────────────────────────
                # Before hard-rejecting, check if the extracted name looks like
                # OCR noise rather than an actual name. This can happen when the
                # image has glare, holograms, or is low resolution.
                # Signals of OCR garbage:
                #   - Very low alpha ratio (lots of numbers/symbols)
                #   - Very short (< 4 chars) — OCR barely read anything
                #   - Best score is extremely low (< 0.20) — effectively no match found
                alpha_ratio = (
                    sum(c.isalpha() for c in doc_name) / max(len(doc_name), 1)
                )
                is_ocr_garbage = (
                    alpha_ratio < 0.70
                    or len(doc_name.strip()) < 4
                    or name_score < 0.20  # no meaningful match found at all
                )
                if is_ocr_garbage:
                    return {
                        "agent": "BGVVerificationAgent",
                        "decision": "review",
                        "confidence": 0.60,
                        "reason": (
                            "The name area on the PAN card could not be read clearly — "
                            "the OCR output appears to be noise or garbled text, possibly due to "
                            "image quality, glare, or a hologram overlay. "
                            "Sent to HR for manual review."
                        ),
                        "checks": base_checks + ["pan_name_ocr_garbage", "hr_review_required"],
                    }
                return {
                    "agent": "BGVVerificationAgent",
                    "decision": "rejected",
                    "confidence": 0.92,
                    "reason": (
                        f"Identity mismatch on PAN card: The name on the PAN card is '{doc_name}', "
                        f"but the candidate profile name is '{candidate_name}'. "
                        "These names appear to belong to different individuals."
                    ),
                    "checks": base_checks + ["pan_name_mismatch"],
                }

        # ── Unknown doc_type ──────────────────────────────────────────────────
        else:
            return {
                "agent": "BGVVerificationAgent",
                "decision": "review",
                "confidence": 0.5,
                "reason": f"Unknown document type '{doc_type}'. Sent to HR for manual review.",
                "checks": base_checks + ["unknown_doc_type", "hr_review_required"],
            }
