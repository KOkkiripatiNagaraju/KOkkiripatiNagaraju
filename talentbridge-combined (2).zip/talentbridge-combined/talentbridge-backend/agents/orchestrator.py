import logging
from sqlalchemy.orm import Session

from agents.job_analysis import JobAnalysisAgent
from agents.resume_parser import ResumeParsingAgent
from agents.semantic_matching import SemanticMatchingAgent
from agents.ats_scoring import ATSScoringAgent
from agents.candidate_ranking import CandidateRankingAgent
from agents.interview_agent import InterviewAgent
from agents.interview_evaluation import InterviewEvaluationAgent
from agents.decision_support import DecisionSupportAgent
from agents.email_agent import EmailAgent
from models import schemas
from repositories import crud

logger = logging.getLogger(__name__)


class RecruitmentOrchestrator:
    def __init__(self):
        self.job_analysis_agent = JobAnalysisAgent()
        self.resume_parsing_agent = ResumeParsingAgent()
        self.semantic_matching_agent = SemanticMatchingAgent()
        self.ats_scoring_agent = ATSScoringAgent()
        self.candidate_ranking_agent = CandidateRankingAgent()
        self.interview_agent = InterviewAgent()
        self.interview_evaluation_agent = InterviewEvaluationAgent()
        self.decision_support_agent = DecisionSupportAgent()
        self.email_agent = EmailAgent()

    # ─────────────────────────────────────────────────────────────────────
    # Stage 1: Resume Upload Pipeline
    # ─────────────────────────────────────────────────────────────────────

    def pipeline_on_resume_upload(self, db: Session, candidate_id: int, raw_resume_text: str):
        """
        Full pipeline triggered when a resume is uploaded:
          1. Parse resume
          2. Semantic matching
          3. ATS scoring
          4. Candidate ranking (all candidates for the job)
          5. Initial recommendation
          6. Draft outreach email
        """
        candidate = db.query(schemas.Candidate).filter(schemas.Candidate.id == candidate_id).first()
        if not candidate:
            logger.error("Pipeline: candidate_id=%d not found.", candidate_id)
            raise ValueError(f"Candidate {candidate_id} not found.")

        job = db.query(schemas.Job).filter(schemas.Job.id == candidate.job_id).first()
        if not job:
            logger.error("Pipeline: job_id=%d not found.", candidate.job_id)
            raise ValueError(f"Job {candidate.job_id} not found.")

        # ── 1. Parse Resume ──────────────────────────────────────────────
        logger.info("Pipeline [1/6]: Parsing resume for candidate_id=%d", candidate_id)
        parsed_profile = self.resume_parsing_agent.parse(raw_resume_text)

        candidate.parsed_data = parsed_profile
        
        # Only overwrite if current database fields are empty or placeholders
        if not candidate.name or candidate.name in ["Pending", ""]:
            candidate.name = parsed_profile.get("name") or candidate.name
        if not candidate.email or candidate.email in ["pending@placeholder.com", ""]:
            candidate.email = parsed_profile.get("email") or candidate.email
        if not candidate.phone or candidate.phone == "":
            candidate.phone = parsed_profile.get("phone") or candidate.phone

        candidate.skills = parsed_profile.get("skills", [])
        candidate.experience_years = float(parsed_profile.get("experience_years", 0.0))
        candidate.education = parsed_profile.get("education", [])
        candidate.status = "Screening"
        db.commit()

        # ── 2. Semantic Matching ─────────────────────────────────────────
        logger.info("Pipeline [2/6]: Semantic matching for candidate_id=%d", candidate_id)
        match_score, _explanation = self.semantic_matching_agent.evaluate_match(
            job.full_description, raw_resume_text
        )

        # ── 3. ATS Scoring ───────────────────────────────────────────────
        logger.info("Pipeline [3/6]: ATS scoring for candidate_id=%d", candidate_id)
        job_profile = job.structured_profile or {}
        if not job_profile.get("required_skills"):
            job_profile["required_skills"] = job.skills_required or []
        if not job_profile.get("experience_required_years") or float(job_profile.get("experience_required_years", 0)) <= 0:
            if job.experience_required and job.experience_required > 0:
                job_profile["experience_required_years"] = job.experience_required
        ats_data = self.ats_scoring_agent.calculate_score(job_profile, parsed_profile, match_score)
        ats_data["candidate_id"] = candidate.id
        crud.save_ats_score(db, ats_data)

        # ── 4. Candidate Rankings ────────────────────────────────────────
        logger.info("Pipeline [4/6]: Computing rankings for job_id=%d", job.id)
        all_cands = db.query(schemas.Candidate).filter(schemas.Candidate.job_id == job.id).all()
        ranking_inputs = []
        for c in all_cands:
            score_rec = crud.get_ats_score(db, c.id)
            if score_rec:
                ranking_inputs.append({
                    "candidate_id":   c.id,
                    "ats_score":      score_rec.total_score,
                    "experience":     c.experience_years or 0.0,
                    "semantic_score": score_rec.semantic_similarity,
                })

        if ranking_inputs:
            ranked_output = self.candidate_ranking_agent.compute_rankings(ranking_inputs)
            crud.update_rankings(db, job.id, ranked_output)

        # ── 5. Initial AI Recommendation ─────────────────────────────────
        logger.info("Pipeline [5/6]: Generating recommendation for candidate_id=%d", candidate_id)
        rec_data = self.decision_support_agent.formulate_recommendation(ats_data["total_score"], None)
        crud.upsert_recommendation(db, candidate.id, rec_data)

        # ── 6. Draft Email ───────────────────────────────────────────────
        logger.info("Pipeline [6/6]: Drafting email for candidate_id=%d", candidate_id)
        email_draft = self.email_agent.generate_draft(candidate.name, "screening", job.title)
        db_email = schemas.EmailLog(
            candidate_id=candidate.id,
            email_type="Screening Notification",
            subject=email_draft["subject"],
            body=email_draft["body"],
            status="Draft",
        )
        db.add(db_email)
        db.commit()
        logger.info("Pipeline complete for candidate_id=%d, ATS=%.2f", candidate_id, ats_data["total_score"])

    # ─────────────────────────────────────────────────────────────────────
    # Stage 2: Interview Answer Submission
    # ─────────────────────────────────────────────────────────────────────

    def process_interview_answer(
        self,
        db: Session,
        interview_id: int,
        question_id: int,
        candidate_answer: str,
        audio_file_path: str | None = None,
        audio_mime_type: str | None = None,
    ) -> dict:
        """
        Evaluate a single interview answer and persist it.
        If all questions are answered, auto-complete the interview and
        update the candidate's recommendation.
        """
        question = (
            db.query(schemas.InterviewQuestion)
            .filter(schemas.InterviewQuestion.id == question_id)
            .first()
        )
        if not question:
            raise ValueError(f"Question {question_id} not found.")

        # Evaluate the answer
        eval_result = self.interview_evaluation_agent.evaluate_response(
            question=question.question_text,
            expected=question.expected_answer,
            actual_answer=candidate_answer,
            rubric=question.rubric,
        )

        crud.save_interview_answer(
            db,
            interview_id=interview_id,
            question_id=question_id,
            candidate_answer=candidate_answer,
            score=eval_result["score"],
            feedback=eval_result["feedback"],
            audio_file_path=audio_file_path,
            audio_mime_type=audio_mime_type,
        )

        # Advance question index
        interview = crud.get_interview(db, interview_id)
        interview.current_question_index = (interview.current_question_index or 0) + 1
        db.commit()

        # Check if all questions are answered
        all_questions = crud.get_interview_questions(db, interview_id)
        all_answers = (
            db.query(schemas.InterviewAnswer)
            .filter(schemas.InterviewAnswer.interview_id == interview_id)
            .all()
        )

        if len(all_answers) >= len(all_questions):
            self._complete_interview(db, interview, all_answers)

        return eval_result

    def _complete_interview(
        self,
        db: Session,
        interview: schemas.Interview,
        answers: list[schemas.InterviewAnswer],
    ):
        """Finalise the interview: compute overall score, update recommendation."""
        scores = [a.score for a in answers if a.score is not None]
        overall = round(sum(scores) / len(scores), 2) if scores else 0.0

        summary_parts = [f"Q{i+1}: {a.feedback}" for i, a in enumerate(answers) if a.feedback]
        summary = " | ".join(summary_parts[:5])

        crud.complete_interview(db, interview.id, overall, summary)

        # Update recommendation now that we have interview data
        ats_rec = crud.get_ats_score(db, interview.candidate_id)
        ats_score = ats_rec.total_score if ats_rec else 0.0
        rec_data = self.decision_support_agent.formulate_recommendation(ats_score, overall)
        crud.upsert_recommendation(db, interview.candidate_id, rec_data)

        # Update candidate status based on AI verdict
        rec = crud.get_recommendation(db, interview.candidate_id)
        if rec and rec.ai_verdict in ("Strong Hire", "Hire"):
            crud.update_candidate_status(db, interview.candidate_id, "Shortlisted")
        else:
            crud.update_candidate_status(db, interview.candidate_id, "Screening")

        logger.info(
            "Interview completed: interview_id=%d, candidate_id=%d, overall_score=%.2f",
            interview.id, interview.candidate_id, overall
        )
