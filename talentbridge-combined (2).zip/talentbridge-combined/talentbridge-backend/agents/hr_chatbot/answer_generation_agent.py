"""Generates employee-friendly HR answers from approved policy context."""
from services.hr_bedrock_service import hr_bedrock_service


class HRAnswerGenerationAgent:
    """Generates answers from approved HR policy context via Bedrock."""

    name = "HRAnswerGenerationAgent"

    SYSTEM_PROMPT = """\
You are an internal HR assistant for a company.
Rules:
- Answer the employee's question directly, naturally, and conversationally.
- Use only the provided approved HR policy context. Do not make up facts or use outside knowledge.
- Do not reveal confidential employee details.
- Avoid robotic or template-like headers (do NOT output headers like "Direct Answer to the Question" or "Source Policy Name and Version").
- Integrate the source policy title, version, and any required review/approval steps naturally into your conversational response.
- Be concise, professional, and empathetic.
"""

    def generate(self, question: str, contexts: list[dict]) -> str:
        if not contexts:
            return (
                "🎫 I couldn't find a published HR policy that directly covers your question.\n\n"
                "**An HR support ticket has been automatically raised on your behalf.** "
                "The HR team will review your query and get back to you shortly.\n\n"
                "In the meantime, you can track your ticket status in the **My Tickets** section."
            )

        context_text = "\n\n---\n\n".join(
            f"Source: {c['title']} v{c['version']}\n{c['chunk']}"
            for c in contexts
        )

        prompt = f"""Approved HR Policy Context:
{context_text}

Employee Question:
{question}

Write a natural, conversational response answering the employee's question based on the policy context above. 
Make sure to:
1. Answer the question fully and clearly using only details from the context.
2. Naturally mention the source policy name and version in your text (e.g. "According to the Leave and Attendance Policy v1.0...").
3. Clearly mention if any manager or HR approval is required for this request.
Do NOT use a numbered list or bullet points for these elements, and do NOT use literal labels like "Direct Answer to the Question:".
"""
        return hr_bedrock_service.generate_text(self.SYSTEM_PROMPT, prompt, max_tokens=1200)
