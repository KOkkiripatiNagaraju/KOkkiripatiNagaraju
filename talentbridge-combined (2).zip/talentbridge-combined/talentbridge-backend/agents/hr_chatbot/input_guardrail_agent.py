"""
Industry-Grade HR Chatbot Input Guardrail Agent  (v3.0)
=======================================================
7-Tier Classification Pipeline:

  Tier 0  Input normalisation  → typo correction + fuzzy HR-term matching
  Tier 1  GREETING             → friendly reply, no ticket, no DB write
  Tier 2  STRONG NON-HR        → hard block, no ticket
  Tier 3  CONFIDENTIAL         → hard block, no ticket
           • [name] salary / salary [name] (bidirectional)
           • salary/pay of <dept/person>
           • employee names, IDs, contact info
  Tier 4  BLOCKED              → block + ticket (jailbreak / abuse)
  Tier 5  SENSITIVE            → allow + auto-ticket (harassment, legal)
  Tier 6  HR INTENT CHECK      → if no HR keyword after normalisation → non-HR
  Tier 7  ALLOWED              → pass to retrieval pipeline
"""
import re
import difflib


class HRInputGuardrailAgent:
    name = "HRInputGuardrailAgent"

    # ──────────────────────────────────────────────────────────────────────────
    # Tier 0: Typo correction map
    # ──────────────────────────────────────────────────────────────────────────
    TYPO_MAP = {
        # reimbursement
        "reiumbursement": "reimbursement", "reiumbursements": "reimbursements",
        "reimbursment":   "reimbursement", "reimbursments":   "reimbursements",
        "rembursement":   "reimbursement", "reimburse":        "reimbursement",
        "reimbrement":    "reimbursement", "reimburesment":    "reimbursement",
        "riembursement":  "reimbursement", "reumbirsement":    "reimbursement",
        # attendance
        "attendence": "attendance", "atendance": "attendance",
        "attendace":  "attendance", "attandance": "attendance",
        # leave / leaves
        "leav": "leave", "leve": "leave", "leavs": "leaves",
        # salary
        "sallary": "salary", "salery": "salary", "salry": "salary",
        "salaray": "salary",
        # policy
        "policey": "policy", "polisy": "policy", "plicy": "policy",
        # payroll
        "payrol": "payroll", "payrool": "payroll", "payrol": "payroll",
        # holiday
        "holliday": "holiday", "holyday": "holiday",
        # vacation
        "vaction": "vacation", "vaccation": "vacation",
        # performance
        "performence": "performance", "perfomance": "performance",
        # appraisal
        "aprasial": "appraisal", "appriasal": "appraisal",
        # onboarding
        "onbording": "onboarding", "onboardng": "onboarding",
        # resignation
        "resignaton": "resignation", "resgination": "resignation",
        # probation
        "probation": "probation",
        # allowance
        "alowance": "allowance", "allownce": "allowance",
        # expense
        "expence": "expense", "expnse": "expense",
        # insurance
        "insurence": "insurance", "insureance": "insurance",
    }

    # HR vocabulary for fuzzy close-match fallback
    HR_VOCABULARY = [
        "reimbursement", "reimbursements", "attendance", "leave", "leaves",
        "salary", "payroll", "holiday", "vacation", "policy", "policies",
        "performance", "appraisal", "onboarding", "probation", "resignation",
        "allowance", "allowances", "expense", "expenses", "benefits",
        "insurance", "gratuity", "bonus", "increment", "overtime", "shift",
        "grievance", "grievances", "harassment", "disciplinary", "promotion",
        "transfer", "training", "induction", "separation", "notice",
        "payslip", "compensation", "increment", "conduct",
    ]

    # ──────────────────────────────────────────────────────────────────────────
    # Tier 1: Greetings
    # ──────────────────────────────────────────────────────────────────────────
    GREETING_PATTERNS = [
        r"^\s*(hi+|hello+|hey+|howdy|hiya|greetings?|good\s*(morning|afternoon|evening|night|day))\s*(there|all|everyone|team)?\s*[!.,?]*\s*$",
        r"^\s*(what'?s\s*up|sup|yo+|helo|hai|hii+)\s*[!.,?]*\s*$",
        r"^\s*(how are you|how r u|how do you do|how's it going|how are u)\s*[!.,?]*\s*$",
        r"^\s*(thanks?|thank you|thank u|thx|ty|cheers|thank\s*you\s*so\s*much)\s*[!.,?]*\s*$",
        r"^\s*(bye|goodbye|good\s*bye|see you|take care|cya|see\s*ya)\s*[!.,?]*\s*$",
        r"^\s*(ok|okay|sure|got it|understood|alright|cool|great|nice|sounds good)\s*[!.,?]*\s*$",
        r"^\s*(good\s*(morning|afternoon|evening|night|day))\s*(sir|ma'?am|team|everyone|all)?\s*[!.,?]*\s*$",
    ]

    GREETING_REPLIES = {
        "thanks": "You're welcome! 😊 Feel free to ask any HR-related questions anytime.",
        "thank":  "You're welcome! 😊 Feel free to ask any HR-related questions anytime.",
        "bye":    "Goodbye! 👋 Have a great day. Come back if you have any HR questions.",
        "goodbye":"Goodbye! 👋 Take care! I'm here whenever you need HR help.",
        "ok":     "Sure! Let me know if you have any HR-related questions. 😊",
        "okay":   "Sure! Let me know if you have any HR-related questions. 😊",
        "cool":   "Great! Let me know if you have any HR-related questions. 😊",
        "default": (
            "Hello! 👋 I'm your AI HR Assistant. I can help you with:\n"
            "- Leave & attendance policies\n"
            "- WFH / remote work guidelines\n"
            "- Benefits, payroll & reimbursements\n"
            "- Code of conduct & HR policies\n\n"
            "What would you like to know?"
        ),
    }

    # ──────────────────────────────────────────────────────────────────────────
    # Tier 2: Strong non-HR – overrides even accidental HR keyword matches
    # ──────────────────────────────────────────────────────────────────────────
    STRONG_NON_HR = [
        r"\bmoview?s?\b", r"\bfilm\b", r"\bactor\b", r"\bactress\b",
        r"\bcricket\b", r"\bfootball\b", r"\bipl\b", r"\bnba\b", r"\bnfl\b",
        r"\bbollywood\b", r"\bhollywood\b", r"\bnew movie\b", r"\blatest movie\b",
        r"\bjoke\b", r"\briddle\b", r"\bmeme\b",
        r"\bpresident of\b", r"\bprime minister of\b", r"\bcapital of\b",
        r"\bpopulation of\b",
        r"\d+\s*[\+\-\*\/]\s*\d+",
        r"\brecipe\b", r"\brestaurant\b",
        r"\bcryptocurrency\b", r"\bbitcoin\b", r"\bcrypto\b",
        r"\bstock price\b", r"\bshare price\b",
        r"\bwho\s+won\b", r"\bmatch\s+score\b", r"\btoday'?s?\s+score\b",
        r"\bweather\b", r"\btemperature\b", r"\bforecast\b",
        r"\bbest\s+laptop\b", r"\bbest\s+phone\b", r"\blatest\s+phone\b",
        r"\b[a-z]{2,5}\s+vs\s+[a-z]{2,5}\b",        # ind vs afg
        r"\bscore\s+(today|live|now|update)\b",
        r"\b(today|live|current)\s+score\b",
        r"\bbreaking\s+news\b", r"\blatest\s+news\b",
        r"\bwhat\s+happened\s+(today|yesterday|in)\b",
    ]

    # ──────────────────────────────────────────────────────────────────────────
    # Tier 3: CONFIDENTIAL – no ticket, hard block
    #
    # Qualifying HR salary adjectives that are NOT names:
    #   If the word before/after a salary term is one of these, it is a
    #   legitimate HR question (allow).  Any OTHER word is treated as a name.
    # ──────────────────────────────────────────────────────────────────────────

    # Whitelisted HR qualifiers that are not names (allowed on either side of a salary term)
    _SALARY_QUALIFIERS = (
        r"my|your|our|his|her|their|its|the|this|that|a|an|"
        r"annual|monthly|weekly|daily|quarterly|yearly|"
        r"total|basic|gross|net|current|expected|fixed|"
        r"average|minimum|maximum|median|revised|variable|"
        r"in|hand|take|home|market|standard|actual|"
        r"new|old|previous|next|last|future|pre|post|"
        r"revised|negotiated|offered|confirmed|final|"
        r"high|low|fair|competitive|bench|marked|"
        r"minimum|maximum|mid|senior|junior|entry|"
        r"what|how|when|where|why|which|whose|any|all|no|not|"
        r"hike|increment|slip|slips|structure|range|band|polic(y|ies)|"
        r"review|letter|break(down)?|raise|revision|scale|deduction|"
        r"allowance|advance|loan|tax|credit|correction|query|"
        r"calculation|formula|info|information|department|team|"
        r"processing|cycle|date|disbursement|account|component|"
        r"components|related|issue|concern|detail|details|"
        r"certificate|transfer|deposit|credited|due|pending|"
        r"cut|delay|hold|dispute|discrepancy|difference|"
        r"of|to|for|in|on|at|is|was|will|are|has|have|and|"
        r"i|me|we|us|you|they|he|she|it|who|"
        # Months & Calendar/Period terms
        r"january|february|march|april|may|june|july|august|september|october|november|december|"
        r"jan|feb|mar|apr|jun|jul|aug|sep|oct|nov|dec|"
        r"month(s)?|year(s)?|week(s)?|day(s)?|date(s)?|period(s)?|"
        r"first|second|third|fourth|"
        # Policy & Process/Document terms
        r"process(es)?|system(s)?|workflow(s)?|portal(s)?|template(s)?|guideline(s)?|guidance|"
        r"rule(s)?|law(s)?|statute(s)?|regulation(s)?|standard(s)?|practice(s)?|schedule(s)?|"
        r"histor(y|ies)|record(s)?|database(s)?|form(s)?|stub(s)?|sheet(s)?|page(s)?|document(s)?|"
        r"file(s)?|card(s)?|agreement(s)?|contract(s)?"
    )

    CONFIDENTIAL_PATTERNS = [
        # ── Salary of / for <person or dept> ─────────────────────────────────
        r"\b(salary|salaries|pay|payroll|compensation|ctc|package|earnings?|income)"
        r"\s+(of|for)\s+\w+",

        # ── How much does <name> earn ─────────────────────────────────────────
        r"\bhow\s+much\s+(does|do|did|is|are)\s+\w+\s+(earn|make|paid|get|receive|draw)\b",

        # ── <name>'s salary ───────────────────────────────────────────────────
        r"\b\w+'s\s+(salary|salaries|pay|payroll|compensation|ctc|package)\b",

        # ── what/tell/show … salary of <name> ────────────────────────────────
        r"\b(what|tell|show|share|reveal|disclose)\s+.{0,20}"
        r"\b(salary|salaries|payroll|pay|compensation)\s+(of|for)\s+\w+",

        # ── other/another employee salary ─────────────────────────────────────
        r"\b(another|other)\s+(employee|staff|colleague|worker|person)'?s?"
        r"\s+(salary|salaries|pay|payroll|compensation)\b",

        # ── salary/pay details of <name> ─────────────────────────────────────
        r"\b(salary|salaries|pay|payroll)\s+details?\s+(of|for)\s+\w+\b",

        # ── personal financial data ───────────────────────────────────────────
        r"\bpersonal\s+(financial|salary|salaries|pay|payroll)\s+(data|info|details|record)\b",
        r"\bconfidential\s+(salary|salaries|pay|payroll|employee)\s+(data|info|details|record)\b",

        # ── BIDIRECTIONAL: [name] salary  OR  salary [name] ──────────────────
        # Pattern A: word(not qualifier) BEFORE salary term (with optional qualifiers in between)
        r"(?<!\w)(?!(?:" + _SALARY_QUALIFIERS + r")\b)[a-z]{2,}\b\s+"
        r"(?:(?:" + _SALARY_QUALIFIERS + r")\s+)*"
        r"(salary|salaries|pay|payroll|compensation|ctc|package|income|earnings)\b",

        # Pattern B: salary term BEFORE word(not qualifier) (with optional qualifiers in between)
        r"\b(salary|salaries|pay|payroll|compensation|ctc|package|income|earnings)\b\s+"
        r"(?:(?:" + _SALARY_QUALIFIERS + r")\s+)*"
        r"(?!(?:" + _SALARY_QUALIFIERS + r")\b)[a-z]{2,}\b",

        # ── Names / IDs / contact info ────────────────────────────────────────
        r"\b(name|names)\s+(of|for)\s+"
        r"(hr|manager|ceo|cto|coo|vp|director|head|lead|boss|team|department|dept)\b",

        r"\b(hr|human\s*resource)\s+"
        r"(name|names|contact|email|phone|number|id|ids|emp|employee)\b",

        r"\bemp(loyee)?\s+(id|ids|number|contact|email|phone|name|names)"
        r"\s*(of|for)?\s*\w*",

        r"\bwho\s+is\s+(the\s+)?"
        r"(hr|manager|ceo|cto|director|head|lead|boss|recruiter|admin)\b",

        r"\bcontact\s+(of|for|details?)\s+"
        r"(hr|manager|ceo|director|employee|staff|team)\b",

        r"\b(phone|mobile|email|address)\s+(number\s+)?(of|for)\s+\w+\b",

        r"\bpersonal\s+(data|info|details|contact|email|phone)\s+(of|for)\s+\w+\b",

        r"\baccess\s+(employee|staff|personal|payroll|hr)\s+"
        r"(data|records?|details?|info)\b",

        r"\b(list|show|give)\s+(all\s+)?(employee|staff|hr)\s+"
        r"(names?|ids?|contacts?|emails?|salaries?|pay|payrolls?)\b",
    ]

    # ──────────────────────────────────────────────────────────────────────────
    # Tier 4: BLOCKED + ticket
    # ──────────────────────────────────────────────────────────────────────────
    BLOCKED_PATTERNS = [
        r"\bignore\s+(previous|all|above)\s+(instructions?|prompts?|rules?)\b",
        r"\bbypass\s+(?:all\s+|any\s+|the\s+)?(policy|rules?|guardrails?|filters?|restrictions?)\b",
        r"\bjailbreak\b",
        r"\bact\s+as\s+(?:if\s+you\s+are|a|an)?\s*(different|other|another|unrestricted|uncensored|free)\b",
        r"\bpretend\s+(you\s+are|to\s+be)\s*(admin|root|superuser|unrestricted)\b",
        r"\bdisregard\s+(your\s+)?(guidelines|rules|instructions)\b",
        r"\bmedical\s+diagnosis\b",
        r"\bfire\s+(this\s+)?employee\b",
        r"\bterminate\s+(this\s+)?employee\b",
    ]

    # ──────────────────────────────────────────────────────────────────────────
    # Tier 5: SENSITIVE – allow + auto-ticket
    # ──────────────────────────────────────────────────────────────────────────
    SENSITIVE_PATTERNS = [
        r"\bharass(ed|ment|ing)?\b", r"\bbull(y|ies|ied|ying)\b", r"\bdiscrimina(te|ted|tion|ting)\b",
        r"\blegal\s+(action|advice|matter|issue)\b",
        r"\bcomplaint\s+(against|about)\b",
        r"\bspecial\s+(approval|exception|case|request)\b",
        r"\bpersonal\s+(issue|problem)\b",
        r"\bdisciplinary\s+(action|case|proceeding)\b",
        r"\btermination\s+(process|letter|reason)\b",
        r"\bwhistleblower\b",
        r"\breport\s+(misconduct|abuse|fraud)\b",
    ]

    # ──────────────────────────────────────────────────────────────────────────
    # Tier 6: HR keyword list (plural-safe)
    # ──────────────────────────────────────────────────────────────────────────
    HR_RELATED_KEYWORDS = [
        r"\bleaves?\b", r"\bvacations?\b", r"\bholidays?\b",
        r"\bsick\s+leave\b", r"\bcasual\s+leave\b", r"\bearned\s+leave\b",
        r"\bpaternity\b", r"\bmaternity\b", r"\bcompensatory\b",
        r"\b(cl|el|pl|sl|ml|al)\b",
        r"\bwfh\b", r"\bwork\s+from\s+home\b", r"\bremote\s+work\b",
        r"\bhybrid\s+work\b", r"\bflexible\s+hours?\b",
        r"\battendance\b", r"\boffice\s+hours?\b", r"\boffice\s+policy\b",
        r"\bpunch\s+(in|out)\b", r"\bcheck\s+(in|out)\b",
        r"\bsalar(y|ies)\b", r"\bpayroll\b", r"\bpay\b", r"\bcompensation\b",
        r"\bbonus(es)?\b", r"\bincrements?\b", r"\bhike\b", r"\bctc\b",
        r"\bappraisals?\b", r"\bperformance\s+review\b",
        r"\bkra\b", r"\bkpi\b", r"\brating\b",
        r"\bpayslips?\b", r"\bpay\s+slip\b",
        r"\bpolicies?\b", r"\bhuman\s+resources?\b",
        r"\breimbursements?\b", r"\bexpenses?\b", r"\ballowances?\b",
        r"\binsurance\b", r"\bmedical\s+claims?\b", r"\bhealth\s+cover\b",
        r"\bbenefits?\b", r"\b(pf|epf|nps|esi)\b", r"\bgratuity\b",
        r"\btravel\s+(policy|allowance|expense)\b",
        r"\bonboarding\b", r"\btrainings?\b", r"\binduction\b",
        r"\bprobations?\b", r"\bnotice\s+period\b", r"\bserving\s+notice\b",
        r"\bresignations?\b", r"\bseparation\b", r"\bfull\s+and\s+final\b",
        r"\boffboarding\b", r"\brelieving\b", r"\bexperience\s+letter\b",
        r"\bharass(ed|ment|ing)?\b", r"\bgrievances?\b", r"\bdisciplinary\b",
        r"\bpromotions?\b", r"\btransfers?\b", r"\brelocation\b",
        r"\bcode\s+of\s+conduct\b", r"\bethics\b", r"\bdress\s+code\b",
        r"\bwork\s+hours?\b", r"\bshifts?\b", r"\bovertime\b",
        r"\bwhistleblower\b",
    ]

    # ──────────────────────────────────────────────────────────────────────────
    # Broader non-HR (checked when no HR keyword found)
    # ──────────────────────────────────────────────────────────────────────────
    BROAD_NON_HR = [
        r"\bsong\b", r"\bmusic\b", r"\balbum\b", r"\bartist\b",
        r"\bcelebrity\b", r"\byoutube\b", r"\bnetflix\b",
        r"\bott\b", r"\bweb\s+series\b", r"\bepisode\b",
        r"\bsports?\b", r"\bipl\b",
        r"\bviral\b", r"\bdiet\s+plan\b",
    ]

    # ──────────────────────────────────────────────────────────────────────────
    # Static reply text
    # ──────────────────────────────────────────────────────────────────────────
    _NON_HR_REPLY = (
        "🚫 This question doesn't appear to be related to HR policies or workplace matters.\n\n"
        "I can only assist with HR topics such as:\n"
        "• Leave & attendance policies\n"
        "• Work-from-home guidelines\n"
        "• Salary, benefits & reimbursements\n"
        "• Code of conduct & company policies\n\n"
        "Please ask an HR-related question and I'll be happy to help! 😊"
    )

    _CONFIDENTIAL_REPLY = (
        "🔒 This information is confidential and cannot be shared as per company guidelines.\n\n"
        "Employee personal data, salary details, IDs, and contact information are "
        "private and are not accessible through this chatbot.\n\n"
        "For your own HR information, please use the official HR portal or contact "
        "HR directly through official channels."
    )

    # ──────────────────────────────────────────────────────────────────────────
    # Tier 0: Input normalisation
    # ──────────────────────────────────────────────────────────────────────────
    def _normalize(self, text: str) -> str:
        words = text.lower().split()
        out = []
        for w in words:
            if w in self.TYPO_MAP:
                out.append(self.TYPO_MAP[w])
                continue
            close = difflib.get_close_matches(w, self.HR_VOCABULARY, n=1, cutoff=0.82)
            out.append(close[0] if close else w)
        return " ".join(out)

    # ──────────────────────────────────────────────────────────────────────────
    # Main check
    # ──────────────────────────────────────────────────────────────────────────
    def check(self, question: str) -> dict:
        q_raw = (question or "").strip()
        if not q_raw:
            return {"allowed": False, "requires_ticket": False,
                    "reason_code": "empty", "reason": self._NON_HR_REPLY}

        q_norm = self._normalize(q_raw)
        q      = q_norm.lower()
        q_orig = q_raw.lower()

        # ── Tier 1: Greeting ─────────────────────────────────────────────────
        for pattern in self.GREETING_PATTERNS:
            if re.search(pattern, q_orig, re.IGNORECASE):
                reply = self.GREETING_REPLIES["default"]
                for key, val in self.GREETING_REPLIES.items():
                    if key in q_orig:
                        reply = val
                        break
                return {"allowed": False, "requires_ticket": False,
                        "reason_code": "greeting", "reason": reply}

        # ── Tier 2: Strong non-HR ─────────────────────────────────────────────
        for kw in self.STRONG_NON_HR:
            if re.search(kw, q_orig) or re.search(kw, q):
                return {"allowed": False, "requires_ticket": False,
                        "reason_code": "non_hr", "reason": self._NON_HR_REPLY}

        # ── Tier 3: Confidential ──────────────────────────────────────────────
        for pattern in self.CONFIDENTIAL_PATTERNS:
            if re.search(pattern, q_orig) or re.search(pattern, q):
                return {"allowed": False, "requires_ticket": False,
                        "reason_code": "confidential", "reason": self._CONFIDENTIAL_REPLY}

        # ── Tier 4: Blocked + ticket ──────────────────────────────────────────
        for pattern in self.BLOCKED_PATTERNS:
            if re.search(pattern, q_orig) or re.search(pattern, q):
                return {
                    "allowed": False, "requires_ticket": True,
                    "reason_code": "blocked",
                    "reason": (
                        "🔒 This query involves restricted content and cannot be processed. "
                        "An HR ticket has been raised for review."
                    ),
                }

        # ── Tier 5: Sensitive + ticket ────────────────────────────────────────
        for pattern in self.SENSITIVE_PATTERNS:
            if re.search(pattern, q_orig) or re.search(pattern, q):
                return {
                    "allowed": True, "requires_ticket": True,
                    "reason_code": "sensitive",
                    "reason": (
                        "⚠️ This topic may require direct HR involvement. "
                        "Your question will be answered based on policy and an HR ticket will be raised for follow-up."
                    ),
                }

        # ── Tier 6: HR intent check ───────────────────────────────────────────
        has_hr = self.has_hr_keywords(q)
        if not has_hr:
            for kw in self.BROAD_NON_HR:
                if re.search(kw, q_orig) or re.search(kw, q):
                    return {"allowed": False, "requires_ticket": False,
                            "reason_code": "non_hr", "reason": self._NON_HR_REPLY}

        # ── Tier 7: Allow ─────────────────────────────────────────────────────
        return {"allowed": True, "requires_ticket": False,
                "reason_code": "ok", "reason": "Input passed all guardrail checks."}

    def has_hr_keywords(self, question: str) -> bool:
        """Returns True if the (normalised) question contains at least one HR keyword."""
        q = self._normalize((question or "").lower())
        return any(re.search(kw, q) for kw in self.HR_RELATED_KEYWORDS)
