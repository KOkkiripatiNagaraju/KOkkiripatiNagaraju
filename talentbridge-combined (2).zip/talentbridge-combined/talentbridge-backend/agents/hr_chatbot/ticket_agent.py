"""Creates HR support tickets when chatbot cannot resolve an employee query."""
from typing import Optional
from sqlalchemy.orm import Session

from models.hr_chatbot_models import HRTicket


class HRTicketEscalationAgent:
    """Escalates unresolved queries to HR by creating hr_tickets records."""

    name = "HRTicketEscalationAgent"

    def create(
        self,
        db: Session,
        employee_id: Optional[str],
        employee_email: Optional[str],
        question: str,
        category: str = "Policy Clarification",
        priority: str = "Medium",
        ai_summary: Optional[str] = None,
        suggested_response: Optional[str] = None,
    ) -> HRTicket:
        ticket = HRTicket(
            employee_id=employee_id,
            employee_email=employee_email,
            question=question,
            category=category,
            priority=priority,
            status="Open",
            ai_summary=ai_summary,
            suggested_response=suggested_response,
            assigned_to="HR_SUPPORT",
        )
        db.add(ticket)
        db.commit()
        db.refresh(ticket)
        return ticket
