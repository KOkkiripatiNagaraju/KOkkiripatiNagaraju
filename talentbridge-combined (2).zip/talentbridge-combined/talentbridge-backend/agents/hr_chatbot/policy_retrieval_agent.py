"""Retrieves relevant content from HR policies (published preferred, review/draft also included)."""
from sqlalchemy.orm import Session

from models.hr_chatbot_models import HRPolicy, HRPolicyVersion
from utils.hr_text_utils import simple_similarity, split_into_chunks


class HRPolicyRetrievalAgent:
    """Searches HR policies for context matching the question.

    Priority order:
      1. Published policies (score × 1.5 boost)
      2. Review-status policies (score × 1.0)
      3. Draft policies (score × 0.8)
    """

    name = "HRPolicyRetrievalAgent"

    # Status → score multiplier
    STATUS_BOOST = {"published": 1.5, "review": 1.0, "draft": 0.8}

    def retrieve(self, db: Session, question: str, limit: int = 3) -> list[dict]:
        # Fetch all non-archived policy versions
        all_versions = (
            db.query(HRPolicyVersion, HRPolicy)
            .join(HRPolicy, HRPolicyVersion.policy_id == HRPolicy.id)
            .filter(HRPolicy.status.in_(["published", "review", "draft"]))
            .order_by(HRPolicyVersion.created_at.desc())
            .all()
        )

        scored_chunks: list[dict] = []
        for version, policy in all_versions:
            boost = self.STATUS_BOOST.get(policy.status, 0.8)
            for chunk in split_into_chunks(version.content or ""):
                raw_score = simple_similarity(question, chunk)
                if raw_score > 0:
                    scored_chunks.append({
                        "policy_id": str(policy.id),
                        "title": policy.title,
                        "version": version.version_number,
                        "status": policy.status,
                        "chunk": chunk,
                        "score": round(raw_score * boost, 4),
                    })

        scored_chunks.sort(key=lambda item: item["score"], reverse=True)
        return scored_chunks[:limit]
