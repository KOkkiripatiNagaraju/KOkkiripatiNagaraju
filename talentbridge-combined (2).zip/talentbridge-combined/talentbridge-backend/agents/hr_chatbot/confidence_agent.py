"""
Confidence Agent — evaluates retrieval quality and decides on ticket escalation.

Escalation rules:
- NO context at all → auto-ticket (HR-related but no published policy covers it)
- Context score too low (noise) → auto-ticket (unreliable match)
- Medium score → no ticket (answer is usable)
- High score → no ticket (confident answer)
"""


class HRConfidenceAgent:
    """Evaluates retrieval quality to decide whether to answer or escalate."""

    name = "HRConfidenceAgent"

    # Minimum score to consider a chunk as relevant at all
    MIN_RELEVANCE_SCORE = 0.10

    def evaluate(self, contexts: list[dict]) -> dict:
        # No context found at all — raise a ticket so HR can follow up
        if not contexts:
            return {
                "confidence": "low",
                "should_escalate": True,
                "reason": "No matching published HR policy found. Escalating to HR team for manual assistance.",
            }

        top_score = contexts[0]["score"]

        # Score too low — context is noise, not relevant — raise a ticket
        if top_score < self.MIN_RELEVANCE_SCORE:
            return {
                "confidence": "low",
                "should_escalate": True,
                "reason": "Retrieved context is too weak to provide a reliable answer. Escalating to HR.",
            }

        if top_score >= 0.35:
            return {
                "confidence": "high",
                "should_escalate": False,
                "reason": "Strong policy context match found.",
            }

        if top_score >= 0.15:
            return {
                "confidence": "medium",
                "should_escalate": False,
                "reason": "Usable policy context found; HR review may help for edge cases.",
            }

        # Between MIN_RELEVANCE and 0.15 — weak but potentially relevant — escalate
        return {
            "confidence": "low",
            "should_escalate": True,
            "reason": "Policy context match is too weak. Escalating to HR for manual review.",
        }
