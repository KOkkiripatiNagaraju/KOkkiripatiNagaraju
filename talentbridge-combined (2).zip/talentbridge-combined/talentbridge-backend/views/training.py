"""
Training & Development View
AI-powered skill gap analysis, course recommendations, and personalized learning paths.
"""

import os
import requests
import streamlit as st
from datetime import datetime

BASE_URL = os.environ.get("BASE_URL", "http://localhost:8000/api")

def clean_html(html_str):
    return " ".join([line.strip() for line in html_str.split("\n") if line.strip()])


def score_color(s):
    if s >= 80: return "#34d399"
    elif s >= 60: return "#fbbf24"
    else: return "#f87171"

def score_gradient(s):
    if s >= 80: return "linear-gradient(135deg, #10b981, #34d399)"
    elif s >= 60: return "linear-gradient(135deg, #f59e0b, #fbbf24)"
    else: return "linear-gradient(135deg, #ef4444, #f87171)"

PRIORITY_COLORS = {
    "Critical": ("#ef4444", "rgba(239,68,68,0.15)"),
    "High":     ("#f59e0b", "rgba(245,158,11,0.15)"),
    "Medium":   ("#3b82f6", "rgba(59,130,246,0.15)"),
    "Low":      ("#8b5cf6", "rgba(139,92,246,0.15)"),
}

PHASE_PALETTE = [
    ("#6366f1", "rgba(99,102,241,0.08)"),
    ("#8b5cf6", "rgba(139,92,246,0.08)"),
    ("#06b6d4", "rgba(6,182,212,0.08)"),
    ("#ec4899", "rgba(236,72,153,0.08)"),
    ("#f59e0b", "rgba(245,158,11,0.08)"),
    ("#10b981", "rgba(16,185,129,0.08)"),
]


# =============================================================================
# Main View
# =============================================================================
def render_training_view(headers):
    """Render the Training & Development page for HR."""

    # ── Training-specific CSS ──────────────────────────────────────────────
    st.markdown("""<style>
.training-phase-card {
    background: rgba(99,102,241,0.06) !important;
    border: 1px solid rgba(99,102,241,0.15);
    border-left: 4px solid #6366f1;
    border-radius: 14px;
    padding: 18px 22px;
    margin-bottom: 12px;
    transition: all 0.35s ease;
}
.section-divider { height: 1px; background: linear-gradient(90deg, transparent, rgba(99,102,241,0.3), transparent); margin: 20px 0; }
.page-subtitle { color: #94a3b8 !important; -webkit-text-fill-color: #94a3b8 !important; font-size: 0.9rem; margin: -4px 0 24px; }
.page-header { display: flex; align-items: center; gap: 14px; margin-bottom: 8px; }
.page-header-icon { font-size: 2rem; }
.hr-emp-badge { font-size: 0.66rem; font-weight: 600; padding: 2px 7px; border-radius: 10px; display: inline-block; margin: 2px 2px 0 0; }
.summary-stat { text-align: center; padding: 16px 12px; background: rgba(15,23,42,0.7) !important; border: 1px solid rgba(99,102,241,0.12); border-radius: 14px; }
.summary-stat-label { font-size: 0.72rem; color: #94a3b8 !important; -webkit-text-fill-color: #94a3b8 !important; text-transform: uppercase; letter-spacing: 0.08em; margin-top: 6px; font-weight: 600; }
.phase-timeline { position: relative; padding-left: 36px; }
.phase-timeline::before { content: ''; position: absolute; left: 16px; top: 8px; bottom: 8px; width: 2px; background: linear-gradient(180deg, #6366f1, #8b5cf6, #06b6d4, #10b981); }
.phase-node { position: relative; margin-bottom: 16px; }
.phase-node::before { content: ''; position: absolute; left: -28px; top: 22px; width: 14px; height: 14px; border-radius: 50%; background: linear-gradient(135deg, #6366f1, #8b5cf6); border: 3px solid #0c0e27; box-shadow: 0 0 10px rgba(99,102,241,0.4); z-index: 1; }
.assign-course-row { display: flex; align-items: center; gap: 16px; padding: 14px 18px; margin-bottom: 8px; background: rgba(15,23,42,0.75) !important; border: 1px solid rgba(99,102,241,0.1); border-radius: 12px; transition: all 0.3s ease; }
.history-row { display: flex; justify-content: space-between; align-items: center; padding: 16px 20px; margin-bottom: 8px; background: rgba(15,23,42,0.75) !important; border: 1px solid rgba(99,102,241,0.1); border-radius: 14px; transition: all 0.3s ease; }
.ai-rec-item { display: flex; align-items: flex-start; gap: 10px; padding: 10px 0; border-bottom: 1px solid rgba(99,102,241,0.06); }
.ai-rec-item:last-child { border-bottom: none; }
[data-testid="stExpanderToggleIcon"] { display: none !important; }

/* Custom Skill Gap styles */
.score-ring-container { display: flex; align-items: center; gap: 24px; padding: 22px 26px; background: rgba(15, 23, 42, 0.65) !important; border: 1px solid rgba(99, 102, 241, 0.15); border-radius: 16px; margin-bottom: 24px; }
.gap-row { display: flex; align-items: center; justify-content: space-between; padding: 16px 20px; border-bottom: 1px solid rgba(99, 102, 241, 0.08); background: rgba(15, 23, 42, 0.4) !important; border-radius: 10px; margin-bottom: 10px; gap: 12px; }
.gap-row:last-child { margin-bottom: 0; }
.gap-skill-name { font-weight: 700; font-size: 0.95rem; color: #f8fafc !important; -webkit-text-fill-color: #f8fafc !important; flex: 2; min-width: 160px; }
.gap-bar-track { width: 100%; height: 6px; background: rgba(255, 255, 255, 0.08); border-radius: 3px; overflow: hidden; position: relative; }
.gap-bar-fill { height: 100%; border-radius: 3px; }
.gap-value { font-family: 'JetBrains Mono', monospace; font-size: 1rem; font-weight: 700; min-width: 45px; text-align: center; }
.gap-priority-badge { font-size: 0.72rem; font-weight: 700; padding: 4px 10px; border-radius: 20px; text-transform: uppercase; letter-spacing: 0.03em; display: inline-block; text-align: center; min-width: 80px; }
</style>""", unsafe_allow_html=True)

    # ── Page Header ───────────────────────────────────────────────────────
    st.markdown('''
    <div class="page-header">
        <div class="page-header-icon">📚</div>
        <div><h1 style="margin:0; font-size:1.8rem !important;">Training &amp; Development</h1></div>
    </div>
    <p class="page-subtitle">AI-powered skill gap analysis, course recommendations, and personalised learning paths</p>
    ''', unsafe_allow_html=True)

    # ── Initialize session state ──────────────────────────────────────────
    if "training_analysis_result" not in st.session_state:
        st.session_state["training_analysis_result"] = None
    if "training_plan_result" not in st.session_state:
        st.session_state["training_plan_result"] = None

    # ── Load employees & roles from backend ───────────────────────────────
    _employees = _fetch_json(f"{BASE_URL}/training/employees", headers)
    _roles     = _fetch_json(f"{BASE_URL}/training/role-templates", headers)
    if _employees is None or _roles is None:
        st.error("⚠️ Unable to load employees or role templates. Please check the backend.")
        return
    if not _employees or not _roles:
        st.warning("No employees or role templates found. Please add data first.")
        return

    # Build option maps
    _emp_options  = {f"{e['name']} — {e.get('current_role','N/A')} ({e.get('department','')})" : e['id'] for e in _employees}
    _role_options = {f"{r['role_title']} — {r.get('department','')}"                             : r['id'] for r in _roles}
    _emp_labels   = list(_emp_options.keys())
    _role_labels  = list(_role_options.keys())

    # ── Employee Roster ────────────────────────────────────────────────────
    st.markdown("#### 👥 Employee Roster — Click a profile to select")
    if "hr_selected_emp_label" not in st.session_state:
        st.session_state["hr_selected_emp_label"] = _emp_labels[0] if _emp_labels else ""

    CARD_COLS = 4
    emp_chunks = [_employees[i:i+CARD_COLS] for i in range(0, len(_employees), CARD_COLS)]
    for chunk in emp_chunks:
        cols = st.columns(len(chunk))
        for col, emp in zip(cols, chunk):
            with col:
                emp_label = f"{emp['name']} — {emp.get('current_role','N/A')} ({emp.get('department','')})"
                is_sel    = st.session_state.get("hr_selected_emp_label") == emp_label
                skills_n  = len(emp.get("skills_profile") or {})
                dept      = emp.get("department", "—")
                role      = emp.get("current_role", "—")
                readiness = emp.get("readiness_score", None)
                initial   = (emp.get("name","?")[0]).upper()
                border    = "2px solid #6366f1" if is_sel else "1px solid rgba(99,102,241,0.18)"
                bg        = "rgba(99,102,241,0.1)" if is_sel else "rgba(15,23,42,0.75)"
                if readiness is not None:
                    rc  = "#10b981" if readiness >= 70 else ("#f59e0b" if readiness >= 40 else "#ef4444")
                    r_b = f'<span class="hr-emp-badge" style="background:{rc}22;color:{rc} !important;-webkit-text-fill-color:{rc} !important;border:1px solid {rc}44;">{readiness:.0f}% ready</span>'
                else:
                    r_b = ""
                st.markdown(
                    f'<div style="background:{bg};border:{border};border-radius:14px;padding:13px 15px;margin-bottom:4px;">' +
                    f'<div style="width:36px;height:36px;border-radius:50%;background:linear-gradient(135deg,#6366f1,#8b5cf6);display:flex;align-items:center;justify-content:center;font-weight:700;color:#fff;font-size:1rem;margin-bottom:8px;">{initial}</div>' +
                    f'<div style="font-weight:700;font-size:0.9rem;color:#e2e8f0 !important;-webkit-text-fill-color:#e2e8f0 !important;margin-bottom:3px;">{emp.get("name","")}</div>' +
                    f'<div style="font-size:0.75rem;color:#94a3b8 !important;-webkit-text-fill-color:#94a3b8 !important;margin-bottom:6px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">{role}</div>' +
                    f'<span class="hr-emp-badge" style="background:rgba(99,102,241,0.12);color:#a5b4fc !important;-webkit-text-fill-color:#a5b4fc !important;border:1px solid rgba(99,102,241,0.22);">{dept}</span>' +
                    (f'<span class="hr-emp-badge" style="background:rgba(6,182,212,0.12);color:#67e8f9 !important;-webkit-text-fill-color:#67e8f9 !important;border:1px solid rgba(6,182,212,0.22);">{skills_n} skills</span>' if skills_n else "") +
                    r_b + '</div>',
                    unsafe_allow_html=True)
                if st.button("Open Profile", key=f"hr_emp_btn_{emp['id']}", use_container_width=True):
                    st.session_state["hr_selected_emp_label"] = emp_label
                    st.session_state["gap_emp_select"]    = emp_label
                    st.session_state["ai_emp_select"]     = emp_label
                    st.session_state["assign_emp_select"] = emp_label
                    st.rerun()

    sel = st.session_state.get("hr_selected_emp_label","")
    if sel:
        st.markdown(f'<div style="font-size:0.84rem;color:#a5b4fc !important;-webkit-text-fill-color:#a5b4fc !important;margin:6px 0 0;font-weight:600;">✓ Selected: {sel.split(" —")[0]}</div>', unsafe_allow_html=True)
    st.markdown("<hr style=\'border:0;border-top:1px solid rgba(99,102,241,0.15);margin:14px 0 20px;\'>", unsafe_allow_html=True)

    # ── Tabs ──────────────────────────────────────────────────────────────
    tab_gap, tab_ai, tab_assign, tab_history = st.tabs([
        "🔍 Skill Gap Analysis",
        "🤖 AI Learning Path",
        "📋 Assign Courses",
        "📊 History",
    ])
    with tab_gap:
        _render_skill_gap_tab(headers, _emp_options, _emp_labels, _role_options, _role_labels)
    with tab_ai:
        _render_ai_learning_tab(headers, _emp_options, _emp_labels, _role_options, _role_labels)
    with tab_assign:
        _render_assign_tab(headers)
    with tab_history:
        _render_history_tab(headers)



def _render_skill_gap_tab(headers, emp_options, emp_labels, role_options, role_labels):
    st.markdown('<div class="section-divider"></div>', unsafe_allow_html=True)

    # Dropdowns
    col1, col2 = st.columns(2)
    with col1:
        selected_emp_label = st.selectbox("👤 Select Employee", emp_labels, key="gap_emp_select")
    with col2:
        selected_role_label = st.selectbox("🎯 Target Role", role_labels, key="gap_role_select")

    # Sync AI tab dropdowns to match this selection
    if "ai_emp_select" not in st.session_state or st.session_state.get("_last_gap_emp") != selected_emp_label:
        st.session_state["ai_emp_select"] = selected_emp_label
    if "ai_role_select" not in st.session_state or st.session_state.get("_last_gap_role") != selected_role_label:
        st.session_state["ai_role_select"] = selected_role_label
    st.session_state["_last_gap_emp"] = selected_emp_label
    st.session_state["_last_gap_role"] = selected_role_label

    st.markdown("")

    # Run Analysis button
    if st.button("⚡ Run Analysis", key="run_gap_analysis_btn", use_container_width=False):
        emp_id = emp_options[selected_emp_label]
        role_id = role_options[selected_role_label]

        with st.spinner("🔍 Analyzing skill gaps..."):
            try:
                res = requests.post(
                    f"{BASE_URL}/training/analyze",
                    json={"employee_id": emp_id, "role_template_id": role_id},
                    headers=headers,
                )
                if res.status_code == 200:
                    st.session_state["training_analysis_result"] = res.json()
                    st.success("✅ Analysis completed! Now go to AI Learning Path tab to generate a full plan.")
                else:
                    st.error(f"Analysis failed (HTTP {res.status_code}): {res.text}")
            except Exception as e:
                st.error(f"Connection error: {e}")

    # Show result
    result = st.session_state.get("training_analysis_result")
    if result:
        st.markdown('<div class="section-divider"></div>', unsafe_allow_html=True)
        _render_analysis_result(result)


def _render_analysis_result(result):
    """Render the analysis result with readiness score ring and skill gaps table."""
    score = result.get("readiness_score", 0)
    gaps = result.get("skill_gaps", [])
    emp_name = result.get("employee_name", "Employee")
    role_title = result.get("role_title", "Role")
    sc = score_color(score)

    # ── Readiness Score Ring ──────────────────────────────────────────────
    radius = 42
    circumference = 2 * 3.14159 * radius
    dash = circumference * (score / 100)
    gap_arc = circumference - dash

    st.markdown(f'''
    <div class="score-ring-container">
        <div style="position: relative; width: 110px; height: 110px; flex-shrink: 0;">
            <svg width="110" height="110" viewBox="0 0 100 100" style="transform: rotate(-90deg);">
                <circle cx="50" cy="50" r="{radius}" fill="none" stroke="rgba(99,102,241,0.1)" stroke-width="8"/>
                <circle cx="50" cy="50" r="{radius}" fill="none" stroke="{sc}" stroke-width="8"
                    stroke-linecap="round" stroke-dasharray="{dash:.1f} {gap_arc:.1f}"/>
            </svg>
            <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); text-align: center;">
                <div style="font-family: 'JetBrains Mono', monospace; font-size: 1.5rem; font-weight: 800; color: {sc} !important; line-height: 1;">{score:.0f}%</div>
                <div style="font-size: 0.6rem; color: #94a3b8 !important; text-transform: uppercase; letter-spacing: 0.08em; margin-top: 2px;">Readiness</div>
            </div>
        </div>
        <div style="flex: 1;">
            <div style="color: #e0e7ff !important; font-weight: 700; font-size: 1.1rem; margin-bottom: 4px;">
                {emp_name}
            </div>
            <div style="color: #94a3b8 !important; font-size: 0.88rem;">
                Target Role: <span style="color: #a78bfa !important; font-weight: 600;">{role_title}</span>
            </div>
            <div style="margin-top: 10px; display: flex; align-items: center; gap: 8px;">
                <span style="font-size: 0.78rem; color: #94a3b8 !important;">Readiness:</span>
                <div style="flex: 1; max-width: 200px; height: 6px; background: rgba(99,102,241,0.1); border-radius: 3px; overflow: hidden;">
                    <div style="width: {min(score, 100):.1f}%; height: 100%; background: {score_gradient(score)}; border-radius: 3px;"></div>
                </div>
                <span style="font-family: 'JetBrains Mono', monospace; font-size: 0.78rem; font-weight: 700; color: {sc} !important;">{score:.0f}%</span>
            </div>
        </div>
    </div>
    ''', unsafe_allow_html=True)

    # ── Summary Stats ─────────────────────────────────────────────────────
    if gaps:
        total_gaps = len(gaps)
        critical = sum(1 for g in gaps if g.get("priority", "").lower() == "critical")
        high = sum(1 for g in gaps if g.get("priority", "").lower() == "high")
        medium = sum(1 for g in gaps if g.get("priority", "").lower() == "medium")

        st.markdown("")
        cols = st.columns(4)
        stat_data = [
            (total_gaps, "Total Gaps", "#a78bfa"),
            (critical, "Critical", "#ef4444"),
            (high, "High", "#f59e0b"),
            (medium, "Medium", "#3b82f6"),
        ]
        for col, (val, label, color) in zip(cols, stat_data):
            with col:
                st.markdown(f'''
                <div class="summary-stat">
                    <div class="summary-stat-value" style="color: {color} !important;">{val}</div>
                    <div class="summary-stat-label">{label}</div>
                </div>
                ''', unsafe_allow_html=True)

        # ── Skill Gaps Table ──────────────────────────────────────────────
        st.markdown("")
        st.markdown('''
        <div style="color: #94a3b8 !important; font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.1em; font-weight: 600; margin-bottom: 12px;">
            Skill Gap Details
        </div>
        ''', unsafe_allow_html=True)

        for g in gaps:
            skill_name = g.get("skill", g.get("skill_name", "Unknown"))
            current = g.get("current_level", g.get("current", 0))
            required = g.get("required_level", g.get("required", 0))
            gap_val = g.get("gap", required - current)
            priority = g.get("priority", "Medium")
            p_color, p_bg = PRIORITY_COLORS.get(priority, ("#8b5cf6", "rgba(139,92,246,0.15)"))

            # Normalize levels to percentages (assume 0-10 scale if not already %)
            current_pct = min(current * 10, 100) if current <= 10 else min(current, 100)
            required_pct = min(required * 10, 100) if required <= 10 else min(required, 100)

            st.markdown(f'''
            <div class="gap-row">
                <div class="gap-skill-name">{skill_name}</div>
                <div style="flex: 1; display: flex; align-items: center; gap: 10px;">
                    <div style="flex: 1;">
                        <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 3px;">
                            <span style="font-size: 0.68rem; color: #94a3b8 !important; min-width: 50px;">Current</span>
                            <div class="gap-bar-track">
                                <div class="gap-bar-fill" style="width: {current_pct:.0f}%; background: rgba(99,102,241,0.4);"></div>
                            </div>
                            <span style="font-family: 'JetBrains Mono', monospace; font-size: 0.72rem; color: #94a3b8 !important; min-width: 20px; text-align: right;">{current}</span>
                        </div>
                        <div style="display: flex; align-items: center; gap: 6px;">
                            <span style="font-size: 0.68rem; color: #94a3b8 !important; min-width: 50px;">Required</span>
                            <div class="gap-bar-track">
                                <div class="gap-bar-fill" style="width: {required_pct:.0f}%; background: {score_gradient(required_pct)};"></div>
                            </div>
                            <span style="font-family: 'JetBrains Mono', monospace; font-size: 0.72rem; color: #e0e7ff !important; min-width: 20px; text-align: right;">{required}</span>
                        </div>
                    </div>
                </div>
                <div class="gap-value" style="color: {p_color} !important;">-{abs(gap_val)}</div>
                <div class="gap-priority-badge" style="color: {p_color} !important; background: {p_bg}; border: 1px solid {p_color}33;">
                    {priority}
                </div>
            </div>
            ''', unsafe_allow_html=True)
    else:
        st.markdown('''
        <div style="text-align: center; padding: 32px; background: rgba(16,185,129,0.06) !important; border: 1px solid rgba(16,185,129,0.15); border-radius: 16px; margin-top: 16px;">
            <span style="font-size: 2.5rem; display: block; margin-bottom: 8px;">🎉</span>
            <div style="color: #34d399 !important; font-weight: 700; font-size: 1rem;">No Skill Gaps Detected!</div>
            <div style="color: #94a3b8 !important; font-size: 0.85rem; margin-top: 4px;">The employee meets all requirements for this role.</div>
        </div>
        ''', unsafe_allow_html=True)


# ─────────────────────────────────────────────────────────────────────────────
# TAB 2  —  AI Learning Path
# ─────────────────────────────────────────────────────────────────────────────
def _render_ai_learning_tab(headers, emp_options, emp_labels, role_options, role_labels):
    st.markdown('<div class="section-divider"></div>', unsafe_allow_html=True)

    col1, col2 = st.columns(2)
    with col1:
        selected_emp_label = st.selectbox("👤 Select Employee", emp_labels, key="ai_emp_select")
    with col2:
        selected_role_label = st.selectbox("🎯 Target Role", role_labels, key="ai_role_select")

    st.markdown("")

    if st.button("🚀 Generate AI Plan", key="gen_ai_plan_btn", use_container_width=False):
        emp_id = emp_options[selected_emp_label]
        role_id = role_options[selected_role_label]

        with st.spinner("🤖 Generating personalized AI learning path..."):
            try:
                res = requests.post(
                    f"{BASE_URL}/training/generate-plan",
                    json={"employee_id": emp_id, "role_template_id": role_id},
                    headers=headers,
                )
                if res.status_code == 200:
                    st.session_state["training_plan_result"] = res.json()
                    st.success("✅ AI learning path generated!")
                else:
                    st.error(f"Plan generation failed (HTTP {res.status_code}): {res.text}")
            except Exception as e:
                st.error(f"Connection error: {e}")

    plan = st.session_state.get("training_plan_result")
    if plan:
        st.markdown('<div class="section-divider"></div>', unsafe_allow_html=True)
        _render_learning_plan(plan)


def _render_learning_plan(plan):
    """Render the full AI-generated learning plan."""
    score = plan.get("readiness_score", 0)
    sc = score_color(score)
    emp_name = plan.get("employee_name", "Employee")
    role_title = plan.get("role_title", "Role")
    courses = plan.get("recommended_courses", [])
    learning_path = plan.get("ai_learning_path", {})
    gaps = plan.get("skill_gaps", [])

    # ── Compact readiness header ──────────────────────────────────────────
    radius = 32
    circumference = 2 * 3.14159 * radius
    dash = circumference * (score / 100)
    gap_arc = circumference - dash

    st.markdown(f'''
    <div style="display: flex; align-items: center; gap: 20px; padding: 16px 20px; background: rgba(255,255,255,0.03) !important; border: 1px solid rgba(99,102,241,0.15); border-radius: 14px; margin-bottom: 20px;">
        <div style="position: relative; width: 72px; height: 72px; flex-shrink: 0;">
            <svg width="72" height="72" viewBox="0 0 72 72" style="transform: rotate(-90deg);">
                <circle cx="36" cy="36" r="{radius}" fill="none" stroke="rgba(99,102,241,0.1)" stroke-width="6"/>
                <circle cx="36" cy="36" r="{radius}" fill="none" stroke="{sc}" stroke-width="6"
                    stroke-linecap="round" stroke-dasharray="{dash:.1f} {gap_arc:.1f}"/>
            </svg>
            <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); text-align: center;">
                <div style="font-family: 'JetBrains Mono', monospace; font-size: 1.1rem; font-weight: 800; color: {sc} !important; line-height: 1;">{score:.0f}%</div>
            </div>
        </div>
        <div>
            <div style="color: #e0e7ff !important; font-weight: 700; font-size: 1rem;">{emp_name}</div>
            <div style="color: #94a3b8 !important; font-size: 0.82rem;">Target: <span style="color: #a78bfa !important; font-weight: 600;">{role_title}</span></div>
            <div style="color: #94a3b8 !important; font-size: 0.75rem; margin-top: 2px;">{len(gaps)} skill gaps identified · {len(courses)} courses recommended</div>
        </div>
    </div>
    ''', unsafe_allow_html=True)

    # ── Recommended Courses ───────────────────────────────────────────────
    course_url_map = {}
    if courses:
        st.markdown('''
        <div style="color: #94a3b8 !important; font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.1em; font-weight: 600; margin-bottom: 12px;">
            📖 Recommended Courses
        </div>
        ''', unsafe_allow_html=True)

        for c in courses:
            title = c.get("course_title", c.get("title", "Untitled Course"))
            skills = c.get("skills_covered", [])
            relevance = c.get("relevance_score", c.get("relevance", 0))
            description = c.get("description", "")
            course_url = c.get("url", "")

            if isinstance(skills, str):
                skills = [s.strip() for s in skills.split(",")]

            # Save in map for the timeline lookup
            course_url_map[title] = course_url

            pills_html = "".join(f'<span class="skill-pill-course">{s}</span>' for s in skills[:6])
            relevance_html = ""
            if relevance:
                rel_color = score_color(relevance) if relevance else "#6366f1"
                relevance_html = (
                    '<div style="text-align: right; flex-shrink: 0;">'
                    f'<div style="font-family: \'JetBrains Mono\', monospace; font-size: 1.1rem; font-weight: 800; color: {rel_color} !important;">{relevance:.0f}%</div>'
                    '<div style="font-size: 0.65rem; color: #94a3b8 !important; text-transform: uppercase; letter-spacing: 0.08em;">Relevance</div>'
                    '<div style="width: 60px; height: 4px; background: rgba(99,102,241,0.1); border-radius: 2px; overflow: hidden; margin-top: 6px;">'
                    f'<div style="width: {min(relevance, 100):.0f}%; height: 100%; background: {score_gradient(relevance)}; border-radius: 2px;"></div>'
                    '</div>'
                    '</div>'
                )

            desc_html = f'<div style="color: #94a3b8 !important; font-size: 0.82rem; margin-bottom: 8px; line-height: 1.5;">{description[:150]}</div>' if description else ''
            title_html = f'<a href="{course_url}" target="_blank" rel="noopener noreferrer" style="color: #a78bfa !important; text-decoration: none; font-weight: 700; font-size: 0.95rem; margin-bottom: 6px; display: inline-block; cursor: pointer; pointer-events: auto; position: relative; z-index: 10;">📘 {title} ↗</a>' if course_url else f'<div style="color: #e0e7ff !important; font-weight: 700; font-size: 0.95rem; margin-bottom: 6px;">📘 {title}</div>'

            st.markdown(
                '<div class="course-card">'
                '<div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 12px;">'
                '<div style="flex: 1;">'
                f'{title_html}'
                f'{desc_html}'
                f'<div>{pills_html}</div>'
                '</div>'
                f'{relevance_html}'
                '</div>'
                '</div>',
                unsafe_allow_html=True
            )

    # ── AI Learning Path Phases (Timeline) ────────────────────────────────
    phases = []
    if isinstance(learning_path, dict):
        phases = learning_path.get("phases", learning_path.get("learning_phases", []))
        # Summary may be nested or top-level
        summary = learning_path.get("summary", {})
        if not summary:
            summary = {
                "weekly_schedule": learning_path.get("weekly_schedule", ""),
                "total_hours": learning_path.get("total_hours", ""),
                "estimated_weeks": learning_path.get("estimated_weeks", ""),
            }
        recommendations = learning_path.get("recommendations", learning_path.get("ai_recommendations", []))
    elif isinstance(learning_path, list):
        phases = learning_path
        summary = {}
        recommendations = []
    else:
        summary = {}
        recommendations = []

    if phases:
        st.markdown('''
        <div style="color: #94a3b8 !important; font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.1em; font-weight: 600; margin: 24px 0 12px;">
            🗺️ Learning Path Phases
        </div>
        ''', unsafe_allow_html=True)

        st.markdown('<div class="phase-timeline">', unsafe_allow_html=True)

        for i, phase in enumerate(phases):
            phase_num = phase.get("phase", phase.get("phase_number", i + 1))
            phase_title = phase.get("title", phase.get("phase_title", f"Phase {phase_num}"))
            phase_desc = phase.get("description", "")
            phase_skills = phase.get("skills", phase.get("skills_covered", []))
            phase_courses = phase.get("courses", phase.get("course_names", []))
            duration = phase.get("duration", phase.get("duration_weeks", ""))
            accent, accent_bg = PHASE_PALETTE[i % len(PHASE_PALETTE)]

            if isinstance(phase_skills, str):
                phase_skills = [s.strip() for s in phase_skills.split(",")]
            if isinstance(phase_courses, str):
                phase_courses = [c.strip() for c in phase_courses.split(",")]

            skills_html = "".join(f'<span class="skill-pill-gap">{s}</span>' for s in phase_skills[:8])
            
            courses_html = ""
            for c in phase_courses[:5]:
                c_url = course_url_map.get(c, "")
                c_link = f'<a href="{c_url}" target="_blank" rel="noopener noreferrer" style="color: #a78bfa !important; text-decoration: none; font-size: 0.82rem; font-weight: 500; cursor: pointer; pointer-events: auto; position: relative; z-index: 10;">{c} ↗</a>' if c_url else f'<span style="color: #cbd5e1 !important; font-size: 0.82rem;">{c}</span>'
                courses_html += (
                    f'<div style="display: flex; align-items: center; gap: 6px; padding: 4px 0;">'
                    f'<span style="color: #6366f1 !important;">▸</span>'
                    f'{c_link}</div>'
                )

            st.markdown(f'''
            <div class="phase-node">
                <div class="training-phase-card" style="border-left-color: {accent}; background: {accent_bg} !important;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                        <div style="display: flex; align-items: center; gap: 10px;">
                            <span style="font-family: 'JetBrains Mono', monospace; font-size: 0.72rem; font-weight: 800; color: {accent} !important; background: {accent}18; padding: 4px 10px; border-radius: 8px; border: 1px solid {accent}33;">PHASE {phase_num}</span>
                            <span style="color: #e0e7ff !important; font-weight: 700; font-size: 0.95rem;">{phase_title}</span>
                        </div>
                        {f'<span style="font-size: 0.75rem; color: #94a3b8 !important; background: rgba(99,102,241,0.08); padding: 4px 10px; border-radius: 8px;">⏱ {duration} weeks</span>' if duration else ''}
                    </div>
                    {f'<div style="color: #94a3b8 !important; font-size: 0.85rem; line-height: 1.6; margin-bottom: 10px;">{phase_desc}</div>' if phase_desc else ''}
                    {f'<div style="margin-bottom: 8px;">{skills_html}</div>' if skills_html else ''}
                    {f'<div style="margin-top: 8px; padding-top: 8px; border-top: 1px solid rgba(99,102,241,0.08);">{courses_html}</div>' if courses_html else ''}
                </div>
            </div>
            ''', unsafe_allow_html=True)

        st.markdown('</div>', unsafe_allow_html=True)

    # ── Summary ───────────────────────────────────────────────────────────
    if summary:
        st.markdown("")
        schedule = summary.get("weekly_schedule", summary.get("schedule", ""))
        total_hours = summary.get("total_hours", summary.get("hours", ""))
        est_weeks = summary.get("estimated_weeks", summary.get("weeks", ""))

        cols = st.columns(3)
        summary_items = [
            ("📅", schedule or "—", "Weekly Schedule"),
            ("⏰", str(total_hours) if total_hours else "—", "Total Hours"),
            ("📆", str(est_weeks) if est_weeks else "—", "Est. Weeks"),
        ]
        for col, (icon, val, label) in zip(cols, summary_items):
            with col:
                st.markdown(f'''
                <div class="summary-stat">
                    <div style="font-size: 1.5rem; margin-bottom: 4px;">{icon}</div>
                    <div style="font-family: 'JetBrains Mono', monospace; font-size: 1.1rem; font-weight: 700; color: #e0e7ff !important;">{val}</div>
                    <div class="summary-stat-label">{label}</div>
                </div>
                ''', unsafe_allow_html=True)

    # ── AI Recommendations ────────────────────────────────────────────────
    if recommendations:
        st.markdown('''
        <div style="color: #94a3b8 !important; font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.1em; font-weight: 600; margin: 24px 0 12px;">
            💡 AI Recommendations
        </div>
        ''', unsafe_allow_html=True)

        recs_html = ""
        for rec in recommendations:
            if isinstance(rec, str):
                recs_html += (
                    '<div class="ai-rec-item">'
                    '<span style="color: #6366f1 !important; font-size: 1rem; flex-shrink: 0; margin-right: 8px;">◆</span>'
                    f'<span style="color: #cbd5e1 !important; font-size: 0.88rem; line-height: 1.5;">{rec}</span>'
                    '</div>'
                )
            elif isinstance(rec, dict):
                rec_text = rec.get("recommendation", rec.get("text", str(rec)))
                recs_html += (
                    '<div class="ai-rec-item">'
                    '<span style="color: #6366f1 !important; font-size: 1rem; flex-shrink: 0; margin-right: 8px;">◆</span>'
                    f'<span style="color: #cbd5e1 !important; font-size: 0.88rem; line-height: 1.5;">{rec_text}</span>'
                    '</div>'
                )

        st.markdown(f'<div class="glass-card" style="padding: 20px 24px;">{recs_html}</div>', unsafe_allow_html=True)


# ─────────────────────────────────────────────────────────────────────────────
# TAB 3  —  Assign Courses
# ─────────────────────────────────────────────────────────────────────────────
def _render_assign_tab(headers):
    st.markdown('<div class="section-divider"></div>', unsafe_allow_html=True)

    # Load previous analyses
    analyses = _fetch_json(f"{BASE_URL}/training/analyses", headers)

    if analyses is None:
        st.error("⚠️ Unable to load analyses. Please check the backend.")
        return

    if not analyses:
        st.markdown('''
        <div class="empty-state">
            <span class="empty-icon">📭</span>
            <h3>No analyses yet</h3>
            <p>Run your first skill gap analysis in the "Skill Gap Analysis" tab to get started</p>
        </div>
        ''', unsafe_allow_html=True)
        return

    # Select analysis
    analysis_options = {
        f"{a.get('employee_name', 'Unknown')} → {a.get('role_title', 'Unknown')} (Score: {a.get('readiness_score', 0):.0f}%)": a['id']
        for a in analyses
    }
    selected_analysis_label = st.selectbox(
        "📋 Select Previous Analysis",
        list(analysis_options.keys()),
        key="assign_analysis_select",
    )
    analysis_id = analysis_options[selected_analysis_label]

    # Fetch full analysis details
    detail = _fetch_json(f"{BASE_URL}/training/analyses/{analysis_id}", headers)
    if not detail:
        st.warning("Could not load analysis details.")
        return

    rec_courses = detail.get("recommended_courses", [])
    existing_assignments = detail.get("assignments", [])

    if not rec_courses:
        st.markdown('''
        <div style="text-align: center; padding: 32px; background: rgba(245,158,11,0.06) !important; border: 1px solid rgba(245,158,11,0.15); border-radius: 16px; margin-bottom: 16px;">
            <span style="font-size: 2rem; display: block; margin-bottom: 8px;">📚</span>
            <div style="color: #fbbf24 !important; font-weight: 600;">No recommended courses for this analysis</div>
            <div style="color: #94a3b8 !important; font-size: 0.85rem; margin-top: 4px;">This was a basic skill gap analysis. Click below to generate an AI Learning Path with course recommendations.</div>
        </div>
        ''', unsafe_allow_html=True)

        if st.button("🚀 Generate AI Plan for this Analysis", key="assign_quick_gen_btn", use_container_width=True):
            with st.spinner("🤖 Generating AI learning path with course recommendations..."):
                try:
                    res = requests.post(
                        f"{BASE_URL}/training/generate-plan",
                        json={"employee_id": detail.get("employee_id"), "role_template_id": detail.get("role_template_id")},
                        headers=headers,
                    )
                    if res.status_code == 200:
                        plan_result = res.json()
                        new_id = plan_result.get("analysis_id")
                        st.session_state["training_plan_result"] = plan_result
                        # Update the selectbox to point to the new analysis
                        new_label = f"{plan_result.get('employee_name', 'Unknown')} → {plan_result.get('role_title', 'Unknown')} (Score: {plan_result.get('readiness_score', 0):.0f}%)"
                        st.session_state["assign_analysis_select"] = new_label
                        st.success("✅ AI plan generated with course recommendations!")
                        st.rerun()
                    else:
                        st.error(f"Generation failed (HTTP {res.status_code}): {res.text}")
                except Exception as e:
                    st.error(f"Connection error: {e}")
        return

    # Show existing assignments if any
    assigned_ids = set()
    if existing_assignments:
        assigned_ids = {a.get("course_id") for a in existing_assignments}
        st.markdown(f'''
        <div style="display: flex; align-items: center; gap: 8px; padding: 10px 14px; background: rgba(16,185,129,0.08) !important; border: 1px solid rgba(16,185,129,0.15); border-radius: 10px; margin-bottom: 16px;">
            <span style="color: #34d399 !important; font-size: 0.85rem; font-weight: 500;">✅ {len(existing_assignments)} course(s) already assigned</span>
        </div>
        ''', unsafe_allow_html=True)

    # Course checkboxes using Streamlit form
    st.markdown('''
    <div style="color: #94a3b8 !important; font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.1em; font-weight: 600; margin-bottom: 12px;">
        Select Courses to Assign
    </div>
    ''', unsafe_allow_html=True)

    with st.form("assign_courses_form"):
        selected_course_ids = []
        for c in rec_courses:
            course_id = c.get("course_id", c.get("id", None))
            title = c.get("course_title", c.get("title", "Unknown Course"))
            skills = c.get("skills_covered", [])
            if isinstance(skills, str):
                skills = [s.strip() for s in skills.split(",")]

            already_assigned = course_id in assigned_ids
            label = f"📘 {title}"
            if already_assigned:
                label += " ✅ (Already Assigned)"

            checked = st.checkbox(
                label,
                value=False,
                disabled=already_assigned,
                key=f"assign_course_{course_id}",
            )
            if checked and course_id is not None:
                selected_course_ids.append(course_id)

            # Show skills as pills
            if skills:
                pills = " ".join(f'`{s}`' for s in skills[:5])
                st.caption(f"Skills: {pills}")

        st.markdown("")
        submitted = st.form_submit_button("✅ Assign Selected Courses", use_container_width=True)

        if submitted:
            if not selected_course_ids:
                st.warning("Please select at least one course to assign.")
            else:
                try:
                    res = requests.post(
                        f"{BASE_URL}/training/assign",
                        json={"gap_analysis_id": analysis_id, "course_ids": selected_course_ids},
                        headers=headers,
                    )
                    if res.status_code == 200:
                        result = res.json()
                        msg = result.get("message", "Courses assigned successfully!")
                        st.success(f"🎉 {msg}")

                        assignments = result.get("assignments", [])
                        if assignments:
                            st.markdown(f'''
                            <div class="glass-card" style="padding: 20px;">
                                <div style="color: #94a3b8 !important; font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.1em; font-weight: 600; margin-bottom: 12px;">
                                    Assigned Courses
                                </div>
                            ''', unsafe_allow_html=True)
                            for a in assignments:
                                st.markdown(f'''
                                <div class="assign-course-row">
                                    <span style="color: #34d399 !important;">✓</span>
                                    <span style="color: #e0e7ff !important; font-weight: 500; font-size: 0.88rem;">
                                        Course ID: {a.get("course_id", "—")}
                                    </span>
                                    <span class="badge badge-sent" style="margin-left: auto;">{a.get("status", "assigned")}</span>
                                </div>
                                ''', unsafe_allow_html=True)
                            st.markdown('</div>', unsafe_allow_html=True)
                    else:
                        st.error(f"Assignment failed (HTTP {res.status_code}): {res.text}")
                except Exception as e:
                    st.error(f"Connection error: {e}")


# ─────────────────────────────────────────────────────────────────────────────
# TAB 4  —  History
# ─────────────────────────────────────────────────────────────────────────────
def _render_history_tab(headers):
    st.markdown('<div class="section-divider"></div>', unsafe_allow_html=True)

    analyses = _fetch_json(f"{BASE_URL}/training/analyses", headers)

    if analyses is None:
        st.error("⚠️ Unable to load analysis history.")
        return

    if not analyses:
        st.markdown('''
        <div class="empty-state">
            <span class="empty-icon">📭</span>
            <h3>No analyses yet</h3>
            <p>Run your first skill gap analysis above</p>
        </div>
        ''', unsafe_allow_html=True)
        return

    # Summary header
    avg_score = sum(a.get("readiness_score", 0) for a in analyses) / len(analyses) if analyses else 0
    st.markdown(f'''
    <div style="display: flex; align-items: center; gap: 16px; padding: 14px 20px; background: rgba(99,102,241,0.06) !important; border: 1px solid rgba(99,102,241,0.12); border-radius: 14px; margin-bottom: 20px;">
        <span style="font-size: 1.3rem;">📊</span>
        <span style="color: #e0e7ff !important; font-weight: 600; font-size: 0.9rem;">
            {len(analyses)} analyses recorded
        </span>
        <span style="color: #94a3b8 !important; font-size: 0.82rem;">•</span>
        <span style="color: #94a3b8 !important; font-size: 0.85rem;">
            Avg readiness: <span style="font-family: 'JetBrains Mono', monospace; font-weight: 700; color: {score_color(avg_score)} !important;">{avg_score:.0f}%</span>
        </span>
    </div>
    ''', unsafe_allow_html=True)

    # List of analyses
    for a in analyses:
        a_id = a.get("id", "—")
        emp_name = a.get("employee_name", "Unknown")
        role_title = a.get("role_title", "Unknown")
        score = a.get("readiness_score", 0)
        analyzed_at_raw = a.get("analyzed_at", "") or ""
        sc = score_color(score)

        # Format date — clean up raw timestamp
        date_str = "—"
        if analyzed_at_raw:
            try:
                clean_ts = analyzed_at_raw.split(".")[0]  # Remove microseconds
                dt = datetime.fromisoformat(clean_ts)
                date_str = dt.strftime("%b %d, %Y at %I:%M %p")
            except Exception:
                date_str = analyzed_at_raw[:19] if len(analyzed_at_raw) > 19 else analyzed_at_raw

        st.markdown(f'''
        <div class="history-row">
            <div style="display: flex; align-items: center; gap: 14px;">
                <div style="width: 40px; height: 40px; border-radius: 12px; background: linear-gradient(135deg, #6366f1, #8b5cf6); display: flex; align-items: center; justify-content: center; font-size: 0.85rem; color: white !important; font-weight: 700; flex-shrink: 0;">
                    {emp_name[:2].upper() if emp_name else "??"}
                </div>
                <div>
                    <div style="color: #e0e7ff !important; font-weight: 600; font-size: 0.9rem;">{emp_name}</div>
                    <div style="color: #94a3b8 !important; font-size: 0.78rem;">Target: {role_title}</div>
                </div>
            </div>
            <div style="display: flex; align-items: center; gap: 20px;">
                <div style="text-align: right;">
                    <div style="font-family: 'JetBrains Mono', monospace; font-size: 1.2rem; font-weight: 800; color: {sc} !important; line-height: 1;">{score:.0f}%</div>
                    <div style="font-size: 0.65rem; color: #94a3b8 !important; text-transform: uppercase; letter-spacing: 0.06em;">Readiness</div>
                </div>
                <div style="width: 60px; height: 6px; background: rgba(99,102,241,0.1); border-radius: 3px; overflow: hidden;">
                    <div style="width: {min(score, 100):.0f}%; height: 100%; background: {score_gradient(score)}; border-radius: 3px;"></div>
                </div>
            </div>
        </div>
        ''', unsafe_allow_html=True)

        # Delete + View Details row
        detail_col, delete_col = st.columns([5, 1])
        with delete_col:
            if st.button("🗑️", key=f"del_analysis_{a_id}", help="Delete this analysis"):
                try:
                    del_res = requests.delete(f"{BASE_URL}/training/analyses/{a_id}", headers=headers)
                    if del_res.status_code == 200:
                        st.success("Deleted!")
                        st.rerun()
                    else:
                        st.error(f"Delete failed: {del_res.text}")
                except Exception as e:
                    st.error(f"Error: {e}")

        with detail_col:
            with st.expander(f"View Details  —  {emp_name}  ➜  {role_title}", expanded=False):
                st.markdown(f'''
                <div style="color: #94a3b8 !important; font-size: 0.8rem; margin-bottom: 12px;">
                    🕐 Analyzed: {date_str}  •  Analysis ID: #{a_id}
                </div>
                ''', unsafe_allow_html=True)

                # Gaps
                gaps = a.get("skill_gaps", [])
                if gaps:
                    st.markdown('''
                    <div style="color: #94a3b8 !important; font-size: 0.72rem; text-transform: uppercase; letter-spacing: 0.08em; font-weight: 600; margin-bottom: 8px;">
                        Skill Gaps
                    </div>
                    ''', unsafe_allow_html=True)

                    for g in gaps:
                        skill_name = g.get("skill", g.get("skill_name", "Unknown"))
                        current = g.get("current_level", g.get("current", 0))
                        required = g.get("required_level", g.get("required", 0))
                        priority = g.get("priority", "Medium")
                        p_color, p_bg = PRIORITY_COLORS.get(priority, ("#8b5cf6", "rgba(139,92,246,0.15)"))

                        st.markdown(f'''
                        <div style="display: flex; align-items: center; gap: 10px; padding: 8px 12px; margin-bottom: 4px; background: rgba(15,23,42,0.6) !important; border-radius: 8px; border: 1px solid rgba(99,102,241,0.06);">
                            <span style="color: #e0e7ff !important; font-weight: 500; font-size: 0.82rem; min-width: 120px;">{skill_name}</span>
                            <span style="font-family: 'JetBrains Mono', monospace; font-size: 0.72rem; color: #94a3b8 !important;">{current} → {required}</span>
                            <span class="gap-priority-badge" style="color: {p_color} !important; background: {p_bg}; border: 1px solid {p_color}33; margin-left: auto; font-size: 0.65rem;">{priority}</span>
                        </div>
                        ''', unsafe_allow_html=True)

                # AI Learning Path
                learning_path = a.get("ai_learning_path", {})
                if learning_path:
                    phases = []
                    if isinstance(learning_path, dict):
                        phases = learning_path.get("phases", learning_path.get("learning_phases", []))
                    elif isinstance(learning_path, list):
                        phases = learning_path

                    if phases:
                        st.markdown('''
                        <div style="color: #94a3b8 !important; font-size: 0.72rem; text-transform: uppercase; letter-spacing: 0.08em; font-weight: 600; margin: 12px 0 8px;">
                            Learning Path Phases
                        </div>
                        ''', unsafe_allow_html=True)

                        for i, phase in enumerate(phases):
                            phase_title = phase.get("title", phase.get("phase_title", f"Phase {i+1}"))
                            duration = phase.get("duration", phase.get("duration_weeks", ""))
                            accent = PHASE_PALETTE[i % len(PHASE_PALETTE)][0]

                            st.markdown(f'''
                            <div style="display: flex; align-items: center; gap: 10px; padding: 8px 12px; margin-bottom: 4px; background: rgba(99,102,241,0.04) !important; border-radius: 8px; border-left: 3px solid {accent};">
                                <span style="font-family: 'JetBrains Mono', monospace; font-size: 0.68rem; font-weight: 700; color: {accent} !important;">P{i+1}</span>
                                <span style="color: #e0e7ff !important; font-weight: 500; font-size: 0.82rem;">{phase_title}</span>
                                {f'<span style="margin-left: auto; font-size: 0.72rem; color: #94a3b8 !important;">⏱ {duration}w</span>' if duration else ''}
                            </div>
                            ''', unsafe_allow_html=True)

                # Recommended Courses
                rec_courses = a.get("recommended_courses", [])
                if rec_courses:
                    st.markdown('''
                    <div style="color: #94a3b8 !important; font-size: 0.72rem; text-transform: uppercase; letter-spacing: 0.08em; font-weight: 600; margin: 12px 0 8px;">
                        Recommended Courses
                    </div>
                    ''', unsafe_allow_html=True)

                    for c in rec_courses:
                        title = c.get("course_title", c.get("title", "Unknown"))
                        course_url = c.get("url", "")
                        c_title_html = f'<a href="{course_url}" target="_blank" rel="noopener noreferrer" style="color: #a78bfa !important; text-decoration: none; font-size: 0.82rem; font-weight: 500; cursor: pointer; pointer-events: auto; position: relative; z-index: 10;">{title} ↗</a>' if course_url else f'<span style="color: #cbd5e1 !important; font-size: 0.82rem;">{title}</span>'
                        st.markdown(f'''
                        <div style="display: flex; align-items: center; gap: 8px; padding: 6px 12px; margin-bottom: 3px;">
                            <span style="color: #6366f1 !important;">📘</span>
                            {c_title_html}
                        </div>
                        ''', unsafe_allow_html=True)


# ─────────────────────────────────────────────────────────────────────────────
# Utility
# ─────────────────────────────────────────────────────────────────────────────
def _fetch_json(url, headers):
    """Helper to GET JSON from API. Returns parsed JSON or None on failure."""
    try:
        res = requests.get(url, headers=headers)
        if res.status_code == 200:
            return res.json()
        else:
            return None
    except Exception:
        return None
