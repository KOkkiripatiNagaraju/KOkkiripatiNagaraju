import datetime
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from jose import jwt, JWTError
import bcrypt
from sqlalchemy.orm import Session

from config.database import settings, get_db
from repositories import crud

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="api/login")


def hash_password(plain: str) -> str:
    password_bytes = plain.encode('utf-8')
    salt = bcrypt.gensalt()
    hashed = bcrypt.hashpw(password_bytes, salt)
    return hashed.decode('utf-8')


def verify_password(plain: str, hashed: str) -> bool:
    password_bytes = plain.encode('utf-8')
    hashed_bytes = hashed.encode('utf-8')
    try:
        return bcrypt.checkpw(password_bytes, hashed_bytes)
    except Exception:
        return False


def create_access_token(email: str) -> str:
    expire = datetime.datetime.utcnow() + datetime.timedelta(hours=settings.ACCESS_TOKEN_EXPIRE_HOURS)
    payload = {"sub": email, "exp": expire}
    return jwt.encode(payload, settings.JWT_SECRET, algorithm=settings.ALGORITHM)


def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)):
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, settings.JWT_SECRET, algorithms=[settings.ALGORITHM])
        email: str = payload.get("sub")
        if email is None:
            raise credentials_exception
    except JWTError:
        raise credentials_exception

    user = crud.get_user_by_email(db, email=email)
    if user is None:
        raise credentials_exception
    return user


# Built-in HR staff accounts that always have HR-level API access.
# Mirrors the frontend rule: is_hr = is_manager or email in [recruiter, manager]
_HR_STAFF_EMAILS = {"recruiter@company.com", "manager@company.com"}


def _is_hr_user(user) -> bool:
    """
    Return True if the user has HR/manager access.
    Qualifies if:
      1. is_manager flag is True (set at registration or by an admin), OR
      2. The account email is one of the built-in seeded HR staff accounts.
    The frontend already grants UI access on the same rule — mirroring it here
    keeps the API and UI in sync so HR staff are never locked out.
    """
    return bool(user.is_manager) or (user.email in _HR_STAFF_EMAILS)


def require_manager(current_user=Depends(get_current_user)):
    """Dependency that enforces HR/manager access."""
    if not _is_hr_user(current_user):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Manager privileges required for this action."
        )
    return current_user
