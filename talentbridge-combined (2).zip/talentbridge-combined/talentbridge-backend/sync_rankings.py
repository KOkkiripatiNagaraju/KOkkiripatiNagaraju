import os
import sys

# Ensure app directory is in path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

DATABASE_URL = os.environ.get("DATABASE_URL", "postgresql://postgres:rootpassword123@db:5432/recruitment_db")

def main():
    print(f"Connecting to database at {DATABASE_URL}...")
    engine = create_engine(DATABASE_URL)
    Session = sessionmaker(bind=engine)
    session = Session()

    from models.schemas import Candidate, Job, ATSScore
    from agents.candidate_ranking import CandidateRankingAgent
    from repositories import crud

    ranking_agent = CandidateRankingAgent()

    print("Retrieving all jobs...")
    jobs = session.query(Job).all()
    for job in jobs:
        print(f"Processing Job ID {job.id} ({job.title})...")
        cands = session.query(Candidate).filter(Candidate.job_id == job.id).all()
        ranking_inputs = []
        for c in cands:
            score_rec = session.query(ATSScore).filter(ATSScore.candidate_id == c.id).first()
            if score_rec:
                ranking_inputs.append({
                    "candidate_id":   c.id,
                    "ats_score":      score_rec.total_score,
                    "experience":     c.experience_years or 0.0,
                    "semantic_score": score_rec.semantic_similarity,
                })
                print(f"  Candidate {c.id} ({c.name}): ATS Score={score_rec.total_score}, Exp={c.experience_years}, Semantic={score_rec.semantic_similarity}")

        if ranking_inputs:
            ranked_output = ranking_agent.compute_rankings(ranking_inputs)
            crud.update_rankings(session, job.id, ranked_output)
            print(f"  Successfully updated rankings for Job ID {job.id}. Count={len(ranked_output)}")
        else:
            print(f"  No scored candidates found for Job ID {job.id}.")

    session.close()
    print("Ranking sync complete!")

if __name__ == "__main__":
    main()
