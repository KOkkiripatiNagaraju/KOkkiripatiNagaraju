# AI HR Hub: Master Integration & Deployment Plan (Team Guide)

This document is the master blueprint for your team. It details the system architecture, database schema, user journey flow, team integration instructions, security patterns, and production deployment guide.

---

## 1. Unified Integration Architecture (Single-Host VM Edition)

The integrated system is packaged as a multi-container Docker Compose stack running behind an Nginx Reverse Proxy. Nginx acts as the secure entry gateway, translating paths and serving both client portals over HTTPS.

```mermaid
graph TB
    %% Client Tier
    subgraph Client Browser Tier
        user["User Browser (Admin / Recruiter / Employee / Candidate)"]
    end

    %% Gateway & Network Entry (Host VM)
    subgraph Gateway Entry (Host VM Ports)
        dns["Domain DNS (A Record to Host IP)"]
        nginx["Nginx Reverse Proxy & SSL Gateway (Port 80/443)"]
    end

    %% Isolated Bridge Network
    subgraph Docker Compose Isolated Bridge Network
        fe_rec["Recruiter UI Container (:8501)"]
        fe_cand["Candidate UI Container (:8502)"]
        be["FastAPI Backend Container (:8000)"]
        db["PostgreSQL Container (:5432)"]
    end

    %% External Cloud Tier
    subgraph External APIs & Services
        s3["AWS S3 Bucket (Resume PDFs, Onboarding Docs, Exit Audios)"]
        bedrock["AWS Bedrock (Llama 3.3 70B / Llama 3.2 11B)"]
        titan["AWS Bedrock (Titan Embeddings v2)"]
        brevo["Brevo SMTP API (Outreach Email Dispatcher)"]
    end

    %% Connection Lines
    user -->|1. Resolves Domain| dns
    dns -->|2. Routes Traffic| nginx
    
    nginx -->|3. Proxies Recruiter UI| fe_rec
    nginx -->|4. Proxies Candidate UI| fe_cand
    nginx -->|5. Proxies /api/| be

    fe_rec -->|6. HTTP Requests| be
    fe_cand -->|6. HTTP Requests| be
    be -->|7. SQL Transactions| db
    
    be -->|8. Uploads Files| s3
    be -->|9. Invokes AI Agents| bedrock
    be -->|10. Generates Vectors| titan
    be -->|11. Dispatches Email| brevo
```

### 1.1 Core Components
*   **Nginx Gateway:** Intercepts external traffic. Proxies standard ports (80/443) to Streamlit portals (`:8501`/`:8502`) and API backend (`:8000`). Database (5432) is isolated from external access.
*   **Recruiter Portal (:8501):** Streamlit app for HR admins to manage positions, view rankings, conduct interviews, and review email queues.
*   **Careers Portal (:8502):** Streamlit app for candidates to view active jobs and apply by submitting personal details and resumes.
*   **FastAPI Backend (:8000):** Exposes backend REST endpoints and orchestrates the AI agent swarm.
*   **PostgreSQL Database (:5432):** Houses all 15 relational tables. Backed by a Docker volume to persist data.

---

## 2. Consolidated Database Entity-Relationship Diagram (ERD)

This schema covers all modules, showing primary keys (**PK**), foreign keys (**FK**), and unique keys (**UK**).

```mermaid
erDiagram
    %% Core Tables
    jobs {
        int id PK
        string title
        string department
        jsonb skills_required
        string status "Active|Inactive"
    }
    candidates {
        int id PK
        int job_id FK "References jobs.id"
        string name
        string email
        string phone
        string status "Applied|Interviewing|Offered|Accepted|Rejected"
        jsonb skills
    }
    ats_scores {
        int id PK
        int candidate_id FK,UK "References candidates.id"
        float total_score
        jsonb skill_gaps
        string recommendation
    }
    interviews {
        int id PK
        int candidate_id FK "References candidates.id"
        boolean is_completed
        string join_token UK
        float overall_score
    }
    interview_questions {
        int id PK
        int interview_id FK "References interviews.id"
        string question_text
        string expected_answer
    }
    interview_answers {
        int id PK
        int interview_id FK "References interviews.id"
        int interview_question_id FK "References interview_questions.id"
        text candidate_answer
        float score
        text feedback
    }

    %% Onboarding Tables
    onboarding_processes {
        int id PK
        int candidate_id FK,UK "References candidates.id"
        int employee_id FK,UK "References employees.id"
        string status "In_Progress|Completed|Failed"
    }
    onboarding_documents {
        int id PK
        int onboarding_process_id FK "References onboarding_processes.id"
        string document_type "ID_Proof|Signed_Contract|Tax_Form"
        string s3_key
        string verification_status "Pending|Approved|Rejected"
    }

    %% Employee & Org Tables
    employees {
        int id PK
        string employee_code UK
        string name
        string email UK
        string status "Active|Onboarding|Terminated"
        jsonb skills_profile
    }
    organizational_structures {
        int id PK
        int employee_id FK,UK "References employees.id"
        int manager_id FK "References employees.id (Self-join)"
    }

    %% Training & Development Tables
    role_templates {
        int id PK
        string role_title UK
        jsonb required_skills
    }
    skill_gap_analyses {
        int id PK
        int employee_id FK "References employees.id"
        int target_role_template_id FK "References role_templates.id"
        float readiness_score
    }
    courses {
        int id PK
        string course_title UK
        jsonb skills_covered
        string description
    }
    course_assignments {
        int id PK
        int employee_id FK "References employees.id"
        int course_id FK "References courses.id"
        int gap_analysis_id FK "References skill_gap_analyses.id"
        string status "Assigned|In_Progress|Completed"
    }

    %% Policies & Chatbot Tables
    policies {
        int id PK
        string title UK
        text content_markdown
    }
    chatbot_tickets {
        int id PK
        int employee_id FK "References employees.id"
        text original_query
        string status "Escalated|Resolved"
    }

    %% Survey Tables
    survey_definitions {
        int id PK
        string title
        boolean is_anonymous
    }
    survey_questions {
        int id PK
        int survey_id FK "References survey_definitions.id"
        text question_text
    }
    survey_responses {
        int id PK
        int survey_id FK "References survey_definitions.id"
        int question_id FK "References survey_questions.id"
        int employee_id FK "References employees.id (NULL if anonymous)"
        text response_value
        float sentiment_score
    }

    %% Offboarding Tables
    offboarding_processes {
        int id PK
        int employee_id FK,UK "References employees.id"
        string exit_reason
        string status "Initiated|Exit_Interview_Scheduled|Completed"
    }
    exit_interviews {
        int id PK
        int offboarding_process_id FK,UK "References offboarding_processes.id"
        string audio_file_path
        text transcript
        float sentiment_score
    }

    %% Core Connections
    jobs ||--o{ candidates : "hosts"
    candidates ||--o| ats_scores : "scored"
    candidates ||--o{ interviews : "undergoes"
    interviews ||--|{ interview_questions : "comprises"
    interviews ||--|{ interview_answers : "saves"
    interview_questions ||--o{ interview_answers : "answers"

    %% Onboarding Connections
    candidates ||--o| onboarding_processes : "progresses"
    onboarding_processes ||--|{ onboarding_documents : "requires"
    onboarding_processes ||--o| employees : "creates"

    %% Employee & Org Connections
    employees ||--o| organizational_structures : "maps"
    employees ||--o{ skill_gap_analyses : "evaluates"
    employees ||--o{ course_assignments : "studies"
    employees ||--o{ chatbot_tickets : "asks"
    employees ||--o{ survey_responses : "fills"
    employees ||--o| offboarding_processes : "departs"

    %% T&D Connections
    role_templates ||--o{ skill_gap_analyses : "benchmarks"
    courses ||--o{ course_assignments : "teaches"
    skill_gap_analyses ||--o{ course_assignments : "resolves"

    %% Survey Connections
    survey_definitions ||--|{ survey_questions : "contains"
    survey_definitions ||--o{ survey_responses : "gathers"
    survey_questions ||--o{ survey_responses : "stores"

    %% Offboarding Connections
    offboarding_processes ||--o| exit_interviews : "reviews"
```

---

## 3. Example User Journey: From Recruitment to Exit

To understand how data flows through the 15 database tables, let's follow a candidate named **John Doe** through his entire lifecycle:

```
[Candidate John Doe] ──> 1. Recruitment (Fills Form: Name/Email/Phone & Uploads PDF)
                              │
                              ▼
                         FastAPI registers Candidate & triggers AI Parsing & Scoring
                              │
                              ▼
                         Recruiter views rankings on dashboard & selects John
                              │
                              ▼
                         2. Onboarding (Uploads ID/Tax Forms to S3)
                              │
                              ▼
                         3. Employee Directory (Assigned Code & Manager)
                              │
                              ▼
                         4. Training & Development (Skill Gap Analysis & Courses)
                              │
                              ▼
                         5. Policies & Surveys (Queries Chatbot & Fills Feedback)
                              │
                              ▼
                         6. Offboarding (Resigns ➔ Exit Interview Text Analytics) ──> Exit
```

1.  **Recruitment (Self-Apply):** 
    *   John visits the **Careers Portal** (`:8502`), clicks "Apply" for the Python Developer job.
    *   He enters his Name, Email, Phone, and uploads `John_Doe_Resume.pdf`.
    *   FastAPI saves the PDF to S3, writes John's typed contact details to the database, and calls **AWS Bedrock Llama 3.3** to extract skills and experience. Llama evaluates his skills, updates `candidates.skills`, and writes his score (`85/100`) to `ats_scores`.
    *   The recruiter views John at the top of the **Rankings** on the Recruiter Portal (`:8501`), conducts the automated voice interview, and clicks **Approve**, changing his status to `Offered`.
2.  **Onboarding:**
    *   An onboarding process is created in `onboarding_processes`. John uploads his ID proof and signed tax contracts. Files are stored in S3 and registered in `onboarding_documents` with state `Pending` until verified by HR.
3.  **Active Employee Directory:**
    *   Once onboarding is `Completed`, John's profile is promoted to the `employees` table: `EMP-045`, `status: "Active"`.
    *   His manager mapping is written to `organizational_structures` linking John to his department head.
4.  **Training & Development:**
    *   John's manager benchmarks him against the "Senior Lead Developer" **`role_template`**.
    *   FastAPI runs a gap assessment and records the gap details in `skill_gap_analyses`. 
    *   Based on the gaps, a python optimization course is assigned, writing a row to `course_assignments` linked to the **`courses`** table.
5.  **Policies & Surveys:**
    *   John asks the policy chatbot about health benefits. The chatbot fetches details from the `policies` table.
    *   He submits the monthly pulse survey. His feedback is written to `survey_responses`, and a local NLP model assigns a sentiment score (`0.82` positive) to flag team morale.
6.  **Offboarding:**
    *   John resigns after two years. An offboarding process is created in `offboarding_processes`.
    *   John records an audio exit notes entry. The backend uploads it to S3, transcripts the speech via Llama, computes the exit sentiment, and completes offboarding in `exit_interviews`. John's status changes to `Terminated`.

---

## 4. Local Development & Docker Stack Orchestration

Using Docker Compose avoids manual database setups. It runs Postgres, FastAPI, and both portals locally in two commands.

### 4.1 Running the Stack
1.  **Prerequisite:** Ensure **Docker Desktop** is installed and running.
2.  **Clone / Copy code:** Ensure all files are in your local project folder.
3.  **Configuration:** Open `docker-compose.yml` and replace placeholders with your credentials:
    *   `AWS_ACCESS_KEY_ID=YOUR_AWS_ACCESS_KEY_ID`
    *   `AWS_SECRET_ACCESS_KEY=YOUR_AWS_SECRET_ACCESS_KEY`
    *   `BREVO_API_KEY=YOUR_BREVO_API_KEY`
    *   `BREVO_SENDER_EMAIL=YOUR_SENDER_EMAIL`
4.  **Launch:** Open a terminal in the project root and run:
    ```bash
    docker compose up -d --build
    ```
5.  **Verification:** Once the build completes, open your browser to verify the services:
    *   **Recruiter Portal:** `http://localhost:8501`
    *   **Careers Portal (Candidate Self-Apply):** `http://localhost:8502`
    *   **Backend API Docs:** `http://localhost:8000/docs`

---

## 5. Team Git & Directory Collaboration Guidelines

Since multiple developers are building different modules, follow these safety protocols to avoid code conflicts.

### 5.1 Working with Git Branching
1.  **Never commit directly to `main`.** Always work on a descriptive feature branch:
    ```bash
    git checkout -b feature/onboarding
    ```
2.  **Pull changes frequently** from main to keep your branch updated:
    ```bash
    git checkout main
    git pull origin main
    git checkout feature/onboarding
    git merge main
    ```
3.  **Submit Pull Requests (PRs):** When your module is tested, push it to GitHub and open a PR. Have another team member review the code differences before merging.

### 5.2 Shared Directory Protocol (If not using Git)
If sharing code through a local network directory, Google Drive, or Dropbox:
1.  **Do NOT share Python caches or virtual environments:** Ensure `.venv/`, `__pycache__/`, `.streamlit/`, and log files are **never** copied to the shared drive.
2.  **Copy-to-Local Pattern:** Copy the shared project folder to your local desktop to edit and run. Once a feature is complete, copy **only** your specific new files (e.g., `routers/onboarding.py` and `views/onboarding.py`) back to the shared drive.
3.  **Single Gatekeeper:** To prevent file conflicts, **only the Lead Dev** should edit the main entrypoint files (`main.py`, `app.py`, `models/schemas.py`, and `docker-compose.yml`). Teammates will request the Lead to register their views and routers.

---

## 6. Detailed Step-by-Step Task Blueprints (Team Assignment)

### 6.1 Lead Developer (Recruitment Dev / Gatekeeper)
*   **Step 1:** Define the SQLAlchemy ORM models inside [models/schemas.py](file:///c:/Users/UMAMAHESHWARMANDA/Desktop/ai-recruitment-system%20-%20Copy/models/schemas.py) for all modules (Onboarding, T&D, Chatbot, Surveys, Offboarding) using the ERD in Section 2.
*   **Step 2:** Ensure [main.py](file:///c:/Users/UMAMAHESHWARMANDA/Desktop/ai-recruitment-system%20-%20Copy/main.py) imports `schemas` on startup to trigger table generation in PostgreSQL.
*   **Step 3:** Commit the project base configuration (including `Dockerfile`, `docker-compose.yml`, and `candidate_app.py`) to the repository/shared drive.
*   **Step 4 (Integration Phase):** As teammates finish, copy their backend and Streamlit view scripts into the project. Import and register their FastAPI routers in `main.py` and link their view functions inside the `nav_options` sidebar selector in `app.py`.

### 6.2 Onboarding Developer (Teammate 1)
*   **Step 1:** Launch the local Docker Compose environment. Database schemas will generate automatically.
*   **Step 2:** Create `routers/onboarding.py` for backend logic (fetching progress, verifying uploaded files). Use `db.query(schemas.OnboardingProcess)` and `db.query(schemas.OnboardingDocument)`.
*   **Step 3:** Create `views/onboarding.py`. Write a Streamlit dashboard function `render_onboarding_view()` showcasing candidate lists and document approvals.
*   **Step 4:** Share files with the Lead Dev for registration.

### 6.3 Training & Development Developer (Teammate 2)
*   **Step 1:** Launch the local Docker Compose environment.
*   **Step 2:** Create `routers/training.py` containing endpoints to calculate skill readiness scores against `RoleTemplate` targets and allocate `CourseAssignment` rows.
*   **Step 3:** Create `views/training.py` with `render_training_view()`, displaying skills progress charts, gap analysis results, and assignable courses.
*   **Step 4:** Share files with the Lead Dev for registration.

### 6.4 Policies & Chatbot Developer (Teammate 3)
*   **Step 1:** Launch the local Docker Compose environment.
*   **Step 2:** Create `routers/policies.py` to handle markdown policy reads and ticket elevations. Combine it with the Titan Embeddings client in `utils/bedrock_client.py` for similarity matching.
*   **Step 3:** Create `views/chatbot.py` with `render_chatbot_view()`, providing a chat input, displaying bot answers, and letting employees log tickets.
*   **Step 4:** Share files with the Lead Dev for registration.

### 6.5 Pulse Surveys & Offboarding Developer (Teammate 4)
*   **Step 1:** Launch the local Docker Compose environment.
*   **Step 2:** Create `routers/surveys.py` and `routers/offboarding.py` to handle questionnaire queries, record survey responses, evaluate sentiment scores, and record exit interviews.
*   **Step 3:** Create `views/surveys_offboarding.py` with `render_surveys_offboarding_view()`, displaying anonymized survey charts, sentiment trends, and offboarding exit forms.
*   **Step 4:** Share files with the Lead Dev for registration.

---

## 7. Single-Host VM Production Deployment Guide (EC2/VPS)

This single-host Docker Compose and Nginx approach easily serves **50+ concurrent active users** (hundreds of requests/sec) with minimal cost and maintenance.

### Step 1: Provision a Host VM
1.  Launch a virtual instance running **Ubuntu Server 22.04 LTS** (e.g. AWS EC2 `t3.medium` or a similar 2 vCPU, 4 GB RAM VPS).
2.  Configure Security Groups / Firewall rules to only expose:
    *   **Port 22:** SSH (Restricted to your team's IP addresses).
    *   **Port 80:** HTTP (Public access for Let's Encrypt SSL validations).
    *   **Port 443:** HTTPS (Public access for portal traffic).
    *   *Keep ports 5432, 8000, 8501, and 8502 blocked from the outside.*

### Step 2: Install Docker & Docker Compose
Connect to your VM via SSH and install Docker:
```bash
# Update and install pre-requisites
sudo apt update && sudo apt install -y apt-transport-https ca-certificates curl software-properties-common

# Add Docker's official GPG key
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg

# Add Docker repository
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

# Install Docker CE and Compose plugin
sudo apt update && sudo apt install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin
```

### Step 3: Clone Code & Configure Environment
1.  Clone the repository to your host VM under `/var/www/ai-hr-system`.
2.  Create a production `.env` file in the root folder of the project on the server:
    ```env
    DATABASE_URL=postgresql://postgres:secureproductionpassword123@db:5432/recruitment_db
    JWT_SECRET=generate-a-long-random-string-for-security-here
    AWS_ACCESS_KEY_ID=YOUR_PRODUCTION_AWS_ACCESS_KEY
    AWS_SECRET_ACCESS_KEY=YOUR_PRODUCTION_AWS_SECRET_KEY
    AWS_REGION=us-east-1
    S3_BUCKET_NAME=your-production-bucket-name
    BREVO_API_KEY=YOUR_PRODUCTION_BREVO_KEY
    BREVO_SENDER_EMAIL=your-sender@email.com
    ```
3.  Launch the containerized stack:
    ```bash
    sudo docker compose -f docker-compose.yml up -d --build
    ```
    This starts Postgres, FastAPI backend, recruiter portal, and candidate portal in detached mode.

### Step 4: Configure Nginx Reverse Proxy
Nginx serves as the public entry gate on the host, handling SSL termination and proxying traffic to the respective Docker container ports:
1.  Install Nginx and Let's Encrypt Certbot:
    ```bash
    sudo apt install -y nginx certbot python3-certbot-nginx
    ```
2.  Create an Nginx configuration file at `/etc/nginx/sites-available/hr-hub`:
    ```nginx
    server {
        listen 80;
        server_name hr.yourcompany.com;

        # 1. Recruiter Portal (Streamlit - Port 8501)
        location / {
            proxy_pass http://localhost:8501;
            proxy_http_version 1.1;
            proxy_set_header Upgrade $http_upgrade;
            proxy_set_header Connection "upgrade";
            proxy_set_header Host $host;
        }

        # 2. Candidate Portal (Streamlit - Port 8502)
        location /join {
            # Rewrites and forwards sub-path to the candidate container
            rewrite ^/join(.*)$ /$1 break;
            proxy_pass http://localhost:8502;
            proxy_http_version 1.1;
            proxy_set_header Upgrade $http_upgrade;
            proxy_set_header Connection "upgrade";
            proxy_set_header Host $host;
        }

        # 3. Backend API Gateway (FastAPI - Port 8000)
        location /api/ {
            proxy_pass http://localhost:8000/;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
        }
    }
    ```
3.  Enable configuration and restart Nginx:
    ```bash
    sudo ln -s /etc/nginx/sites-available/hr-hub /etc/nginx/sites-enabled/
    sudo systemctl restart nginx
    ```
4.  Acquire Let's Encrypt SSL certificates for automated HTTPS setup:
    ```bash
    sudo certbot --nginx -d hr.yourcompany.com
    ```
    Certbot will automatically verify the domain, write secure SSL configuration lines, and reload Nginx.

### Step 5: Domain DNS Routing
Add a **DNS A Record** in your domain provider control panel (GoDaddy, Cloudflare, etc.) mapping `hr.yourcompany.com` directly to the public IPv4 address of your Ubuntu host VM.

---

## 8. Deployment Timelines: AWS Native vs. Single-Host VPS (Docker)

| Task / Setup Phase | Option A (AWS Native: ECS, RDS, ALB, S3, Secrets Manager) | Option B (Single-Host: Docker Compose + Nginx VPS) |
| :--- | :--- | :--- |
| **Phase 1: DB Seeding & Local Docker Setup** | 1 Day (Configure models, local compose, verify logs) | 1 Day (Configure models, local compose, verify logs) |
| **Phase 2: Core Feature Logic Coding** | 4 Days (Teammates code routers/views, link to schemas) | 4 Days (Teammates code routers/views, link to schemas) |
| **Phase 3: Code Integration & PRs** | 2 Days (Branch merges, testing endpoints) | 2 Days (Branch merges, testing endpoints) |
| **Phase 4: Cloud Infrastructure Setup** | 3 Days (Configure VPC, subnets, gateways, IAM, ALB, ECS) | 0.5 Days (Provision Ubuntu VM, open firewalls, install Docker) |
| **Phase 5: Cloud Push & Container Test** | 2 Days (ECR push, task tasks, debug ECS network) | 0.5 Days (SSH in, git clone, docker compose up, check logs) |
| **Phase 6: SSL & DNS Verification** | 1 Day (ACM certificate, CloudFront mapping, Route 53) | 0.5 Days (Write Nginx config, run Certbot SSL, add A Record) |
| **Total Calendar Setup Loop** | **13 - 15 Days** | **7 - 8.5 Days** (Save ~1 business week) |

---

## 9. Security Access Patterns: RBAC vs. ABAC (For Teammates)

To secure candidate details and employee data, teammates should implement these access control guards inside their routers.

### 9.1 RBAC (Role-Based Access Control)
Access is granted based on the user's role (e.g. `Admin`, `Recruiter`, `Employee`, `Candidate`).

```python
from fastapi import HTTPException, Depends, status

# Dependency to check for recruiter roles
def require_recruiter(current_user: schemas.User = Depends(get_current_user)):
    if current_user.role not in ["Recruiter", "Admin"]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Forbidden: Recruiter access required."
        )
    return current_user

# Example Endpoint Guarded by RBAC
@router.get("/candidates/list")
def list_candidates(db: Session = Depends(get_db), recruiter: schemas.User = Depends(require_recruiter)):
    return crud.get_all_candidates(db)
```

### 9.2 ABAC (Attribute-Based Access Control)
Access is granted dynamically by matching attributes (e.g. comparing user department to resource department).

```python
from fastapi import HTTPException, Depends

# Dependency to check department match
def verify_department_access(
    job_id: int, 
    current_user: schemas.User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    # Admins bypass checks
    if current_user.role == "Admin":
        return True

    # Load resource attributes
    job = db.query(schemas.Job).filter(schemas.Job.id == job_id).first()
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")

    # Compare user attribute with resource attribute
    if current_user.department != job.department:
        raise HTTPException(
            status_code=403,
            detail=f"Forbidden: You belong to {current_user.department}, but this job belongs to {job.department}."
        )
    return True

# Example Endpoint Guarded by ABAC
@router.get("/jobs/{job_id}/candidates")
def get_job_candidates(
    job_id: int, 
    db: Session = Depends(get_db),
    authorized: bool = Depends(verify_department_access)
):
    return crud.get_candidates_by_job(db, job_id)
```
