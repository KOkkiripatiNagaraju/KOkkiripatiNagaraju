from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base, sessionmaker
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    DATABASE_URL: str = "postgresql://postgres:root@localhost:5432/recruitment_db"
    # Vertex AI
    VERTEX_PROJECT: str = ""
    VERTEX_LOCATION: str = "us-central1"
    # Legacy GCS / Gemini vars kept so old .env files don't break on startup
    GEMINI_API_KEY: str = ""
    GCS_BUCKET_NAME: str = ""
    # Legacy AWS vars kept so existing .env files don't break on startup
    AWS_ACCESS_KEY_ID: str = "mock_key"
    AWS_SECRET_ACCESS_KEY: str = "mock_secret"
    AWS_REGION: str = "us-east-1"
    S3_BUCKET_NAME: str = ""
    # Gmail API (OAuth2)
    GMAIL_CLIENT_ID: str = ""
    GMAIL_CLIENT_SECRET: str = ""
    GMAIL_REFRESH_TOKEN: str = ""
    GMAIL_REDIRECT_URI: str = "https://developers.google.com/oauthplayground"
    GMAIL_SENDER_EMAIL: str = "hr@company.com"
    INTERVIEW_PUBLIC_BASE_URL: str = "http://localhost:8000"
    JWT_SECRET: str = "change-me-in-production-use-a-long-random-string"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_HOURS: int = 12
    MOCK_AWS: bool = True
    BEDROCK_MODEL_ID: str = "gemini-2.5-flash"

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore"
    )


settings = Settings()

engine = create_engine(
    settings.DATABASE_URL,
    pool_pre_ping=True,
    pool_size=10,
    max_overflow=20,
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
