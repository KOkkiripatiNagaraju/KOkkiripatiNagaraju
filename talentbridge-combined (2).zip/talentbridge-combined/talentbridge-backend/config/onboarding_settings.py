"""
Onboarding-specific settings that piggyback on the base project's .env file.
GCS credentials are provided via GOOGLE_APPLICATION_CREDENTIALS (mounted in Docker).
"""
from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class OnboardingSettings(BaseSettings):
    # GCP storage
    gcs_bucket_name: str = ""
    offer_gcs_bucket: str = ""       # if empty, falls back to gcs_bucket_name

    # Legacy AWS vars — kept so old .env files don't crash on load (unused)
    aws_access_key_id: str = ""
    aws_secret_access_key: str = ""
    aws_region: str = "us-east-1"
    aws_session_token: str = ""
    offer_s3_bucket: str = ""
    s3_bucket_name: str = ""

    # Vertex AI config (replaces Gemini API key)
    vertex_project: str = ""
    vertex_location: str = "us-central1"
    vertex_model_id: str = "gemini-2.5-flash"

    # Legacy aliases so old code that reads these fields still works
    gemini_model_id: str = "gemini-2.5-flash"
    bedrock_model_id: str = "gemini-2.5-flash"

    # Local storage fallback for offer PDFs
    local_storage_dir: str = "storage/offers"

    # Storage provider: "gcs" or "local"
    storage_provider: str = "local"

    # Email provider: "gmail" or "local"
    email_provider: str = "local"
    gmail_client_id: str = ""
    gmail_client_secret: str = ""
    gmail_refresh_token: str = ""
    gmail_redirect_uri: str = "https://developers.google.com/oauthplayground"
    gmail_sender_email: str = "hr@company.com"

    # Identity provider
    identity_provider: str = "local"
    cognito_user_pool_id: str = ""
    cognito_client_id: str = ""
    company_email_domain: str = "company.com"

    # BGV AI verification toggle
    use_ai_bgv: bool = True
    tesseract_cmd: str = ""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    def effective_offer_bucket(self) -> str:
        return self.offer_gcs_bucket or self.gcs_bucket_name


@lru_cache
def get_onboarding_settings() -> OnboardingSettings:
    return OnboardingSettings()
