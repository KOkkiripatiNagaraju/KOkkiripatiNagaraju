"""
Email integration for onboarding — Gmail API or local log-only mode.
Replaces the previous Brevo (Sendinblue) integration.
"""
import datetime
import logging
from uuid import uuid4

from config.onboarding_settings import OnboardingSettings

logger = logging.getLogger(__name__)


class OnboardingEmailClient:
    def __init__(self, settings: OnboardingSettings):
        self.settings = settings

    async def send_offer_email(
        self,
        db,
        candidate_id: int,
        recipient: str,
        subject: str,
        body: str,
        attachment_content: bytes | None = None,
        attachment_name: str = "offer-letter.pdf",
    ) -> dict:
        """
        Send an offer email with optional PDF attachment via Gmail API.
        Returns dict with provider, status, message_id.
        """
        provider = self.settings.email_provider.lower()
        provider_message_id = f"local-{uuid4()}"
        status = "sent"

        # Check whether Gmail credentials are available
        has_credentials = bool(
            self.settings.gmail_client_id
            and self.settings.gmail_client_secret
            and self.settings.gmail_refresh_token
        )

        if provider == "gmail" and has_credentials:
            try:
                from utils.gmail_client import send_gmail_email

                attachments = []
                if attachment_content:
                    attachments.append({
                        "filename": attachment_name,
                        "content": attachment_content,
                        "mime_type": "application/pdf",
                    })

                # Convert plain-text body to minimal HTML for the offer letter
                html_body = body.replace("\n", "<br/>")

                success = send_gmail_email(
                    to_email=recipient,
                    to_name="Candidate",
                    subject=subject,
                    html_content=f"<p>{html_body}</p>",
                    plain_text=body,
                    attachments=attachments if attachments else None,
                )

                if success:
                    provider_message_id = f"gmail-{uuid4()}"
                    logger.info("Offer email sent via Gmail to %s", recipient)
                    status = "sent"
                else:
                    logger.error("Gmail offer email failed for %s.", recipient)
                    status = "failed"

            except Exception as exc:
                logger.error("Gmail email send failed: %s.", exc)
                status = "failed"
        else:
            logger.warning(
                "Gmail credentials not configured or provider is not 'gmail' "
                "(provider=%s, has_credentials=%s) — email not sent.",
                provider, has_credentials,
            )
            status = "failed"

        # Persist email log
        from models.onboarding_models import OnboardingEmailLog
        log = OnboardingEmailLog(
            candidate_id=candidate_id,
            recipient=recipient,
            subject=subject,
            provider=provider,
            status=status,
            provider_message_id=provider_message_id,
            created_at=datetime.datetime.utcnow(),
        )
        db.add(log)
        db.commit()

        return {"provider": provider, "status": status, "message_id": provider_message_id}
