"""
Storage integration — GCS or local filesystem for offer letter PDFs and BGV docs.
Replaces the boto3/S3 version; all method signatures are unchanged.
"""
import logging
from pathlib import Path
from uuid import uuid4
from urllib.parse import urlparse
from datetime import timedelta

from config.onboarding_settings import OnboardingSettings

logger = logging.getLogger(__name__)


class OnboardingStorageClient:
    def __init__(self, settings: OnboardingSettings):
        self.settings = settings
        self._gcs_client = None

    def _get_gcs_client(self):
        if self._gcs_client is None:
            from google.cloud import storage as gcs
            self._gcs_client = gcs.Client()
        return self._gcs_client

    def put_bytes(
        self,
        key_prefix: str,
        file_name: str,
        content: bytes,
        content_type: str = "application/octet-stream",
    ) -> str:
        safe_name = file_name.replace("/", "_").replace("\\", "_")
        key = f"{key_prefix.strip('/')}/{uuid4()}-{safe_name}"

        if self.settings.storage_provider.lower() == "gcs":
            bucket_name = self.settings.effective_offer_bucket()
            if not bucket_name:
                logger.warning("GCS bucket not configured — falling back to local storage")
            else:
                try:
                    client = self._get_gcs_client()
                    blob = client.bucket(bucket_name).blob(key)
                    blob.upload_from_string(content, content_type=content_type)
                    return f"gs://{bucket_name}/{key}"
                except Exception as exc:
                    logger.error("GCS upload failed, falling back to local: %s", exc)

        # Local fallback (unchanged)
        root = Path(self.settings.local_storage_dir)
        path = root / key
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(content)
        return str(path)

    def get_bytes(self, uri: str) -> bytes:
        if uri.startswith("gs://"):
            parsed = urlparse(uri)
            client = self._get_gcs_client()
            blob = client.bucket(parsed.netloc).blob(parsed.path.lstrip("/"))
            return blob.download_as_bytes()
        return Path(uri).read_bytes()
