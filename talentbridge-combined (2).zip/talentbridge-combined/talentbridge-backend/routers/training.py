"""
Training & Development API Router.

Endpoints for skill gap analysis, AI learning path generation,
course assignment, and analysis history.
"""
import logging
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from config.database import get_db
from models import schemas
from repositories import crud
from middleware.auth import get_current_user, require_manager
from services.training_adapters import (
    employee_skills_to_list,
    role_skills_to_list,
    course_orm_to_dict,
    build_employee_context,
    build_role_context,
)
from services.skill_gap_engine import analyze_skill_gaps
from services.course_recommender import recommend_courses
from services.bedrock_training import generate_learning_path

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/training")


# ─────────────────────────────────────────────────────────────────────────────
# Listing endpoints
# ─────────────────────────────────────────────────────────────────────────────

@router.get("/employees")
def list_training_employees(
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(get_current_user),
):
    """List all employees for the training selection dropdown."""
    employees = crud.get_all_employees(db)
    return [
        {
            "id": e.id,
            "name": e.name,
            "email": e.email,
            "employee_code": e.employee_code,
            "current_role": getattr(e, "current_role", None) or "Not specified",
            "department": getattr(e, "department", None) or "Not specified",
            "skills_profile": e.skills_profile,
        }
        for e in employees
    ]


@router.get("/role-templates")
def list_role_templates(
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(get_current_user),
):
    """List all role templates for the training selection dropdown."""
    roles = crud.get_all_role_templates(db)
    return [
        {
            "id": r.id,
            "role_title": r.role_title,
            "required_skills": r.required_skills,
            "department": getattr(r, "department", None),
            "description": getattr(r, "description", None),
        }
        for r in roles
    ]


@router.get("/courses")
def list_courses(
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(get_current_user),
):
    """List all courses in the training catalog."""
    courses = crud.get_courses(db)
    return [
        {
            "id": c.id,
            "course_title": c.course_title,
            "skills_covered": c.skills_covered,
            "description": c.description,
            "url": getattr(c, "url", None),
        }
        for c in courses
    ]


# ─────────────────────────────────────────────────────────────────────────────
# Analysis endpoints
# ─────────────────────────────────────────────────────────────────────────────

@router.post("/analyze")
def run_analysis(
    req: schemas.TrainingAnalyzeRequest,
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(get_current_user),
):
    """Run skill gap analysis (without AI learning path) and persist results."""
    emp = crud.get_employee_by_id(db, req.employee_id)
    if not emp:
        raise HTTPException(status_code=404, detail="Employee not found.")
    role = crud.get_role_template_by_id(db, req.role_template_id)
    if not role:
        raise HTTPException(status_code=404, detail="Role template not found.")

    emp_skills = employee_skills_to_list(emp)
    role_skills = role_skills_to_list(role)
    result = analyze_skill_gaps(emp_skills, role_skills)

    analysis = crud.create_skill_gap_analysis(
        db,
        employee_id=emp.id,
        target_role_template_id=role.id,
        readiness_score=result["readiness_score"],
        skill_gaps=result["skill_gaps"],
        ai_learning_path=None,
        recommended_courses=None,
    )

    logger.info("Skill gap analysis: %s -> %s (%.1f%%)",
                emp.name, role.role_title, result["readiness_score"])

    return {
        "analysis_id": analysis.id,
        "readiness_score": result["readiness_score"],
        "skill_gaps": result["skill_gaps"],
        "employee_name": emp.name,
        "role_title": role.role_title,
    }


@router.post("/generate-plan")
def generate_plan(
    req: schemas.TrainingGeneratePlanRequest,
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(get_current_user),
):
    """Run full analysis, course recommendation, and AI learning path generation."""
    emp = crud.get_employee_by_id(db, req.employee_id)
    if not emp:
        raise HTTPException(status_code=404, detail="Employee not found.")
    role = crud.get_role_template_by_id(db, req.role_template_id)
    if not role:
        raise HTTPException(status_code=404, detail="Role template not found.")

    all_courses = crud.get_courses(db)

    # Step 1: Skill gap analysis
    emp_skills = employee_skills_to_list(emp)
    role_skills = role_skills_to_list(role)
    gap_result = analyze_skill_gaps(emp_skills, role_skills)

    # Step 2: Course recommendations
    course_dicts = [course_orm_to_dict(c) for c in all_courses]
    recommended = recommend_courses(gap_result["skill_gaps"], course_dicts)

    # Step 3: AI learning path (with fallback)
    emp_ctx = build_employee_context(emp)
    role_ctx = build_role_context(role)
    ai_path = generate_learning_path(emp_ctx, role_ctx, gap_result["skill_gaps"], recommended)

    # Step 4: Persist
    analysis = crud.create_skill_gap_analysis(
        db,
        employee_id=emp.id,
        target_role_template_id=role.id,
        readiness_score=gap_result["readiness_score"],
        skill_gaps=gap_result["skill_gaps"],
        ai_learning_path=ai_path,
        recommended_courses=recommended,
    )

    logger.info("Generated learning plan for %s -> %s", emp.name, role.role_title)

    return {
        "analysis_id": analysis.id,
        "readiness_score": gap_result["readiness_score"],
        "skill_gaps": gap_result["skill_gaps"],
        "recommended_courses": recommended,
        "ai_learning_path": ai_path,
        "employee_name": emp.name,
        "role_title": role.role_title,
    }


# ─────────────────────────────────────────────────────────────────────────────
# Assignment endpoint
# ─────────────────────────────────────────────────────────────────────────────

@router.post("/assign")
def assign_courses(
    req: schemas.TrainingAssignRequest,
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(require_manager),
):
    """Assign recommended courses to employee (Manager only)."""
    analysis = crud.get_skill_gap_analysis(db, req.gap_analysis_id)
    if not analysis:
        raise HTTPException(status_code=404, detail="Analysis not found.")

    assignments = []
    for cid in req.course_ids:
        course = db.query(schemas.Course).filter(schemas.Course.id == cid).first()
        if not course:
            logger.warning("Skipping invalid course_id=%d", cid)
            continue
        a = crud.create_course_assignment(db, analysis.employee_id, cid, analysis.id)
        assignments.append({
            "id": a.id,
            "course_id": a.course_id,
            "course_title": course.course_title,
            "status": a.status,
        })

    logger.info("Assigned %d courses for analysis %d", len(assignments), analysis.id)
    return {
        "message": f"{len(assignments)} course(s) assigned successfully",
        "assignments": assignments,
    }


# ─────────────────────────────────────────────────────────────────────────────
# History / detail endpoints
# ─────────────────────────────────────────────────────────────────────────────

@router.get("/analyses")
def list_analyses(
    employee_id: Optional[int] = None,
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(get_current_user),
):
    """List all analyses, optionally filtered by employee_id."""
    if employee_id:
        emp = crud.get_employee_by_id(db, employee_id)
        employees = [emp] if emp and emp.training_plan else []
    else:
        employees = (
            db.query(schemas.Employee)
            .filter(schemas.Employee.training_plan != None)
            .all()
        )

    result = []
    for emp in employees:
        a = emp.training_plan
        if not a:
            continue
        role = crud.get_role_template_by_id(db, a.get("target_role_template_id"))
        result.append({
            "id": emp.id,
            "employee_id": emp.id,
            "employee_name": emp.name,
            "role_template_id": a.get("target_role_template_id"),
            "role_title": role.role_title if role else "Unknown",
            "readiness_score": a.get("readiness_score"),
            "analyzed_at": a.get("analyzed_at"),
            "skill_gaps": a.get("skill_gaps"),
            "ai_learning_path": a.get("ai_learning_path"),
            "recommended_courses": a.get("recommended_courses"),
        })
    return result


@router.get("/analyses/{analysis_id}")
def get_analysis_detail(
    analysis_id: int,
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(get_current_user),
):
    """Get detailed view of a specific analysis."""
    a = crud.get_skill_gap_analysis(db, analysis_id)
    if not a:
        raise HTTPException(status_code=404, detail="Analysis not found.")

    emp = crud.get_employee_by_id(db, a.employee_id)
    role = crud.get_role_template_by_id(db, a.target_role_template_id)
    assignments = crud.get_course_assignments_by_analysis(db, analysis_id)

    return {
        "id": a.id,
        "employee_id": a.employee_id,
        "employee_name": emp.name if emp else "Unknown",
        "role_template_id": a.target_role_template_id,
        "role_title": role.role_title if role else "Unknown",
        "readiness_score": a.readiness_score,
        "analyzed_at": str(a.analyzed_at) if a.analyzed_at else None,
        "skill_gaps": getattr(a, "skill_gaps", None),
        "ai_learning_path": getattr(a, "ai_learning_path", None),
        "recommended_courses": getattr(a, "recommended_courses", None),
        "assignments": [
            {
                "id": ca.id,
                "course_id": ca.course_id,
                "status": ca.status,
                "assigned_at": str(ca.assigned_at) if ca.assigned_at else None,
            }
            for ca in assignments
        ],
    }


@router.delete("/analyses/{analysis_id}")
def delete_analysis(
    analysis_id: int,
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(require_manager),
):
    """Delete an analysis and its associated course assignments."""
    emp = db.query(schemas.Employee).filter(schemas.Employee.id == analysis_id).first()
    if not emp or not emp.training_plan:
        raise HTTPException(status_code=404, detail="Analysis not found.")

    emp.training_plan = None
    from sqlalchemy.orm.attributes import flag_modified
    flag_modified(emp, "training_plan")
    db.commit()
    logger.info("Deleted analysis for employee %d", analysis_id)
    return {"message": f"Analysis #{analysis_id} deleted successfully"}


@router.post("/skills/self-rate")
def save_self_rating(
    skills: dict,
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(get_current_user),
):
    """Save or update employee's skills self-rating in skills_profile."""
    emp = db.query(schemas.Employee).filter(schemas.Employee.email == current_user.email).first()
    if not emp:
        raise HTTPException(status_code=404, detail="Employee record not found for this user.")

    emp.skills_profile = skills
    from sqlalchemy.orm.attributes import flag_modified
    flag_modified(emp, "skills_profile")
    db.commit()
    db.refresh(emp)

    return {"message": "Skills profile updated successfully", "skills_profile": emp.skills_profile}
