"""
Pulse Survey API Router
Provides endpoints for survey management, response submission, and dashboard analytics.
"""
import datetime
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List, Dict, Any, Optional

from config.database import get_db
from models.schemas import (
    Employee, SurveyDefinition, SurveyQuestion, Policy,
    PulseSurveyResponse, AIInsight, DashboardMetric,
    PulseSurveyStartRequest, PulseSurveyStartResponse,
    PulseSurveyResponseCreate, PulseSurveyQuestionSchema,
    PulseEmployeeDashboardResponse, PulseHRDashboardResponse,
    PulseSurveyCheckResponse, SurveyCreateSchema
)
from services.pulse_survey_crud import (
    get_survey, get_surveys, get_employee_by_id,
    create_pulse_survey_response, get_employee_insights
)
from services.pulse_s3_service import pulse_s3_service
from services.pulse_rag_service import pulse_rag_service

router = APIRouter(prefix="/pulse-survey", tags=["Pulse Survey"])


@router.get("/surveys")
def list_surveys(db: Session = Depends(get_db)):
    """Fetch all available surveys."""
    surveys = get_surveys(db)
    results = []
    for s in surveys:
        # Get description from first question or survey title
        results.append({
            "id": s.id,
            "title": s.title,
            "description": f"Pulse survey: {s.title}",
            "type": "form"
        })
    return results


@router.post("/create")
def create_survey(survey_in: SurveyCreateSchema, db: Session = Depends(get_db)):
    """Create a new custom survey definition with questions."""
    db_survey = SurveyDefinition(
        title=survey_in.title,
        is_anonymous=survey_in.is_anonymous
    )
    db.add(db_survey)
    db.commit()
    db.refresh(db_survey)

    for idx, q in enumerate(survey_in.questions):
        seq = q.sequence if q.sequence is not None else (idx + 1)
        db_question = SurveyQuestion(
            survey_id=db_survey.id,
            question_text=q.question_text,
            type=q.type,
            options=q.options,
            sequence=seq
        )
        db.add(db_question)
    
    db.commit()
    return {"message": "Survey created successfully.", "survey_id": db_survey.id}


SURVEY_COOLDOWN_DAYS = 30  # 1-month cooldown between survey submissions


@router.get("/frequency-check/{employee_id}", response_model=PulseSurveyCheckResponse)
def check_survey_frequency(employee_id: int, db: Session = Depends(get_db)):
    """Check if employee can submit another survey (30-day cooldown)."""
    employee = get_employee_by_id(db, employee_id)
    if not employee or not employee.last_survey_submission:
        return PulseSurveyCheckResponse(is_allowed=True)

    now = datetime.datetime.utcnow()
    diff = now - employee.last_survey_submission
    cooldown = datetime.timedelta(days=SURVEY_COOLDOWN_DAYS)

    if diff < cooldown:
        remaining = cooldown - diff
        remaining_seconds = int(remaining.total_seconds())
        days = remaining_seconds // 86400
        hours = (remaining_seconds % 86400) // 3600
        minutes = (remaining_seconds % 3600) // 60
        return PulseSurveyCheckResponse(
            is_allowed=False,
            remaining_days=days,
            remaining_hours=hours,
            remaining_minutes=minutes
        )

    return PulseSurveyCheckResponse(is_allowed=True)


@router.post("/start", response_model=PulseSurveyStartResponse)
def start_survey_session(request: PulseSurveyStartRequest, db: Session = Depends(get_db)):
    """Initialize a survey session — validate employee and fetch questions."""
    survey = get_survey(db, request.survey_id)
    if not survey:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Survey with ID {request.survey_id} not found."
        )

    employee_name = None
    if request.employee_id:
        employee = get_employee_by_id(db, request.employee_id)
        if not employee:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Employee ID {request.employee_id} not recognized."
            )
        employee_name = employee.name

    # Get questions for this survey
    questions = db.query(SurveyQuestion)\
        .filter(SurveyQuestion.survey_id == survey.id)\
        .order_by(SurveyQuestion.sequence.asc().nullslast(), SurveyQuestion.id.asc())\
        .all()

    question_schemas = [
        PulseSurveyQuestionSchema(
            id=q.id,
            survey_id=q.survey_id,
            question_text=q.question_text,
            type=q.type or "text",
            options=q.options,
            sequence=q.sequence or idx + 1
        )
        for idx, q in enumerate(questions)
    ]

    return PulseSurveyStartResponse(
        survey_id=survey.id,
        title=survey.title,
        description=f"Pulse survey: {survey.title}",
        type="form",
        questions=question_schemas,
        employee_name=employee_name
    )


@router.post("/response")
def submit_survey_response(response_in: PulseSurveyResponseCreate, db: Session = Depends(get_db)):
    """Submit survey answers — triggers AI analysis and S3 backup."""
    # Validate employee if provided
    if response_in.employee_id:
        employee = get_employee_by_id(db, response_in.employee_id)
        if not employee:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Employee ID {response_in.employee_id} not found."
            )

        # Server-side frequency enforcement (30-day cooldown)
        if employee.last_survey_submission:
            diff = datetime.datetime.utcnow() - employee.last_survey_submission
            if diff < datetime.timedelta(days=SURVEY_COOLDOWN_DAYS):
                remaining_days = (datetime.timedelta(days=SURVEY_COOLDOWN_DAYS) - diff).days
                raise HTTPException(
                    status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                    detail=f"You have already submitted a survey recently. Please wait {remaining_days} more day(s) before submitting again."
                )

    # Process and save response
    try:
        db_emp_id = None if response_in.is_anonymous else response_in.employee_id
        response = create_pulse_survey_response(
            db,
            employee_id=db_emp_id,
            survey_id=response_in.survey_id,
            response_data=response_in.response_data
        )

        # Update last survey submission timestamp for cooldown tracking
        if response_in.employee_id:
            employee = get_employee_by_id(db, response_in.employee_id)
            if employee:
                employee.last_survey_submission = datetime.datetime.utcnow()
                db.commit()
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to record and analyze response: {e}"
        )

    # S3 backup
    s3_path = pulse_s3_service.upload_response_backup(response.id, response_in.response_data)

    # Check if insight was generated
    insight = db.query(AIInsight).filter(AIInsight.response_id == response.id).first()

    return {
        "message": "Response submitted and analyzed successfully.",
        "response_id": response.id,
        "backup_destination": s3_path,
        "insights_generated": insight is not None
    }


@router.get("/dashboard/employee/{employee_id}", response_model=PulseEmployeeDashboardResponse)
def get_employee_dashboard(employee_id: int, db: Session = Depends(get_db)):
    """Compile personal sentiment metrics, recommendations, and history for an employee."""
    employee = get_employee_by_id(db, employee_id)
    if not employee:
        raise HTTPException(status_code=404, detail="Employee not found")

    insights = get_employee_insights(db, employee_id)

    if insights:
        avg_sentiment = sum(ins.sentiment_score for ins in insights) / len(insights)
        latest_emotions = insights[0].emotion_scores
        latest_recs = insights[0].recommendations.get("employee", [])

        # RAG search using latest comments
        latest_response = db.query(PulseSurveyResponse)\
            .filter(PulseSurveyResponse.id == insights[0].response_id).first()
        feedback_text = ""
        if latest_response:
            feedback_text = " ".join(
                str(v) for v in latest_response.response_data.values()
                if isinstance(v, str) and len(v) > 5
            )

        if feedback_text:
            resources = pulse_rag_service.retrieve_policies(feedback_text, db, limit=2)
        else:
            resources = [
                {"title": p.title, "content": (p.content_markdown or "")[:150] + "...", "category": getattr(p, 'category', 'general') or 'general'}
                for p in db.query(Policy).limit(2).all()
            ]

        sentiment_summary = (
            "Positive engagement" if avg_sentiment > 0.3 else
            "Moderate engagement" if avg_sentiment > -0.1 else
            "High stress or lower satisfaction detected"
        )
    else:
        latest_emotions = {"Stress": 0.0, "Burnout": 0.0, "Satisfaction": 0.5, "Anxiety": 0.0, "Excitement": 0.0}
        latest_recs = ["Complete your first survey to generate active tips."]
        resources = []
        sentiment_summary = "No survey responses on record."

    # Historical data
    history_data = []
    for ins in reversed(insights):
        resp = db.query(PulseSurveyResponse).filter(PulseSurveyResponse.id == ins.response_id).first()
        history_data.append({
            "date": resp.timestamp.strftime("%Y-%m-%d") if resp else "Unknown",
            "sentiment": ins.sentiment_score,
            "stress": ins.emotion_scores.get("Stress", 0.0),
            "burnout": ins.emotion_scores.get("Burnout", 0.0),
            "satisfaction": ins.emotion_scores.get("Satisfaction", 0.0)
        })

    has_anon = False
    if employee.last_survey_submission and not insights:
        has_anon = True

    return PulseEmployeeDashboardResponse(
        employee_id=employee.id,
        employee_name=employee.name,
        department=employee.department,
        sentiment_summary=sentiment_summary,
        emotion_chart_data=latest_emotions,
        recommendations=latest_recs,
        resources=resources,
        history=history_data,
        has_anonymous_submission=has_anon
    )


@router.get("/dashboard/hr", response_model=PulseHRDashboardResponse)
def get_hr_dashboard(survey_id: Optional[int] = None, db: Session = Depends(get_db)):
    """Compile company-wide statistics, department comparisons, and strategic alerts."""
    # Resolve target survey_id
    if not survey_id:
        latest_survey = db.query(SurveyDefinition).order_by(SurveyDefinition.id.desc()).first()
        target_survey_id = latest_survey.id if latest_survey else 1
    else:
        target_survey_id = survey_id

    total_employees = db.query(Employee).count()
    total_responses = db.query(PulseSurveyResponse).filter(PulseSurveyResponse.survey_id == target_survey_id).count()

    # Fetch org-wide aggregates for target survey
    metrics = db.query(DashboardMetric).filter(DashboardMetric.survey_id == target_survey_id).all()
    all_metric = next((m for m in metrics if m.department == "All"), None)

    if all_metric:
        overall_sentiment = all_metric.aggregated_sentiment
        top_topics_dict = all_metric.aggregated_topics or {}
        risk_summary_dict = all_metric.risk_summary or {"High": 0, "Medium": 0, "Low": 0}
    else:
        overall_sentiment = 0.0
        top_topics_dict = {}
        risk_summary_dict = {"High": 0, "Medium": 0, "Low": 0}

    top_topics_list = [{"topic": k, "count": v} for k, v in sorted(top_topics_dict.items(), key=lambda x: x[1], reverse=True)]

    # Department sentiment comparison
    dept_metrics = [m for m in metrics if m.department != "All"]
    dept_sentiment = {m.department: m.aggregated_sentiment for m in dept_metrics}

    # Department stress and risk
    dept_stress = {}
    dept_risks = {}
    all_departments = db.query(Employee.department).distinct().all()
    all_departments = [d[0] for d in all_departments if d[0]]

    for dept in all_departments:
        dept_emp_ids = [e.id for e in db.query(Employee).filter(Employee.department == dept).all()]
        dept_resp_ids = [r.id for r in db.query(PulseSurveyResponse).filter(
            PulseSurveyResponse.employee_id.in_(dept_emp_ids),
            PulseSurveyResponse.survey_id == target_survey_id
        ).all()] if dept_emp_ids else []

        dept_insights = db.query(AIInsight).filter(
            AIInsight.response_id.in_(dept_resp_ids)
        ).all() if dept_resp_ids else []

        if dept_insights:
            avg_stress = sum(ins.emotion_scores.get("Stress", 0.0) for ins in dept_insights) / len(dept_insights)
            dept_stress[dept] = round(avg_stress, 2)
            risks = {"High": 0, "Medium": 0, "Low": 0}
            for ins in dept_insights:
                risks[ins.retention_risk] = risks.get(ins.retention_risk, 0) + 1
            dept_risks[dept] = risks
        else:
            dept_stress[dept] = 0.0
            dept_risks[dept] = {"High": 0, "Medium": 0, "Low": 0}

    # Strategic priorities from AI recommendations for target survey
    target_resp_ids = [r.id for r in db.query(PulseSurveyResponse).filter(PulseSurveyResponse.survey_id == target_survey_id).all()]
    insights = db.query(AIInsight).filter(AIInsight.response_id.in_(target_resp_ids)).all() if target_resp_ids else []
    strategic_priorities = []
    for ins in insights:
        for hr_tip in ins.recommendations.get("hr", []):
            if hr_tip not in strategic_priorities:
                strategic_priorities.append(hr_tip)

    # RAG policy suggestions
    all_concatenated_comments = ""
    for resp in db.query(PulseSurveyResponse).filter(PulseSurveyResponse.survey_id == target_survey_id).limit(5).all():
        for ans in resp.response_data.values():
            if isinstance(ans, str) and len(ans) > 10:
                all_concatenated_comments += " " + ans

    if len(all_concatenated_comments) > 15:
        policy_recs = pulse_rag_service.retrieve_policies(all_concatenated_comments, db, limit=3)
    else:
        policy_recs = [
            {"title": p.title, "content": (p.content_markdown or "")[:200] + "...", "category": getattr(p, 'category', 'general') or 'general'}
            for p in db.query(Policy).limit(3).all()
        ]

    # Historical sentiment trend
    responses = db.query(PulseSurveyResponse).filter(PulseSurveyResponse.survey_id == target_survey_id).order_by(PulseSurveyResponse.timestamp.asc()).all()
    response_ids = [r.id for r in responses]
    all_insights = db.query(AIInsight).filter(AIInsight.response_id.in_(response_ids)).all() if response_ids else []
    insight_by_resp = {ins.response_id: ins for ins in all_insights}

    history_dict = {}
    for r in responses:
        date_str = r.timestamp.strftime("%Y-%m-%d")
        ins = insight_by_resp.get(r.id)
        if ins:
            if date_str not in history_dict:
                history_dict[date_str] = []
            history_dict[date_str].append(ins.sentiment_score)

    historical_trend = []
    for d_str, scores in history_dict.items():
        historical_trend.append({
            "date": d_str,
            "sentiment": round(sum(scores) / len(scores), 2)
        })

    return PulseHRDashboardResponse(
        total_employees=total_employees,
        total_responses=total_responses,
        overall_sentiment=round(overall_sentiment, 2),
        department_sentiment=dept_sentiment,
        department_stress_levels=dept_stress,
        risk_by_department=dept_risks,
        top_topics=top_topics_list[:5],
        strategic_priorities=strategic_priorities[:5],
        policy_recommendations=policy_recs,
        historical_sentiment_trend=historical_trend
    )


@router.get("/dashboard/department/{department}")
def get_department_dashboard(department: str, survey_id: Optional[int] = None, db: Session = Depends(get_db)):
    """Department-specific drill-down analytics (combined Manager Dashboard logic)."""
    # Resolve target survey_id
    if not survey_id:
        latest_survey = db.query(SurveyDefinition).order_by(SurveyDefinition.id.desc()).first()
        target_survey_id = latest_survey.id if latest_survey else 1
    else:
        target_survey_id = survey_id

    # Get department employees
    dept_employees = db.query(Employee).filter(Employee.department == department).all()
    emp_ids = [e.id for e in dept_employees]

    if not emp_ids:
        return {
            "department": department,
            "team_size": 0,
            "average_sentiment": 0.0,
            "emotion_distribution": {"Stress": 0.0, "Burnout": 0.0, "Satisfaction": 0.5, "Anxiety": 0.0, "Excitement": 0.0},
            "topic_clusters": {},
            "retention_risk_summary": {"High": 0, "Medium": 0, "Low": 0},
            "coaching_tips": ["Encourage team members to submit their quarterly surveys."],
            "recent_responses_count": 0
        }

    # Get insights for these employees and target survey
    resp_ids = [r.id for r in db.query(PulseSurveyResponse).filter(
        PulseSurveyResponse.employee_id.in_(emp_ids),
        PulseSurveyResponse.survey_id == target_survey_id
    ).all()]

    insights = db.query(AIInsight).filter(
        AIInsight.response_id.in_(resp_ids)
    ).all() if resp_ids else []

    team_size = len(emp_ids)
    coaching_tips = []

    if insights:
        avg_sentiment = sum(ins.sentiment_score for ins in insights) / len(insights)

        emotions = {"Stress": 0.0, "Burnout": 0.0, "Satisfaction": 0.0, "Anxiety": 0.0, "Excitement": 0.0}
        for ins in insights:
            for k, v in ins.emotion_scores.items():
                if k in emotions:
                    emotions[k] += v
        emotions = {k: round(v / len(insights), 2) for k, v in emotions.items()}

        topics_count = {}
        for ins in insights:
            for t in ins.topics:
                topics_count[t] = topics_count.get(t, 0) + 1

        risk_summary = {"High": 0, "Medium": 0, "Low": 0}
        for ins in insights:
            risk_summary[ins.retention_risk] = risk_summary.get(ins.retention_risk, 0) + 1

        for ins in insights:
            for tip in ins.recommendations.get("manager", []):
                if tip not in coaching_tips:
                    coaching_tips.append(tip)
    else:
        avg_sentiment = 0.0
        emotions = {"Stress": 0.0, "Burnout": 0.0, "Satisfaction": 0.5, "Anxiety": 0.0, "Excitement": 0.0}
        topics_count = {}
        risk_summary = {"High": 0, "Medium": 0, "Low": 0}
        coaching_tips = ["Encourage team members to submit their quarterly surveys."]

    return {
        "department": department,
        "team_size": team_size,
        "average_sentiment": round(avg_sentiment, 2),
        "emotion_distribution": emotions,
        "topic_clusters": topics_count,
        "retention_risk_summary": risk_summary,
        "coaching_tips": coaching_tips[:4],
        "recent_responses_count": len(insights)
    }
