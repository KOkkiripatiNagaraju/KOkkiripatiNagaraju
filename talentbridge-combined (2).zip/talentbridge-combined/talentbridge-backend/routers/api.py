import datetime
import logging
import os
import secrets
from pathlib import Path
from typing import Optional, Dict, Any, List
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form, status
from fastapi.responses import HTMLResponse, Response
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session

from config.database import get_db, settings
from models import schemas
from repositories import crud
from services import recruitment_service
from middleware.auth import (
    get_current_user,
    require_manager,
    hash_password,
    verify_password,
    create_access_token,
)
from utils import gmail_client, report_generator

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api")
RECORDINGS_DIR = Path("interview_recordings")


# ─────────────────────────────────────────────────────────────────────────────
# Auth
# ─────────────────────────────────────────────────────────────────────────────

@router.post("/register", response_model=schemas.TokenSchema, tags=["Auth"])
def register(user_in: schemas.UserCreate, db: Session = Depends(get_db)):
    """Register a new HR user account."""
    if crud.get_user_by_email(db, user_in.email):
        raise HTTPException(status_code=400, detail="An account with this email already exists.")
    hashed = hash_password(user_in.password)
    user = crud.create_user(db, user_in, hashed)
    token = create_access_token(user.email)
    crud.log_audit(db, user.id, "REGISTER", f"New user registered: {user.email}")
    return {"access_token": token, "token_type": "bearer"}


@router.post("/login", response_model=schemas.TokenSchema, tags=["Auth"])
def login(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    """Authenticate and receive a JWT token."""
    user = crud.get_user_by_email(db, form_data.username)
    if not user or not verify_password(form_data.password, user.hashed_password):
        raise HTTPException(status_code=400, detail="Incorrect email or password.")
    token = create_access_token(user.email)
    crud.log_audit(db, user.id, "LOGIN", f"User logged in: {user.email}")
    return {"access_token": token, "token_type": "bearer"}


# ─────────────────────────────────────────────────────────────────────────────
# Jobs
# ─────────────────────────────────────────────────────────────────────────────

@router.post("/jobs", response_model=schemas.JobResponse, tags=["Jobs"])
def create_job(
    job: schemas.JobCreate,
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(require_manager),
):
    """
    Create a new job posting and auto-analyse its description. (Manager only)

    BUG FIX: previously the job was created but the structured_profile was never
    committed back to the DB — process_job_creation_service now explicitly
    commits the profile so job analysis is persisted.
    """
    db_job = crud.create_job(db, job)
    # Run job analysis synchronously so structured_profile is populated before
    # any candidate pipelines run against this job.
    try:
        recruitment_service.process_job_creation_service(db, db_job.id)
    except Exception as exc:
        logger.warning("Job analysis failed for job_id=%d: %s", db_job.id, exc)
        # Job is still created — analysis can be re-triggered later
    crud.log_audit(db, current_user.id, "CREATE_JOB", f"Job '{db_job.title}' (ID {db_job.id}) created.")
    # Refresh so response includes structured_profile
    db.refresh(db_job)
    return db_job


@router.get("/jobs", tags=["Jobs"])
def get_jobs(
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(get_current_user),
):
    """List all active jobs."""
    return crud.get_jobs(db)


@router.get("/jobs/{job_id}", tags=["Jobs"])
def get_job(
    job_id: int,
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(get_current_user),
):
    """Get a specific job and its structured profile."""
    job = crud.get_job(db, job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found.")
    return job


@router.get("/jobs/{job_id}/candidates", tags=["Jobs"])
def get_candidates_for_job(
    job_id: int,
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(get_current_user),
):
    """List all candidates who applied for a job."""
    return crud.get_candidates_by_job(db, job_id)


@router.get("/jobs/{job_id}/rankings", tags=["Jobs"])
def get_job_rankings(
    job_id: int,
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(get_current_user),
):
    """
    Return ranked candidate list for a job with full candidate details.

    BUG FIX: the original endpoint returned only CandidateRanking rows which
    contain just IDs and scores — candidate names/emails were never included,
    causing the frontend to show 'Unknown' for every candidate.
    """
    rankings = crud.get_rankings_by_job(db, job_id)
    if not rankings:
        raise HTTPException(
            status_code=404,
            detail="No rankings found. Ensure candidates have been processed."
        )

    result = []
    for rk in rankings:
        cand = crud.get_candidate(db, rk.candidate_id)
        ats = crud.get_ats_score(db, rk.candidate_id)
        rec = crud.get_recommendation(db, rk.candidate_id)
        result.append({
            "rank":             rk.rank,
            "final_score":      rk.final_score,
            "candidate_id":     rk.candidate_id,
            # Candidate basic info — previously missing
            "name":             cand.name if cand else "Unknown",
            "email":            cand.email if cand else "Unknown",
            "phone":            cand.phone if cand else "",
            "status":           cand.status if cand else "Unknown",
            "experience_years": cand.experience_years if cand else 0,
            "skills":           cand.skills if cand else [],
            "applied_at":       cand.applied_at if cand else None,
            # ATS breakdown
            "ats_breakdown": {
                "skills_match":        ats.skills_match if ats else None,
                "experience_match":    ats.experience_match if ats else None,
                "semantic_similarity": ats.semantic_similarity if ats else None,
                "total_score":         ats.total_score if ats else None,
                "strengths":           ats.strengths if ats else [],
                "skill_gaps":          ats.skill_gaps if ats else [],
            } if ats else None,
            # AI recommendation
            "ai_verdict":       rec.ai_verdict if rec else None,
            "ai_rating":        rec.ai_rating if rec else None,
        })
    return result


@router.patch("/jobs/{job_id}/archive", tags=["Jobs"])
def archive_job(
    job_id: int,
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(require_manager),
):
    """Archive a job posting. (Manager only)"""
    job = crud.archive_job(db, job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found.")
    crud.log_audit(db, current_user.id, "ARCHIVE_JOB", f"Job ID {job_id} archived.")
    return {"message": f"Job '{job.title}' has been archived."}


# ─────────────────────────────────────────────────────────────────────────────
# Candidates & Resumes
# ─────────────────────────────────────────────────────────────────────────────

@router.post("/resumes/upload", tags=["Candidates"])
async def upload_resume(
    job_id: int = Form(...),
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(get_current_user),
):
    """
    Upload a candidate's resume. Triggers the full ATS pipeline:
    parse → semantic match → ATS score → ranking → recommendation → email draft.

    BUG FIX: S3 upload was silently failing — errors are now logged clearly.
    Candidate is created with placeholder name/email that the pipeline
    immediately overwrites from the parsed resume.
    """
    job = crud.get_job(db, job_id)
    if not job:
        raise HTTPException(status_code=404, detail=f"Job {job_id} not found.")

    contents = await file.read()
    if not contents:
        raise HTTPException(status_code=400, detail="Uploaded file is empty.")

    # ── S3 upload ────────────────────────────────────────────────────────
    s3_key = ""
    try:
        from utils import aws_s3
        s3_key = aws_s3.upload_to_s3(contents, file.filename)
        logger.info("Resume stored at S3 key: %s", s3_key)
    except Exception as exc:
        # S3 is non-fatal — log clearly and continue with processing
        logger.warning("S3 upload failed (key will be empty): %s", exc)

    # ── Text extraction ──────────────────────────────────────────────────
    from utils import text_extractor
    raw_text = text_extractor.extract_text(contents, file.filename)
    if not raw_text:
        raise HTTPException(
            status_code=422,
            detail="Could not extract text from the uploaded file. Please upload PDF, DOCX, or plain-text.",
        )

    # Create a stub candidate — pipeline will fill name/email from parsed resume
    cand = crud.create_candidate(db, job_id, "Pending", "pending@placeholder.com", "", s3_key)
    recruitment_service.process_resume_ingestion_service(db, cand.id, raw_text)

    # Refresh to return the name/email populated by the pipeline
    db.refresh(cand)
    crud.log_audit(db, current_user.id, "UPLOAD_RESUME", f"Candidate {cand.id} ({cand.name}) uploaded for job {job_id}.")

    return {
        "message":      "Resume uploaded and processed successfully.",
        "candidate_id": cand.id,
        "name":         cand.name,
        "email":        cand.email,
        "s3_stored":    bool(s3_key),
    }


@router.get("/candidates/me", tags=["Candidates"])
def get_my_applications(
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(get_current_user),
):
    """Retrieve all candidate application records matching the logged-in user's email."""
    candidates = db.query(schemas.Candidate).filter(schemas.Candidate.email == current_user.email).all()
    
    result = []
    for cand in candidates:
        job = db.query(schemas.Job).filter(schemas.Job.id == cand.job_id).first()
        interview = db.query(schemas.Interview).filter(schemas.Interview.candidate_id == cand.id).first()
        
        result.append({
            "candidate_id": cand.id,
            "job_id": cand.job_id,
            "job_title": job.title if job else "Unknown Position",
            "department": job.department if job else "Unknown",
            "location": job.location if job else "Unknown",
            "status": cand.status,
            "applied_at": cand.applied_at.isoformat() if cand.applied_at else None,
            "interview_id": interview.id if interview else None,
            "interview_scheduled_at": interview.scheduled_at.isoformat() if (interview and interview.scheduled_at) else None,
            "interview_completed": interview.is_completed if interview else False,
            "interview_join_token": interview.join_token if interview else None,
            "parsed_data": cand.parsed_data,
        })
    return result


@router.get("/candidates/{candidate_id}", tags=["Candidates"])
def get_candidate(
    candidate_id: int,
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(get_current_user),
):
    """Retrieve a candidate's full profile."""
    cand = crud.get_candidate(db, candidate_id)
    if not cand:
        raise HTTPException(status_code=404, detail="Candidate not found.")
    return cand


@router.get("/candidates/{candidate_id}/resume-url", tags=["Candidates"])
def get_candidate_resume_url(
    candidate_id: int,
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(get_current_user),
):
    """Retrieve a presigned S3 download URL for the candidate's resume."""
    cand = crud.get_candidate(db, candidate_id)
    if not cand:
        raise HTTPException(status_code=404, detail="Candidate not found.")
    if not cand.s3_key:
        raise HTTPException(status_code=404, detail="No resume stored in S3 for this candidate.")

    from utils import aws_s3
    try:
        url = aws_s3.generate_presigned_download_url(cand.s3_key)
        return {"resume_url": url}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Failed to generate download URL: {exc}")


@router.get("/candidates/{candidate_id}/ats-score", tags=["Candidates"])
def get_ats_score(
    candidate_id: int,
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(get_current_user),
):
    """Get the ATS scoring breakdown for a candidate."""
    score = crud.get_ats_score(db, candidate_id)
    if not score:
        raise HTTPException(status_code=404, detail="ATS score not found.")
    return score


@router.patch("/candidates/{candidate_id}/status", tags=["Candidates"])
def update_candidate_status(
    candidate_id: int,
    new_status: str,
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(require_manager),
):
    """Manually update a candidate's pipeline status. (Manager only)"""
    valid_statuses = {"Applied", "Screening", "Shortlisted", "Interviewing", "Offered", "Rejected"}
    if new_status not in valid_statuses:
        raise HTTPException(status_code=400, detail=f"Invalid status. Must be one of: {valid_statuses}")
    cand = crud.update_candidate_status(db, candidate_id, new_status)
    if not cand:
        raise HTTPException(status_code=404, detail="Candidate not found.")
    crud.log_audit(db, current_user.id, "UPDATE_STATUS", f"Candidate {candidate_id} status → '{new_status}'.")
    return {"message": f"Status updated to '{new_status}'.", "candidate_id": candidate_id}


# ─────────────────────────────────────────────────────────────────────────────
# Interviews  (HR-facing panel)
# ─────────────────────────────────────────────────────────────────────────────

@router.post("/interviews/setup/{candidate_id}", tags=["Interviews"])
def setup_interview(
    candidate_id: int,
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(require_manager),   # HR-only
):
    """
    Generate tailored interview questions for a candidate. (Manager/HR only)

    BUG FIX: was accessible to all users — now restricted to managers so only
    HR can set up an interview and preview questions before the candidate sees them.
    """
    interview = recruitment_service.setup_interview_workflow_service(db, candidate_id)
    questions = crud.get_interview_questions(db, interview.id)

    crud.log_audit(
        db, current_user.id, "SETUP_INTERVIEW",
        f"Interview {interview.id} created for candidate {candidate_id}."
    )
    return {
        "message":      "Interview questions generated successfully.",
        "interview_id": interview.id,
        "candidate_id": candidate_id,
        # Return questions immediately so HR can preview/edit before conducting
        "questions": [
            {
                "id":            q.id,
                "category":      q.category,
                "difficulty":    q.difficulty,
                "question_text": q.question_text,
                "expected_answer": q.expected_answer,  # visible to HR only
                "rubric":        q.rubric,
            }
            for q in questions
        ],
    }


def _candidate_join_page() -> str:
    return """
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>AI Video Interview</title>
  <style>
    :root { color-scheme: dark; font-family: Inter, system-ui, -apple-system, Segoe UI, sans-serif; background: #0b1020; color: #e5edf8; }
    * { box-sizing: border-box; }
    body { margin: 0; min-height: 100vh; background: #0b1020; }
    main { display: grid; grid-template-columns: minmax(320px, 1.05fr) minmax(320px, 0.95fr); gap: 24px; width: min(1180px, calc(100vw - 32px)); margin: 0 auto; padding: 28px 0; }
    header { grid-column: 1 / -1; display: flex; justify-content: space-between; align-items: end; gap: 16px; border-bottom: 1px solid rgba(148,163,184,.22); padding-bottom: 18px; }
    h1 { margin: 0; font-size: 28px; letter-spacing: 0; }
    .muted { color: #94a3b8; }
    .panel { border: 1px solid rgba(148,163,184,.18); background: #111827; border-radius: 8px; padding: 18px; }
    video { width: 100%; aspect-ratio: 16 / 10; background: #020617; border-radius: 8px; object-fit: cover; border: 1px solid rgba(148,163,184,.2); }
    .question { font-size: 21px; line-height: 1.5; margin: 14px 0; color: #f8fafc; }
    .row { display: flex; gap: 10px; flex-wrap: wrap; align-items: center; }
    button { border: 0; border-radius: 6px; padding: 11px 14px; font-weight: 700; cursor: pointer; background: #2563eb; color: #fff; }
    button.secondary { background: #334155; }
    button.danger { background: #dc2626; }
    button:disabled { opacity: .5; cursor: not-allowed; }
    textarea { width: 100%; min-height: 190px; resize: vertical; border-radius: 8px; border: 1px solid rgba(148,163,184,.24); background: #020617; color: #e5edf8; padding: 14px; line-height: 1.5; }
    .pill { display: inline-flex; border: 1px solid rgba(148,163,184,.22); border-radius: 999px; padding: 6px 10px; color: #cbd5e1; font-size: 13px; }
    .status { min-height: 24px; color: #bfdbfe; }
    @media (max-width: 820px) { main { grid-template-columns: 1fr; } header { align-items: start; flex-direction: column; } }
  </style>
</head>
<body>
  <main>
    <header>
      <div>
        <h1>AI Video Interview</h1>
        <div class="muted" id="candidateLine">Loading interview...</div>
      </div>
      <div class="pill" id="progress">Question 0 of 0</div>
    </header>

    <section class="panel">
      <video id="preview" autoplay muted playsinline></video>
      <p class="muted">Camera and microphone stay local while you answer. Audio clips are uploaded only when you submit each response.</p>
      <div class="row">
        <button id="startMedia">Enable Camera & Mic</button>
        <button class="secondary" id="speakQuestion">Speak Question</button>
      </div>
      <p class="status" id="mediaStatus"></p>
    </section>

    <section class="panel">
      <div class="pill" id="category">Interview</div>
      <div class="question" id="questionText">Loading...</div>
      <div class="row" style="margin-bottom: 12px;">
        <button id="startAnswer">Start Answer</button>
        <button class="danger" id="stopAnswer" disabled>Stop</button>
        <button class="secondary" id="clearTranscript" style="background: #334155;">Clear Text</button>
        <button class="secondary" id="submitAnswer" disabled>Submit & Continue</button>
      </div>
      <div style="margin-bottom: 12px; display: flex; align-items: center; gap: 8px;">
        <input type="checkbox" id="toggleSR" checked style="width: auto; height: auto; cursor: pointer; margin: 0;" />
        <label for="toggleSR" style="font-size: 13px; color: #94a3b8; cursor: pointer; user-select: none;">🎙️ Enable Real-Time Speech-to-Text (turn off if lagging)</label>
      </div>
      <p class="status" id="answerStatus"></p>
      <textarea id="transcript" placeholder="Your spoken answer will appear here in real time. You can edit before submitting."></textarea>
    </section>
  </main>

  <script>
    const token = location.pathname.split('/').filter(Boolean).pop();
    const apiBase = '/api/public/interviews/' + encodeURIComponent(token);
    const state = { stream: null, recorder: null, chunks: [], recognition: null, data: null, qIndex: 0, closed: false };
    const $ = (id) => document.getElementById(id);

    function setStatus(id, text) { $(id).textContent = text || ''; }
    function currentQuestion() { return state.data.questions[state.qIndex]; }
    function stopMedia() {
      try {
        if (state.recognition) {
          state.recognition.stop();
          state.recognition = null;
        }
      } catch (_) {}
      try {
        if (state.recorder && state.recorder.state !== 'inactive') {
          state.recorder.stop();
        }
      } catch (_) {}
      if (state.stream) {
        state.stream.getTracks().forEach((track) => track.stop());
        state.stream = null;
      }
      $('preview').srcObject = null;
      $('startMedia').disabled = false;
      $('startAnswer').disabled = state.data && (state.data.is_completed || state.qIndex >= state.data.questions.length);
      $('stopAnswer').disabled = true;
      setStatus('mediaStatus', 'Camera and microphone are off.');
    }

    async function loadInterview() {
      const res = await fetch(apiBase);
      if (!res.ok) throw new Error(await res.text());
      state.data = await res.json();
      state.qIndex = Math.min(state.data.answered_count || 0, state.data.questions.length);
      $('candidateLine').textContent = state.data.candidate_name + ' - ' + state.data.job_title;
      renderQuestion();
    }

    function renderQuestion() {
      if (state.data.is_completed || state.qIndex >= state.data.questions.length) {
        $('progress').textContent = 'Complete';
        $('category').textContent = 'Finished';
        $('questionText').textContent = 'Thank you. Your interview has been submitted.';
        $('startAnswer').disabled = true;
        $('submitAnswer').disabled = true;
        stopMedia();
        return;
      }
      const q = currentQuestion();
      $('progress').textContent = 'Question ' + (state.qIndex + 1) + ' of ' + state.data.questions.length;
      $('category').textContent = (q.category || 'Question') + ' - ' + (q.difficulty || 'Standard');
      $('questionText').textContent = q.question_text;
      $('transcript').value = '';
      speak(q.question_text);
    }

    function speak(text) {
      if (!('speechSynthesis' in window)) return;
      speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.92;
      utterance.pitch = 1;
      speechSynthesis.speak(utterance);
    }

    async function enableMedia() {
      if (!navigator.mediaDevices) {
        setStatus('mediaStatus', 'Error: Web camera access requires a secure connection (HTTPS) or localhost. Please ensure you are accessing this page via http://localhost or https://.');
        throw new Error('Media devices not supported on insecure origins.');
      }
      try {
        state.stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
        $('preview').srcObject = state.stream;
        setStatus('mediaStatus', 'Camera and microphone are ready.');
      } catch (err) {
        console.warn('Webcam failed, trying audio-only fallback...', err);
        try {
          state.stream = await navigator.mediaDevices.getUserMedia({ audio: true });
          setStatus('mediaStatus', 'Microphone is ready. (Webcam not found or disabled)');
          $('preview').style.background = '#1e293b';
        } catch (audioErr) {
          setStatus('mediaStatus', 'Error: Could not access microphone or camera. Please check browser permissions.');
          throw audioErr;
        }
      }
    }

    function startSpeechRecognition() {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (!SpeechRecognition) {
        setStatus('answerStatus', 'Speech recognition is not supported in this browser. Type your answer after recording.');
        return;
      }
      const recognition = new SpeechRecognition();
      recognition.lang = 'en-US';
      recognition.interimResults = true;
      recognition.continuous = true;
      let finalText = '';
      recognition.onresult = (event) => {
        let interim = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          const text = event.results[i][0].transcript;
          if (event.results[i].isFinal) {
            const lowerText = text.toLowerCase().trim();
            // Filter out common google speech silent hallucinations
            if (lowerText.includes("subtitles by") || lowerText.includes("sub by") || lowerText.includes("thank you for watching") || lowerText.includes("subscribe to")) {
              continue;
            }
            finalText += text + ' ';
          }
          else interim += text;
        }
        $('transcript').value = (finalText + interim).trim();
      };
      recognition.onerror = () => setStatus('answerStatus', 'Speech recognition paused. Your audio recording is still active.');
      recognition.start();
      state.recognition = recognition;
    }

    async function startAnswer() {
      if (!state.stream) await enableMedia();
      state.chunks = [];
      state.recorder = new MediaRecorder(state.stream);
      state.recorder.ondataavailable = (event) => { if (event.data.size) state.chunks.push(event.data); };
      state.recorder.start();
      
      if ($('toggleSR').checked) {
        startSpeechRecognition();
        setStatus('answerStatus', 'Recording and transcribing...');
      } else {
        setStatus('answerStatus', 'Recording audio. Please type your answer below.');
      }
      
      $('startAnswer').disabled = true;
      $('stopAnswer').disabled = false;
      $('submitAnswer').disabled = true;
    }

    function stopAnswer() {
      if (state.recognition) state.recognition.stop();
      if (state.recorder && state.recorder.state !== 'inactive') state.recorder.stop();
      $('startAnswer').disabled = false;
      $('stopAnswer').disabled = true;
      $('submitAnswer').disabled = false;
      setStatus('answerStatus', 'Review the transcript, then submit.');
    }

    async function submitAnswer() {
      const q = currentQuestion();
      const transcript = $('transcript').value.trim();
      if (!transcript) {
        setStatus('answerStatus', 'Please provide an answer before submitting.');
        return;
      }
      const blob = new Blob(state.chunks, { type: state.chunks[0]?.type || 'audio/webm' });
      const form = new FormData();
      form.append('question_id', q.id);
      form.append('transcript', transcript);
      if (blob.size) form.append('audio', blob, 'answer-' + q.id + '.webm');
      $('submitAnswer').disabled = true;
      setStatus('answerStatus', 'Submitting for AI evaluation...');
      const res = await fetch(apiBase + '/answer', { method: 'POST', body: form });
      const payload = await res.json();
      if (!res.ok) throw new Error(payload.detail || 'Could not submit answer.');
      setStatus('answerStatus', payload.message || 'Answer submitted.');
      state.qIndex += 1;
      setTimeout(renderQuestion, 1200);
    }

    $('startMedia').onclick = () => enableMedia().catch(err => setStatus('mediaStatus', err.message));
    $('speakQuestion').onclick = () => currentQuestion() && speak(currentQuestion().question_text);
    $('startAnswer').onclick = () => startAnswer().catch(err => setStatus('answerStatus', err.message));
    $('stopAnswer').onclick = stopAnswer;
    $('clearTranscript').onclick = () => { $('transcript').value = ''; };
    $('submitAnswer').onclick = () => submitAnswer().catch(err => setStatus('answerStatus', err.message));

    // ── Waiting-room shown when time-gate 403 fires ────────────────────────
    function showWaitingRoom(detail) {
      // Parse scheduled time from the detail message e.g. "...scheduled for 2026-06-19 10:00 UTC..."
      const match = detail.match(/scheduled for ([0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2} UTC)/);
      const schedText = match ? match[1] : '';

      let displayTimeStr = schedText;
      if (schedText) {
        try {
          const utcIso = schedText.replace(' UTC', 'Z').replace(' ', 'T');
          const localDate = new Date(utcIso);
          if (!isNaN(localDate.getTime())) {
            displayTimeStr = `${localDate.toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' })} (Local) / ${schedText}`;
          }
        } catch(e) {}
      }

      document.querySelector('main').innerHTML = `
        <div style="grid-column:1/-1; display:flex; flex-direction:column; align-items:center; justify-content:center; min-height:60vh; gap:24px; text-align:center;">
          <div style="font-size:3.5rem;">🕐</div>
          <h2 style="margin:0; font-size:1.8rem; color:#f8fafc;">Interview Not Yet Open</h2>
          ${schedText ? `<p style="margin:0; font-size:1.1rem; color:#94a3b8;">Your interview is scheduled for <strong style="color:#60a5fa;">${displayTimeStr}</strong></p>` : ''}
          <p style="margin:0; font-size:0.95rem; color:#94a3b8;">
            This page will automatically refresh every 30 seconds.<br/>
            Once the time arrives, the interview will load automatically.
          </p>
          <div style="background:#1e293b; border:1px solid rgba(148,163,184,.2); border-radius:8px; padding:16px 28px; font-size:1rem; color:#bfdbfe;">
            Refreshing in <strong id="countdown">30</strong>s &nbsp;·&nbsp;
            <a href="javascript:location.reload()" style="color:#60a5fa; text-decoration:none; font-weight:600;">Refresh Now</a>
          </div>
        </div>`;

      let secs = 30;
      const tick = setInterval(() => {
        secs--;
        const el = document.getElementById('countdown');
        if (el) el.textContent = secs;
        if (secs <= 0) { clearInterval(tick); location.reload(); }
      }, 1000);
    }

    loadInterview().catch(async err => {
      // Try to parse a structured error from the backend
      let detail = err.message || '';
      try { const parsed = JSON.parse(detail); detail = parsed.detail || detail; } catch (_) {}

      if (detail.toLowerCase().includes('not yet open') || detail.toLowerCase().includes('scheduled for')) {
        showWaitingRoom(detail);
      } else {
        $('questionText').textContent = 'This interview link is unavailable.';
        setStatus('answerStatus', detail);
      }
    });

    function handleClose() {
      if (state.closed) return;
      // Only send beacon if the interview was actually loaded and started
      if (!state.data || state.data.is_completed) return;
      if (state.qIndex < state.data.questions.length) {
        state.closed = true;
        stopMedia();
        navigator.sendBeacon(apiBase + '/close');
      }
    }
    window.addEventListener('beforeunload', handleClose);
    window.addEventListener('pagehide', handleClose);
    window.addEventListener('unload', handleClose);
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'hidden') stopMedia();
    });
  </script>
</body>
</html>
"""



@router.get("/interviews/join/{join_token}", response_class=HTMLResponse, tags=["Candidate Interview"])
def candidate_interview_page(join_token: str):
    return HTMLResponse(_candidate_join_page())


@router.post("/interviews/{interview_id}/schedule", tags=["Interviews"])
def schedule_interview(
    interview_id: int,
    body: schemas.InterviewScheduleRequest,
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(require_manager),
):
    interview = crud.get_interview(db, interview_id)
    if not interview:
        raise HTTPException(status_code=404, detail="Interview not found.")
    cand = crud.get_candidate(db, interview.candidate_id)
    if not cand:
        raise HTTPException(status_code=404, detail="Candidate not found.")

    job = db.query(schemas.Job).filter(schemas.Job.id == cand.job_id).first()

    join_token = interview.join_token or secrets.token_urlsafe(32)
    expires_at = body.scheduled_at + datetime.timedelta(days=7)
    interview = crud.schedule_interview(db, interview_id, body.scheduled_at, join_token, expires_at)
    base_url = (body.base_join_url or settings.INTERVIEW_PUBLIC_BASE_URL).rstrip("/")
    join_link = f"{base_url}/api/interviews/join/{join_token}"

    from zoneinfo import ZoneInfo
    from datetime import timezone
    utc_dt = body.scheduled_at.replace(tzinfo=timezone.utc)
    ist_dt = utc_dt.astimezone(ZoneInfo("Asia/Kolkata"))
    utc_str = utc_dt.strftime('%Y-%m-%d %H:%M UTC')
    ist_str = ist_dt.strftime('%Y-%m-%d %I:%M %p IST')

    job_title    = job.title if job else "the applied position"
    company_name = "TalentBridge"

    sent = gmail_client.send_interview_invitation(
        to_email=cand.email,
        candidate_name=cand.name,
        job_title=job_title,
        company_name=company_name,
        interview_date=ist_dt.strftime("%A, %B %d, %Y"),
        interview_time=ist_dt.strftime("%I:%M %p"),
        timezone_label="IST",
        interview_mode="Online",
        meeting_platform="AI Video Interview",
        join_link=join_link,
    )
    crud.log_audit(
        db,
        current_user.id,
        "SCHEDULE_INTERVIEW",
        f"Interview {interview_id} scheduled for candidate {cand.id}. Email status: {'sent' if sent else 'failed'}.",
    )
    return {
        "message": "Interview scheduled.",
        "interview_id": interview_id,
        "candidate_id": cand.id,
        "scheduled_at": interview.scheduled_at,
        "join_link": join_link,
        "email_sent": sent,
    }


def _public_interview_or_404(db: Session, join_token: str) -> schemas.Interview:
    interview = crud.get_interview_by_join_token(db, join_token)
    if not interview:
        raise HTTPException(status_code=404, detail="Invalid interview link.")
    if interview.join_token_expires_at and interview.join_token_expires_at < datetime.datetime.utcnow():
        raise HTTPException(status_code=410, detail="This interview link has expired.")
    return interview



def force_complete_interview_db(db: Session, interview: schemas.Interview) -> float:
    questions = crud.get_interview_questions(db, interview.id)
    answers_db = db.query(schemas.InterviewAnswer).filter(schemas.InterviewAnswer.interview_id == interview.id).all()
    answered_qids = {a.interview_question_id for a in answers_db}

    placeholders = []
    for q in questions:
        if q.id not in answered_qids:
            placeholder = schemas.InterviewAnswer(
                interview_id=interview.id,
                interview_question_id=q.id,
                candidate_answer="[Not attempted — interview closed early]",
                transcript="[Not attempted — interview closed early]",
                score=0.0,
                feedback="Question not attempted. Score: 0/100.",
            )
            db.add(placeholder)
            placeholders.append(placeholder)
    
    if placeholders:
        db.commit()
        # Reload all answers
        answers_db = db.query(schemas.InterviewAnswer).filter(schemas.InterviewAnswer.interview_id == interview.id).all()

    # Call complete_interview logic (which calculates average score, runs decision agent, and updates status)
    recruitment_service.orchestrator._complete_interview(db, interview, answers_db)
    db.commit()
    db.refresh(interview)
    return interview.overall_score


@router.get("/public/interviews/{join_token}", tags=["Candidate Interview"])
def get_public_interview(join_token: str, db: Session = Depends(get_db)):
    interview = _public_interview_or_404(db, join_token)
    if interview.is_completed:
        return {
            "interview_id": interview.id,
            "candidate_name": "Candidate",
            "job_title": "Interview",
            "is_completed": True,
            "questions": [],
        }

    # TIME-GATE: Block access before the scheduled interview time
    if interview.scheduled_at and datetime.datetime.utcnow() < interview.scheduled_at:
        from zoneinfo import ZoneInfo
        from datetime import timezone
        utc_dt = interview.scheduled_at.replace(tzinfo=timezone.utc)
        ist_dt = utc_dt.astimezone(ZoneInfo("Asia/Kolkata"))
        utc_str = utc_dt.strftime("%Y-%m-%d %H:%M UTC")
        ist_str = ist_dt.strftime("%I:%M %p IST")
        raise HTTPException(
            status_code=403,
            detail=f"Interview not yet open. Your interview is scheduled for {utc_str} ({ist_str}). Please return at that time.",
        )

    if interview.started_at is not None:
        force_complete_interview_db(db, interview)
        raise HTTPException(status_code=403, detail="This interview has already been started once. Re-entry is not permitted.")
    
    interview.started_at = datetime.datetime.utcnow()
    db.commit()
    interview = _public_interview_or_404(db, join_token)
    cand = crud.get_candidate(db, interview.candidate_id)
    job = crud.get_job(db, cand.job_id) if cand else None
    questions = crud.get_interview_questions(db, interview.id)
    answers = (
        db.query(schemas.InterviewAnswer)
        .filter(schemas.InterviewAnswer.interview_id == interview.id)
        .all()
    )
    answered_ids = {a.interview_question_id for a in answers}
    return {
        "interview_id": interview.id,
        "candidate_name": cand.name if cand else "Candidate",
        "job_title": job.title if job else "Interview",
        "scheduled_at": interview.scheduled_at,
        "is_completed": interview.is_completed,
        "answered_count": len(answered_ids),
        "questions": [
            {
                "id": q.id,
                "category": q.category,
                "difficulty": q.difficulty,
                "question_text": q.question_text,
                "answered": q.id in answered_ids,
            }
            for q in questions
        ],
    }


@router.post("/public/interviews/{join_token}/answer", tags=["Candidate Interview"])
async def submit_public_interview_answer(
    join_token: str,
    question_id: int = Form(...),
    transcript: str = Form(...),
    audio: UploadFile | None = File(None),
    db: Session = Depends(get_db),
):
    interview = _public_interview_or_404(db, join_token)
    if interview.is_completed:
        raise HTTPException(status_code=400, detail="This interview has already been completed.")
    question = (
        db.query(schemas.InterviewQuestion)
        .filter(
            schemas.InterviewQuestion.id == question_id,
            schemas.InterviewQuestion.interview_id == interview.id,
        )
        .first()
    )
    if not question:
        raise HTTPException(status_code=404, detail="Question not found for this interview.")

    audio_path = None
    audio_mime_type = None
    if audio:
        RECORDINGS_DIR.mkdir(parents=True, exist_ok=True)
        safe_ext = ".webm"
        if audio.filename:
            ext = os.path.splitext(audio.filename)[1].lower()
            if ext in {".webm", ".ogg", ".mp3", ".wav", ".m4a"}:
                safe_ext = ext
        filename = f"interview_{interview.id}_question_{question_id}_{int(datetime.datetime.utcnow().timestamp())}{safe_ext}"
        destination = RECORDINGS_DIR / filename
        destination.write_bytes(await audio.read())
        audio_path = str(destination)
        audio_mime_type = audio.content_type

    recruitment_service.submit_interview_answer_service(
        db,
        interview_id=interview.id,
        question_id=question_id,
        candidate_answer=transcript,
        audio_file_path=audio_path,
        audio_mime_type=audio_mime_type,
    )
    return {
        "message": "Answer submitted. Please continue to the next question.",
        "audio_stored": bool(audio_path),
    }


@router.post("/public/interviews/{join_token}/close", tags=["Candidate Interview"])
def close_public_interview(join_token: str, db: Session = Depends(get_db)):
    """
    Force complete the interview when the user closes the tab early.
    Sets all unattempted questions to 0 score, updates candidate status,
    and runs evaluation.
    """
    interview = _public_interview_or_404(db, join_token)
    if interview.is_completed:
        return {"message": "Interview already completed.", "overall_score": interview.overall_score}
    
    force_complete_interview_db(db, interview)
    return {"message": "Interview closed and scored.", "overall_score": interview.overall_score}


@router.get("/interviews/job/{job_id}/panel", tags=["Interviews"])
def get_interview_panel_for_job(
    job_id: int,
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(require_manager),  # HR-only
):
    """
    HR interview panel: returns job details, description, and all candidates
    who have applied, with their basic profiles and interview status.

    NEW endpoint — gives HR a single view of everything they need before
    conducting interviews for a given job.
    """
    job = crud.get_job(db, job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found.")

    candidates = crud.get_candidates_by_job(db, job_id)
    rankings = {rk.candidate_id: rk.rank for rk in crud.get_rankings_by_job(db, job_id)}

    candidate_summaries = []
    for cand in candidates:
        interview = crud.get_interview_by_candidate(db, cand.id)
        ats = crud.get_ats_score(db, cand.id)
        rec = crud.get_recommendation(db, cand.id)
        candidate_summaries.append({
            "candidate_id":     cand.id,
            "name":             cand.name,
            "email":            cand.email,
            "phone":            cand.phone,
            "status":           cand.status,
            "experience_years": cand.experience_years,
            "skills":           cand.skills or [],
            "education":        cand.education or [],
            "applied_at":       cand.applied_at,
            "rank":             rankings.get(cand.id),
            "ats_total_score":  ats.total_score if ats else None,
            "ai_verdict":       rec.ai_verdict if rec else None,
            "interview_id":     interview.id if interview else None,
            "interview_done":   interview.is_completed if interview else False,
            "interview_score":  interview.overall_score if interview else None,
        })

    # Sort by rank, unranked candidates last
    candidate_summaries.sort(key=lambda x: (x["rank"] is None, x["rank"] or 9999))

    return {
        "job_id":          job.id,
        "job_title":       job.title,
        "job_description": job.full_description,
        "structured_profile": job.structured_profile,
        "total_candidates": len(candidate_summaries),
        "candidates":      candidate_summaries,
    }


@router.get("/interviews/job/{job_id}/results", tags=["Interviews"])
def get_interview_results_for_job(
    job_id: int,
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(require_manager),
):
    """HR-only interview results sorted by evaluation score descending."""
    job = crud.get_job(db, job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found.")

    candidates = crud.get_candidates_by_job(db, job_id)
    results = []
    for cand in candidates:
        interview = crud.get_interview_by_candidate(db, cand.id)
        if not interview:
            continue

        questions = crud.get_interview_questions(db, interview.id)
        answers = (
            db.query(schemas.InterviewAnswer)
            .filter(schemas.InterviewAnswer.interview_id == interview.id)
            .order_by(schemas.InterviewAnswer.id)
            .all()
        )
        answers_by_qid = {a.interview_question_id: a for a in answers}
        qa_items = []
        for q in questions:
            ans = answers_by_qid.get(q.id)
            qa_items.append({
                "question_id": q.id,
                "category": q.category,
                "difficulty": q.difficulty,
                "question_text": q.question_text,
                "response": ans.candidate_answer if ans else None,
                "transcript": ans.transcript if ans else None,
                "score": ans.score if ans else None,
                "feedback": ans.feedback if ans else None,
                "audio_file_path": ans.audio_file_path if ans else None,
                "answered_at": ans.answered_at if ans else None,
            })

        results.append({
            "interview_id": interview.id,
            "candidate_id": cand.id,
            "candidate_name": cand.name,
            "candidate_email": cand.email,
            "candidate_status": cand.status,
            "scheduled_at": interview.scheduled_at,
            "is_completed": interview.is_completed,
            "answered_count": len(answers),
            "total_questions": len(questions),
            "overall_score": interview.overall_score,
            "summary": interview.evaluation_summary,
            "responses": qa_items,
        })

    results.sort(
        key=lambda item: (
            item["overall_score"] is None,
            -(item["overall_score"] or 0),
            item["candidate_name"].lower(),
        )
    )
    return {
        "job_id": job.id,
        "job_title": job.title,
        "results": results,
    }


@router.get("/interviews/{interview_id}/hr-preview", tags=["Interviews"])
def get_interview_hr_preview(
    interview_id: int,
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(require_manager),  # HR-only
):
    """
    HR-only full preview of an interview: questions, expected answers,
    rubrics, candidate answers and scores.

    BUG FIX / NEW: candidates should not see expected_answer or rubric;
    this separate HR endpoint exposes all fields including those internal details.
    """
    interview = crud.get_interview(db, interview_id)
    if not interview:
        raise HTTPException(status_code=404, detail="Interview not found.")

    cand = crud.get_candidate(db, interview.candidate_id)
    questions = crud.get_interview_questions(db, interview_id)
    answers_db = (
        db.query(schemas.InterviewAnswer)
        .filter(schemas.InterviewAnswer.interview_id == interview_id)
        .all()
    )
    answers_by_qid = {a.interview_question_id: a for a in answers_db}

    qa_list = []
    for q in questions:
        ans = answers_by_qid.get(q.id)
        qa_list.append({
            "question_id":      q.id,
            "category":         q.category,
            "difficulty":       q.difficulty,
            "question_text":    q.question_text,
            "expected_answer":  q.expected_answer,  # HR sees expected answer
            "rubric":           q.rubric,
            "candidate_answer": ans.candidate_answer if ans else None,
            "transcript":        ans.transcript if ans else None,
            "audio_file_path":   ans.audio_file_path if ans else None,
            "audio_mime_type":   ans.audio_mime_type if ans else None,
            "score":            ans.score if ans else None,
            "feedback":         ans.feedback if ans else None,
            "answered_at":      ans.answered_at if ans else None,
        })

    return {
        "interview_id":    interview_id,
        "candidate_id":    interview.candidate_id,
        "candidate_name":  cand.name if cand else "Unknown",
        "candidate_email": cand.email if cand else "Unknown",
        "is_completed":    interview.is_completed,
        "overall_score":   interview.overall_score,
        "summary":         interview.evaluation_summary,
        "questions_and_answers": qa_list,
    }


@router.get("/interviews/{interview_id}", tags=["Interviews"])
def get_interview_state(
    interview_id: int,
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(get_current_user),
):
    """
    Get the current state of an interview for the candidate:
    only shows question text — NOT expected answers or rubrics.
    """
    return recruitment_service.get_interview_state_service(db, interview_id)


@router.get("/interviews/{interview_id}/questions", tags=["Interviews"])
def get_interview_questions(
    interview_id: int,
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(get_current_user),
):
    """
    List questions for an interview.
    Candidates only see question text; expected_answer is stripped out.
    HR should use /hr-preview instead to see all fields.
    """
    questions = crud.get_interview_questions(db, interview_id)
    if not questions:
        raise HTTPException(status_code=404, detail="No questions found for this interview.")

    is_manager = getattr(current_user, "is_manager", False)
    return [
        {
            "id":            q.id,
            "category":      q.category,
            "difficulty":    q.difficulty,
            "question_text": q.question_text,
            # Only HR sees expected_answer and rubric
            **({"expected_answer": q.expected_answer, "rubric": q.rubric} if is_manager else {}),
        }
        for q in questions
    ]


@router.put("/interviews/questions/{question_id}", tags=["Interviews"])
def update_interview_question(
    question_id: int,
    body: schemas.QuestionUpdate,
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(require_manager),  # HR-only
):
    """
    HR can replace a generated question before conducting the interview.
    Only managers may edit questions.
    """
    q = db.query(schemas.InterviewQuestion).filter(schemas.InterviewQuestion.id == question_id).first()
    if not q:
        raise HTTPException(status_code=404, detail="Question not found.")
    q.question_text = body.question_text
    if hasattr(body, "expected_answer") and body.expected_answer:
        q.expected_answer = body.expected_answer
    db.commit()
    db.refresh(q)
    crud.log_audit(
        db, current_user.id, "UPDATE_QUESTION",
        f"Updated question {question_id}: {body.question_text[:60]}..."
    )
    return {
        "message":       "Question updated successfully.",
        "id":            question_id,
        "question_text": q.question_text,
    }


@router.post("/interviews/{interview_id}/regenerate-questions", tags=["Interviews"])
def regenerate_interview_questions(
    interview_id: int,
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(require_manager),  # HR-only
):
    """
    HR can request a fresh set of questions for an interview that hasn't
    started yet. Deletes existing questions and regenerates them.
    """
    interview = crud.get_interview(db, interview_id)
    if not interview:
        raise HTTPException(status_code=404, detail="Interview not found.")

    answers_exist = (
        db.query(schemas.InterviewAnswer)
        .filter(schemas.InterviewAnswer.interview_id == interview_id)
        .count()
    )
    if answers_exist:
        raise HTTPException(
            status_code=400,
            detail="Cannot regenerate questions — the candidate has already started answering."
        )

    # Delete existing questions
    db.query(schemas.InterviewQuestion).filter(
        schemas.InterviewQuestion.interview_id == interview_id
    ).delete()
    db.commit()

    # Regenerate
    cand = crud.get_candidate(db, interview.candidate_id)
    job = crud.get_job(db, cand.job_id)
    questions = recruitment_service.orchestrator.interview_agent.generate_questions(
        job_title=job.title,
        job_description=job.full_description,
        required_skills=job.skills_required or [],
        candidate_skills=cand.skills or [],
        candidate_projects=(cand.parsed_data or {}).get("projects", []),
    )
    for q in questions:
        db_q = schemas.InterviewQuestion(
            interview_id=interview_id,
            category=q.get("category"),
            difficulty=q.get("difficulty"),
            question_text=q.get("question_text"),
            expected_answer=q.get("expected_answer"),
            rubric=q.get("rubric"),
        )
        db.add(db_q)
    db.commit()

    new_questions = crud.get_interview_questions(db, interview_id)
    crud.log_audit(db, current_user.id, "REGEN_QUESTIONS", f"Regenerated questions for interview {interview_id}.")
    return {
        "message":   "Questions regenerated successfully.",
        "questions": [
            {
                "id":              q.id,
                "category":        q.category,
                "difficulty":      q.difficulty,
                "question_text":   q.question_text,
                "expected_answer": q.expected_answer,
                "rubric":          q.rubric,
            }
            for q in new_questions
        ],
    }


@router.get("/interviews/{interview_id}/answers", tags=["Interviews"])
def get_interview_answers(
    interview_id: int,
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(require_manager),  # HR-only
):
    """
    HR review of all answers submitted for an interview, with scores and feedback.
    Restricted to managers.
    """
    answers = (
        db.query(schemas.InterviewAnswer)
        .filter(schemas.InterviewAnswer.interview_id == interview_id)
        .order_by(schemas.InterviewAnswer.id)
        .all()
    )
    results = []
    for ans in answers:
        q = db.query(schemas.InterviewQuestion).filter(
            schemas.InterviewQuestion.id == ans.interview_question_id
        ).first()
        results.append({
            "id":               ans.id,
            "question_id":      ans.interview_question_id,
            "category":         q.category if q else "General",
            "question_text":    q.question_text if q else "Unknown",
            "expected_answer":  q.expected_answer if q else "",
            "rubric":           q.rubric if q else {},
            "candidate_answer": ans.candidate_answer,
            "transcript":        ans.transcript,
            "audio_file_path":   ans.audio_file_path,
            "audio_mime_type":   ans.audio_mime_type,
            "score":            ans.score,
            "feedback":         ans.feedback,
            "answered_at":      ans.answered_at,
        })
    return results


@router.post("/interviews/{interview_id}/answer", tags=["Interviews"])
def submit_answer(
    interview_id: int,
    submission: schemas.InterviewAnswerSubmit,
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(get_current_user),
):
    """
    Submit and auto-evaluate one interview answer.
    When the last question is answered, the interview is auto-completed.
    """
    result = recruitment_service.submit_interview_answer_service(
        db,
        interview_id=interview_id,
        question_id=submission.question_id,
        candidate_answer=submission.candidate_answer,
    )
    crud.log_audit(
        db, current_user.id, "SUBMIT_ANSWER",
        f"Answer: interview {interview_id}, question {submission.question_id}.",
    )
    return {
        "message":  "Answer evaluated.",
        "score":    result["score"],
        "feedback": result["feedback"],
    }


# ─────────────────────────────────────────────────────────────────────────────
# Recommendations & HR Override
# ─────────────────────────────────────────────────────────────────────────────

@router.get("/candidates/{candidate_id}/recommendation", tags=["Recommendations"])
def get_recommendation(
    candidate_id: int,
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(get_current_user),
):
    """Get the AI recommendation for a candidate."""
    rec = crud.get_recommendation(db, candidate_id)
    if not rec:
        raise HTTPException(status_code=404, detail="No recommendation found.")
    return rec


@router.patch("/candidates/{candidate_id}/recommendation/override", tags=["Recommendations"])
def hr_override_recommendation(
    candidate_id: int,
    override: schemas.HROverrideRequest,
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(require_manager),
):
    """Allow an HR manager to override the AI's recommendation verdict. (Manager only)"""
    rec = crud.apply_hr_override(db, candidate_id, override.hr_override_verdict, override.hr_notes)
    if not rec:
        raise HTTPException(status_code=404, detail="Recommendation not found.")
    crud.log_audit(
        db, current_user.id, "HR_OVERRIDE",
        f"Manager overrode candidate {candidate_id} verdict to '{override.hr_override_verdict}'.",
    )
    return {
        "message":             "HR override applied.",
        "ai_verdict":          rec.ai_verdict,
        "hr_override_verdict": rec.hr_override_verdict,
        "hr_notes":            rec.hr_notes,
    }


# ─────────────────────────────────────────────────────────────────────────────
# Email Management
# ─────────────────────────────────────────────────────────────────────────────

@router.get("/emails/pending", tags=["Emails"])
def get_pending_emails(
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(get_current_user),
):
    """List all email drafts awaiting HR review."""
    return crud.get_pending_emails(db)


@router.post("/emails/{email_log_id}/review", tags=["Emails"])
def review_and_send_email(
    email_log_id: int,
    decision: schemas.EmailDecision,
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(get_current_user),
):
    """HR reviews an AI-generated email draft and optionally edits before sending."""
    log = db.query(schemas.EmailLog).filter(schemas.EmailLog.id == email_log_id).first()
    if not log:
        raise HTTPException(status_code=404, detail="Email draft not found.")
    if log.status != "Draft":
        raise HTTPException(status_code=400, detail=f"Email is not in Draft status (current: {log.status}).")

    cand = crud.get_candidate(db, log.candidate_id)
    if not cand:
        raise HTTPException(status_code=404, detail="Candidate not found for this email.")

    if decision.approve:
        subject = decision.edited_subject or log.subject
        body = decision.edited_body or log.body
        success = gmail_client.send_gmail_email(cand.email, cand.name, subject, body)
        log.status = "Sent" if success else "Failed"
        log.subject = subject
        log.body = body
        log.sent_at = datetime.datetime.utcnow()
        crud.log_audit(
            db, current_user.id,
            "EMAIL_SENT" if success else "EMAIL_FAILED",
            f"Email {email_log_id} {'sent to' if success else 'failed for'} {cand.email}.",
        )
    else:
        log.status = "Rejected_By_HR"
        crud.log_audit(db, current_user.id, "EMAIL_REJECTED", f"Email draft {email_log_id} rejected by HR.")

    db.commit()
    return {"status": log.status}


# ─────────────────────────────────────────────────────────────────────────────
# Reports
# ─────────────────────────────────────────────────────────────────────────────

@router.get("/candidates/{candidate_id}/report/pdf", tags=["Reports"])
def download_pdf_report(
    candidate_id: int,
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(get_current_user),
):
    """Download a PDF hiring assessment report for a candidate."""
    cand = crud.get_candidate(db, candidate_id)
    if not cand:
        raise HTTPException(status_code=404, detail="Candidate not found.")

    ats = crud.get_ats_score(db, candidate_id)
    rec = crud.get_recommendation(db, candidate_id)

    report_data = {}
    if ats:
        report_data.update({
            "skills_match":        ats.skills_match,
            "experience_match":    ats.experience_match,
            "project_relevance":   ats.project_relevance,
            "education_score":     ats.education_score,
            "certification_score": ats.certification_score,
            "semantic_similarity": ats.semantic_similarity,
            "total_score":         ats.total_score,
            "strengths":           ats.strengths,
            "skill_gaps":          ats.skill_gaps,
            "recommendation":      ats.recommendation,
        })
    if rec:
        report_data.update({
            "ai_verdict":          rec.ai_verdict,
            "ai_rating":           rec.ai_rating,
            "ai_justification":    rec.ai_justification,
            "hr_override_verdict": rec.hr_override_verdict or "N/A",
            "hr_notes":            rec.hr_notes or "N/A",
        })

    pdf_bytes = report_generator.generate_pdf_report(cand.name, report_data)
    crud.log_audit(db, current_user.id, "DOWNLOAD_PDF", f"PDF report for candidate {candidate_id}.")
    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={"Content-Disposition": f'attachment; filename="report_{candidate_id}.pdf"'},
    )


@router.get("/candidates/{candidate_id}/report/excel", tags=["Reports"])
def download_excel_report(
    candidate_id: int,
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(get_current_user),
):
    """Download an Excel hiring assessment report for a candidate."""
    cand = crud.get_candidate(db, candidate_id)
    if not cand:
        raise HTTPException(status_code=404, detail="Candidate not found.")

    ats = crud.get_ats_score(db, candidate_id)
    rec = crud.get_recommendation(db, candidate_id)

    report_data = {
        "Candidate Name":   cand.name,
        "Email":            cand.email,
        "Experience (yrs)": cand.experience_years or "N/A",
        "Status":           cand.status,
    }
    if ats:
        report_data.update({
            "Skills Match (%)":        ats.skills_match,
            "Experience Match (%)":    ats.experience_match,
            "Project Relevance (%)":   ats.project_relevance,
            "Education Score (%)":     ats.education_score,
            "Certification Score (%)": ats.certification_score,
            "Semantic Similarity (%)": ats.semantic_similarity,
            "Total ATS Score (%)":     ats.total_score,
            "Strengths":               ", ".join(ats.strengths or []),
            "Skill Gaps":              ", ".join(ats.skill_gaps or []),
            "ATS Recommendation":      ats.recommendation,
        })
    if rec:
        report_data.update({
            "AI Verdict":       rec.ai_verdict,
            "AI Rating (%)":    rec.ai_rating,
            "AI Justification": rec.ai_justification,
            "HR Override":      rec.hr_override_verdict or "N/A",
            "HR Notes":         rec.hr_notes or "N/A",
        })

    excel_bytes = report_generator.generate_excel_report(cand.name, report_data)
    crud.log_audit(db, current_user.id, "DOWNLOAD_EXCEL", f"Excel report for candidate {candidate_id}.")
    return Response(
        content=excel_bytes,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f'attachment; filename="report_{candidate_id}.xlsx"'},
    )


# ─────────────────────────────────────────────────────────────────────────────
# Interview Force-Complete
# ─────────────────────────────────────────────────────────────────────────────

@router.post("/interviews/{interview_id}/force-complete", tags=["Interviews"])
def force_complete_interview(
    interview_id: int,
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(require_manager),
):
    """
    Force-close an interview that was abandoned mid-way.
    Unanswered questions receive a score of 0.
    Overall score is the average across all questions (including zeros).
    Candidate status is updated based on AI verdict.
    """
    interview = crud.get_interview(db, interview_id)
    if not interview:
        raise HTTPException(status_code=404, detail="Interview not found.")
    if interview.is_completed:
        return {
            "message": "Interview is already completed.",
            "interview_id": interview_id,
            "overall_score": interview.overall_score
        }

    overall_score = force_complete_interview_db(db, interview)
    crud.log_audit(
        db, current_user.id, "FORCE_COMPLETE_INTERVIEW",
        f"Interview {interview_id} force-completed. Score: {overall_score:.1f}%.",
    )
    return {
        "message": "Interview closed and scored.",
        "interview_id": interview_id,
        "overall_score": round(overall_score, 2),
    }


# ─────────────────────────────────────────────────────────────────────────────
# Candidate Decisions
# ─────────────────────────────────────────────────────────────────────────────

@router.post("/candidates/{candidate_id}/approve", tags=["Candidates"])
def approve_candidate(
    candidate_id: int,
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(require_manager),
):
    """HR approves a candidate — sets status to 'Offered'."""
    cand = crud.update_candidate_status(db, candidate_id, "Offered")
    if not cand:
        raise HTTPException(status_code=404, detail="Candidate not found.")
    crud.log_audit(db, current_user.id, "APPROVE_CANDIDATE",
                   f"Candidate {candidate_id} ({cand.name}) approved → Offered.")
    return {"message": "Candidate approved and status set to Offered.",
            "status": "Offered", "candidate_id": candidate_id}


@router.post("/candidates/{candidate_id}/reject", tags=["Candidates"])
def reject_candidate(
    candidate_id: int,
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(require_manager),
):
    """HR rejects a candidate — sets status to 'Rejected'. Record kept in DB."""
    cand = crud.update_candidate_status(db, candidate_id, "Rejected")
    if not cand:
        raise HTTPException(status_code=404, detail="Candidate not found.")
        
    # Revoke onboarding offer and onboarding process if they exist
    from models import onboarding_models
    offer = db.query(onboarding_models.OnboardingOffer).filter(
        onboarding_models.OnboardingOffer.candidate_id == candidate_id
    ).first()
    if offer:
        offer.status = "revoked"
        
    process = db.query(schemas.OnboardingProcess).filter(
        schemas.OnboardingProcess.candidate_id == candidate_id
    ).first()
    if process:
        process.status = "Failed"
        
    crud.log_audit(db, current_user.id, "REJECT_CANDIDATE",
                   f"Candidate {candidate_id} ({cand.name}) rejected. Onboarding process failed, offer revoked.")
    return {"message": "Candidate rejected. Record retained in database. Onboarding offer revoked.",
            "status": "Rejected", "candidate_id": candidate_id}


@router.get("/candidates/{candidate_id}/decision", tags=["Candidates"])
def get_candidate_decision(
    candidate_id: int,
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(get_current_user),
):
    """Retrieve Decision Agent's structured verdict and recommended action."""
    rec = crud.get_recommendation(db, candidate_id)
    if not rec:
        raise HTTPException(status_code=404, detail="No recommendation found.")
    
    verdict = rec.hr_override_verdict or rec.ai_verdict or "Consider"
    
    # Map verdict to recommended action
    action_map = {
        "Strong Hire": "Extend Offer immediately",
        "Hire": "Proceed with Offer",
        "Consider": "Schedule follow-up interview / assessment",
        "Borderline": "Re-evaluate for alternative roles / decline",
        "Reject": "Decline application"
    }
    recommended_action = action_map.get(verdict, "Under review")
    
    return {
        "verdict": verdict,
        "confidence": rec.ai_rating or 0.0,
        "justification": rec.ai_justification or "",
        "recommended_action": recommended_action
    }


# ─────────────────────────────────────────────────────────────────────────────
# Admin Database Management
# ─────────────────────────────────────────────────────────────────────────────

@router.delete("/admin/clear-db", tags=["Admin"])
def clear_database(
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(require_manager),
):
    """
    DANGER: Deletes all candidate, interview, email, ranking, ATS, and
    recommendation data. Users and job postings are preserved.
    Manager-only.
    """
    db.query(schemas.InterviewAnswer).delete()
    db.query(schemas.InterviewQuestion).delete()
    db.query(schemas.Interview).delete()
    db.query(schemas.ATSScore).delete()
    db.query(schemas.CandidateRanking).delete()
    db.query(schemas.Recommendation).delete()
    db.query(schemas.EmailLog).delete()
    db.query(schemas.Candidate).delete()
    db.commit()
    crud.log_audit(db, current_user.id, "CLEAR_DB",
                   "All candidate/interview/email/ranking data cleared by admin.")
    return {
        "message": "Database cleared successfully. All candidate and interview data deleted. Jobs and users are preserved."
    }


# ─────────────────────────────────────────────────────────────────────────────
# Public Careers Portal
# ─────────────────────────────────────────────────────────────────────────────

@router.get("/public/jobs", tags=["Public Careers"])
def public_list_jobs(db: Session = Depends(get_db)):
    """List all active jobs for the public careers page."""
    jobs = db.query(schemas.Job).filter(schemas.Job.status == "Active").all()
    return [
        {
            "id": job.id,
            "title": job.title,
            "department": job.department,
            "location": job.location,
            "employment_type": job.employment_type,
            "salary_range": job.salary_range,
            "experience_required": job.experience_required,
            "skills_required": job.skills_required,
            "responsibilities": job.responsibilities,
            "full_description": job.full_description,
        }
        for job in jobs
    ]


@router.post("/public/jobs/{job_id}/apply", tags=["Public Careers"])
async def public_apply_to_job(
    job_id: int,
    name: str = Form(...),
    email: str = Form(...),
    phone: str = Form(...),
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
):
    """
    Public candidate application endpoint.
    Creates the candidate with user-submitted details and processes the resume.
    """
    job = db.query(schemas.Job).filter(schemas.Job.id == job_id).first()
    if not job:
        raise HTTPException(status_code=404, detail="Job not found.")

    contents = await file.read()
    if not contents:
        raise HTTPException(status_code=400, detail="Uploaded file is empty.")

    # S3 upload
    s3_key = ""
    try:
        from utils import aws_s3
        s3_key = aws_s3.upload_to_s3(contents, file.filename)
    except Exception as exc:
        logger.warning("S3 upload failed: %s", exc)

    # Text extraction
    from utils import text_extractor
    raw_text = text_extractor.extract_text(contents, file.filename)
    if not raw_text:
        raise HTTPException(
            status_code=422,
            detail="Could not extract text from the uploaded file.",
        )

    # Create candidate with user-submitted values directly (preserves what they entered)
    cand = crud.create_candidate(db, job_id, name, email, phone, s3_key)
    
    # Process the pipeline
    from services import recruitment_service
    recruitment_service.process_resume_ingestion_service(db, cand.id, raw_text)
    
    # Refresh to pick up updated fields
    db.refresh(cand)
    
    # Log audit
    crud.log_audit(db, None, "CANDIDATE_APPLY", f"Candidate {cand.id} ({cand.name}) applied online for job {job_id}.")

    return {
        "message": "Application submitted successfully.",
        "candidate_id": cand.id,
        "name": cand.name,
        "email": cand.email,
    }


@router.get("/users/me", tags=["Auth"])
def get_me(current_user: schemas.User = Depends(get_current_user)):
    """Retrieve the currently logged-in user's details."""
    return {
        "id": current_user.id,
        "email": current_user.email,
        "full_name": current_user.full_name,
        "is_manager": current_user.is_manager,
        "created_at": current_user.created_at,
    }


from pydantic import BaseModel

class BGVSubmitSchema(BaseModel):
    father_name: str
    permanent_address: str
    identity_proof_no: str
    declaration_accepted: bool

@router.post("/candidates/me/accept-offer", tags=["Candidate Flows"])
def accept_offer_me(
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(get_current_user),
):
    """Candidate accepts the extended offer in the Candidate Portal."""
    cand = db.query(schemas.Candidate).filter(
        schemas.Candidate.email == current_user.email,
        schemas.Candidate.status == "Offered"
    ).order_by(schemas.Candidate.id.desc()).first()
    if not cand:
        raise HTTPException(status_code=404, detail="No candidate application found for this user.")
    
    if cand.status != "Offered":
        raise HTTPException(status_code=400, detail=f"No extended offer to accept. Current status: {cand.status}")
    
    cand.status = "Offer Accepted"
    db.commit()
    db.refresh(cand)
    
    crud.log_audit(db, current_user.id, "ACCEPT_OFFER", f"Candidate {cand.id} accepted offer for job {cand.job_id}.")
    return {"message": "Offer accepted successfully. Please proceed with Background Verification (BGV).", "status": "Offer Accepted"}


@router.post("/candidates/me/reject-offer", tags=["Candidate Flows"])
def reject_offer_me(
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(get_current_user),
):
    """Candidate rejects the extended offer in the Candidate Portal."""
    cand = db.query(schemas.Candidate).filter(
        schemas.Candidate.email == current_user.email,
        schemas.Candidate.status == "Offered"
    ).order_by(schemas.Candidate.id.desc()).first()
    if not cand:
        raise HTTPException(status_code=404, detail="No candidate application found for this user.")
    
    if cand.status != "Offered":
        raise HTTPException(status_code=400, detail=f"No extended offer to reject. Current status: {cand.status}")
    
    cand.status = "Offer Rejected"
    db.commit()
    db.refresh(cand)
    
    crud.log_audit(db, current_user.id, "REJECT_OFFER", f"Candidate {cand.id} rejected offer for job {cand.job_id}.")
    return {"message": "Offer rejected successfully.", "status": "Offer Rejected"}



@router.post("/candidates/me/submit-bgv", tags=["Candidate Flows"])
def submit_bgv_me(
    bgv_data: BGVSubmitSchema,
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(get_current_user),
):
    """Candidate submits BGV details. On success, creates an Employee record and Onboarding process."""
    cand = db.query(schemas.Candidate).filter(
        schemas.Candidate.email == current_user.email,
        schemas.Candidate.status.in_(("Offer Accepted", "BGV In Progress"))
    ).order_by(schemas.Candidate.id.desc()).first()
    if not cand:
        raise HTTPException(status_code=404, detail="No candidate application found for this user.")
    
    if cand.status != "Offer Accepted":
        raise HTTPException(status_code=400, detail=f"Offer must be accepted before BGV can be completed. Current status: {cand.status}")
    
    # Ensure both Aadhaar and PAN documents have been uploaded and verified successfully
    from models import onboarding_models
    
    aadhaar_doc = db.query(onboarding_models.OnboardingBGVDocument).filter(
        onboarding_models.OnboardingBGVDocument.candidate_id == cand.id,
        onboarding_models.OnboardingBGVDocument.doc_type == "aadhaar"
    ).order_by(onboarding_models.OnboardingBGVDocument.uploaded_at.desc()).first()
    
    pan_doc = db.query(onboarding_models.OnboardingBGVDocument).filter(
        onboarding_models.OnboardingBGVDocument.candidate_id == cand.id,
        onboarding_models.OnboardingBGVDocument.doc_type == "pan"
    ).order_by(onboarding_models.OnboardingBGVDocument.uploaded_at.desc()).first()
    
    if not aadhaar_doc:
        raise HTTPException(status_code=400, detail="Aadhaar card has not been uploaded. Please upload it in the Aadhaar Card slot.")
    if aadhaar_doc.verification_status != "accepted":
        reason = aadhaar_doc.agent_result.get("reason", "Aadhaar verification failed.") if aadhaar_doc.agent_result else "Aadhaar verification failed."
        raise HTTPException(status_code=400, detail=f"Aadhaar verification rejected: {reason}")
        
    if not pan_doc:
        raise HTTPException(status_code=400, detail="PAN card has not been uploaded. Please upload it in the PAN Card slot.")
    if pan_doc.verification_status != "accepted":
        reason = pan_doc.agent_result.get("reason", "PAN verification failed.") if pan_doc.agent_result else "PAN verification failed."
        raise HTTPException(status_code=400, detail=f"PAN verification rejected: {reason}")

    # Save BGV details into parsed_data JSON field
    pdata = dict(cand.parsed_data or {})
    pdata["bgv_details"] = {
        "father_name": bgv_data.father_name,
        "permanent_address": bgv_data.permanent_address,
        "identity_proof_no": bgv_data.identity_proof_no,
        "submitted_at": datetime.datetime.utcnow().isoformat()
    }
    cand.parsed_data = pdata
    
    # Update candidate status to Joined/BGV Cleared
    cand.status = "Joined"
    
    # Generate corporate email and password
    import re
    clean_name = re.sub(r'[^a-zA-Z0-9\.]', '', cand.name.lower().replace(' ', '.'))
    corp_email = f"{clean_name}@company.com"
    
    # Ensure corp_email is unique
    existing_user = db.query(schemas.User).filter(schemas.User.email == corp_email).first()
    counter = 1
    while existing_user:
        corp_email = f"{clean_name}{counter}@company.com"
        existing_user = db.query(schemas.User).filter(schemas.User.email == corp_email).first()
        counter += 1
        
    import random
    temp_password = f"Welcome@{random.randint(1000, 9999)}"
    
    # Check if Employee record already exists to avoid duplication
    emp = db.query(schemas.Employee).filter(schemas.Employee.email == corp_email).first()
    if not emp:
        # Generate unique employee code
        import hashlib
        emp_hash = int(hashlib.md5(corp_email.encode()).hexdigest(), 16)
        emp_code = f"EMP-{emp_hash % 900000 + 100000}"
        
        # Fetch the job record to get designation/department/location
        job = db.query(schemas.Job).filter(schemas.Job.id == cand.job_id).first()
        
        # Convert candidate skills list to a dictionary with default rating 5
        cand_skills = cand.skills or []
        skills_profile = {}
        if isinstance(cand_skills, list):
            for skill in cand_skills:
                skills_profile[skill] = 5
        elif isinstance(cand_skills, dict):
            skills_profile = cand_skills

        # Create Employee record with corporate email
        emp = schemas.Employee(
            employee_code=emp_code,
            name=cand.name,
            email=corp_email,
            status="Active",
            designation=job.title if job else None,
            department=job.department if job else None,
            location=job.location if job else None,
            skills_profile=skills_profile
        )
        db.add(emp)
        db.commit()
        db.refresh(emp)
        
        # Create User record in the users table so they can log in
        from middleware.auth import hash_password
        hashed_pass = hash_password(temp_password)
        new_user = schemas.User(
            email=corp_email,
            hashed_password=hashed_pass,
            full_name=cand.name,
            is_manager=False
        )
        db.add(new_user)
        db.commit()
        
        # Save corporate credentials into candidate parsed_data so candidate_app can show it
        pdata = dict(cand.parsed_data or {})
        pdata["corporate_credentials"] = {
            "email": corp_email,
            "password": temp_password
        }
        cand.parsed_data = pdata
        db.commit()
        db.refresh(cand)
        
        # Create OnboardingProcess record
        onboarding = schemas.OnboardingProcess(
            candidate_id=cand.id,
            employee_id=emp.id,
            status="In_Progress"
        )
        db.add(onboarding)
        db.commit()
    
    db.commit()
    db.refresh(cand)
    
    crud.log_audit(db, current_user.id, "SUBMIT_BGV_PROMOTION", f"Candidate {cand.id} cleared BGV and promoted to Employee {emp.employee_code}.")
    return {"message": "BGV submitted and verification completed. You are now promoted to Employee status.", "employee_code": emp.employee_code}


@router.get("/employees/me", tags=["Employees"])
def get_employee_me(
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(get_current_user),
):
    """Retrieve logged-in employee profile. Used for employee portal login restriction."""
    emp = db.query(schemas.Employee).filter(schemas.Employee.email == current_user.email).first()
    if not emp:
        raise HTTPException(status_code=404, detail="Employee profile not found.")
    return {
        "id": emp.id,
        "employee_code": emp.employee_code,
        "name": emp.name,
        "email": emp.email,
        "status": emp.status,
        "designation": emp.designation,
        "department": emp.department,
        "location": emp.location,
        "skills_profile": emp.skills_profile,
        "joined_at": str(emp.joined_at) if emp.joined_at else None,
    }


# ───────────────────────────────────────────────────────────────────────────────
# Resume Submission Security Helpers
# ───────────────────────────────────────────────────────────────────────────────

import re as _re

def _names_match(profile_name: str, resume_name: str, threshold: float = 0.75) -> bool:
    """
    Check that the name on the resume overlaps sufficiently (≥75% token overlap)
    with the logged-in user's profile name.
    Normalises to lowercase, splits on whitespace/punctuation, and compares token sets.
    """
    def _tokenise(name: str) -> set:
        # lower-case, strip punctuation, split on spaces/dots/commas
        cleaned = _re.sub(r"[^a-z0-9\s]", " ", name.lower())
        return {t for t in cleaned.split() if t}

    p_tokens = _tokenise(profile_name)
    r_tokens = _tokenise(resume_name)
    if not p_tokens or not r_tokens:
        return False
    overlap = len(p_tokens & r_tokens)
    ratio = overlap / max(len(p_tokens), len(r_tokens))
    return ratio >= threshold


def _is_resume_document(text: str) -> bool:
    """
    Two-stage resume document classifier:
      Stage 1 — Fast regex heuristic: count how many resume-signal patterns fire.
                 If ≥3 signals match  → definitely a resume (True).
                 If 0 signals match   → definitely NOT a resume (False).
                 If 1-2 signals match → borderline, escalate to Stage 2.
      Stage 2 — LLM fallback for borderline cases.
    """
    import json as _json
    from utils.llm_client import invoke_llm, LLM_UNAVAILABLE

    RESUME_SIGNALS = [
        r"\b(experience|work experience|employment history|work history)\b",
        r"\b(education|qualification|degree|university|college|b\.?tech|m\.?tech|bsc|msc|bachelor|master|phd)\b",
        r"\b(skills?|technical skills?|technologies|proficient in|expertise)\b",
        r"\b(projects?|portfolio)\b",
        r"\b(certifications?|certified|achievements?|awards?)\b",
        r"\b(summary|objective|career objective|professional profile|about me)\b",
        r"\b(internship|intern|trainee|fresher|fresher candidate)\b",
        r"\b(github\.com|linkedin\.com|portfolio\.io|stackoverflow)\b",
    ]

    sample = text[:4000]  # Only inspect the first 4000 chars (much faster)
    signal_count = sum(
        1 for pattern in RESUME_SIGNALS
        if _re.search(pattern, sample, _re.IGNORECASE)
    )

    # Fast accept path
    if signal_count >= 3:
        return True

    # Fast reject path — not even close to a resume
    if signal_count == 0:
        return False

    # Borderline (1–2 signals): ask the LLM
    logger.info("Resume classifier: borderline (%d signals) — escalating to LLM.", signal_count)
    llm_prompt = f"""You are a document classification expert.
Read the following text (first 2000 characters of a PDF) and decide if it is a professional resume/CV.

A resume/CV typically contains: personal contact info, work experience, education, skills, and/or projects.
It is NOT an Aadhaar card, PAN card, identity document, invoice, medical report, or unrelated work document.

Respond with ONLY a JSON object: {{"is_resume": true}} or {{"is_resume": false}}

Document text:
{text[:2000]}
"""
    raw = invoke_llm(llm_prompt, max_tokens=64, json_mode=True)
    if raw == LLM_UNAVAILABLE:
        # LLM unavailable — be permissive and let it through (don't block on infra failure)
        logger.warning("Resume classifier LLM unavailable — defaulting to accept.")
        return True
    try:
        result = _json.loads(raw)
        return bool(result.get("is_resume", True))
    except Exception:
        logger.warning("Resume classifier LLM returned invalid JSON — defaulting to accept.")
        return True


@router.post("/public/jobs/{job_id}/apply-secure", tags=["Public Careers"])
async def public_apply_secure(
    job_id: int,
    phone: str = Form(...),
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(get_current_user),
):
    """
    Authenticated candidate application endpoint.
    Retrieves Name and Email securely from the logged-in user's token.
    """
    job = db.query(schemas.Job).filter(schemas.Job.status == "Active").filter(schemas.Job.id == job_id).first()
    if not job:
        raise HTTPException(status_code=404, detail="Job not found or inactive.")

    contents = await file.read()
    if not contents:
        raise HTTPException(status_code=400, detail="Uploaded file is empty.")

    # S3 upload
    s3_key = ""
    try:
        from utils import aws_s3
        s3_key = aws_s3.upload_to_s3(contents, file.filename)
    except Exception as exc:
        logger.warning("S3 upload failed: %s", exc)

    # Text extraction
    from utils import text_extractor
    raw_text = text_extractor.extract_text(contents, file.filename)
    if not raw_text:
        raise HTTPException(
            status_code=422,
            detail="Could not extract text from the uploaded file.",
        )

    # ── Security Validation 1: Is this actually a resume? ────────────────
    if not _is_resume_document(raw_text):
        raise HTTPException(
            status_code=400,
            detail=(
                "The uploaded document does not appear to be a resume or CV. "
                "Please upload your professional resume in PDF or TXT format. "
                "Identity documents (Aadhaar, PAN), invoices, and unrelated files are not accepted."
            ),
        )

    # ── Security Validation 2: Resume name must match logged-in profile ──
    from agents.resume_parser import ResumeParsingAgent as _ResumeParsingAgent
    _quick_parsed = _ResumeParsingAgent().parse(raw_text)
    resume_name = _quick_parsed.get("name", "").strip()
    profile_name = (current_user.full_name or "").strip()

    # Only enforce the check when name extraction actually succeeded.
    # An empty resume_name means OCR/LLM couldn't read the name (e.g. scanned PDF,
    # image-only resume) — we allow the upload rather than blocking with a false mismatch.
    _extraction_failed = not resume_name or resume_name.lower() in (
        "unknown candidate", "unknown", "n/a", "none", "candidate"
    )
    if not _extraction_failed and profile_name and not _names_match(profile_name, resume_name):
        raise HTTPException(
            status_code=400,
            detail=(
                f"Identity mismatch: The name on the resume ('{resume_name}') does not match "
                f"your profile name ('{profile_name}'). "
                "Please upload your own resume. If your name differs, update your profile first."
            ),
        )
    if _extraction_failed:
        logger.info(
            "Resume name extraction returned '%s' for profile '%s' — skipping identity check.",
            resume_name, profile_name,
        )

    # Create candidate with user-submitted values directly (preserves what they entered)
    cand = crud.create_candidate(db, job_id, current_user.full_name, current_user.email, phone, s3_key)
    
    # Process the pipeline
    from services import recruitment_service
    recruitment_service.process_resume_ingestion_service(db, cand.id, raw_text)
    
    # Refresh to pick up updated fields
    db.refresh(cand)
    
    # Log audit
    crud.log_audit(db, current_user.id, "CANDIDATE_APPLY_SECURE", f"Candidate {cand.id} ({cand.name}) applied securely for job {job_id}.")

    return {
        "message": "Application submitted successfully.",
        "candidate_id": cand.id,
        "name": cand.name,
        "email": cand.email,
    }



# ===============================================================================
# AI ONBOARDING PIPELINE ENDPOINTS
# ===============================================================================

from services import onboarding_service


class SalaryInputSchema(BaseModel):
    current_salary: Optional[float] = None
    expected_salary: Optional[float] = None


class GenerateOfferSchema(BaseModel):
    salary: float
    salary_notes: Optional[Dict[str, Any]] = None


@router.post("/onboarding/{candidate_id}/salary-recommendation", tags=["Onboarding"])
def recommend_salary(
    candidate_id: int,
    payload: SalaryInputSchema = SalaryInputSchema(),
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(require_manager),
):
    """AI salary recommendation using AWS Bedrock. Job salary_range sets the budget boundary."""
    return onboarding_service.get_salary_recommendation(
        db, candidate_id,
        current_salary=payload.current_salary,
        expected_salary=payload.expected_salary,
    )


@router.post("/onboarding/{candidate_id}/generate-offer-letter", tags=["Onboarding"])
def generate_offer_letter_endpoint(
    candidate_id: int,
    payload: GenerateOfferSchema,
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(require_manager),
):
    """Generate AI offer letter PDF (Bedrock + S3/local). Returns offer record with URI."""
    result = onboarding_service.generate_offer_letter(
        db, candidate_id, salary=payload.salary, salary_notes=payload.salary_notes or {},
    )
    crud.log_audit(db, current_user.id, "GENERATE_OFFER_LETTER",
                   f"AI offer letter generated for candidate {candidate_id}. Salary={payload.salary}")
    return result


@router.post("/onboarding/{candidate_id}/send-offer-email", tags=["Onboarding"])
async def send_offer_email_endpoint(
    candidate_id: int,
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(require_manager),
):
    """Send generated offer letter PDF to candidate via email (Gmail/local log)."""
    result = await onboarding_service.send_offer_email(db, candidate_id)
    crud.log_audit(db, current_user.id, "SEND_OFFER_EMAIL",
                   f"Offer email sent to candidate {candidate_id}")
    return result


@router.get("/onboarding/{candidate_id}/offer", tags=["Onboarding"])
def get_onboarding_offer(
    candidate_id: int,
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(get_current_user),
):
    """Retrieve current offer record for a candidate (HR + candidate portal)."""
    offer = onboarding_service.get_offer(db, candidate_id)
    if not offer:
        raise HTTPException(status_code=404, detail="No offer found for this candidate.")
    return offer


@router.get("/onboarding/{candidate_id}/offer-letter-pdf", tags=["Onboarding"])
def download_offer_letter_pdf_endpoint(
    candidate_id: int,
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(get_current_user),
):
    """Download AI-generated offer letter PDF."""
    from fastapi.responses import Response
    pdf_bytes = onboarding_service.get_offer_pdf(db, candidate_id)
    return Response(content=pdf_bytes, media_type="application/pdf")


@router.post("/onboarding/{candidate_id}/assign-access", tags=["Onboarding"])
def assign_access_endpoint(
    candidate_id: int,
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(require_manager),
):
    """Assign birthright access to a newly joined employee based on their department."""
    emp = (
        db.query(schemas.Employee)
        .join(schemas.Candidate, schemas.Employee.email == schemas.Candidate.email)
        .filter(schemas.Candidate.id == candidate_id)
        .first()
    )
    assignments = onboarding_service.assign_access(db, candidate_id, employee_id=emp.id if emp else None)
    crud.log_audit(db, current_user.id, "ASSIGN_ACCESS",
                   f"Birthright access assigned for candidate {candidate_id}: {len(assignments)} items.")
    return {"candidate_id": candidate_id, "assignments": assignments}


@router.get("/candidates/me/offer", tags=["Candidate Flows"])
def get_my_onboarding_offer(
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(get_current_user),
):
    """Retrieve AI offer for logged-in candidate. Returns null if no offer generated yet."""
    cand = db.query(schemas.Candidate).filter(
        schemas.Candidate.email == current_user.email,
        schemas.Candidate.status.in_(("Offered", "Offer Accepted", "BGV In Progress", "Joined"))
    ).order_by(schemas.Candidate.id.desc()).first()
    if not cand:
        cand = db.query(schemas.Candidate).filter(schemas.Candidate.email == current_user.email).order_by(schemas.Candidate.id.desc()).first()
    if not cand:
        raise HTTPException(status_code=404, detail="No candidate application found.")
    return onboarding_service.get_offer(db, cand.id)


@router.get("/candidates/me/offer-pdf", tags=["Candidate Flows"])
def download_my_offer_pdf_endpoint(
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(get_current_user),
):
    """Download AI offer letter PDF for logged-in candidate."""
    from fastapi.responses import Response
    cand = db.query(schemas.Candidate).filter(
        schemas.Candidate.email == current_user.email,
        schemas.Candidate.status.in_(("Offered", "Offer Accepted", "BGV In Progress", "Joined"))
    ).order_by(schemas.Candidate.id.desc()).first()
    if not cand:
        cand = db.query(schemas.Candidate).filter(schemas.Candidate.email == current_user.email).order_by(schemas.Candidate.id.desc()).first()
    if not cand:
        raise HTTPException(status_code=404, detail="No candidate application found.")
    pdf_bytes = onboarding_service.get_offer_pdf(db, cand.id)
    return Response(content=pdf_bytes, media_type="application/pdf")


@router.post("/onboarding/{candidate_id}/bgv", tags=["Onboarding"])
async def upload_bgv_document(
    candidate_id: int,
    doc_type: str = Form(...),
    file: UploadFile = File(...),
    identity_no: Optional[str] = Form(None),
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(get_current_user),
):
    """Upload and verify BGV document (aadhaar, pan, offer_letter) using OCR/AI."""
    # Allow if candidate themselves or manager
    if not current_user.is_manager:
        cand = db.query(schemas.Candidate).filter(schemas.Candidate.id == candidate_id).first()
        if not cand or cand.email != current_user.email:
            raise HTTPException(status_code=403, detail="Not authorized to perform BGV upload.")
            
    contents = await file.read()
    if not contents:
        raise HTTPException(status_code=400, detail="Uploaded file is empty.")
        
    return onboarding_service.store_bgv_document(
        db=db,
        candidate_id=candidate_id,
        doc_type=doc_type,
        file_name=file.filename,
        file_bytes=contents,
        content_type=file.content_type,
        identity_no=identity_no,
    )


@router.get("/onboarding/{candidate_id}/bgv", tags=["Onboarding"])
def get_bgv_documents(
    candidate_id: int,
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(get_current_user),
):
    """Return all BGV document verification records for a candidate, newest first."""
    if not current_user.is_manager:
        cand = db.query(schemas.Candidate).filter(schemas.Candidate.id == candidate_id).first()
        if not cand or cand.email != current_user.email:
            raise HTTPException(status_code=403, detail="Not authorized to access BGV history.")
            
    from models import onboarding_models
    docs = db.query(onboarding_models.OnboardingBGVDocument)\
             .filter(onboarding_models.OnboardingBGVDocument.candidate_id == candidate_id)\
             .order_by(onboarding_models.OnboardingBGVDocument.uploaded_at.desc()).all()
             
    return [
        {
            "id": d.id,
            "candidate_id": d.candidate_id,
            "doc_type": d.doc_type,
            "file_name": d.file_name,
            "storage_uri": d.storage_uri,
            "verification_status": d.verification_status,
            "agent_result": d.agent_result,
            "uploaded_at": d.uploaded_at.isoformat() if d.uploaded_at else None,
            "verified_at": d.verified_at.isoformat() if d.verified_at else None,
        }
        for d in docs
    ]


class BGVFailureSchema(BaseModel):
    reasons: List[str]

@router.post("/candidates/me/register-bgv-failure", tags=["Candidate Flows"])
def register_bgv_failure_me(
    payload: BGVFailureSchema,
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(get_current_user),
):
    """Candidate portal reports a BGV check failure. Updates metadata and status."""
    cand = db.query(schemas.Candidate).filter(
        schemas.Candidate.email == current_user.email,
        schemas.Candidate.status.in_(("Offer Accepted", "BGV In Progress"))
    ).order_by(schemas.Candidate.id.desc()).first()
    if not cand:
        raise HTTPException(status_code=404, detail="No candidate application found for this user.")
        
    pdata = dict(cand.parsed_data or {})
    attempts = pdata.get("bgv_attempts", 0) + 1
    pdata["bgv_attempts"] = attempts
    
    # Save failure details
    failure_entry = {
        "attempt": attempts,
        "timestamp": datetime.datetime.utcnow().isoformat(),
        "reasons": payload.reasons
    }
    pdata.setdefault("bgv_failures", []).append(failure_entry)
    
    if attempts >= 3:
        pdata["bgv_locked"] = True
        pdata["bgv_retry_allowed"] = False
        cand.status = "Offer Revoked"
        # Compile final revoke reason details
        reasons_list = []
        for fail in pdata.get("bgv_failures", []):
            reasons_list.append(f"Attempt {fail['attempt']}: {'; '.join(fail['reasons'])}")
        pdata["bgv_revocation_details"] = "Background Verification failed on all three attempts. Details:\n- " + "\n- ".join(reasons_list)
        
        # Revoke onboarding offer and fail process
        from models import onboarding_models
        offer = db.query(onboarding_models.OnboardingOffer).filter(
            onboarding_models.OnboardingOffer.candidate_id == cand.id
        ).first()
        if offer:
            offer.status = "revoked"
        
        process = db.query(schemas.OnboardingProcess).filter(
            schemas.OnboardingProcess.candidate_id == cand.id
        ).first()
        if process:
            process.status = "Failed"
            
        crud.log_audit(db, current_user.id, "BGV_REVOKE", f"Candidate {cand.id} failed BGV on 3rd attempt. Offer Revoked.")
    else:
        pdata["bgv_locked"] = False
        pdata["bgv_retry_allowed"] = True
        crud.log_audit(db, current_user.id, "BGV_FAILURE", f"Candidate {cand.id} failed BGV on attempt {attempts}.")
        
    cand.parsed_data = pdata
    db.commit()
    db.refresh(cand)
    return {
        "status": cand.status,
        "attempts": attempts,
        "locked": pdata.get("bgv_locked", False),
        "retry_allowed": pdata.get("bgv_retry_allowed", True)
    }


@router.post("/candidates/{candidate_id}/grant-bgv-retry", tags=["Onboarding"])
def grant_bgv_retry(
    candidate_id: int,
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(require_manager),
):
    """HR grants a failed candidate a retry chance for BGV. Resets locked status and clears old docs."""
    cand = db.query(schemas.Candidate).filter(schemas.Candidate.id == candidate_id).first()
    if not cand:
        raise HTTPException(status_code=404, detail="Candidate not found.")
        
    pdata = dict(cand.parsed_data or {})
    attempts = pdata.get("bgv_attempts", 0)
    
    if attempts == 0:
        raise HTTPException(status_code=400, detail="Candidate has not attempted BGV yet.")
        
    # Grant retry
    pdata["bgv_locked"] = False
    pdata["bgv_retry_allowed"] = True
    pdata["bgv_attempts"] = 0
    pdata.pop("bgv_failures", None)
    pdata.pop("bgv_revocation_details", None)
    cand.parsed_data = pdata
    
    # If candidate status was revoked, restore it
    if cand.status == "Offer Revoked":
        cand.status = "Offer Accepted"
        
        # Restore offer and process
        from models import onboarding_models
        offer = db.query(onboarding_models.OnboardingOffer).filter(
            onboarding_models.OnboardingOffer.candidate_id == candidate_id
        ).first()
        if offer:
            offer.status = "accepted"
            
        process = db.query(schemas.OnboardingProcess).filter(
            schemas.OnboardingProcess.candidate_id == candidate_id
        ).first()
        if process:
            process.status = "In_Progress"
            
    # Clear previous documents from onboarding_bgv_documents so candidate has fresh upload slots
    from models import onboarding_models
    db.query(onboarding_models.OnboardingBGVDocument).filter(
        onboarding_models.OnboardingBGVDocument.candidate_id == candidate_id
    ).delete()
    
    db.commit()
    db.refresh(cand)
    crud.log_audit(db, current_user.id, "BGV_GRANT_RETRY", f"HR granted BGV retry for candidate {candidate_id}.")
    return {
        "message": "BGV retry successfully granted.",
        "candidate_id": candidate_id,
        "locked": pdata.get("bgv_locked", False),
        "retry_allowed": pdata.get("bgv_retry_allowed", True)
    }


# ─────────────────────────────────────────────────────────────────────────────
# BGV HR MANUAL REVIEW — Approve or Reject a blurry/unreadable document
# ─────────────────────────────────────────────────────────────────────────────

class BGVHRReviewSchema(BaseModel):
    decision: str      # "approved" | "rejected"
    hr_notes: str = ""


@router.post("/onboarding/{candidate_id}/bgv/{doc_id}/hr-review", tags=["Onboarding"])
def hr_review_bgv_document(
    candidate_id: int,
    doc_id: int,
    payload: BGVHRReviewSchema,
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(require_manager),
):
    """
    HR manually approves or rejects a BGV document that the AI flagged for review (e.g. blurry scan).
    - If approved → sets document verification_status to 'accepted'.
      If both docs now accepted, candidate moves to 'Joined' and an employee record is created.
    - If rejected → sets document verification_status to 'rejected' and registers a BGV failure.
    """
    from models import onboarding_models

    # Validate decision
    if payload.decision not in ("approved", "rejected"):
        raise HTTPException(status_code=400, detail="decision must be 'approved' or 'rejected'")

    # Load candidate
    cand = db.query(schemas.Candidate).filter(schemas.Candidate.id == candidate_id).first()
    if not cand:
        raise HTTPException(status_code=404, detail="Candidate not found.")

    # Block HR review on Offer Revoked candidates
    if cand.status == "Offer Revoked":
        raise HTTPException(status_code=400, detail="Cannot review documents for a revoked candidate.")

    # Load the document
    doc = db.query(onboarding_models.OnboardingBGVDocument).filter(
        onboarding_models.OnboardingBGVDocument.id == doc_id,
        onboarding_models.OnboardingBGVDocument.candidate_id == candidate_id,
    ).first()
    if not doc:
        raise HTTPException(status_code=404, detail="BGV document not found.")
    if doc.verification_status != "review":
        raise HTTPException(status_code=400, detail="Document is not pending HR review.")

    pdata = dict(cand.parsed_data or {})

    if payload.decision == "approved":
        doc.verification_status = "accepted"
        # Merge HR notes into agent_result
        agent_r = dict(doc.agent_result or {})
        agent_r["hr_decision"] = "approved"
        agent_r["hr_notes"] = payload.hr_notes
        doc.agent_result = agent_r
        db.commit()
        db.refresh(doc)

        # Check if ALL docs for this candidate are now accepted
        all_docs = db.query(onboarding_models.OnboardingBGVDocument).filter(
            onboarding_models.OnboardingBGVDocument.candidate_id == candidate_id
        ).all()

        # Deduplicate: take latest doc per doc_type
        latest_by_type: dict = {}
        for d in sorted(all_docs, key=lambda x: x.uploaded_at):
            latest_by_type[d.doc_type] = d

        required_types = {"aadhaar", "pan"}
        all_clear = required_types.issubset(latest_by_type.keys()) and all(
            latest_by_type[t].verification_status == "accepted" for t in required_types
        )

        if all_clear and cand.status in ("Offer Accepted", "BGV In Progress"):
            # Promote to Joined
            cand.status = "Joined"
            pdata["bgv_cleared"] = True
            cand.parsed_data = pdata

            # Check if OnboardingProcess already exists to avoid duplication
            onboarding = db.query(onboarding_models.OnboardingProcess).filter(
                onboarding_models.OnboardingProcess.candidate_id == candidate_id
            ).first()

            if not onboarding:
                # Generate corporate email and password
                import re
                clean_name = re.sub(r'[^a-zA-Z0-9\.]', '', cand.name.lower().replace(' ', '.'))
                corp_email = f"{clean_name}@company.com"
                
                # Ensure corp_email is unique
                existing_user = db.query(schemas.User).filter(schemas.User.email == corp_email).first()
                counter = 1
                while existing_user:
                    corp_email = f"{clean_name}{counter}@company.com"
                    existing_user = db.query(schemas.User).filter(schemas.User.email == corp_email).first()
                    counter += 1
                    
                import random
                temp_password = f"Welcome@{random.randint(1000, 9999)}"
                
                # Check if Employee record already exists to avoid duplication
                emp = db.query(schemas.Employee).filter(schemas.Employee.email == corp_email).first()
                if not emp:
                    # Generate unique employee code
                    import hashlib
                    emp_hash = int(hashlib.md5(corp_email.encode()).hexdigest(), 16)
                    emp_code = f"EMP-{emp_hash % 900000 + 100000}"
                    
                    # Fetch the job record to get designation/department/location
                    job = db.query(schemas.Job).filter(schemas.Job.id == cand.job_id).first()
                    
                    # Convert candidate skills list to a dictionary with default rating 5
                    cand_skills = cand.skills or []
                    skills_profile = {}
                    if isinstance(cand_skills, list):
                        for skill in cand_skills:
                            skills_profile[skill] = 5
                    elif isinstance(cand_skills, dict):
                        skills_profile = cand_skills

                    # Create Employee record with corporate email
                    emp = schemas.Employee(
                        employee_code=emp_code,
                        name=cand.name,
                        email=corp_email,
                        status="Active",
                        designation=job.title if job else None,
                        department=job.department if job else None,
                        location=job.location if job else None,
                        skills_profile=skills_profile
                    )
                    db.add(emp)
                    db.commit()
                    db.refresh(emp)
                    
                    # Create User record in the users table so they can log in
                    from middleware.auth import hash_password
                    hashed_pass = hash_password(temp_password)
                    new_user = schemas.User(
                        email=corp_email,
                        hashed_password=hashed_pass,
                        full_name=cand.name,
                        is_manager=False
                    )
                    db.add(new_user)
                    db.commit()
                    
                    # Save corporate credentials into candidate parsed_data so candidate_app can show it
                    pdata = dict(cand.parsed_data or {})
                    pdata["corporate_credentials"] = {
                        "email": corp_email,
                        "password": temp_password
                    }
                    cand.parsed_data = pdata
                    db.commit()
                    db.refresh(cand)
                    
                    # Create OnboardingProcess record
                    onboarding = onboarding_models.OnboardingProcess(
                        candidate_id=cand.id,
                        employee_id=emp.id,
                        status="In_Progress"
                    )
                    db.add(onboarding)

            db.commit()
            db.refresh(cand)
            crud.log_audit(db, current_user.id, "BGV_HR_APPROVED_ALL",
                           f"HR approved doc {doc_id}; candidate {candidate_id} promoted to Joined.")
            return {"message": "Document approved. All BGV docs cleared — candidate promoted to Joined.", "all_clear": True}

        db.commit()
        crud.log_audit(db, current_user.id, "BGV_HR_APPROVED_DOC",
                       f"HR approved BGV doc {doc_id} for candidate {candidate_id}.")
        return {"message": "Document approved by HR.", "all_clear": False}

    else:
        # Rejected by HR
        doc.verification_status = "rejected"
        agent_r = dict(doc.agent_result or {})
        agent_r["hr_decision"] = "rejected"
        agent_r["hr_notes"] = payload.hr_notes
        doc.agent_result = agent_r

        # Register failure
        failures = pdata.get("bgv_failures", [])
        failures.append(f"[HR Rejected] {doc.doc_type.upper()}: {payload.hr_notes or 'Rejected by HR.'}")
        pdata["bgv_failures"] = failures
        attempts = pdata.get("bgv_attempts", 0) + 1
        pdata["bgv_attempts"] = attempts

        if attempts >= 3:
            cand.status = "Offer Revoked"
            pdata["bgv_locked"] = True
            pdata["bgv_revocation_details"] = (
                "Your offer has been revoked after review. Documents failed verification. "
                f"Reason: {'; '.join(failures)}"
            )
        else:
            pdata["bgv_locked"] = True

        cand.parsed_data = pdata
        db.commit()
        crud.log_audit(db, current_user.id, "BGV_HR_REJECTED_DOC",
                       f"HR rejected BGV doc {doc_id} for candidate {candidate_id}. Attempts: {attempts}.")
        return {
            "message": "Document rejected by HR.",
            "attempts": attempts,
            "revoked": cand.status == "Offer Revoked",
        }


@router.get("/onboarding/{candidate_id}/bgv/{doc_id}/preview", tags=["Onboarding"])
def preview_bgv_document(
    candidate_id: int,
    doc_id: int,
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(require_manager),
):
    """
    Stream a BGV document image/PDF for HR preview.
    Returns the raw bytes with appropriate content-type header.
    """
    from models import onboarding_models
    from integrations.onboarding_storage import OnboardingStorageClient
    from config.onboarding_settings import get_onboarding_settings

    doc = db.query(onboarding_models.OnboardingBGVDocument).filter(
        onboarding_models.OnboardingBGVDocument.id == doc_id,
        onboarding_models.OnboardingBGVDocument.candidate_id == candidate_id,
    ).first()
    if not doc:
        raise HTTPException(status_code=404, detail="BGV document not found.")

    settings_ = get_onboarding_settings()
    storage = OnboardingStorageClient(settings_)
    try:
        file_bytes = storage.get_bytes(doc.storage_uri)
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Could not retrieve file: {exc}") from exc

    fn_lower = doc.file_name.lower()
    if fn_lower.endswith(".pdf"):
        media_type = "application/pdf"
    elif fn_lower.endswith(".png"):
        media_type = "image/png"
    elif fn_lower.endswith(".jpg") or fn_lower.endswith(".jpeg"):
        media_type = "image/jpeg"
    else:
        media_type = "application/octet-stream"

    return Response(
        content=file_bytes,
        media_type=media_type,
        headers={"Content-Disposition": f"inline; filename=\"{doc.file_name}\""},
    )


# ═══════════════════════════════════════════════════════════════════════════════
# EXIT MANAGEMENT / OFFBOARDING ENDPOINTS
# ═══════════════════════════════════════════════════════════════════════════════

@router.post("/employees/resign", tags=["Exit Management"])
def employee_resign(
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(get_current_user),
):
    """
    Called when an employee clicks 'Proceed' on the resignation letter.
    1. Finds the employee record by email.
    2. Inserts a row into the resignations table (preserving their data).
    3. Deletes the employee from the employees table.
    The employee's user account (users table) is kept intact for JWT auth,
    but /employees/me will now 404, blocking portal access.
    """
    emp = db.query(schemas.Employee).filter(schemas.Employee.email == current_user.email).first()
    if not emp:
        raise HTTPException(status_code=404, detail="Employee profile not found.")

    # Check not already resigned
    existing = db.query(schemas.Resignation).filter(schemas.Resignation.email == current_user.email).first()
    if existing:
        raise HTTPException(status_code=400, detail="Resignation already submitted.")

    # Save to resignations table
    resignation = schemas.Resignation(
        employee_id=emp.id,
        employee_code=emp.employee_code,
        name=emp.name,
        email=emp.email,
        department=emp.department,
        designation=emp.designation,
        resigned_at=datetime.datetime.utcnow(),
        audio_uploaded=False,
        analysis_done=False,
    )
    db.add(resignation)
    db.flush()  # Get the resignation.id before deleting employee

    # Delete from employees table (revokes portal access)
    # Clean up dependent database records first to avoid foreign key integrity constraint violations
    try:
        # 1. Nullify onboarding_processes
        db.query(schemas.OnboardingProcess).filter(schemas.OnboardingProcess.employee_id == emp.id).update({schemas.OnboardingProcess.employee_id: None})
        
        # 2. Nullify manager references in organizational_structures
        db.query(schemas.OrganizationalStructure).filter(schemas.OrganizationalStructure.manager_id == emp.id).update({schemas.OrganizationalStructure.manager_id: None})
        # Delete employee's own record in organizational_structures
        db.query(schemas.OrganizationalStructure).filter(schemas.OrganizationalStructure.employee_id == emp.id).delete()
        
        # 3. Delete course assignments
        db.query(schemas.CourseAssignment).filter(schemas.CourseAssignment.employee_id == emp.id).delete()
        
        # 4. Delete skill gap analyses
        db.query(schemas.SkillGapAnalysis).filter(schemas.SkillGapAnalysis.employee_id == emp.id).delete()
        
        # 5. Delete chatbot tickets
        db.query(schemas.ChatbotTicket).filter(schemas.ChatbotTicket.employee_id == emp.id).delete()
        
        # 6. Nullify survey_responses (preserving anonymous/historical response content)
        db.query(schemas.SurveyResponse).filter(schemas.SurveyResponse.employee_id == emp.id).update({schemas.SurveyResponse.employee_id: None})
        
        # 7. Delete exit clearances/interviews if any exist for old offboarding process
        off_procs = db.query(schemas.OffboardingProcess).filter(schemas.OffboardingProcess.employee_id == emp.id).all()
        off_proc_ids = [op.id for op in off_procs]
        if off_proc_ids:
            db.query(schemas.ExitInterview).filter(schemas.ExitInterview.offboarding_process_id.in_(off_proc_ids)).delete(synchronize_session=False)
            db.query(schemas.OffboardingProcess).filter(schemas.OffboardingProcess.id.in_(off_proc_ids)).delete(synchronize_session=False)
            
        # 8. Nullify pulse_survey_responses
        db.query(schemas.PulseSurveyResponse).filter(schemas.PulseSurveyResponse.employee_id == emp.id).update({schemas.PulseSurveyResponse.employee_id: None})
        
        # 9. Finally delete the employee
        db.delete(emp)
        db.commit()
    except Exception as e:
        db.rollback()
        logger.error(f"Failed to delete employee: {e}")
        raise HTTPException(status_code=500, detail=f"Database integrity error during offboarding: {e}")

    db.refresh(resignation)

    crud.log_audit(db, current_user.id, "EMPLOYEE_RESIGNED",
                   f"Employee {resignation.employee_code} ({resignation.name}) has resigned.")

    return {
        "message": "Resignation accepted. You have been successfully offboarded.",
        "resignation_id": resignation.id,
        "name": resignation.name,
        "employee_code": resignation.employee_code,
    }


@router.get("/hr/resignations", tags=["Exit Management"])
def list_resignations(
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(require_manager),
):
    """
    HR endpoint: Returns all resigned employees whose exit interview audio
    has NOT yet been uploaded (audio_uploaded=False).
    Once analysis is done, the profile no longer appears here.
    """
    resignations = (
        db.query(schemas.Resignation)
        .filter(schemas.Resignation.analysis_done == False)
        .order_by(schemas.Resignation.resigned_at.desc())
        .all()
    )
    return [
        {
            "id": r.id,
            "employee_code": r.employee_code,
            "name": r.name,
            "email": r.email,
            "department": r.department or "—",
            "designation": r.designation or "—",
            "resigned_at": r.resigned_at.isoformat() if r.resigned_at else None,
            "audio_uploaded": r.audio_uploaded,
            "analysis_done": r.analysis_done,
        }
        for r in resignations
    ]


@router.get("/hr/resignations/completed", tags=["Exit Management"])
def list_completed_resignations(
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(require_manager),
):
    """
    HR endpoint: Returns all resigned employees whose exit interview analysis
    is completed (analysis_done=True).
    """
    resignations = (
        db.query(schemas.Resignation)
        .filter(schemas.Resignation.analysis_done == True)
        .order_by(schemas.Resignation.resigned_at.desc())
        .all()
    )
    return [
        {
            "id": r.id,
            "employee_code": r.employee_code,
            "name": r.name,
            "email": r.email,
            "department": r.department or "—",
            "designation": r.designation or "—",
            "resigned_at": r.resigned_at.isoformat() if r.resigned_at else None,
            "audio_uploaded": r.audio_uploaded,
            "analysis_done": r.analysis_done,
            "sentiment_score": r.sentiment_score,
            "hr_report": r.hr_report,
            "transcript": r.transcript,
            "s3_report_path": r.s3_report_path,
        }
        for r in resignations
    ]


@router.get("/hr/resignations/{resignation_id}", tags=["Exit Management"])
def get_resignation(
    resignation_id: int,
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(require_manager),
):
    """HR endpoint: Get full details of a resignation record including analysis results."""
    r = db.query(schemas.Resignation).filter(schemas.Resignation.id == resignation_id).first()
    if not r:
        raise HTTPException(status_code=404, detail="Resignation record not found.")
    return {
        "id": r.id,
        "employee_code": r.employee_code,
        "name": r.name,
        "email": r.email,
        "department": r.department or "—",
        "designation": r.designation or "—",
        "resigned_at": r.resigned_at.isoformat() if r.resigned_at else None,
        "audio_uploaded": r.audio_uploaded,
        "analysis_done": r.analysis_done,
        "transcript": r.transcript,
        "sentiment_score": r.sentiment_score,
        "hr_report": r.hr_report,
        "s3_report_path": r.s3_report_path,
    }


@router.post("/hr/resignations/{resignation_id}/upload-interview", tags=["Exit Management"])
async def upload_exit_interview(
    resignation_id: int,
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: schemas.User = Depends(require_manager),
):
    """
    HR endpoint: Upload exit interview audio for a resigned employee.
    Pipeline: Whisper transcription → Bedrock guardrail → Bedrock HR report → S3 upload.
    Marks analysis_done=True on success.
    """
    from services.exit_interview_service import analyze_exit_interview

    r = db.query(schemas.Resignation).filter(schemas.Resignation.id == resignation_id).first()
    if not r:
        raise HTTPException(status_code=404, detail="Resignation record not found.")
    if r.analysis_done:
        raise HTTPException(status_code=400, detail="Analysis already completed for this employee.")

    # Validate file type
    allowed_types = {"audio/mpeg", "audio/wav", "audio/mp4", "audio/ogg", "audio/x-m4a", "audio/m4a"}
    allowed_exts = {".mp3", ".wav", ".m4a", ".ogg", ".webm"}
    file_ext = os.path.splitext(file.filename)[1].lower()
    if file_ext not in allowed_exts:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid file type '{file_ext}'. Allowed: mp3, wav, m4a, ogg, webm"
        )

    # Read audio bytes
    audio_bytes = await file.read()
    if len(audio_bytes) == 0:
        raise HTTPException(status_code=400, detail="Uploaded file is empty.")

    # Mark audio as uploaded
    r.audio_uploaded = True
    db.commit()

    # Run the full analysis pipeline
    result = analyze_exit_interview(
        audio_bytes=audio_bytes,
        filename=file.filename,
        employee_name=r.name,
        employee_code=r.employee_code,
        department=r.department or "",
    )

    if not result["success"]:
        # Reset audio_uploaded on failure so HR can retry
        r.audio_uploaded = False
        db.commit()
        raise HTTPException(status_code=422, detail=result["error"])

    # Persist analysis results
    r.transcript = result["transcript"]
    r.sentiment_score = result["sentiment_score"]
    r.hr_report = result["hr_report"]
    r.s3_report_path = result.get("s3_report_path")
    r.analysis_done = True
    db.commit()
    db.refresh(r)

    crud.log_audit(db, current_user.id, "EXIT_INTERVIEW_ANALYZED",
                   f"HR analyzed exit interview for {r.name} ({r.employee_code}). S3: {r.s3_report_path}")

    return {
        "success": True,
        "message": f"Exit interview for {r.name} analyzed successfully.",
        "transcript": r.transcript,
        "sentiment": result["sentiment"],
        "sentiment_score": r.sentiment_score,
        "hr_report": r.hr_report,
        "s3_report_path": r.s3_report_path,
    }
