"""
HR Policy Generator & Chatbot API Router.
All endpoints are mounted under /api/hr (see main.py).

This router is ISOLATED from the existing recruitment/onboarding/training routers.
It only reads/writes to hr_policies, hr_policy_versions, hr_chat_messages,
hr_tickets, and hr_audit_trail tables.
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from config.database import get_db
from middleware.auth import get_current_user
from models.schemas import User
from models.hr_chatbot_schemas import (
    HRChatAskRequest,
    HRPolicyGenerateRequest,
    HRPolicySaveRequest,
    HRTicketUpdateRequest,
)
from services.hr_permissions import get_role, require_permission
from services.hr_policy_service import (
    delete_hr_policy,
    get_hr_policy,
    list_hr_policies,
    publish_hr_policy,
    save_hr_policy,
)
from services.hr_ticket_service import (
    create_hr_ticket,
    get_hr_ticket,
    get_tickets_by_employee,
    list_hr_tickets,
    update_hr_ticket,
)
from agents.hr_chatbot_orchestrator import HRChatbotOrchestrator
from agents.hr_policy_orchestrator import HRPolicyOrchestrator

router = APIRouter(prefix="/hr", tags=["HR Policy & Chatbot"])

_chatbot_orch = HRChatbotOrchestrator()
_policy_orch  = HRPolicyOrchestrator()


# ─────────────────────────────────────────────────────────────────────────────
# HR Policy — CRUD
# ─────────────────────────────────────────────────────────────────────────────

@router.get("/policies")
def api_list_policies(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """List policies. HR_ADMIN sees all; employees see only published."""
    role = get_role(current_user.is_manager)
    policies = list_hr_policies(db)
    if role != "HR_ADMIN":
        policies = [p for p in policies if p.status == "published"]
    return [
        {
            "id": str(p.id),
            "title": p.title,
            "policy_type": p.policy_type,
            "status": p.status,
            "review_date": p.review_date,
            "created_by": p.created_by,
            "created_at": p.created_at.isoformat() if p.created_at else None,
            "versions": [
                {
                    "id": str(v.id),
                    "version_number": v.version_number,
                    "status": v.status,
                    "compliance_score": v.compliance_score,
                    "created_at": v.created_at.isoformat() if v.created_at else None,
                }
                for v in p.versions
            ],
        }
        for p in policies
    ]


@router.get("/policies/{policy_id}")
def api_get_policy(
    policy_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Get full policy detail including all versions."""
    policy = get_hr_policy(db, policy_id)
    if not policy:
        raise HTTPException(status_code=404, detail="Policy not found")
    return {
        "id": str(policy.id),
        "title": policy.title,
        "policy_type": policy.policy_type,
        "status": policy.status,
        "review_date": policy.review_date,
        "created_by": policy.created_by,
        "versions": [
            {
                "id": str(v.id),
                "version_number": v.version_number,
                "content": v.content,
                "status": v.status,
                "compliance_score": v.compliance_score,
                "risks": v.risks,
                "change_summary": v.change_summary,
                "effective_date": v.effective_date,
                "created_at": v.created_at.isoformat() if v.created_at else None,
            }
            for v in policy.versions
        ],
    }


@router.post("/policies/save")
def api_save_policy(
    req: HRPolicySaveRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Save / update a policy draft (HR_ADMIN only)."""
    role = get_role(current_user.is_manager)
    try:
        require_permission(role, "save_policy")
        policy = save_hr_policy(db, req, created_by=current_user.email)
        return {
            "message": "Policy saved successfully",
            "policy_id": str(policy.id),
            "status": policy.status,
        }
    except PermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc))


@router.post("/policies/{policy_id}/publish")
def api_publish_policy(
    policy_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Publish a policy (HR_ADMIN only)."""
    role = get_role(current_user.is_manager)
    try:
        require_permission(role, "publish_policy")
        policy = publish_hr_policy(db, policy_id)
        return {
            "message": "Policy published successfully",
            "policy_id": str(policy.id),
            "status": policy.status,
        }
    except PermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))


@router.delete("/policies/{policy_id}")
def api_delete_policy(
    policy_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Permanently delete a policy (HR_ADMIN only)."""
    role = get_role(current_user.is_manager)
    try:
        require_permission(role, "delete_policy")
        delete_hr_policy(db, policy_id)
        return {"message": "Policy deleted successfully"}
    except PermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))


# ─────────────────────────────────────────────────────────────────────────────
# Agentic Workflow — Policy Generation
# ─────────────────────────────────────────────────────────────────────────────

@router.post("/agentic/policies/generate")
def agentic_generate_policy(
    req: HRPolicyGenerateRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Run the full multi-agent policy generation pipeline (HR_ADMIN only).
    Policies are saved and published immediately — no separate review step required.
    """
    role = get_role(current_user.is_manager)
    try:
        require_permission(role, "generate_policy")
    except PermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc))

    try:
        result = _policy_orch.generate_review_save(
            db=db,
            policy_type=req.policy_type,
            title=req.title,
            requirements=req.requirements,
            department=req.department,
            location=req.location,
            effective_date=req.effective_date,
            save_status="published",   # ← publish directly, no review queue needed
            created_by=current_user.email,
        )
        return result
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))



# ─────────────────────────────────────────────────────────────────────────────
# Tickets — HR Management
# ─────────────────────────────────────────────────────────────────────────────

@router.get("/tickets")
def api_list_tickets(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """List all HR support tickets (HR_ADMIN only)."""
    role = get_role(current_user.is_manager)
    try:
        require_permission(role, "view_tickets")
    except PermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc))

    tickets = list_hr_tickets(db)
    return [_ticket_to_dict(t) for t in tickets]


@router.get("/tickets/my")
def api_my_tickets(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Get the current employee's own tickets."""
    tickets = get_tickets_by_employee(db, current_user.email)
    return [_ticket_to_dict(t) for t in tickets]


@router.patch("/tickets/{ticket_id}")
def api_update_ticket(
    ticket_id: str,
    req: HRTicketUpdateRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Update ticket status / resolution (HR_ADMIN only)."""
    role = get_role(current_user.is_manager)
    try:
        require_permission(role, "update_ticket")
    except PermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc))

    try:
        ticket = update_hr_ticket(
            db,
            ticket_id=ticket_id,
            status=req.status,
            resolution_response=req.resolution_response,
            resolved_by=current_user.email,
            assigned_to=req.assigned_to,
        )
        return {
            "message": "Ticket updated successfully",
            "ticket_id": str(ticket.id),
            "status": ticket.status,
        }
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))


# ─────────────────────────────────────────────────────────────────────────────
# Chatbot — Employee Q&A
# ─────────────────────────────────────────────────────────────────────────────

@router.post("/chatbot/ask")
def api_chatbot_ask(
    req: HRChatAskRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Ask the HR chatbot a question. Available to all authenticated users."""
    try:
        result = _chatbot_orch.ask(
            db=db,
            question=req.question,
            employee_id=str(current_user.id),
            employee_email=current_user.email,
        )
        return result
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


# ─────────────────────────────────────────────────────────────────────────────
# Helper
# ─────────────────────────────────────────────────────────────────────────────

def _ticket_to_dict(t) -> dict:
    return {
        "id": str(t.id),
        "employee_id": t.employee_id,
        "employee_email": t.employee_email,
        "question": t.question,
        "category": t.category,
        "priority": t.priority,
        "status": t.status,
        "ai_summary": t.ai_summary,
        "suggested_response": t.suggested_response,
        "resolution_response": t.resolution_response,
        "assigned_to": t.assigned_to,
        "resolved_by": t.resolved_by,
        "resolved_at": t.resolved_at.isoformat() if t.resolved_at else None,
        "created_at": t.created_at.isoformat() if t.created_at else None,
        "updated_at": t.updated_at.isoformat() if t.updated_at else None,
    }
