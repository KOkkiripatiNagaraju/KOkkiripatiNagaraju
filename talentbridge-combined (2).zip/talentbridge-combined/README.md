# TalentBridge — Combined Package (Backend + New Next.js Frontend)

This zip contains both halves of the app side by side:

```
talentbridge-backend/   ← your existing FastAPI backend, copied as-is
talentbridge-web/       ← the new Next.js recruiter + careers frontend
```

They are **not merged into one process** — they run as two separate
services (same as your current Cloud Run setup: a backend service plus
one or more frontend services), with the frontend proxying API calls to
the backend. That separation is intentional and matches how this is
already deployed.

## What was deliberately left out of `talentbridge-backend/`

Per your original migration brief ("do not rewrite backend logic,"
"preserve all APIs") I copied the backend byte-for-byte, **except** for
the following, which I removed before packaging:

| Removed | Why |
|---|---|
| `gcp-key.json/` (service account key) | Live GCP credential — should never be distributed in a zip |
| `.env` | Contained live secrets (DB URL, JWT secret, Gmail OAuth tokens, etc.) |
| `storage/` | Real candidate resumes, BGV documents, offer letters — actual PII |
| `data_backup/`, `scratch/` | Local generated/working files, not source |
| `09_angry_loud_voice_unfair_treatment.mp3` | Looks like a real exit-interview audio recording |
| `streamlit.log`, `uvicorn.log`, `*.err.log` | Runtime logs, may contain request data |

In place of `.env`, there's a `.env.example` listing the variable *names*
the backend expects (`DATABASE_URL`, `JWT_SECRET`, `GCS_BUCKET_NAME`,
etc.) with no values — copy it to `.env` and fill in your real ones.

**I verified the backend still imports and boots correctly without these
files** — `main.py` loads, the FastAPI app object constructs, and all 100
routes register. So nothing was broken by removing them; they just need
to be supplied locally (or already exist in your Cloud Run service's
Secret Manager / env config, if you're deploying rather than running
locally).

## Running both locally

**Terminal 1 — backend:**
```bash
cd talentbridge-backend
cp .env.example .env
# edit .env with your real DATABASE_URL, JWT_SECRET, GCS_BUCKET_NAME, etc.
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

**Terminal 2 — frontend:**
```bash
cd talentbridge-web
npm install
export BACKEND_BASE_URL=http://localhost:8000   # Windows: set/`$env:` equivalent
npm run dev
```

Open `http://localhost:3000`.

## Deploying both to Cloud Run

Your backend presumably already has its own deploy path (it's the same
`hr-backend` service referenced throughout this migration) — this package
doesn't change that. For the frontend, `talentbridge-web/deploy.sh` still
applies as before: it deploys a new `hr-recruiter-ui-v2` service in
`asia-south1` under `hr-portal-500307`, pointed at your existing backend's
URL via `BACKEND_BASE_URL`.

If you also want a from-scratch backend deploy command, it would look
like:
```bash
cd talentbridge-backend
gcloud run deploy hr-backend --source . --region asia-south1 \
  --set-env-vars "DATABASE_URL=...,JWT_SECRET=...,..." \
  # (or, better: --set-secrets to pull from Secret Manager rather than
  # passing secrets as plain env vars on the command line)
```
I haven't run this myself — no GCP credentials or network path from this
environment — so treat it as a starting point, not a verified command.

## Frontend module status

See `talentbridge-web/README.md` for the detailed breakdown of what's
built (Dashboard, Jobs, Candidate Evaluation, Candidate Profile,
Interviews, Offers, Pipeline, Analytics, Email Center, Notifications,
Careers Portal, public interview flow with completion screen) versus
what's intentionally not built yet (HR Operations, candidate notes,
communication history, candidate-source analytics, full audio/video
interview recording UI).
