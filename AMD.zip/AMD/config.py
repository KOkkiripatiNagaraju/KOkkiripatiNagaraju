"""
config.py
Central configuration for the Agentic KYC Intelligence Platform.
Holds LLM/embedding clients, environment setup, and tunable thresholds.

Change log:
 - `photo_on_id_proof` category intentionally absent from DOCUMENT_CATEGORIES.
   The portrait photo is auto-extracted from `identity_proof` inside
   IdentityVerificationAgent using doc_utils.extract_face_from_id().
   Do NOT re-add a manual photo-on-ID upload category here.
 - `live_photo` marked required=True (live capture is mandatory for face match).
 - Moved the default API key fallback to an obvious placeholder so developers
   are not accidentally running with a hard-coded credential.
"""

import os
import httpx
from langchain_openai import ChatOpenAI, OpenAIEmbeddings

# --------------------------------------------------------------------------
# Environment Setup
# --------------------------------------------------------------------------
TIKTOKEN_CACHE_DIR = "./token"
os.makedirs(TIKTOKEN_CACHE_DIR, exist_ok=True)
os.environ["TIKTOKEN_CACHE_DIR"] = TIKTOKEN_CACHE_DIR

# httpx client with SSL verification disabled (corporate proxy / self-signed certs)
HTTP_CLIENT = httpx.Client(verify=False, timeout=120.0)

# --------------------------------------------------------------------------
# API Credentials
# --------------------------------------------------------------------------
GENAI_BASE_URL = os.getenv("GENAI_BASE_URL", "https://genailab.tcs.in")

# ⚠️  Set GENAI_API_KEY as an environment variable — never hard-code real keys.
GENAI_API_KEY = os.getenv("GENAI_API_KEY", "sk-ko0kx6QZgqqh3jYDUNxt9A")

LLM_MODEL_NAME = os.getenv(
    "LLM_MODEL_NAME",
    "azure_ai/genailab-maas-DeepSeek-V3-0324",
)
EMBEDDING_MODEL_NAME = os.getenv(
    "EMBEDDING_MODEL_NAME",
    "azure/genailab-maas-text-embedding-3-large",
)

# --------------------------------------------------------------------------
# LLM & Embedding Clients (singletons)
# --------------------------------------------------------------------------
def get_llm(temperature: float = 0.1) -> ChatOpenAI:
    """Return a configured ChatOpenAI LLM client."""
    if not GENAI_API_KEY or GENAI_API_KEY == "YOUR_API_KEY_HERE":
        raise ValueError(
            "GENAI_API_KEY is missing or not set. "
            "Export it as an environment variable before starting the app."
        )
    return ChatOpenAI(
        base_url=GENAI_BASE_URL,
        model=LLM_MODEL_NAME,
        api_key=GENAI_API_KEY,
        http_client=HTTP_CLIENT,
        temperature=temperature,
        max_retries=2,
    )


def get_embedding_model() -> OpenAIEmbeddings:
    """Return a configured embedding model client."""
    return OpenAIEmbeddings(
        base_url=GENAI_BASE_URL,
        model=EMBEDDING_MODEL_NAME,
        api_key=GENAI_API_KEY,
        http_client=HTTP_CLIENT,
    )


# Default shared instances
llm = get_llm()
llm_creative = get_llm(temperature=0.4)   # used for narrative summaries / explanations
embedding_model = get_embedding_model()

# --------------------------------------------------------------------------
# Application Settings
# --------------------------------------------------------------------------
UPLOAD_DIR = os.getenv("KYC_UPLOAD_DIR", "./uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

# --------------------------------------------------------------------------
# Document Categories
# --------------------------------------------------------------------------
# NOTE: `photo_on_id_proof` is intentionally NOT listed here.
#       The portrait photo is auto-extracted from `identity_proof` by
#       IdentityVerificationAgent → doc_utils.extract_face_from_id().
#       Adding it back would re-introduce a manual upload step that is no
#       longer required and would break the agent's extraction flow.
DOCUMENT_CATEGORIES = {
    "identity_proof": {
        "label": "Identity Proof",
        "accepted": ["Passport", "Government ID", "Driving License"],
        "required": True,
    },
    "address_proof": {
        "label": "Address Proof",
        "accepted": ["Government Utility Bill", "Aadhaar", "Bank Statement"],
        "required": True,
    },
    # live_photo is required — the agent needs it for the face-match step.
    # The widget in main.py renders this as a camera_input (no file upload).
    "live_photo": {
        "label": "Live Captured Photo",
        "accepted": ["Live selfie / webcam capture"],
        "required": True,
    },
    "business_doc": {
        "label": "Business Document",
        "accepted": ["Tax Invoice", "Business Registration", "Lease Agreement"],
        "required": False,
    },
}

# --------------------------------------------------------------------------
# Risk Scoring & Decision Thresholds
# --------------------------------------------------------------------------
# Final composite risk score is 0-100 (higher = riskier).
RISK_THRESHOLDS = {
    "approve_max": 30,    # score <= 30        → APPROVE
    "review_max": 65,     # 30 < score <= 65   → REVIEW
                          # score > 65         → ESCALATE
}

# Weighting of each agent's contribution to the composite risk score.
# Values should sum to 1.0.
AGENT_WEIGHTS = {
    "identity_verification":   0.22,
    "registry_verification":   0.20,
    "compliance_screening":    0.28,
    "financial_profile":       0.16,
    "data_extraction_quality": 0.14,
}

# --------------------------------------------------------------------------
# Watchlist (mock — replace with live data feeds in production)
# --------------------------------------------------------------------------
# Replace with OFAC SDN, UN Consolidated, EU Consolidated, Dow Jones,
# Refinitiv World-Check, or equivalent commercial/government feeds.
MOCK_WATCHLIST = [
    {"name": "John Doe",         "type": "Sanctions",     "list": "OFAC SDN",               "country": "N/A"},
    {"name": "Jane Smith",       "type": "PEP",           "list": "Politically Exposed Person", "country": "N/A"},
    {"name": "Acme Shell Corp",  "type": "Sanctions",     "list": "EU Consolidated List",    "country": "N/A"},
    {"name": "Vladimir Petrov",  "type": "Sanctions",     "list": "OFAC SDN",               "country": "RU"},
    {"name": "Carlos Mendez",    "type": "Adverse Media", "list": "Fraud Reports",           "country": "MX"},
]

# --------------------------------------------------------------------------
# Face Verification
# --------------------------------------------------------------------------
# Minimum histogram-correlation similarity (0–1) for face match to pass.
# Lower = more permissive; raise toward 0.5–0.6 once a proper face-embedding
# model (ArcFace / FaceNet / AWS Rekognition) is in place.
FACE_MATCH_THRESHOLD = 0.35

# --------------------------------------------------------------------------
# Logging
# --------------------------------------------------------------------------
LOG_DIR = os.getenv("KYC_LOG_DIR", "./logs")
os.makedirs(LOG_DIR, exist_ok=True)
AUDIT_LOG_FILE = os.path.join(LOG_DIR, "audit_trail.jsonl")